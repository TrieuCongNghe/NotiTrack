package com.example

import com.example.data.model.AppRuleEntity
import com.example.data.model.KeywordAction
import com.example.data.model.KeywordRuleEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.TtsFeedbackRuleEntity
import com.example.data.model.TtsFilterMode
import com.example.data.model.TtsNumberReadMode
import com.example.data.prefs.NotiTrackSettings
import com.example.engine.BackupRestoreEngine
import com.example.engine.BackupSelection
import com.example.engine.ConversationGrouper
import com.example.engine.DeviceGuardConfig
import com.example.engine.DeviceGuardEngine
import com.example.engine.DeviceGuardEvent
import com.example.engine.GuardTelemetrySnapshot
import com.example.engine.KeywordFilterEngine
import com.example.engine.MotionSensitivity
import com.example.engine.SmartTtsFormatter
import com.example.engine.SmartTtsTemplateEngine
import com.example.engine.TtsFeedbackEngine
import com.example.engine.VietnameseLunarCalendar
import com.example.ui.i18n.AppLanguage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `keyword filter highlights OTP and mutes TTS`() {
        val rules = listOf(
            KeywordRuleEntity(
                id = 1L,
                keywords = "OTP, chuyển khoản",
                action = KeywordAction.HIGHLIGHT
            ),
            KeywordRuleEntity(
                id = 2L,
                keywords = "OTP, mật khẩu",
                action = KeywordAction.MUTE_TTS
            )
        )

        val result = KeywordFilterEngine.evaluate(
            packageName = "com.bank.app",
            title = "Thông báo giao dịch",
            content = "Mã OTP xác thực của bạn là 482916",
            subText = "",
            rules = rules
        )

        assertFalse(result.shouldBlock)
        assertTrue(result.shouldHighlight)
        assertTrue(result.shouldMuteTts)
        assertEquals(listOf(1L, 2L), result.matchedRuleIds)
    }

    @Test
    fun `keyword filter blocks spam and respects app scope`() {
        val rules = listOf(
            KeywordRuleEntity(
                id = 10L,
                keywords = "flash sale, voucher",
                action = KeywordAction.BLOCK,
                targetPackage = "com.shop.app"
            )
        )

        val blocked = KeywordFilterEngine.evaluate(
            packageName = "com.shop.app",
            title = "Flash Sale 50%",
            content = "Săn deal ngay",
            subText = "",
            rules = rules
        )
        assertTrue(blocked.shouldBlock)

        val otherApp = KeywordFilterEngine.evaluate(
            packageName = "com.chat.app",
            title = "Flash Sale 50%",
            content = "Bạn gửi link",
            subText = "",
            rules = rules
        )
        assertFalse(otherApp.shouldBlock)
    }

    @Test
    fun `otp extractor detects code only with otp context`() {
        assertEquals(
            "482916",
            KeywordFilterEngine.extractOtpCode(
                "Ngân hàng",
                "Mã xác thực OTP của bạn là 482916 để hoàn tất giao dịch"
            )
        )
        assertNull(
            KeywordFilterEngine.extractOtpCode(
                "Lịch họp",
                "Phòng họp 2045 lúc 14h chiều nay"
            )
        )
    }

    @Test
    fun `smart tts formats bank transaction concisely and hides balance when enabled`() {
        val spokenHidden = SmartTtsFormatter.formatForSpeech(
            appName = "MB Bank",
            title = "Biến động số dư",
            content = "TK 003456xxxx GD: +50,000 VND luc 14:25 19/11/2026. SD: 15,420,000 VND. ND: Chuyen tien cafe FT263239182736",
            includeAppName = true,
            smartFilterEnabled = true,
            hideBalance = true,
            language = AppLanguage.VIETNAMESE
        )

        assertTrue("Got: $spokenHidden", spokenHidden.contains("Đã nhận 50.000 đồng"))
        assertFalse("Got: $spokenHidden", spokenHidden.contains("FT263239182736"))
        assertFalse("Got: $spokenHidden", spokenHidden.contains("15.420.000"))
        assertFalse("Got: $spokenHidden", spokenHidden.contains("15,420,000"))

        val spokenWithBalance = SmartTtsFormatter.formatForSpeech(
            appName = "MB Bank",
            title = "Biến động số dư",
            content = "TK 003456xxxx GD: +50,000 VND luc 14:25 19/11/2026. SD: 15,420,000 VND. ND: Chuyen tien cafe FT263239182736",
            includeAppName = true,
            smartFilterEnabled = true,
            hideBalance = false,
            language = AppLanguage.VIETNAMESE
        )

        assertTrue("Got: $spokenWithBalance", spokenWithBalance.contains("Đã nhận 50.000 đồng"))
        assertTrue("Got: $spokenWithBalance", spokenWithBalance.contains("Số dư 15.420.000 đồng"))
        assertFalse("Got: $spokenWithBalance", spokenWithBalance.contains("FT263239182736"))
    }

    @Test
    fun `vietnamese lunar calendar converts known Tet dates accurately`() {
        val tet2025 = VietnameseLunarCalendar.solarToLunar(29, 1, 2025)
        assertEquals(1, tet2025.day)
        assertEquals(1, tet2025.month)
        assertEquals(2025, tet2025.year)

        val tet2026 = VietnameseLunarCalendar.solarToLunar(17, 2, 2026)
        assertEquals(1, tet2026.day)
        assertEquals(1, tet2026.month)
        assertEquals(2026, tet2026.year)
    }

    @Test
    fun `conversation grouper merges messages from same sender and strips count suffix`() {
        val m1 = NotificationEntity(
            id = 1L,
            packageName = "com.zing.zalo",
            appName = "Zalo",
            title = "Nhóm Gia Đình (2 tin nhắn)",
            content = "Tối nay ăn gì?",
            timestamp = 1000L
        )
        val m2 = NotificationEntity(
            id = 2L,
            packageName = "com.zing.zalo",
            appName = "Zalo",
            title = "Nhóm Gia Đình",
            content = "Ăn lẩu nhé!",
            timestamp = 2000L
        )

        val threads = ConversationGrouper.buildThreads(listOf(m1, m2))
        assertEquals(1, threads.size)
        assertEquals("Nhóm Gia Đình", threads.first().threadTitle)
        assertEquals(2, threads.first().totalCount)
        assertEquals("Ăn lẩu nhé!", threads.first().latestContent)
    }

    @Test
    fun `smart tts strictly strips account numbers and transfer memos`() {
        val spoken = SmartTtsFormatter.formatForSpeech(
            appName = "MB Bank",
            title = "Biến động số dư",
            content = "TK 003456 GD: +50,000 VND luc 14:25 19/11/2026. SD: 15,420,000 VND. ND: NGUYEN VAN A chuyen tien cafe",
            includeAppName = true,
            smartFilterEnabled = true,
            hideBalance = true,
            language = AppLanguage.VIETNAMESE
        )

        assertEquals("MB Bank: Đã nhận 50.000 đồng.", spoken)
        assertFalse("Should strip account number: $spoken", spoken.contains("003456"))
        assertFalse("Should strip memo: $spoken", spoken.contains("NGUYEN VAN A"))
        assertFalse("Should strip memo: $spoken", spoken.contains("cafe"))
    }

    @Test
    fun `number reading mode spells 9999 digit by digit in context auto and exact digits`() {
        val spoken = SmartTtsFormatter.formatForSpeech(
            appName = "Bank",
            title = "Thông báo",
            content = "Số đuôi 9999 đã xác nhận, thanh toán 50000 VND",
            includeAppName = false,
            smartFilterEnabled = false,
            hideBalance = false,
            language = AppLanguage.VIETNAMESE,
            numberReadMode = TtsNumberReadMode.CONTEXT_AUTO
        )

        assertTrue("Expected digit-by-digit for 9999, got: $spoken", spoken.contains("chín chín chín chín"))
        assertTrue("Expected currency amount preserved, got: $spoken", spoken.contains("50000 VND"))

        val exactMode = SmartTtsFormatter.applyNumberReadMode(
            text = "STK 003456 mã 9999",
            mode = TtsNumberReadMode.EXACT_DIGITS,
            language = AppLanguage.VIETNAMESE
        )
        assertTrue("Got: $exactMode", exactMode.contains("không không ba bốn năm sáu"))
        assertTrue("Got: $exactMode", exactMode.contains("chín chín chín chín"))
    }

    @Test
    fun `numeric only tts filter accepts balance alerts and rejects promo ads`() {
        assertTrue(
            SmartTtsFormatter.shouldSpeakForRule(
                title = "MB Bank",
                content = "TK 003456 GD: +250,000 VND. SD: 10,000,000 VND",
                filterMode = TtsFilterMode.NUMERIC_ONLY
            )
        )
        assertFalse(
            SmartTtsFormatter.shouldSpeakForRule(
                title = "Siêu ưu đãi hôm nay",
                content = "Flash sale giảm giá 50% voucher quà tặng cho bạn!",
                filterMode = TtsFilterMode.NUMERIC_ONLY
            )
        )
    }

    @Test
    fun `custom highlight template dynamically extracts highlighted region from new notifications`() {
        val sample = "TK 003456 GD: +50,000 VND luc 14:25 SD: 1,500,000 VND"
        // Tokens: 0=TK, 1=003456, 2=GD:, 3=+50,000, 4=VND, 5=luc, 6=14:25, 7=SD:, 8=1,500,000, 9=VND
        val template = SmartTtsTemplateEngine.buildSerializedTemplate(sample, setOf(3, 4))
        assertTrue(template.startsWith("v1||"))

        val incoming = "TK 998877 GD: +250,000 VND luc 18:10 SD: 9,000,000 VND"
        val extracted = SmartTtsTemplateEngine.applyTemplate(template, incoming)
        assertEquals("+250,000 VND", extracted)
    }

    @Test
    fun `app inbox grouper merges multiple threads of same app into one unique app entry`() {
        val notifications = listOf(
            NotificationEntity(
                id = 1L,
                packageName = "com.zing.zalo",
                appName = "Zalo",
                title = "Nhóm Gia Đình",
                content = "Ăn cơm chưa?",
                timestamp = 1000L
            ),
            NotificationEntity(
                id = 2L,
                packageName = "com.zing.zalo",
                appName = "Zalo",
                title = "Nguyễn Văn A",
                content = "Alo bạn ơi",
                timestamp = 3000L
            ),
            NotificationEntity(
                id = 3L,
                packageName = "com.mbmobile",
                appName = "MB Bank",
                title = "Biến động số dư",
                content = "+50,000 VND",
                timestamp = 2000L
            )
        )

        val appGroups = ConversationGrouper.buildAppGroups(notifications)
        assertEquals(2, appGroups.size)
        assertEquals("com.zing.zalo", appGroups[0].packageName)
        assertEquals(2, appGroups[0].threads.size)
        assertEquals(2, appGroups[0].totalCount)
        assertEquals("com.mbmobile", appGroups[1].packageName)
        assertEquals(1, appGroups[1].threads.size)
    }

    @Test
    fun `smart tts handles real pipe-delimited MB Bank notification accurately`() {
        val title = "Thông báo biến động số dư"
        val content = "TK 00xxx456|GD: +50,000VND 19/11/26 18:28 |SD: 550,090VND|TU: DANG VIET TRIEU - 9997777999|ND: DANG VIET TRIEU chuyen FT26323526514098 k2L5F4B4/924105"

        val hiddenBalance = SmartTtsFormatter.formatForSpeech(
            appName = "MB Bank",
            title = title,
            content = content,
            includeAppName = true,
            smartFilterEnabled = true,
            hideBalance = true,
            language = AppLanguage.VIETNAMESE
        )
        assertEquals("MB Bank: Đã nhận 50.000 đồng.", hiddenBalance)

        val withBalance = SmartTtsFormatter.formatForSpeech(
            appName = "MB Bank",
            title = title,
            content = content,
            includeAppName = true,
            smartFilterEnabled = true,
            hideBalance = false,
            language = AppLanguage.VIETNAMESE
        )
        assertEquals("MB Bank: Đã nhận 50.000 đồng. Số dư 550.090 đồng.", withBalance)

        // Pipe tokenization separates TK/GD/SD cleanly for custom highlight templates
        val tokens = SmartTtsTemplateEngine.tokenize(content)
        assertTrue("Expected GD: as standalone token, got: $tokens", tokens.contains("GD:"))
        assertTrue("Expected +50,000VND as standalone token, got: $tokens", tokens.contains("+50,000VND"))
        assertTrue(SmartTtsFormatter.shouldSpeakForRule(title, content, TtsFilterMode.NUMERIC_ONLY))
    }

    @Test
    fun `smart tts handles real currency-before-amount bank notification accurately`() {
        val title = "+ VND 550,000"
        val content = "Tài khoản: 9997777999\nSố dư: VND 8,000,649\nDANG VIET TRIEU chuyen tien"

        val hiddenBalance = SmartTtsFormatter.formatForSpeech(
            appName = "Techcombank",
            title = title,
            content = content,
            includeAppName = true,
            smartFilterEnabled = true,
            hideBalance = true,
            language = AppLanguage.VIETNAMESE
        )
        assertEquals("Techcombank: Đã nhận 550.000 đồng.", hiddenBalance)

        val withBalance = SmartTtsFormatter.formatForSpeech(
            appName = "Techcombank",
            title = title,
            content = content,
            includeAppName = true,
            smartFilterEnabled = true,
            hideBalance = false,
            language = AppLanguage.VIETNAMESE
        )
        assertEquals("Techcombank: Đã nhận 550.000 đồng. Số dư 8.000.649 đồng.", withBalance)

        // Non-smart mode with hideBalance still strips "Số dư: VND 8,000,649" and spells 9997777999 digit-by-digit
        val rawHideBalance = SmartTtsFormatter.formatForSpeech(
            appName = "Techcombank",
            title = title,
            content = content,
            includeAppName = false,
            smartFilterEnabled = false,
            hideBalance = true,
            language = AppLanguage.VIETNAMESE,
            numberReadMode = TtsNumberReadMode.CONTEXT_AUTO
        )
        assertFalse("Balance should be stripped: $rawHideBalance", rawHideBalance.contains("8,000,649"))
        assertTrue("Account should be read digit by digit: $rawHideBalance", rawHideBalance.contains("chín chín chín bảy bảy bảy bảy chín chín chín"))
        assertTrue(SmartTtsFormatter.shouldSpeakForRule(title, content, TtsFilterMode.NUMERIC_ONLY))
    }

    @Test
    fun `strict numeric ratio anti-ad filter passes real bank alerts and blocks promotional ads`() {
        val mbRatio = SmartTtsTemplateEngine.calculateNumericRatioPercent(
            title = "Thông báo biến động số dư",
            content = "TK 00xxx456|GD: +50,000VND 19/11/26 18:28 |SD: 550,090VND|TU: DANG VIET TRIEU - 9997777999|ND: DANG VIET TRIEU chuyen FT26323526514098 k2L5F4B4/924105"
        )
        assertTrue("MB Bank alert should have >= 40% numeric density, got $mbRatio%", mbRatio >= 40)

        val tcbRatio = SmartTtsTemplateEngine.calculateNumericRatioPercent(
            title = "+ VND 550,000",
            content = "Tài khoản: 9997777999\nSố dư: VND 8,000,649\nDANG VIET TRIEU chuyen tien"
        )
        assertTrue("Techcombank alert should have >= 40% numeric density, got $tcbRatio%", tcbRatio >= 40)

        val promoCashbackRatio = SmartTtsTemplateEngine.calculateNumericRatioPercent(
            title = "Ưu đãi đặc biệt từ ngân hàng",
            content = "Hoàn 500,000 VND khi mở thẻ tín dụng mới và chi tiêu trong tháng này, đăng ký ngay hôm nay!"
        )
        assertTrue("Promo ad should be < 40% numeric density, got $promoCashbackRatio%", promoCashbackRatio < 40)
        assertFalse(
            SmartTtsTemplateEngine.passesNumericOnlyFilter(
                title = "Ưu đãi đặc biệt từ ngân hàng",
                content = "Hoàn 500,000 VND khi mở thẻ tín dụng mới và chi tiêu trong tháng này, đăng ký ngay hôm nay!",
                thresholdPercent = 40
            )
        )

        val flashSaleRatio = SmartTtsTemplateEngine.calculateNumericRatioPercent(
            title = "Siêu sale cuối tuần",
            content = "Giảm giá 50% toàn bộ giỏ hàng cùng hàng ngàn mã miễn phí vận chuyển hấp dẫn"
        )
        assertTrue("Flash sale ad should be < 40% numeric density, got $flashSaleRatio%", flashSaleRatio < 40)
        assertFalse(
            SmartTtsFormatter.shouldSpeakForRule(
                title = "Siêu sale cuối tuần",
                content = "Giảm giá 50% toàn bộ giỏ hàng cùng hàng ngàn mã miễn phí vận chuyển hấp dẫn",
                filterMode = TtsFilterMode.NUMERIC_ONLY,
                numericThresholdPercent = 40
            )
        )
    }

    @Test
    fun `tts feedback engine learns notification templates and matches future variations per package`() {
        val sampleTitle = "Ưu đãi thẻ tín dụng"
        val sampleContent = "Hoàn 500,000 VND khi chi tiêu từ 2,000,000 VND trước ngày 30/11/2026"
        val fp = TtsFeedbackEngine.buildFingerprint(sampleTitle, sampleContent)
        val titleSig = TtsFeedbackEngine.buildTitleSignature(sampleTitle)

        val rule = TtsFeedbackRuleEntity(
            id = 1L,
            packageName = "com.mbmobile",
            appName = "MB Bank",
            patternFingerprint = fp,
            titleSignature = titleSig,
            samplePreview = TtsFeedbackEngine.buildSamplePreview(sampleTitle, sampleContent),
            shouldSpeak = false
        )

        // Different amounts and date should still match the learned mute pattern
        val futureMatch = TtsFeedbackEngine.findBestMatch(
            packageName = "com.mbmobile",
            title = "Ưu đãi thẻ tín dụng",
            content = "Hoàn 1,000,000 VND khi chi tiêu từ 5,000,000 VND trước ngày 15/12/2026",
            rules = listOf(rule)
        )
        assertNotNull("Future promo variation should match learned rule", futureMatch)
        assertFalse(futureMatch!!.shouldSpeak)

        // Different package must NOT match
        val otherPkg = TtsFeedbackEngine.findBestMatch(
            packageName = "com.zing.zalo",
            title = "Ưu đãi thẻ tín dụng",
            content = "Hoàn 1,000,000 VND khi chi tiêu từ 5,000,000 VND trước ngày 15/12/2026",
            rules = listOf(rule)
        )
        assertNull("Rule must stay isolated to its package", otherPkg)

        // Real balance alert from the same bank must NOT match the promo mute rule
        val balanceAlert = TtsFeedbackEngine.findBestMatch(
            packageName = "com.mbmobile",
            title = "Thông báo biến động số dư",
            content = "TK 00xxx456|GD: +50,000VND 19/11/26 18:28 |SD: 550,090VND",
            rules = listOf(rule)
        )
        assertNull("Balance alert should not be confused with muted promo template", balanceAlert)
    }

    @Test
    fun `backup restore engine serializes selectively and round-trips payload cleanly`() {
        val notifications = listOf(
            NotificationEntity(
                id = 5L,
                packageName = "com.mbmobile",
                appName = "MB Bank",
                title = "Biến động số dư",
                content = "+50,000 VND",
                timestamp = 1732000000000L,
                isStarred = true,
                detectedOtp = "123456"
            )
        )
        val appRules = listOf(
            AppRuleEntity(
                packageName = "com.mbmobile",
                appName = "MB Bank",
                readAloudEnabled = true,
                ttsFilterMode = TtsFilterMode.NUMERIC_ONLY.name,
                ttsNumericRatioPercent = 45
            )
        )
        val keywordRules = listOf(
            KeywordRuleEntity(
                id = 2L,
                keywords = "OTP",
                action = KeywordAction.HIGHLIGHT
            )
        )
        val feedbackRules = listOf(
            TtsFeedbackRuleEntity(
                id = 3L,
                packageName = "com.mbmobile",
                appName = "MB Bank",
                patternFingerprint = "uu dai <AMT>",
                titleSignature = "uu dai",
                samplePreview = "Ưu đãi 500k",
                shouldSpeak = false
            )
        )
        val settings = NotiTrackSettings(
            ttsOnlyWhenScreenOff = true,
            ttsNumericRatioPercent = 45,
            ttsDelayBetweenMs = 2000
        )

        val fullJson = BackupRestoreEngine.serializeToJson(
            selection = BackupSelection(),
            notifications = notifications,
            appRules = appRules,
            keywordRules = keywordRules,
            ttsFeedbackRules = feedbackRules,
            settings = settings,
            exportedAt = 1732000100000L
        )
        val parsed = BackupRestoreEngine.parseBackupJson(fullJson).getOrThrow()
        assertEquals(1, parsed.notificationCount)
        assertEquals(1, parsed.appRuleCount)
        assertEquals(1, parsed.keywordRuleCount)
        assertEquals(1, parsed.ttsFeedbackCount)
        assertTrue(parsed.hasSettings)
        assertEquals(true, parsed.payload.settings?.ttsOnlyWhenScreenOff)
        assertEquals(45, parsed.payload.settings?.ttsNumericRatioPercent)
        assertEquals(45, parsed.payload.appRules?.first()?.ttsNumericRatioPercent)

        // Selective export: only notifications + feedback
        val partialJson = BackupRestoreEngine.serializeToJson(
            selection = BackupSelection(
                includeNotifications = true,
                includeAppRules = false,
                includeKeywordRules = false,
                includeTtsFeedback = true,
                includeSettings = false
            ),
            notifications = notifications,
            appRules = appRules,
            keywordRules = keywordRules,
            ttsFeedbackRules = feedbackRules,
            settings = settings
        )
        val partialParsed = BackupRestoreEngine.parseBackupJson(partialJson).getOrThrow()
        assertNotNull(partialParsed.payload.notifications)
        assertNull(partialParsed.payload.appRules)
        assertNull(partialParsed.payload.keywordRules)
        assertNotNull(partialParsed.payload.ttsFeedbackRules)
        assertNull(partialParsed.payload.settings)

        // Invalid JSON fails cleanly
        assertTrue(BackupRestoreEngine.parseBackupJson("{not valid json").isFailure)
        assertTrue(BackupRestoreEngine.parseBackupJson("{\"foo\":\"bar\"}").isFailure)
    }

    @Test
    fun `device guard engine triggers low battery once and resets with hysteresis`() {
        val engine = DeviceGuardEngine()
        val config = DeviceGuardConfig(lowBatteryEnabled = true, lowBatteryThreshold = 20)

        val above = engine.evaluateTelemetry(
            GuardTelemetrySnapshot(batteryPercent = 25, isCharging = false, tempCelsius = 32f, nowMs = 1_000L),
            config
        )
        assertTrue(above.isEmpty())

        val trigger = engine.evaluateTelemetry(
            GuardTelemetrySnapshot(batteryPercent = 20, isCharging = false, tempCelsius = 32f, nowMs = 2_000L),
            config
        )
        assertEquals(1, trigger.filterIsInstance<DeviceGuardEvent.LowBatteryAlert>().size)

        // Repeated low readings do not spam
        val duplicate = engine.evaluateTelemetry(
            GuardTelemetrySnapshot(batteryPercent = 18, isCharging = false, tempCelsius = 32f, nowMs = 3_000L),
            config
        )
        assertTrue(duplicate.isEmpty())

        // Charging resets latch; unplugging below threshold triggers again
        engine.evaluateTelemetry(
            GuardTelemetrySnapshot(batteryPercent = 19, isCharging = true, tempCelsius = 32f, nowMs = 4_000L),
            config
        )
        val reTrigger = engine.evaluateTelemetry(
            GuardTelemetrySnapshot(batteryPercent = 19, isCharging = false, tempCelsius = 32f, nowMs = 5_000L),
            config
        )
        assertEquals(1, reTrigger.filterIsInstance<DeviceGuardEvent.LowBatteryAlert>().size)
    }

    @Test
    fun `device guard engine supports charging target alert and 100 percent extra soak minutes`() {
        val engine = DeviceGuardEngine()
        val config = DeviceGuardConfig(
            chargingAlertEnabled = true,
            chargingAlertThreshold = 80,
            fullChargeEnabled = true,
            fullChargeThreshold = 100,
            fullChargeExtraMinutes = 10
        )

        val at80 = engine.evaluateTelemetry(
            GuardTelemetrySnapshot(batteryPercent = 80, isCharging = true, tempCelsius = 34f, nowMs = 10_000L),
            config
        )
        assertEquals(1, at80.filterIsInstance<DeviceGuardEvent.ChargingLevelAlert>().size)
        assertTrue(at80.filterIsInstance<DeviceGuardEvent.FullChargeAlert>().isEmpty())

        // Reaches 100%: starts soak timer, does NOT fire immediately
        val start100Ms = 100_000L
        val at100Start = engine.evaluateTelemetry(
            GuardTelemetrySnapshot(batteryPercent = 100, isCharging = true, tempCelsius = 34f, nowMs = start100Ms),
            config
        )
        assertTrue(at100Start.filterIsInstance<DeviceGuardEvent.FullChargeAlert>().isEmpty())

        // After 5 minutes (less than 10 min soak): still null
        assertNull(
            engine.checkFullChargeTimerTick(
                isCharging = true,
                batteryPercent = 100,
                nowMs = start100Ms + 5 * 60_000L,
                config = config
            )
        )

        // After 10 minutes: fires FullChargeAlert with extraMinutesWaited = 10
        val matured = engine.checkFullChargeTimerTick(
            isCharging = true,
            batteryPercent = 100,
            nowMs = start100Ms + 10 * 60_000L,
            config = config
        )
        assertNotNull(matured)
        assertEquals(10, matured!!.extraMinutesWaited)

        // Does not fire a second time on subsequent ticks
        assertNull(
            engine.checkFullChargeTimerTick(
                isCharging = true,
                batteryPercent = 100,
                nowMs = start100Ms + 15 * 60_000L,
                config = config
            )
        )
    }

    @Test
    fun `device guard engine throttles overheat alerts by cooldown interval`() {
        val engine = DeviceGuardEngine()
        val config = DeviceGuardConfig(
            overheatEnabled = true,
            overheatThresholdC = 42,
            overheatCooldownSeconds = 60
        )

        val first = engine.evaluateTelemetry(
            GuardTelemetrySnapshot(batteryPercent = 65, isCharging = false, tempCelsius = 43.2f, nowMs = 10_000L),
            config
        )
        assertEquals(1, first.filterIsInstance<DeviceGuardEvent.OverheatAlert>().size)

        // Within 60s cooldown -> suppressed
        val suppressed = engine.evaluateTelemetry(
            GuardTelemetrySnapshot(batteryPercent = 64, isCharging = false, tempCelsius = 44.0f, nowMs = 45_000L),
            config
        )
        assertTrue(suppressed.isEmpty())

        // After 60s cooldown -> fires again
        val second = engine.evaluateTelemetry(
            GuardTelemetrySnapshot(batteryPercent = 63, isCharging = false, tempCelsius = 43.5f, nowMs = 71_000L),
            config
        )
        assertEquals(1, second.filterIsInstance<DeviceGuardEvent.OverheatAlert>().size)
    }

    @Test
    fun `charging anti theft arms above min battery clamps confirm timeout to 120s and detects unplug`() {
        assertEquals(5, DeviceGuardEngine.clampConfirmSeconds(1))
        assertEquals(45, DeviceGuardEngine.clampConfirmSeconds(45))
        assertEquals(120, DeviceGuardEngine.clampConfirmSeconds(300))

        val engine = DeviceGuardEngine()
        val config = DeviceGuardConfig(
            chargeGuardEnabled = true,
            chargeGuardMinBatteryPercent = 50,
            chargeGuardDelaySeconds = 4,
            chargeGuardConfirmDialogEnabled = true,
            chargeGuardConfirmSeconds = 180 // should clamp to 120
        )

        // Charging below min battery % -> not yet armed
        engine.evaluateTelemetry(
            GuardTelemetrySnapshot(batteryPercent = 40, isCharging = true, tempCelsius = 33f, nowMs = 1_000L),
            config
        )
        assertFalse(engine.isChargeGuardArmed)

        // Reaches >= 50% while charging -> armed
        engine.evaluateTelemetry(
            GuardTelemetrySnapshot(batteryPercent = 55, isCharging = true, tempCelsius = 33f, nowMs = 2_000L),
            config
        )
        assertTrue(engine.isChargeGuardArmed)

        // Unplugged -> fires ChargerGuardUnplugged with clamped confirmSeconds = 120
        val unpluggedEvents = engine.evaluateTelemetry(
            GuardTelemetrySnapshot(batteryPercent = 55, isCharging = false, tempCelsius = 33f, nowMs = 3_000L),
            config
        )
        val alert = unpluggedEvents.filterIsInstance<DeviceGuardEvent.ChargerGuardUnplugged>().firstOrNull()
        assertNotNull(alert)
        assertEquals(4, alert!!.delaySeconds)
        assertTrue(alert.confirmDialogEnabled)
        assertEquals(120, alert.confirmSeconds)
        assertFalse(engine.isChargeGuardArmed)
    }

    @Test
    fun `motion sensitivity thresholds distinguish low medium and high movement`() {
        assertTrue(DeviceGuardEngine.exceedsMotionThreshold(1.5f, 0f, 0f, MotionSensitivity.HIGH))
        assertFalse(DeviceGuardEngine.exceedsMotionThreshold(1.5f, 0f, 0f, MotionSensitivity.MEDIUM))
        assertTrue(DeviceGuardEngine.exceedsMotionThreshold(2.5f, 0f, 0f, MotionSensitivity.MEDIUM))
        assertFalse(DeviceGuardEngine.exceedsMotionThreshold(2.5f, 0f, 0f, MotionSensitivity.LOW))
        assertTrue(DeviceGuardEngine.exceedsMotionThreshold(4.0f, 0f, 0f, MotionSensitivity.LOW))
    }
}

