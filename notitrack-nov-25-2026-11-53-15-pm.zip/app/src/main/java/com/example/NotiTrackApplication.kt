package com.example

import android.app.Application
import com.example.data.db.NotiTrackDatabase
import com.example.data.prefs.NotiTrackPreferences
import com.example.data.repository.NotiTrackRepository
import com.example.engine.NotificationSpeaker

class NotiTrackApplication : Application() {

    lateinit var database: NotiTrackDatabase
        private set
    lateinit var preferences: NotiTrackPreferences
        private set
    lateinit var repository: NotiTrackRepository
        private set
    lateinit var speaker: NotificationSpeaker
        private set

    override fun onCreate() {
        super.onCreate()
        database = NotiTrackDatabase.getInstance(this)
        preferences = NotiTrackPreferences(this)
        repository = NotiTrackRepository(
            context = this,
            notificationDao = database.notificationDao(),
            appRuleDao = database.appRuleDao(),
            keywordRuleDao = database.keywordRuleDao(),
            ttsFeedbackRuleDao = database.ttsFeedbackRuleDao(),
            preferences = preferences
        )
        speaker = NotificationSpeaker(this)
    }

    override fun onTerminate() {
        speaker.shutdown()
        super.onTerminate()
    }
}
