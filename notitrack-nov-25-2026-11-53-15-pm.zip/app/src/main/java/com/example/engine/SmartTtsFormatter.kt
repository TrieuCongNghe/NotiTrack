package com.example.engine

import com.example.data.model.TtsFilterMode
import com.example.data.model.TtsNumberReadMode
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.stringsFor

/**
 * Formats notification text into clean, natural spoken speech:
 * - Supports user-highlighted custom templates per app
 * - Smart mode: strips account numbers, transaction memos/notes, ref IDs, URLs & timestamps,
 *   speaking only concise alerts (e.g. "MB Bank: Đã nhận 50.000 đồng.")
 * - Non-smart / Digit modes: reads numbers accurately by context or digit-by-digit
 *   (e.g. "9999" -> "chín chín chín chín" instead of "chín nghìn chín trăm chín mươi chín")
 * - Optionally hides account balance clauses ("SD: ...", "Số dư: ...", "Balance: ...")
 */
object SmartTtsFormatter {

    private val SIGNED_AMOUNT_BEFORE_REGEX = Regex(
        """(?i)([+\-])\s*(vnđ|vnd|đ|usd|\$|€|eur|¥|jpy|원|krw)\s*(\d{1,3}(?:[.,]\d{3})+|\d+(?:[.,]\d{1,2})?)(?=\s|[|,.;)\n]|$)"""
    )
    private val SIGNED_AMOUNT_AFTER_REGEX = Regex(
        """(?i)([+\-])\s*(\d{1,3}(?:[.,]\d{3})+|\d+(?:[.,]\d{1,2})?)\s*(vnđ|vnd|đ|d|usd|\$|€|eur|¥|jpy|원|krw)?(?=\s|[|,.;)\n]|$)"""
    )
    private val CONTEXT_AMOUNT_REGEX = Regex(
        """(?i)(nhận(?:\s+được)?|được\s+cộng|chuyển\s+đến|biến\s+động|cộng|trừ|thanh\s+toán|rút|chuyển\s+(?:đi|khoản)|received|credited|deposited|spent|paid|debited|withdrew)\s*[:\-]?\s*([+\-])?\s*(?:(vnđ|vnd|đ|usd|\$|€|eur|¥|jpy)\s*)?(\d{1,3}(?:[.,]\d{3})+|\d+(?:[.,]\d{1,2})?)\s*(vnđ|vnd|đ|usd|\$|€|eur|¥|jpy)?"""
    )

    private val BALANCE_CLAUSE_REGEX = Regex(
        """(?i)(?:^|(?<=[\s|.,;(]))(?:số\s*dư(?:\s*hiện\s*tại|\s*khả\s*dụng|\s*cuối)?|so\s*du(?:\s*hien\s*tai|\s*kha\s*dung)?|sd|s\.d|balance|avail(?:able)?\s*bal(?:ance)?|bal)\s*[:=\-]?\s*[+\-]?\s*(?:(?:vnđ|vnd|đ|usd|\$|€|eur|¥|jpy|krw)\s*)?\d[\d.,]*\s*(?:vnđ|vnd|đ|d|usd|\$|€|eur|¥|krw)?(?=\s|[|.,;)\n]|$)"""
    )

    private val BALANCE_EXTRACT_REGEX = Regex(
        """(?i)(?:^|(?<=[\s|.,;(]))(?:số\s*dư(?:\s*hiện\s*tại|\s*khả\s*dụng|\s*cuối)?|so\s*du(?:\s*hien\s*tai|\s*kha\s*dung)?|sd|s\.d|balance|avail(?:able)?\s*bal(?:ance)?|bal)\s*[:=\-]?\s*(?:(vnđ|vnd|đ|usd|\$|€|eur|¥|jpy|krw)\s*)?([+\-]?\d{1,3}(?:[.,]\d{3})+|\d+(?:[.,]\d{1,2})?)\s*(vnđ|vnd|đ|d|usd|\$|€|eur|¥|krw)?(?=\s|[|.,;)\n]|$)"""
    )

    private val ACCOUNT_NO_REGEX = Regex(
        """(?i)(?:^|(?<=[\s|.,;(]))(?:stk|tk|số\s*tk|so\s*tk|tài\s*khoản|tai\s*khoan|acct|account)\s*[:#\-]?\s*[a-z0-9*xX\-]{3,}(?=\s|[|.,;)\n]|$)"""
    )

    // Strip sender/from clauses (e.g. |TU: DANG VIET TRIEU - 9997777999|) in smart concise mode
    private val SENDER_CLAUSE_REGEX = Regex(
        """(?i)(?:^|(?<=[\s|]))(?:từ|tu|from|người\s*gửi|nguoi\s*gui)\s*[:\-]\s*[^|\n]*"""
    )

    // Strip memo/description/note clauses completely in smart concise mode
    private val MEMO_CLAUSE_REGEX = Regex(
        """(?i)(?:^|(?<=[\s|]))(?:nd|nội\s*dung|noi\s*dung|memo|diễn\s*giải|dien\s*giai|lời\s*nhắn|loi\s*nhan|chi\s*tiết|chi\s*tiet|mô\s*tả|mo\s*ta|ref|ghi\s*chú|ghi\s*chu)\s*[:\-]\s*[^|\n]*"""
    )

    private val LABELED_CODE_REGEX = Regex(
        """(?i)\b(?:mã\s*gd|ma\s*gd|mã\s*giao\s*dịch|ma\s*giao\s*dich|mã\s*đơn|ma\s*don|ref(?:\s*no)?|trace|ft|ibft|trans(?:action)?\s*(?:id|code|no)?|order\s*(?:id|no|#)?|code|id)\s*[:#=\-]?\s*[a-z0-9\-_]{4,}\b"""
    )

    private val MIXED_ALPHANUM_CODE_REGEX = Regex(
        """(?i)(?:#|\b)(?=[a-z0-9\-_/]{6,}\b)(?=[a-z\-_/]*\d)(?=\d*[a-z])[a-z0-9\-_/]{6,}\b"""
    )

    private val LONG_DIGIT_ID_REGEX = Regex("""\b\d{6,}\b""")

    private val DATETIME_NOISE_REGEX = Regex(
        """(?i)\b(?:lúc|luc|vào\s*lúc|vao\s*luc|ngày|ngay|at|on)?\s*(?:\d{1,2}:\d{2}(?::\d{2})?(?:\s+\d{1,2}[/\-]\d{1,2}(?:[/\-]\d{2,4})?)?|\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?)\b"""
    )

    private val URL_REGEX = Regex("""https?://\S+|www\.\S+""", RegexOption.IGNORE_CASE)

    private val PLAIN_NUMBER_REGEX = Regex("""(?<![\d.,:/+\-])\b(\d{2,})\b(?![\d.,:/])""")
    private val CODE_CONTEXT_BEFORE_REGEX = Regex(
        """(?i)(otp|pin|mã|ma|code|stk|tk|tài\s*khoản|tai\s*khoan|số\s*đt|sđt|sdt|phone|số|so|id|ref|đơn|don|phòng|phong|biển|bien|mật\s*khẩu|pass)\s*[:#=\-]?\s*$"""
    )
    private val QUANTITY_OR_CURRENCY_AFTER_REGEX = Regex(
        """(?i)^\s*(?:vnđ|vnd|đồng|dong|usd|\$|€|eur|¥|jpy|krw|%|°c|°f|giờ|gio|phút|phut|giây|giay|ngày|ngay|tháng|thang|năm|nam|tuổi|tuoi|người|nguoi|cái|cai|chiếc|chiec|lần|lan|tin\s*nhắn|thông\s*báo|km|cm|kg|mb|gb|tb|items?|mins?|hours?|days?|years?|đ|m|g)(?=\s|[.,;!?)]|$)"""
    )

    private val VI_DIGITS = mapOf(
        '0' to "không",
        '1' to "một",
        '2' to "hai",
        '3' to "ba",
        '4' to "bốn",
        '5' to "năm",
        '6' to "sáu",
        '7' to "bảy",
        '8' to "tám",
        '9' to "chín"
    )

    fun shouldSpeakForRule(
        title: String,
        content: String,
        filterMode: TtsFilterMode,
        numericThresholdPercent: Int = SmartTtsTemplateEngine.DEFAULT_NUMERIC_RATIO_PERCENT
    ): Boolean {
        return when (filterMode) {
            TtsFilterMode.ALL -> true
            TtsFilterMode.NUMERIC_ONLY -> SmartTtsTemplateEngine.passesNumericOnlyFilter(
                title = title,
                content = content,
                thresholdPercent = numericThresholdPercent
            )
        }
    }

    fun formatForSpeech(
        appName: String,
        title: String,
        content: String,
        includeAppName: Boolean,
        smartFilterEnabled: Boolean,
        hideBalance: Boolean,
        language: AppLanguage = AppLanguage.VIETNAMESE,
        numberReadMode: TtsNumberReadMode = TtsNumberReadMode.CONTEXT_AUTO,
        customTemplate: String = ""
    ): String {
        val resolvedLang = language.resolved()
        val strings = stringsFor(resolvedLang)

        // 0. If user defined a custom highlight template for this app, apply it first!
        if (customTemplate.isNotBlank()) {
            val fullSource = listOf(title.trim(), content.trim())
                .filter { it.isNotBlank() }
                .distinct()
                .joinToString(" ")
            val extracted = SmartTtsTemplateEngine.applyTemplate(customTemplate, fullSource)
            if (!extracted.isNullOrBlank()) {
                val filteredExtracted = if (hideBalance) stripBalance(extracted) else extracted
                val formatted = if (smartFilterEnabled) {
                    tryFormatTransactionSummary(
                        appName = appName,
                        combinedText = filteredExtracted,
                        includeAppName = includeAppName,
                        hideBalance = hideBalance,
                        language = resolvedLang
                    ) ?: buildStandardSpeech(
                        appName = appName,
                        title = "",
                        content = applyNumberReadMode(filteredExtracted, numberReadMode, resolvedLang),
                        includeAppName = includeAppName,
                        prefixProvider = strings.ttsSpokenPrefix
                    )
                } else {
                    buildStandardSpeech(
                        appName = appName,
                        title = "",
                        content = applyNumberReadMode(filteredExtracted, numberReadMode, resolvedLang),
                        includeAppName = includeAppName,
                        prefixProvider = strings.ttsSpokenPrefix
                    )
                }
                if (formatted.isNotBlank()) return formatted
            }
        }

        val workingTitle = if (hideBalance) stripBalance(title) else title
        val workingContent = if (hideBalance) stripBalance(content) else content

        if (!smartFilterEnabled) {
            val styledTitle = applyNumberReadMode(workingTitle, numberReadMode, resolvedLang)
            val styledContent = applyNumberReadMode(workingContent, numberReadMode, resolvedLang)
            return buildStandardSpeech(
                appName = appName,
                title = styledTitle,
                content = styledContent,
                includeAppName = includeAppName,
                prefixProvider = strings.ttsSpokenPrefix
            )
        }

        // 1. Smart banking / money transaction summary: ONLY amount (+ balance if !hideBalance).
        // Strips account numbers, memos/ND, ref codes, timestamps, and other extra details!
        val combined = "$workingTitle. $workingContent"
        val bankSummary = tryFormatTransactionSummary(
            appName = appName,
            combinedText = combined,
            includeAppName = includeAppName,
            hideBalance = hideBalance,
            language = resolvedLang
        )
        if (bankSummary != null) {
            return bankSummary
        }

        // 2. General concise cleaning: strip URLs, account IDs, memos, transaction codes & timestamps
        val cleanTitle = applyNumberReadMode(cleanNoisyTokens(workingTitle), numberReadMode, resolvedLang)
        val cleanContent = applyNumberReadMode(cleanNoisyTokens(workingContent), numberReadMode, resolvedLang)

        return buildStandardSpeech(
            appName = appName,
            title = cleanTitle,
            content = cleanContent,
            includeAppName = includeAppName,
            prefixProvider = strings.ttsSpokenPrefix
        )
    }

    /**
     * Converts digit sequences based on TtsNumberReadMode so e.g. "9999" is spoken as
     * "chín chín chín chín" instead of "chín nghìn chín trăm chín mươi chín" when appropriate.
     */
    fun applyNumberReadMode(
        text: String,
        mode: TtsNumberReadMode,
        language: AppLanguage
    ): String {
        if (text.isBlank() || mode == TtsNumberReadMode.NATURAL_WORDS) return text

        return PLAIN_NUMBER_REGEX.replace(text) { match ->
            val digits = match.groupValues[1]
            val start = match.range.first
            val end = match.range.last + 1
            val before = text.substring((start - 28).coerceAtLeast(0), start)
            val after = text.substring(end, (end + 24).coerceAtMost(text.length))

            val shouldReadDigits = when (mode) {
                TtsNumberReadMode.EXACT_DIGITS -> {
                    // Read digit-by-digit for all multi-digit numbers except explicit currency amounts
                    !QUANTITY_OR_CURRENCY_AFTER_REGEX.containsMatchIn(after)
                }
                TtsNumberReadMode.CONTEXT_AUTO -> {
                    val hasQuantityOrCurrencyAfter = QUANTITY_OR_CURRENCY_AFTER_REGEX.containsMatchIn(after)
                    val hasCodeContextBefore = CODE_CONTEXT_BEFORE_REGEX.containsMatchIn(before)
                    val looksLikeYear = digits.length == 4 && digits.toIntOrNull()?.let { it in 1900..2100 } == true
                    val startsWithZero = digits.startsWith("0") && digits.length >= 2

                    when {
                        hasQuantityOrCurrencyAfter -> false
                        startsWithZero -> true
                        hasCodeContextBefore -> true
                        digits.length >= 4 && !looksLikeYear -> true
                        else -> false
                    }
                }
                TtsNumberReadMode.NATURAL_WORDS -> false
            }

            if (shouldReadDigits) {
                spellDigits(digits, language)
            } else {
                digits
            }
        }
    }

    private fun spellDigits(digits: String, language: AppLanguage): String {
        return if (language.resolved() == AppLanguage.VIETNAMESE) {
            digits.mapNotNull { VI_DIGITS[it] }.joinToString(" ")
        } else {
            digits.toCharArray().joinToString(" ")
        }
    }

    private fun buildStandardSpeech(
        appName: String,
        title: String,
        content: String,
        includeAppName: Boolean,
        prefixProvider: (String) -> String
    ): String {
        val parts = buildList {
            if (includeAppName && appName.isNotBlank()) add(prefixProvider(appName))
            if (title.isNotBlank()) add(title.trim().trimEnd('.') + ".")
            if (content.isNotBlank() && !content.trim().equals(title.trim(), ignoreCase = true)) {
                add(content.trim().take(240))
            }
        }
        return parts.joinToString(" ").replace(Regex("\\s+"), " ").trim()
    }

    private fun stripBalance(text: String): String {
        return BALANCE_CLAUSE_REGEX.replace(text, " ")
            .replace(Regex("""\s{2,}"""), " ")
            .trim()
    }

    private fun extractBalanceAmount(text: String): Pair<String, String>? {
        val match = BALANCE_EXTRACT_REGEX.find(text) ?: return null
        val curBefore = match.groupValues[1]
        val amount = match.groupValues[2].trimStart('+')
        val curAfter = match.groupValues[3]
        val currency = curBefore.ifBlank { curAfter }
        return amount to currency
    }

    private fun tryFormatTransactionSummary(
        appName: String,
        combinedText: String,
        includeAppName: Boolean,
        hideBalance: Boolean,
        language: AppLanguage
    ): String? {
        val balancePair = if (!hideBalance) extractBalanceAmount(combinedText) else null
        val withoutBalance = stripBalance(combinedText)

        var isIncoming: Boolean? = null
        var rawAmount: String? = null
        var rawCurrency: String? = null

        val signedBeforeMatch = SIGNED_AMOUNT_BEFORE_REGEX.find(withoutBalance)
        if (signedBeforeMatch != null) {
            val sign = signedBeforeMatch.groupValues[1]
            val cur = signedBeforeMatch.groupValues[2]
            val amt = signedBeforeMatch.groupValues[3]
            if (amt.replace(Regex("[.,]"), "").length <= 12) {
                isIncoming = (sign == "+")
                rawAmount = amt
                rawCurrency = cur
            }
        }

        if (rawAmount == null) {
            val signedAfterMatch = SIGNED_AMOUNT_AFTER_REGEX.find(withoutBalance)
            if (signedAfterMatch != null) {
                val sign = signedAfterMatch.groupValues[1]
                val amt = signedAfterMatch.groupValues[2]
                val cur = signedAfterMatch.groupValues[3]
                val hasCurrencyOrBankCue = cur.isNotBlank() || looksLikeMoneyContext(withoutBalance)
                if (hasCurrencyOrBankCue && amt.replace(Regex("[.,]"), "").length <= 12) {
                    isIncoming = (sign == "+")
                    rawAmount = amt
                    rawCurrency = cur
                }
            }
        }

        if (rawAmount == null) {
            val ctxMatch = CONTEXT_AMOUNT_REGEX.find(withoutBalance)
            if (ctxMatch != null) {
                val verb = ctxMatch.groupValues[1].lowercase()
                val sign = ctxMatch.groupValues[2]
                val curBefore = ctxMatch.groupValues[3]
                val amt = ctxMatch.groupValues[4]
                val curAfter = ctxMatch.groupValues[5]
                val cur = curBefore.ifBlank { curAfter }
                if (cur.isNotBlank() || looksLikeMoneyContext(withoutBalance)) {
                    isIncoming = when {
                        sign == "+" -> true
                        sign == "-" -> false
                        verb.contains("nhận") || verb.contains("cộng") || verb.contains("đến") ||
                            verb.contains("received") || verb.contains("credited") || verb.contains("deposited") -> true
                        else -> false
                    }
                    rawAmount = amt
                    rawCurrency = cur
                }
            }
        }

        if (rawAmount == null || isIncoming == null) return null

        val spokenAmount = formatSpokenAmount(rawAmount, rawCurrency, language)
        val actionPhrase = if (language == AppLanguage.VIETNAMESE) {
            if (isIncoming) "Đã nhận $spokenAmount" else "Đã trừ $spokenAmount"
        } else {
            if (isIncoming) "Received $spokenAmount" else "Spent $spokenAmount"
        }

        // Concise bank speech: strips account number, memo/ND, transaction IDs & timestamps completely!
        val parts = buildList {
            if (includeAppName && appName.isNotBlank()) {
                add("$appName:")
            }
            add("$actionPhrase.")
            if (balancePair != null) {
                val spokenBal = formatSpokenAmount(balancePair.first, balancePair.second, language)
                val balPhrase = if (language == AppLanguage.VIETNAMESE) {
                    "Số dư $spokenBal."
                } else {
                    "Balance $spokenBal."
                }
                add(balPhrase)
            }
        }
        return parts.joinToString(" ").replace(Regex("\\s+"), " ").trim()
    }

    private fun looksLikeMoneyContext(text: String): Boolean {
        val lower = text.lowercase()
        val cues = listOf(
            "vnd", "vnđ", "đồng", "chuyển khoản", "số dư", "biến động", "tài khoản",
            "gd:", "thanh toán", "nhận tiền", "giao dịch", "bank", "momo", "zalopay",
            "vnpay", "transfer", "balance", "payment", "credited", "debited", "usd", "$"
        )
        return cues.any { lower.contains(it) }
    }

    private fun formatSpokenAmount(amount: String, currency: String?, language: AppLanguage): String {
        val cur = currency?.trim()?.lowercase().orEmpty()
        val normalizedVnd = amount.replace(",", ".")
        return when {
            cur in listOf("vnd", "vnđ", "đ", "d", "") && language == AppLanguage.VIETNAMESE -> "$normalizedVnd đồng"
            cur in listOf("usd", "$") -> if (language == AppLanguage.VIETNAMESE) "$amount đô la" else "$amount dollars"
            cur in listOf("eur", "€") -> "$amount euro"
            cur in listOf("jpy", "¥") -> if (language == AppLanguage.VIETNAMESE) "$amount yên" else "$amount yen"
            cur in listOf("krw", "원") -> "$amount won"
            cur.isNotBlank() -> "$amount $cur"
            else -> "$amount VND"
        }
    }

    fun cleanNoisyTokens(raw: String): String {
        if (raw.isBlank()) return ""
        return raw
            .replace(URL_REGEX, " ")
            .replace(SENDER_CLAUSE_REGEX, " ")
            .replace(MEMO_CLAUSE_REGEX, " ")
            .replace(ACCOUNT_NO_REGEX, " ")
            .replace(LABELED_CODE_REGEX, " ")
            .replace(MIXED_ALPHANUM_CODE_REGEX, " ")
            .replace(DATETIME_NOISE_REGEX, " ")
            .replace(LONG_DIGIT_ID_REGEX, " ")
            .replace(Regex("""[|•·_*#~`]+"""), " ")
            .replace(Regex("""\s*[,;:\-]+\s*([.,;:\-]+\s*)+"""), ", ")
            .replace(Regex("""\s{2,}"""), " ")
            .trim(' ', ',', ';', '-', ':', '.')
    }
}
