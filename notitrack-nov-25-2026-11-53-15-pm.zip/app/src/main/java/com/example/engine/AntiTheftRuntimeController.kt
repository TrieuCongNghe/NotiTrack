package com.example.engine

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.ui.screens.AntiTheftAlarmActivity
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class AntiTheftPhase {
    IDLE,
    GRACE_DELAY,          // Short pre-dialog unplug delay (cancelled if re-plugged)
    AWAITING_CONFIRM,     // Confirmation countdown (<= 120s) accepting 4-digit PIN or Biometric
    ALARM_RINGING         // Full siren + max volume lock + flash + vibration; strictly 4-digit PIN only
}

data class AntiTheftRuntimeState(
    val phase: AntiTheftPhase = AntiTheftPhase.IDLE,
    val reason: AntiTheftTriggerReason? = null,
    val remainingConfirmSeconds: Int = 0,
    val totalConfirmSeconds: Int = 0,
    val flashEnabled: Boolean = true,
    val vibrateEnabled: Boolean = true,
    val isChargeGuardArmed: Boolean = false,
    val isMotionGuardArmed: Boolean = false,
    val motionArmingCountdownSec: Int = 0
)

/**
 * Coordinates the live Anti-Theft lifecycle across KeepAliveService, InboxScreen FAB,
 * and AntiTheftAlarmActivity:
 * - Pre-alarm unplug delay & <= 120s owner confirmation countdown (PIN or Biometric)
 * - Active siren on USAGE_ALARM with 200ms max-volume lock watchdog
 * - Rear camera torch strobe via CameraManager.setTorchMode (no CAMERA permission required)
 * - Strong vibration loop (toggleable)
 * - Play-safe full-screen lock intent & auto re-launch watchdog until 4-digit PIN is entered
 */
object AntiTheftRuntimeController {

    private const val CHANNEL_ALARM_ID = "notitrack_antitheft_alarm_v1"
    private const val ALARM_NOTIF_ID = 6099

    private val exceptionHandler = CoroutineExceptionHandler { _, _ -> }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default + exceptionHandler)

    private val _state = MutableStateFlow(AntiTheftRuntimeState())
    val state: StateFlow<AntiTheftRuntimeState> = _state.asStateFlow()

    @Volatile
    private var alarmActivityVisible = false

    private var phaseJob: Job? = null
    private var volumeWatchdogJob: Job? = null
    private var flashJob: Job? = null
    private var vibrateJob: Job? = null
    private var relaunchWatchdogJob: Job? = null

    private var mediaPlayer: MediaPlayer? = null
    private var savedAlarmVolume: Int? = null

    fun updateArmedIndicators(
        chargeGuardArmed: Boolean,
        motionGuardArmed: Boolean,
        motionArmingCountdownSec: Int = _state.value.motionArmingCountdownSec
    ) {
        val current = _state.value
        if (current.isChargeGuardArmed != chargeGuardArmed ||
            current.isMotionGuardArmed != motionGuardArmed ||
            current.motionArmingCountdownSec != motionArmingCountdownSec
        ) {
            _state.value = current.copy(
                isChargeGuardArmed = chargeGuardArmed,
                isMotionGuardArmed = motionGuardArmed,
                motionArmingCountdownSec = motionArmingCountdownSec
            )
        }
    }

    fun onAlarmActivityVisibilityChanged(visible: Boolean) {
        alarmActivityVisible = visible
    }

    fun triggerGuardBreach(
        context: Context,
        reason: AntiTheftTriggerReason,
        delaySeconds: Int,
        confirmDialogEnabled: Boolean,
        confirmSeconds: Int,
        flashEnabled: Boolean,
        vibrateEnabled: Boolean
    ) {
        val currentPhase = _state.value.phase
        if (currentPhase == AntiTheftPhase.ALARM_RINGING || currentPhase == AntiTheftPhase.AWAITING_CONFIRM) {
            return
        }
        val appContext = context.applicationContext
        val clampedConfirm = DeviceGuardEngine.clampConfirmSeconds(confirmSeconds)
        val safeDelay = delaySeconds.coerceIn(0, 30)

        phaseJob?.cancel()
        phaseJob = scope.launch {
            if (safeDelay > 0 && reason == AntiTheftTriggerReason.CHARGER_UNPLUGGED) {
                _state.value = _state.value.copy(
                    phase = AntiTheftPhase.GRACE_DELAY,
                    reason = reason,
                    flashEnabled = flashEnabled,
                    vibrateEnabled = vibrateEnabled
                )
                delay(safeDelay * 1_000L)
            }

            if (confirmDialogEnabled) {
                _state.value = _state.value.copy(
                    phase = AntiTheftPhase.AWAITING_CONFIRM,
                    reason = reason,
                    remainingConfirmSeconds = clampedConfirm,
                    totalConfirmSeconds = clampedConfirm,
                    flashEnabled = flashEnabled,
                    vibrateEnabled = vibrateEnabled
                )
                launchAlarmScreen(appContext, isEmergencySiren = false)

                var remaining = clampedConfirm
                while (remaining > 0 && isActive && _state.value.phase == AntiTheftPhase.AWAITING_CONFIRM) {
                    _state.value = _state.value.copy(remainingConfirmSeconds = remaining)
                    delay(1_000L)
                    remaining--
                }
                if (isActive && _state.value.phase == AntiTheftPhase.AWAITING_CONFIRM) {
                    escalateToFullAlarm(appContext, reason, flashEnabled, vibrateEnabled)
                }
            } else {
                escalateToFullAlarm(appContext, reason, flashEnabled, vibrateEnabled)
            }
        }
    }

    fun onChargerReconnectedDuringGrace() {
        if (_state.value.phase == AntiTheftPhase.GRACE_DELAY &&
            _state.value.reason == AntiTheftTriggerReason.CHARGER_UNPLUGGED
        ) {
            phaseJob?.cancel()
            _state.value = _state.value.copy(
                phase = AntiTheftPhase.IDLE,
                reason = null,
                remainingConfirmSeconds = 0
            )
        }
    }

    private fun escalateToFullAlarm(
        appContext: Context,
        reason: AntiTheftTriggerReason,
        flashEnabled: Boolean,
        vibrateEnabled: Boolean
    ) {
        _state.value = _state.value.copy(
            phase = AntiTheftPhase.ALARM_RINGING,
            reason = reason,
            remainingConfirmSeconds = 0,
            flashEnabled = flashEnabled,
            vibrateEnabled = vibrateEnabled
        )
        startSirenAndVolumeLock(appContext)
        if (flashEnabled) startFlashStrobe(appContext)
        if (vibrateEnabled) startStrongVibration(appContext)
        launchAlarmScreen(appContext, isEmergencySiren = true)
        startRelaunchWatchdog(appContext)
    }

    fun disarmAll(context: Context) {
        val appContext = context.applicationContext
        phaseJob?.cancel()
        volumeWatchdogJob?.cancel()
        flashJob?.cancel()
        vibrateJob?.cancel()
        relaunchWatchdogJob?.cancel()

        stopSirenAndRestoreVolume(appContext)
        setTorch(appContext, false)
        stopVibration(appContext)
        cancelAlarmNotification(appContext)

        _state.value = _state.value.copy(
            phase = AntiTheftPhase.IDLE,
            reason = null,
            remainingConfirmSeconds = 0,
            totalConfirmSeconds = 0
        )
    }

    fun ensureAlarmActivityInFront(context: Context) {
        val phase = _state.value.phase
        if (phase == AntiTheftPhase.ALARM_RINGING || phase == AntiTheftPhase.AWAITING_CONFIRM) {
            launchAlarmScreen(context.applicationContext, isEmergencySiren = phase == AntiTheftPhase.ALARM_RINGING)
        }
    }

    private fun launchAlarmScreen(appContext: Context, isEmergencySiren: Boolean) {
        val intent = Intent(appContext, AntiTheftAlarmActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        }

        // Direct launch works when foreground service is active or screen is awake
        runCatching { appContext.startActivity(intent) }

        // Also post high-priority full-screen intent notification for lock-screen / Android 10+ background wake
        val manager = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        ensureAlarmChannel(manager)
        val fullScreenPending = PendingIntent.getActivity(
            appContext,
            ALARM_NOTIF_ID,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = if (isEmergencySiren) "BÁO ĐỘNG CHỐNG TRỘM!" else "Xác nhận chủ thiết bị"
        val text = if (isEmergencySiren) {
            "Nhập mã PIN 4 số để tắt còi báo động NotiTrack"
        } else {
            "Nhập mã PIN hoặc vân tay trước khi còi báo động kích hoạt"
        }

        val notif = NotificationCompat.Builder(appContext, CHANNEL_ALARM_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(fullScreenPending)
            .setFullScreenIntent(fullScreenPending, true)
            .build()
        runCatching { manager.notify(ALARM_NOTIF_ID, notif) }
    }

    private fun startRelaunchWatchdog(appContext: Context) {
        relaunchWatchdogJob?.cancel()
        relaunchWatchdogJob = scope.launch {
            while (isActive && _state.value.phase == AntiTheftPhase.ALARM_RINGING) {
                delay(1_100L)
                if (!alarmActivityVisible && _state.value.phase == AntiTheftPhase.ALARM_RINGING) {
                    launchAlarmScreen(appContext, isEmergencySiren = true)
                }
            }
        }
    }

    private fun startSirenAndVolumeLock(appContext: Context) {
        val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val maxAlarmVol = runCatching { audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM) }
            .getOrDefault(7)
            .coerceAtLeast(1)

        if (savedAlarmVolume == null) {
            savedAlarmVolume = runCatching { audioManager.getStreamVolume(AudioManager.STREAM_ALARM) }.getOrNull()
        }

        runCatching {
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, maxAlarmVol, 0)
        }

        runCatching {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(appContext, alarmUri)
                isLooping = true
                setVolume(1.0f, 1.0f)
                prepare()
                start()
            }
            mediaPlayer = player
        }

        volumeWatchdogJob?.cancel()
        volumeWatchdogJob = scope.launch {
            while (isActive && _state.value.phase == AntiTheftPhase.ALARM_RINGING) {
                runCatching {
                    val cur = audioManager.getStreamVolume(AudioManager.STREAM_ALARM)
                    if (cur < maxAlarmVol) {
                        audioManager.setStreamVolume(AudioManager.STREAM_ALARM, maxAlarmVol, 0)
                    }
                    if (mediaPlayer?.isPlaying == false) {
                        mediaPlayer?.start()
                    }
                }
                delay(200L)
            }
        }
    }

    private fun stopSirenAndRestoreVolume(appContext: Context) {
        runCatching {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        }
        mediaPlayer = null

        val prev = savedAlarmVolume
        savedAlarmVolume = null
        if (prev != null) {
            runCatching {
                val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                audioManager.setStreamVolume(AudioManager.STREAM_ALARM, prev, 0)
            }
        }
    }

    private fun startFlashStrobe(appContext: Context) {
        flashJob?.cancel()
        flashJob = scope.launch {
            var torchOn = false
            while (isActive && _state.value.phase == AntiTheftPhase.ALARM_RINGING) {
                torchOn = !torchOn
                setTorch(appContext, torchOn)
                delay(220L)
            }
            setTorch(appContext, false)
        }
    }

    private fun setTorch(appContext: Context, enabled: Boolean) {
        runCatching {
            val camManager = appContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val rearFlashId = camManager.cameraIdList.firstOrNull { id ->
                val chars = camManager.getCameraCharacteristics(id)
                val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK
            } ?: camManager.cameraIdList.firstOrNull { id ->
                camManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (rearFlashId != null) {
                camManager.setTorchMode(rearFlashId, enabled)
            }
        }
    }

    private fun startStrongVibration(appContext: Context) {
        vibrateJob?.cancel()
        vibrateJob = scope.launch {
            val vibrator = resolveVibrator(appContext) ?: return@launch
            while (isActive && _state.value.phase == AntiTheftPhase.ALARM_RINGING) {
                runCatching {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        val pattern = longArrayOf(0L, 450L, 180L, 450L, 180L)
                        val amps = intArrayOf(0, 255, 0, 255, 0)
                        vibrator.vibrate(VibrationEffect.createWaveform(pattern, amps, -1))
                    } else {
                        @Suppress("DEPRECATION")
                        vibrator.vibrate(longArrayOf(0L, 450L, 180L, 450L, 180L), -1)
                    }
                }
                delay(1_300L)
            }
            runCatching { vibrator.cancel() }
        }
    }

    private fun stopVibration(appContext: Context) {
        runCatching { resolveVibrator(appContext)?.cancel() }
    }

    private fun resolveVibrator(appContext: Context): Vibrator? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val mgr = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            mgr?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    private fun ensureAlarmChannel(manager: NotificationManager) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ALARM_ID,
            "Báo động chống trộm NotiTrack",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            setSound(null, null) // Sound handled directly via USAGE_ALARM MediaPlayer
            enableVibration(false)
            lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
        }
        manager.createNotificationChannel(channel)
    }

    private fun cancelAlarmNotification(appContext: Context) {
        runCatching {
            val manager = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.cancel(ALARM_NOTIF_ID)
        }
    }
}
