package com.example.engine

import com.example.data.model.AppRuleEntity
import com.example.data.model.KeywordAction
import com.example.data.model.KeywordRuleEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.TtsFeedbackRuleEntity
import com.example.data.model.TtsFilterMode
import com.example.data.model.TtsNumberReadMode
import com.example.data.prefs.KeepAliveNotifTheme
import com.example.data.prefs.NotiTrackSettings
import com.example.ui.i18n.AppLanguage
import com.example.ui.theme.ThemeMode

data class BackupSelection(
    val includeNotifications: Boolean = true,
    val includeAppRules: Boolean = true,
    val includeKeywordRules: Boolean = true,
    val includeTtsFeedback: Boolean = true,
    val includeSettings: Boolean = true
) {
    val hasAnySelected: Boolean
        get() = includeNotifications || includeAppRules || includeKeywordRules || includeTtsFeedback || includeSettings
}

enum class RestoreMode {
    MERGE,
    REPLACE
}

data class BackupPayload(
    val schemaVersion: Int,
    val exportedAt: Long,
    val notifications: List<NotificationEntity>?,
    val appRules: List<AppRuleEntity>?,
    val keywordRules: List<KeywordRuleEntity>?,
    val ttsFeedbackRules: List<TtsFeedbackRuleEntity>?,
    val settings: NotiTrackSettings?
)

data class BackupPreview(
    val schemaVersion: Int,
    val exportedAt: Long,
    val notificationCount: Int,
    val appRuleCount: Int,
    val keywordRuleCount: Int,
    val ttsFeedbackCount: Int,
    val hasSettings: Boolean,
    val payload: BackupPayload
) {
    val totalItemCount: Int
        get() = notificationCount + appRuleCount + keywordRuleCount + ttsFeedbackCount + (if (hasSettings) 1 else 0)
}

data class RestoreSummary(
    val notificationsRestored: Int,
    val appRulesRestored: Int,
    val keywordRulesRestored: Int,
    val feedbackRulesRestored: Int,
    val settingsRestored: Boolean
)

/**
 * Pure Kotlin RFC 8259 JSON backup/restore engine (zero external dependencies, runs identically
 * on Android devices and JVM unit tests).
 * Supports selective section export, schema validation, merge deduplication, and full replacement.
 */
object BackupRestoreEngine {

    const val CURRENT_SCHEMA_VERSION = 1

    fun notificationDedupKey(n: NotificationEntity): String =
        "${n.packageName}|${n.timestamp}|${n.title}|${n.content}"

    fun keywordDedupKey(k: KeywordRuleEntity): String =
        "${k.keywords}|${k.action.name}|${k.targetPackage.orEmpty()}|${k.isRegex}|${k.isCaseSensitive}"

    fun feedbackDedupKey(f: TtsFeedbackRuleEntity): String =
        "${f.packageName}|${f.patternFingerprint}"

    fun serializeToJson(
        selection: BackupSelection,
        notifications: List<NotificationEntity>,
        appRules: List<AppRuleEntity>,
        keywordRules: List<KeywordRuleEntity>,
        ttsFeedbackRules: List<TtsFeedbackRuleEntity>,
        settings: NotiTrackSettings,
        exportedAt: Long = System.currentTimeMillis()
    ): String {
        val root = linkedMapOf<String, Any?>(
            "app" to "NotiTrack",
            "schemaVersion" to CURRENT_SCHEMA_VERSION,
            "exportedAt" to exportedAt
        )

        if (selection.includeNotifications) {
            root["notifications"] = notifications.map { n ->
                linkedMapOf<String, Any?>(
                    "packageName" to n.packageName,
                    "appName" to n.appName,
                    "title" to n.title,
                    "content" to n.content,
                    "subText" to n.subText,
                    "conversationTitle" to n.conversationTitle,
                    "timestamp" to n.timestamp,
                    "notificationKey" to n.notificationKey,
                    "category" to n.category,
                    "isRead" to n.isRead,
                    "isStarred" to n.isStarred,
                    "isHighlighted" to n.isHighlighted,
                    "isHidden" to n.isHidden,
                    "matchedKeywords" to n.matchedKeywords,
                    "wasSpoken" to n.wasSpoken,
                    "detectedOtp" to n.detectedOtp
                )
            }
        }

        if (selection.includeAppRules) {
            root["appRules"] = appRules.map { r ->
                linkedMapOf<String, Any?>(
                    "packageName" to r.packageName,
                    "appName" to r.appName,
                    "captureEnabled" to r.captureEnabled,
                    "readAloudEnabled" to r.readAloudEnabled,
                    "autoDismissEnabled" to r.autoDismissEnabled,
                    "smartTtsEnabled" to r.smartTtsEnabled,
                    "ttsHideBalance" to r.ttsHideBalance,
                    "ttsFilterMode" to r.ttsFilterMode,
                    "ttsNumberReadMode" to r.ttsNumberReadMode,
                    "ttsAutoBoostVolume" to r.ttsAutoBoostVolume,
                    "ttsCustomTemplate" to r.ttsCustomTemplate,
                    "ttsNumericRatioPercent" to r.ttsNumericRatioPercent,
                    "updatedAt" to r.updatedAt
                )
            }
        }

        if (selection.includeKeywordRules) {
            root["keywordRules"] = keywordRules.map { k ->
                linkedMapOf<String, Any?>(
                    "keywords" to k.keywords,
                    "action" to k.action.name,
                    "targetPackage" to k.targetPackage,
                    "targetAppName" to k.targetAppName,
                    "isCaseSensitive" to k.isCaseSensitive,
                    "isRegex" to k.isRegex,
                    "isEnabled" to k.isEnabled,
                    "matchCount" to k.matchCount,
                    "createdAt" to k.createdAt
                )
            }
        }

        if (selection.includeTtsFeedback) {
            root["ttsFeedbackRules"] = ttsFeedbackRules.map { f ->
                linkedMapOf<String, Any?>(
                    "packageName" to f.packageName,
                    "appName" to f.appName,
                    "patternFingerprint" to f.patternFingerprint,
                    "titleSignature" to f.titleSignature,
                    "samplePreview" to f.samplePreview,
                    "shouldSpeak" to f.shouldSpeak,
                    "matchCount" to f.matchCount,
                    "createdAt" to f.createdAt
                )
            }
        }

        if (selection.includeSettings) {
            root["settings"] = linkedMapOf<String, Any?>(
                "autoLockSeconds" to settings.autoLockSeconds,
                "flagSecureEnabled" to settings.flagSecureEnabled,
                "ttsGlobalEnabled" to settings.ttsGlobalEnabled,
                "ttsSpeechRate" to settings.ttsSpeechRate.toDouble(),
                "ttsIncludeAppName" to settings.ttsIncludeAppName,
                "ttsSmartFilterGlobal" to settings.ttsSmartFilterGlobal,
                "ttsHideBalanceGlobal" to settings.ttsHideBalanceGlobal,
                "ttsOverrideVolumeEnabled" to settings.ttsOverrideVolumeEnabled,
                "ttsBypassSilentMode" to settings.ttsBypassSilentMode,
                "ttsCustomVolumePercent" to settings.ttsCustomVolumePercent,
                "ttsDelayBetweenMs" to settings.ttsDelayBetweenMs,
                "ttsOnlyWhenScreenOff" to settings.ttsOnlyWhenScreenOff,
                "ttsNumericRatioPercent" to settings.ttsNumericRatioPercent,
                "captureNewAppsByDefault" to settings.captureNewAppsByDefault,
                "retentionDays" to settings.retentionDays,
                "themeMode" to settings.themeMode.name,
                "defaultGroupedView" to settings.defaultGroupedView,
                "chatTimelineGroupingEnabled" to settings.chatTimelineGroupingEnabled,
                "appLanguage" to settings.appLanguage.code,
                "keepAliveEnabled" to settings.keepAliveEnabled,
                "keepAliveShowTemp" to settings.keepAliveShowTemp,
                "keepAliveShowLunar" to settings.keepAliveShowLunar,
                "keepAliveShowCount" to settings.keepAliveShowCount,
                "keepAliveShowBattery" to settings.keepAliveShowBattery,
                "keepAliveTheme" to settings.keepAliveTheme.name
            )
        }

        val sb = StringBuilder()
        writeJsonValue(sb, root, indent = 0)
        return sb.toString()
    }

    fun parseBackupJson(rawJson: String): Result<BackupPreview> = runCatching {
        val parsed = MiniJsonParser(rawJson).parseRoot()
        @Suppress("UNCHECKED_CAST")
        val root = parsed as? Map<String, Any?> ?: error("Root must be a JSON object")

        val schemaVersion = root.optInt("schemaVersion", 0)
        require(schemaVersion >= 1) { "Invalid NotiTrack backup schemaVersion" }
        val exportedAt = root.optLong("exportedAt", System.currentTimeMillis())

        val notifications = root.optObjectList("notifications")?.mapNotNull { o ->
            val pkg = o.optString("packageName", "").trim()
            if (pkg.isEmpty()) return@mapNotNull null
            NotificationEntity(
                id = 0L,
                packageName = pkg,
                appName = o.optString("appName", pkg),
                title = o.optString("title", ""),
                content = o.optString("content", ""),
                subText = o.optString("subText", ""),
                conversationTitle = o.optString("conversationTitle", ""),
                timestamp = o.optLong("timestamp", System.currentTimeMillis()),
                notificationKey = o.optString("notificationKey", ""),
                category = o.optString("category", ""),
                isRead = o.optBoolean("isRead", false),
                isStarred = o.optBoolean("isStarred", false),
                isHighlighted = o.optBoolean("isHighlighted", false),
                isHidden = o.optBoolean("isHidden", false),
                matchedKeywords = o.optString("matchedKeywords", ""),
                wasSpoken = o.optBoolean("wasSpoken", false),
                detectedOtp = o.optNullableString("detectedOtp")
            )
        }

        val appRules = root.optObjectList("appRules")?.mapNotNull { o ->
            val pkg = o.optString("packageName", "").trim()
            if (pkg.isEmpty()) return@mapNotNull null
            AppRuleEntity(
                packageName = pkg,
                appName = o.optString("appName", pkg),
                captureEnabled = o.optBoolean("captureEnabled", true),
                readAloudEnabled = o.optBoolean("readAloudEnabled", false),
                autoDismissEnabled = o.optBoolean("autoDismissEnabled", false),
                smartTtsEnabled = o.optBoolean("smartTtsEnabled", true),
                ttsHideBalance = o.optBoolean("ttsHideBalance", true),
                ttsFilterMode = o.optString("ttsFilterMode", TtsFilterMode.NUMERIC_ONLY.name),
                ttsNumberReadMode = o.optString("ttsNumberReadMode", TtsNumberReadMode.CONTEXT_AUTO.name),
                ttsAutoBoostVolume = o.optBoolean("ttsAutoBoostVolume", false),
                ttsCustomTemplate = o.optString("ttsCustomTemplate", ""),
                ttsNumericRatioPercent = o.optInt("ttsNumericRatioPercent", 0),
                updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
            )
        }

        val keywordRules = root.optObjectList("keywordRules")?.mapNotNull { o ->
            val kw = o.optString("keywords", "").trim()
            if (kw.isEmpty()) return@mapNotNull null
            val action = runCatching {
                KeywordAction.valueOf(o.optString("action", KeywordAction.HIGHLIGHT.name))
            }.getOrDefault(KeywordAction.HIGHLIGHT)
            KeywordRuleEntity(
                id = 0L,
                keywords = kw,
                action = action,
                targetPackage = o.optNullableString("targetPackage")?.takeIf { it.isNotBlank() },
                targetAppName = o.optNullableString("targetAppName")?.takeIf { it.isNotBlank() },
                isCaseSensitive = o.optBoolean("isCaseSensitive", false),
                isRegex = o.optBoolean("isRegex", false),
                isEnabled = o.optBoolean("isEnabled", true),
                matchCount = o.optInt("matchCount", 0),
                createdAt = o.optLong("createdAt", System.currentTimeMillis())
            )
        }

        val ttsFeedbackRules = root.optObjectList("ttsFeedbackRules")?.mapNotNull { o ->
            val pkg = o.optString("packageName", "").trim()
            val fp = o.optString("patternFingerprint", "").trim()
            if (pkg.isEmpty() || fp.isEmpty()) return@mapNotNull null
            TtsFeedbackRuleEntity(
                id = 0L,
                packageName = pkg,
                appName = o.optString("appName", pkg),
                patternFingerprint = fp,
                titleSignature = o.optString("titleSignature", ""),
                samplePreview = o.optString("samplePreview", ""),
                shouldSpeak = o.optBoolean("shouldSpeak", false),
                matchCount = o.optInt("matchCount", 0),
                createdAt = o.optLong("createdAt", System.currentTimeMillis())
            )
        }

        val settings = root.optObject("settings")?.let { o ->
            NotiTrackSettings(
                autoLockSeconds = o.optInt("autoLockSeconds", 30),
                flagSecureEnabled = o.optBoolean("flagSecureEnabled", false),
                ttsGlobalEnabled = o.optBoolean("ttsGlobalEnabled", false),
                ttsSpeechRate = o.optDouble("ttsSpeechRate", 1.0).toFloat().coerceIn(0.6f, 1.8f),
                ttsIncludeAppName = o.optBoolean("ttsIncludeAppName", true),
                ttsSmartFilterGlobal = o.optBoolean("ttsSmartFilterGlobal", true),
                ttsHideBalanceGlobal = o.optBoolean("ttsHideBalanceGlobal", true),
                ttsOverrideVolumeEnabled = o.optBoolean("ttsOverrideVolumeEnabled", false),
                ttsBypassSilentMode = o.optBoolean("ttsBypassSilentMode", false),
                ttsCustomVolumePercent = o.optInt("ttsCustomVolumePercent", 85).coerceIn(10, 100),
                ttsDelayBetweenMs = o.optInt("ttsDelayBetweenMs", 1500).coerceIn(500, 5000),
                ttsOnlyWhenScreenOff = o.optBoolean("ttsOnlyWhenScreenOff", false),
                ttsNumericRatioPercent = o.optInt("ttsNumericRatioPercent", 40).coerceIn(20, 70),
                captureNewAppsByDefault = o.optBoolean("captureNewAppsByDefault", true),
                retentionDays = o.optInt("retentionDays", 30),
                themeMode = runCatching {
                    ThemeMode.valueOf(o.optString("themeMode", ThemeMode.SYSTEM.name))
                }.getOrDefault(ThemeMode.SYSTEM),
                defaultGroupedView = o.optBoolean("defaultGroupedView", true),
                chatTimelineGroupingEnabled = o.optBoolean("chatTimelineGroupingEnabled", true),
                appLanguage = AppLanguage.fromCode(o.optString("appLanguage", AppLanguage.VIETNAMESE.code)),
                keepAliveEnabled = o.optBoolean("keepAliveEnabled", true),
                keepAliveShowTemp = o.optBoolean("keepAliveShowTemp", true),
                keepAliveShowLunar = o.optBoolean("keepAliveShowLunar", true),
                keepAliveShowCount = o.optBoolean("keepAliveShowCount", true),
                keepAliveShowBattery = o.optBoolean("keepAliveShowBattery", true),
                keepAliveTheme = runCatching {
                    KeepAliveNotifTheme.valueOf(o.optString("keepAliveTheme", KeepAliveNotifTheme.JADE.name))
                }.getOrDefault(KeepAliveNotifTheme.JADE)
            )
        }

        val payload = BackupPayload(
            schemaVersion = schemaVersion,
            exportedAt = exportedAt,
            notifications = notifications,
            appRules = appRules,
            keywordRules = keywordRules,
            ttsFeedbackRules = ttsFeedbackRules,
            settings = settings
        )

        BackupPreview(
            schemaVersion = schemaVersion,
            exportedAt = exportedAt,
            notificationCount = notifications?.size ?: 0,
            appRuleCount = appRules?.size ?: 0,
            keywordRuleCount = keywordRules?.size ?: 0,
            ttsFeedbackCount = ttsFeedbackRules?.size ?: 0,
            hasSettings = settings != null,
            payload = payload
        )
    }

    // ---- Lightweight JSON Serializer ----

    private fun writeJsonValue(sb: StringBuilder, value: Any?, indent: Int) {
        when (value) {
            null -> sb.append("null")
            is Boolean -> sb.append(if (value) "true" else "false")
            is Number -> sb.append(value.toString())
            is String -> writeEscapedString(sb, value)
            is Map<*, *> -> {
                if (value.isEmpty()) {
                    sb.append("{}")
                    return
                }
                sb.append("{\n")
                val entries = value.entries.toList()
                entries.forEachIndexed { idx, (k, v) ->
                    appendIndent(sb, indent + 2)
                    writeEscapedString(sb, k.toString())
                    sb.append(": ")
                    writeJsonValue(sb, v, indent + 2)
                    if (idx < entries.lastIndex) sb.append(',')
                    sb.append('\n')
                }
                appendIndent(sb, indent)
                sb.append('}')
            }
            is List<*> -> {
                if (value.isEmpty()) {
                    sb.append("[]")
                    return
                }
                sb.append("[\n")
                value.forEachIndexed { idx, item ->
                    appendIndent(sb, indent + 2)
                    writeJsonValue(sb, item, indent + 2)
                    if (idx < value.lastIndex) sb.append(',')
                    sb.append('\n')
                }
                appendIndent(sb, indent)
                sb.append(']')
            }
            else -> writeEscapedString(sb, value.toString())
        }
    }

    private fun appendIndent(sb: StringBuilder, spaces: Int) {
        repeat(spaces) { sb.append(' ') }
    }

    private fun writeEscapedString(sb: StringBuilder, text: String) {
        sb.append('"')
        for (ch in text) {
            when (ch) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> {
                    if (ch.code < 0x20) {
                        sb.append("\\u%04x".format(ch.code))
                    } else {
                        sb.append(ch)
                    }
                }
            }
        }
        sb.append('"')
    }

    // ---- Typed Map Accessors ----

    private fun Map<String, Any?>.optString(key: String, default: String): String {
        val v = this[key] ?: return default
        return v as? String ?: v.toString()
    }

    private fun Map<String, Any?>.optNullableString(key: String): String? {
        val v = this[key] ?: return null
        return v as? String ?: v.toString()
    }

    private fun Map<String, Any?>.optBoolean(key: String, default: Boolean): Boolean {
        return when (val v = this[key]) {
            is Boolean -> v
            is String -> v.toBooleanStrictOrNull() ?: default
            else -> default
        }
    }

    private fun Map<String, Any?>.optInt(key: String, default: Int): Int {
        return when (val v = this[key]) {
            is Number -> v.toInt()
            is String -> v.toIntOrNull() ?: default
            else -> default
        }
    }

    private fun Map<String, Any?>.optLong(key: String, default: Long): Long {
        return when (val v = this[key]) {
            is Number -> v.toLong()
            is String -> v.toLongOrNull() ?: default
            else -> default
        }
    }

    private fun Map<String, Any?>.optDouble(key: String, default: Double): Double {
        return when (val v = this[key]) {
            is Number -> v.toDouble()
            is String -> v.toDoubleOrNull() ?: default
            else -> default
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun Map<String, Any?>.optObject(key: String): Map<String, Any?>? {
        return this[key] as? Map<String, Any?>
    }

    @Suppress("UNCHECKED_CAST")
    private fun Map<String, Any?>.optObjectList(key: String): List<Map<String, Any?>>? {
        val list = this[key] as? List<*> ?: return null
        return list.mapNotNull { it as? Map<String, Any?> }
    }

    // ---- Minimal RFC 8259 Recursive-Descent JSON Parser ----

    private class MiniJsonParser(private val src: String) {
        private var pos = 0

        fun parseRoot(): Any? {
            skipWhitespace()
            val value = parseValue()
            skipWhitespace()
            require(pos == src.length) { "Unexpected trailing content at index $pos" }
            return value
        }

        private fun parseValue(): Any? {
            skipWhitespace()
            if (pos >= src.length) error("Unexpected end of JSON input")
            return when (src[pos]) {
                '{' -> parseObject()
                '[' -> parseArray()
                '"' -> parseString()
                't' -> parseLiteral("true", true)
                'f' -> parseLiteral("false", false)
                'n' -> parseLiteral("null", null)
                '-', in '0'..'9' -> parseNumber()
                else -> error("Unexpected token '${src[pos]}' at index $pos")
            }
        }

        private fun parseObject(): Map<String, Any?> {
            expect('{')
            val map = linkedMapOf<String, Any?>()
            skipWhitespace()
            if (peek() == '}') {
                pos++
                return map
            }
            while (true) {
                skipWhitespace()
                val key = parseString()
                skipWhitespace()
                expect(':')
                val value = parseValue()
                map[key] = value
                skipWhitespace()
                when (peek()) {
                    ',' -> pos++
                    '}' -> {
                        pos++
                        return map
                    }
                    else -> error("Expected ',' or '}' in object at index $pos")
                }
            }
        }

        private fun parseArray(): List<Any?> {
            expect('[')
            val list = mutableListOf<Any?>()
            skipWhitespace()
            if (peek() == ']') {
                pos++
                return list
            }
            while (true) {
                list.add(parseValue())
                skipWhitespace()
                when (peek()) {
                    ',' -> pos++
                    ']' -> {
                        pos++
                        return list
                    }
                    else -> error("Expected ',' or ']' in array at index $pos")
                }
            }
        }

        private fun parseString(): String {
            expect('"')
            val sb = StringBuilder()
            while (pos < src.length) {
                val ch = src[pos++]
                when (ch) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (pos >= src.length) error("Unterminated escape sequence")
                        when (val esc = src[pos++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (pos + 4 > src.length) error("Invalid unicode escape")
                                val hex = src.substring(pos, pos + 4)
                                sb.append(hex.toInt(16).toChar())
                                pos += 4
                            }
                            else -> error("Invalid escape '\\$esc'")
                        }
                    }
                    else -> sb.append(ch)
                }
            }
            error("Unterminated JSON string")
        }

        private fun parseNumber(): Number {
            val start = pos
            if (peek() == '-') pos++
            while (pos < src.length && src[pos] in '0'..'9') pos++
            var isFloat = false
            if (peek() == '.') {
                isFloat = true
                pos++
                while (pos < src.length && src[pos] in '0'..'9') pos++
            }
            if (peek() == 'e' || peek() == 'E') {
                isFloat = true
                pos++
                if (peek() == '+' || peek() == '-') pos++
                while (pos < src.length && src[pos] in '0'..'9') pos++
            }
            val token = src.substring(start, pos)
            return if (isFloat) token.toDouble() else token.toLong()
        }

        private fun parseLiteral(expected: String, result: Any?): Any? {
            if (src.startsWith(expected, pos)) {
                pos += expected.length
                return result
            }
            error("Expected '$expected' at index $pos")
        }

        private fun expect(ch: Char) {
            if (pos >= src.length || src[pos] != ch) {
                error("Expected '$ch' at index $pos")
            }
            pos++
        }

        private fun peek(): Char? = if (pos < src.length) src[pos] else null

        private fun skipWhitespace() {
            while (pos < src.length && src[pos].isWhitespace()) pos++
        }
    }
}
