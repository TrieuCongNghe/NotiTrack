package com.example.engine

import kotlin.math.sqrt

enum class AntiTheftTriggerReason {
    CHARGER_UNPLUGGED,
    DEVICE_MOVED
}

enum class MotionSensitivity(
    val level: Int,
    val labelVi: String,
    val labelEn: String,
    val linearThresholdMps2: Float
) {
    LOW(1, "Nhẹ (chống rung nhỏ)", "Low (firm movement)", 3.8f),
    MEDIUM(2, "Vừa (Khuyên dùng)", "Medium (Recommended)", 2.2f),
    HIGH(3, "Nhạy (cầm lên là báo)", "High (instant pickup)", 1.25f);

    companion object {
        fun fromLevel(level: Int): MotionSensitivity =
            entries.firstOrNull { it.level == level } ?: MEDIUM
    }
}

data class GuardTelemetrySnapshot(
    val batteryPercent: Int,
    val isCharging: Boolean,
    val tempCelsius: Float,
    val nowMs: Long
)

data class DeviceGuardConfig(
    val lowBatteryEnabled: Boolean = false,
    val lowBatteryThreshold: Int = 20,
    val chargingAlertEnabled: Boolean = false,
    val chargingAlertThreshold: Int = 80,
    val fullChargeEnabled: Boolean = false,
    val fullChargeThreshold: Int = 100,
    val fullChargeExtraMinutes: Int = 15,
    val overheatEnabled: Boolean = false,
    val overheatThresholdC: Int = 42,
    val overheatCooldownSeconds: Int = 120,
    val chargeGuardEnabled: Boolean = false,
    val chargeGuardMinBatteryPercent: Int = 0,
    val chargeGuardDelaySeconds: Int = 3,
    val chargeGuardConfirmDialogEnabled: Boolean = true,
    val chargeGuardConfirmSeconds: Int = 15,
    val motionGuardEnabled: Boolean = false,
    val motionGuardSensitivity: Int = MotionSensitivity.MEDIUM.level,
    val motionGuardArmDelaySeconds: Int = 5,
    val motionGuardConfirmDialogEnabled: Boolean = true,
    val motionGuardConfirmSeconds: Int = 15
)

sealed interface DeviceGuardEvent {
    data class LowBatteryAlert(val batteryPercent: Int, val threshold: Int) : DeviceGuardEvent
    data class ChargingLevelAlert(val batteryPercent: Int, val threshold: Int) : DeviceGuardEvent
    data class FullChargeAlert(val batteryPercent: Int, val threshold: Int, val extraMinutesWaited: Int) : DeviceGuardEvent
    data class OverheatAlert(val tempCelsius: Float, val thresholdC: Int) : DeviceGuardEvent
    data class ChargerGuardUnplugged(
        val delaySeconds: Int,
        val confirmDialogEnabled: Boolean,
        val confirmSeconds: Int
    ) : DeviceGuardEvent
    data object ChargerReconnected : DeviceGuardEvent
}

/**
 * Pure-Kotlin state machine for battery alerts, 100% extra-minute "soak" timer,
 * overheat cooldown throttling, charging anti-theft arming/unplugging, and motion detection.
 */
class DeviceGuardEngine {

    private var lowBatteryAlerted = false
    private var chargingLevelAlerted = false
    private var fullChargeAlerted = false
    private var reached100ChargingAtMs: Long? = null
    private var lastOverheatAlertAtMs: Long = 0L

    private var wasCharging: Boolean? = null
    var isChargeGuardArmed: Boolean = false
        private set

    fun evaluateTelemetry(
        snapshot: GuardTelemetrySnapshot,
        config: DeviceGuardConfig
    ): List<DeviceGuardEvent> {
        val events = mutableListOf<DeviceGuardEvent>()
        val pct = snapshot.batteryPercent.coerceIn(0, 100)
        val charging = snapshot.isCharging
        val now = snapshot.nowMs

        // 1. Low battery alert (fires once per discharge below threshold; resets when charging or +3% above)
        if (config.lowBatteryEnabled) {
            if (!charging && pct <= config.lowBatteryThreshold) {
                if (!lowBatteryAlerted) {
                    lowBatteryAlerted = true
                    events += DeviceGuardEvent.LowBatteryAlert(pct, config.lowBatteryThreshold)
                }
            } else if (charging || pct >= (config.lowBatteryThreshold + 3).coerceAtMost(100)) {
                lowBatteryAlerted = false
            }
        } else {
            lowBatteryAlerted = false
        }

        // 2. Charging target level alert (fires once per charge cycle when reaching >= threshold)
        if (config.chargingAlertEnabled && charging) {
            if (pct >= config.chargingAlertThreshold) {
                if (!chargingLevelAlerted) {
                    chargingLevelAlerted = true
                    events += DeviceGuardEvent.ChargingLevelAlert(pct, config.chargingAlertThreshold)
                }
            } else if (pct <= (config.chargingAlertThreshold - 3).coerceAtLeast(0)) {
                chargingLevelAlerted = false
            }
        } else {
            chargingLevelAlerted = false
        }

        // 3. Full charge alert (supports extra minutes soak timer when threshold == 100%)
        if (config.fullChargeEnabled && charging) {
            val target = config.fullChargeThreshold.coerceIn(80, 100)
            if (pct >= target) {
                val extraMins = if (target == 100) config.fullChargeExtraMinutes.coerceIn(0, 60) else 0
                if (extraMins <= 0) {
                    if (!fullChargeAlerted) {
                        fullChargeAlerted = true
                        events += DeviceGuardEvent.FullChargeAlert(pct, target, 0)
                    }
                } else {
                    val startMs = reached100ChargingAtMs ?: now.also { reached100ChargingAtMs = it }
                    val elapsedMs = (now - startMs).coerceAtLeast(0L)
                    if (!fullChargeAlerted && elapsedMs >= extraMins * 60_000L) {
                        fullChargeAlerted = true
                        events += DeviceGuardEvent.FullChargeAlert(pct, target, extraMins)
                    }
                }
            } else {
                reached100ChargingAtMs = null
                if (pct <= (target - 3).coerceAtLeast(0)) {
                    fullChargeAlerted = false
                }
            }
        } else {
            reached100ChargingAtMs = null
            fullChargeAlerted = false
        }

        // 4. Overheat temperature alert with customizable repeat cooldown
        if (config.overheatEnabled && snapshot.tempCelsius >= config.overheatThresholdC.toFloat()) {
            val cooldownMs = config.overheatCooldownSeconds.coerceIn(15, 3600) * 1_000L
            if (lastOverheatAlertAtMs == 0L || (now - lastOverheatAlertAtMs) >= cooldownMs) {
                lastOverheatAlertAtMs = now
                events += DeviceGuardEvent.OverheatAlert(snapshot.tempCelsius, config.overheatThresholdC)
            }
        } else if (!config.overheatEnabled || snapshot.tempCelsius < (config.overheatThresholdC - 2f)) {
            if (!config.overheatEnabled) lastOverheatAlertAtMs = 0L
        }

        // 5. Charging Anti-Theft Guard arm/unplug state machine
        val prevCharging = wasCharging
        wasCharging = charging
        if (config.chargeGuardEnabled) {
            if (charging) {
                if (prevCharging == false) {
                    events += DeviceGuardEvent.ChargerReconnected
                }
                if (pct >= config.chargeGuardMinBatteryPercent.coerceIn(0, 100)) {
                    isChargeGuardArmed = true
                }
            } else {
                // Transitioned from armed+charging -> unplugged!
                if (isChargeGuardArmed && prevCharging == true) {
                    isChargeGuardArmed = false
                    events += DeviceGuardEvent.ChargerGuardUnplugged(
                        delaySeconds = config.chargeGuardDelaySeconds.coerceIn(0, 30),
                        confirmDialogEnabled = config.chargeGuardConfirmDialogEnabled,
                        confirmSeconds = clampConfirmSeconds(config.chargeGuardConfirmSeconds)
                    )
                } else if (!charging) {
                    isChargeGuardArmed = false
                }
            }
        } else {
            isChargeGuardArmed = false
        }

        return events
    }

    /**
     * Checks if the 100% extra-minutes soak timer has matured even if battery % hasn't changed.
     */
    fun checkFullChargeTimerTick(
        isCharging: Boolean,
        batteryPercent: Int,
        nowMs: Long,
        config: DeviceGuardConfig
    ): DeviceGuardEvent.FullChargeAlert? {
        if (!config.fullChargeEnabled || !isCharging || fullChargeAlerted) return null
        val target = config.fullChargeThreshold.coerceIn(80, 100)
        if (target != 100 || batteryPercent < 100) return null
        val extraMins = config.fullChargeExtraMinutes.coerceIn(0, 60)
        if (extraMins <= 0) return null
        val startMs = reached100ChargingAtMs ?: return null
        return if ((nowMs - startMs) >= extraMins * 60_000L) {
            fullChargeAlerted = true
            DeviceGuardEvent.FullChargeAlert(batteryPercent, target, extraMins)
        } else {
            null
        }
    }

    fun resetChargeGuardArm() {
        isChargeGuardArmed = false
    }

    companion object {
        const val MIN_CONFIRM_SECONDS = 5
        const val MAX_CONFIRM_SECONDS = 120

        fun clampConfirmSeconds(seconds: Int): Int =
            seconds.coerceIn(MIN_CONFIRM_SECONDS, MAX_CONFIRM_SECONDS)

        /**
         * Computes linear acceleration magnitude (m/s^2) and checks against sensitivity threshold.
         */
        fun exceedsMotionThreshold(
            ax: Float,
            ay: Float,
            az: Float,
            sensitivity: MotionSensitivity
        ): Boolean {
            val magnitude = sqrt((ax * ax + ay * ay + az * az).toDouble()).toFloat()
            return magnitude >= sensitivity.linearThresholdMps2
        }
    }
}
