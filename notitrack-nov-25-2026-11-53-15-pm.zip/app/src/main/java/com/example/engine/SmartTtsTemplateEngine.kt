package com.example.engine

/**
 * Handles:
 * 1. Numeric-only message filtering (separates balance/transaction alerts from promo ads).
 * 2. Interactive highlight template serialization & dynamic extraction for future notifications.
 */
object SmartTtsTemplateEngine {

    const val DEFAULT_NUMERIC_RATIO_PERCENT = 40
    const val MIN_NUMERIC_RATIO_PERCENT = 20
    const val MAX_NUMERIC_RATIO_PERCENT = 70

    private val TOKEN_SPLIT_REGEX = Regex("""[^\s|]+""")
    private val DIGIT_REGEX = Regex("""\d""")
    private val PUNCT_ONLY_REGEX = Regex("""^[^\p{L}\p{N}]+$""")
    private val CURRENCY_ONLY_TOKEN_REGEX = Regex(
        """(?i)^[+\-]?(?:vnđ|vnd|đồng|dong|đ|usd|\$|€|eur|¥|jpy|원|krw)$"""
    )

    data class TemplateSpan(
        val startIndex: Int,
        val endIndex: Int,
        val leftAnchor: String,
        val rightAnchor: String,
        val sampleText: String
    )

    data class ParsedTemplate(
        val sampleText: String,
        val selectedIndices: List<Int>,
        val spans: List<TemplateSpan>
    )

    /**
     * Calculates what percentage (0..100) of the notification's meaningful content consists of
     * numeric values, amounts (including adjacent currency codes like "VND 550,000"),
     * masked/full account numbers ("00xxx456", "9997777999"), transaction codes ("FT263235..."),
     * dates ("19/11/26"), times ("18:28"), and OTP codes.
     */
    fun calculateNumericRatioPercent(title: String, content: String): Int {
        val combined = listOf(title.trim(), content.trim())
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(" ")
        if (combined.isBlank()) return 0

        val rawTokens = TOKEN_SPLIT_REGEX.findAll(combined)
            .map { it.value.trim(',', '.', ';', ':', '(', ')', '[', ']', '"', '\'', '!', '?') }
            .filter { it.isNotEmpty() && !PUNCT_ONLY_REGEX.matches(it) }
            .toList()
        if (rawTokens.isEmpty()) return 0

        val isNumericToken = BooleanArray(rawTokens.size) { idx ->
            DIGIT_REGEX.containsMatchIn(rawTokens[idx])
        }

        // Count pure currency codes ("VND", "USD", "đ", "$") adjacent to a number as part of the money amount
        for (i in rawTokens.indices) {
            if (!isNumericToken[i] && CURRENCY_ONLY_TOKEN_REGEX.matches(rawTokens[i])) {
                val prevNum = i > 0 && isNumericToken[i - 1]
                val nextNum = i + 1 < rawTokens.size && isNumericToken[i + 1]
                if (prevNum || nextNum) {
                    isNumericToken[i] = true
                }
            }
        }

        var numericChars = 0
        var totalChars = 0
        for (i in rawTokens.indices) {
            val tokenLen = rawTokens[i].length
            totalChars += tokenLen
            if (isNumericToken[i]) {
                numericChars += tokenLen
            }
        }
        if (totalChars <= 0) return 0
        return ((numericChars * 100.0) / totalChars).toInt().coerceIn(0, 100)
    }

    /**
     * Returns true when a notification's numeric density meets or exceeds the configured
     * threshold (default 40%, range 20%–70%), cleanly separating bank/balance/OTP alerts
     * from marketing/promotional ads.
     */
    fun passesNumericOnlyFilter(
        title: String,
        content: String,
        thresholdPercent: Int = DEFAULT_NUMERIC_RATIO_PERCENT
    ): Boolean {
        val combined = "$title $content".trim()
        if (combined.isBlank() || !DIGIT_REGEX.containsMatchIn(combined)) return false
        val clampedThreshold = thresholdPercent.coerceIn(MIN_NUMERIC_RATIO_PERCENT, MAX_NUMERIC_RATIO_PERCENT)
        return calculateNumericRatioPercent(title, content) >= clampedThreshold
    }

    fun tokenize(text: String): List<String> {
        return TOKEN_SPLIT_REGEX.findAll(text.trim()).map { it.value }.toList()
    }

    fun buildSerializedTemplate(sampleText: String, selectedIndices: Set<Int>): String {
        val tokens = tokenize(sampleText)
        val sorted = selectedIndices.filter { it in tokens.indices }.sorted()
        if (sorted.isEmpty()) return ""

        val spans = groupContiguousIndices(sorted).map { (start, end) ->
            val left = tokens.getOrNull(start - 1)?.let(::normalizeAnchor).orEmpty()
            val right = tokens.getOrNull(end + 1)?.let(::normalizeAnchor).orEmpty()
            val snippet = tokens.subList(start, end + 1).joinToString(" ")
            TemplateSpan(start, end, left, right, snippet)
        }

        val indicesPart = sorted.joinToString(",")
        val spansPart = spans.joinToString(";;") { span ->
            listOf(
                span.startIndex.toString(),
                span.endIndex.toString(),
                escape(span.leftAnchor),
                escape(span.rightAnchor),
                escape(span.sampleText)
            ).joinToString("::")
        }
        return "v1||$indicesPart||$spansPart||${escape(sampleText)}"
    }

    fun parseTemplate(serialized: String): ParsedTemplate? {
        if (!serialized.startsWith("v1||")) return null
        val parts = serialized.split("||", limit = 4)
        if (parts.size < 4) return null

        val indices = parts[1].split(",").mapNotNull { it.toIntOrNull() }
        if (indices.isEmpty()) return null

        val spans = parts[2].split(";;").mapNotNull { rawSpan ->
            val fields = rawSpan.split("::", limit = 5)
            if (fields.size < 5) return@mapNotNull null
            val start = fields[0].toIntOrNull() ?: return@mapNotNull null
            val end = fields[1].toIntOrNull() ?: return@mapNotNull null
            TemplateSpan(
                startIndex = start,
                endIndex = end,
                leftAnchor = unescape(fields[2]),
                rightAnchor = unescape(fields[3]),
                sampleText = unescape(fields[4])
            )
        }
        if (spans.isEmpty()) return null
        return ParsedTemplate(
            sampleText = unescape(parts[3]),
            selectedIndices = indices,
            spans = spans
        )
    }

    /**
     * Dynamically applies a user-highlighted template to a new incoming notification.
     * Matches static anchors around highlighted slots first, falling back to token positions.
     */
    fun applyTemplate(serializedTemplate: String, incomingText: String): String? {
        val parsed = parseTemplate(serializedTemplate) ?: return null
        val incomingTokens = tokenize(incomingText)
        if (incomingTokens.isEmpty()) return null

        val extractedParts = mutableListOf<String>()
        var searchCursor = 0

        for (span in parsed.spans) {
            val expectedLen = (span.endIndex - span.startIndex + 1).coerceAtLeast(1)
            val matched = extractSpan(incomingTokens, span, expectedLen, searchCursor)
            if (matched != null) {
                val (text, nextCursor) = matched
                if (text.isNotBlank()) {
                    extractedParts.add(text)
                }
                searchCursor = nextCursor
            }
        }

        val result = extractedParts.joinToString(" ").replace(Regex("\\s+"), " ").trim()
        return result.ifBlank { null }
    }

    private fun extractSpan(
        tokens: List<String>,
        span: TemplateSpan,
        expectedLen: Int,
        searchFrom: Int
    ): Pair<String, Int>? {
        val leftAnchor = span.leftAnchor
        val rightAnchor = span.rightAnchor

        // Strategy 1: Match left anchor (and optional right anchor)
        if (leftAnchor.isNotEmpty()) {
            val leftIdx = findAnchorIndex(tokens, leftAnchor, searchFrom)
            if (leftIdx >= 0 && leftIdx + 1 < tokens.size) {
                val start = leftIdx + 1
                val endExclusive = if (rightAnchor.isNotEmpty()) {
                    val rightIdx = findAnchorIndex(tokens, rightAnchor, start)
                    if (rightIdx > start && (rightIdx - start) <= expectedLen + 6) {
                        rightIdx
                    } else {
                        (start + expectedLen).coerceAtMost(tokens.size)
                    }
                } else {
                    (start + expectedLen).coerceAtMost(tokens.size)
                }
                if (endExclusive > start) {
                    return tokens.subList(start, endExclusive).joinToString(" ") to endExclusive
                }
            }
        }

        // Strategy 2: Match right anchor alone
        if (rightAnchor.isNotEmpty()) {
            val rightIdx = findAnchorIndex(tokens, rightAnchor, searchFrom)
            if (rightIdx > 0) {
                val start = (rightIdx - expectedLen).coerceAtLeast(searchFrom)
                if (rightIdx > start) {
                    return tokens.subList(start, rightIdx).joinToString(" ") to rightIdx
                }
            }
        }

        // Strategy 3: Positional fallback when notification structure matches sample
        if (span.startIndex in tokens.indices) {
            val endExclusive = (span.endIndex + 1).coerceAtMost(tokens.size)
            if (endExclusive > span.startIndex) {
                return tokens.subList(span.startIndex, endExclusive).joinToString(" ") to endExclusive
            }
        }

        return null
    }

    private fun findAnchorIndex(tokens: List<String>, anchor: String, fromIndex: Int): Int {
        for (i in fromIndex.coerceAtLeast(0) until tokens.size) {
            if (normalizeAnchor(tokens[i]).equals(anchor, ignoreCase = true)) {
                return i
            }
        }
        return -1
    }

    private fun normalizeAnchor(token: String): String {
        val trimmed = token.trim()
        // Pure dynamic numbers/amounts should not act as fixed text anchors
        if (Regex("""^[+\-]?[\d.,:/%]+$""").matches(trimmed)) return ""
        return trimmed.trim(',', '.', ';', '(', ')', '[', ']')
    }

    private fun groupContiguousIndices(sorted: List<Int>): List<Pair<Int, Int>> {
        val result = mutableListOf<Pair<Int, Int>>()
        var start = sorted.first()
        var prev = start
        for (i in 1 until sorted.size) {
            val cur = sorted[i]
            if (cur == prev + 1) {
                prev = cur
            } else {
                result.add(start to prev)
                start = cur
                prev = cur
            }
        }
        result.add(start to prev)
        return result
    }

    private fun escape(value: String): String = value
        .replace("%", "%25")
        .replace("|", "%7C")
        .replace(";", "%3B")
        .replace(":", "%3A")

    private fun unescape(value: String): String = value
        .replace("%3A", ":")
        .replace("%3B", ";")
        .replace("%7C", "|")
        .replace("%25", "%")
}
