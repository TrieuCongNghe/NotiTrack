package com.example.engine

import com.example.data.model.TtsFeedbackRuleEntity
import java.util.Locale

/**
 * Offline pattern-learning engine for user TTS feedback ("Should Speak" / "Do Not Speak").
 * Normalizes dynamic values (amounts, dates, times, account numbers, transaction IDs, sender memos)
 * into structural placeholders so future notifications with the same template match reliably.
 */
object TtsFeedbackEngine {

    private const val SIMILARITY_THRESHOLD = 0.65
    private const val SAME_TITLE_SIMILARITY_THRESHOLD = 0.50

    private val URL_REGEX = Regex("""https?://\S+|www\.\S+""", RegexOption.IGNORE_CASE)
    private val SENDER_PIPE_REGEX = Regex(
        """(?i)(?:^|(?<=\|))\s*(?:từ|tu|from|người\s*gửi|nguoi\s*gui)\s*[:\-]\s*[^|\n]+"""
    )
    private val MEMO_PIPE_REGEX = Regex(
        """(?i)(?:^|(?<=\|))\s*(?:nd|nội\s*dung|noi\s*dung|memo|diễn\s*giải|dien\s*giai|chi\s*tiết|chi\s*tiet)\s*[:\-]\s*[^|\n]+"""
    )
    private val AMOUNT_REGEX = Regex(
        """(?i)(?:[+\-]\s*)?(?:(?:vnđ|vnd|đ|usd|\$|€|eur|¥|jpy|krw)\s*\d[\d.,]*|\d{1,3}(?:[.,]\d{3})+(?:\s*(?:vnđ|vnd|đ|d|usd|\$|€|eur|¥|jpy|krw))?|\d+(?:[.,]\d{1,2})?\s*(?:vnđ|vnd|đ|usd|\$|€|eur|¥|jpy|krw|k\b|tr\b))"""
    )
    private val DATE_REGEX = Regex("""\b\d{1,4}[/\-]\d{1,2}(?:[/\-]\d{2,4})?\b""")
    private val TIME_REGEX = Regex("""\b\d{1,2}:\d{2}(?::\d{2})?\b""")
    private val MASKED_ACCOUNT_REGEX = Regex("""(?i)\b(?:\*{2,}\d{2,}|\d{2,}[x*]{2,}\d{2,}|[x*]{2,}\d{2,})\b""")
    private val MIXED_CODE_REGEX = Regex(
        """(?i)\b(?=[a-z0-9\-_/]{5,}\b)(?=[a-z\-_/]*\d)(?=\d*[a-z])[a-z0-9\-_/]{5,}\b"""
    )
    private val NUMBER_REGEX = Regex("""\b\d+(?:[.,]\d+)?%?\b""")
    private val PUNCT_CLEAN_REGEX = Regex("""[^\p{L}\p{N}<>\s]""")
    private val MULTI_SPACE_REGEX = Regex("""\s+""")

    fun normalizeText(raw: String): String {
        if (raw.isBlank()) return ""
        return raw
            .trim()
            .replace(URL_REGEX, " <URL> ")
            .replace(SENDER_PIPE_REGEX, " tu <SENDER> ")
            .replace(MEMO_PIPE_REGEX, " nd <MEMO> ")
            .replace(DATE_REGEX, " <DATE> ")
            .replace(TIME_REGEX, " <TIME> ")
            .replace(MASKED_ACCOUNT_REGEX, " <ACCT> ")
            .replace(AMOUNT_REGEX, " <AMT> ")
            .replace(MIXED_CODE_REGEX, " <CODE> ")
            .replace(NUMBER_REGEX, " <NUM> ")
            .lowercase(Locale.getDefault())
            .replace(PUNCT_CLEAN_REGEX, " ")
            .replace(MULTI_SPACE_REGEX, " ")
            .trim()
    }

    fun buildFingerprint(title: String, content: String): String {
        val combined = listOf(title.trim(), content.trim())
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(" | ")
        return normalizeText(combined).take(280)
    }

    fun buildTitleSignature(title: String): String {
        return normalizeText(title).take(120)
    }

    fun buildSamplePreview(title: String, content: String): String {
        val t = title.trim()
        val c = content.trim()
        val combined = when {
            t.isBlank() -> c
            c.isBlank() || c.equals(t, ignoreCase = true) -> t
            else -> "$t — $c"
        }
        return combined.replace(Regex("\\s+"), " ").trim().take(140)
    }

    fun findBestMatch(
        packageName: String,
        title: String,
        content: String,
        rules: List<TtsFeedbackRuleEntity>
    ): TtsFeedbackRuleEntity? {
        val appRules = rules.filter { it.packageName == packageName }
        if (appRules.isEmpty()) return null

        val incomingFp = buildFingerprint(title, content)
        if (incomingFp.isBlank()) return null

        // Priority 1: Exact normalized fingerprint match (most recently created wins)
        appRules
            .filter { it.patternFingerprint == incomingFp }
            .maxByOrNull { it.createdAt }
            ?.let { return it }

        // Priority 2: Token Jaccard similarity on normalized fingerprint
        val incomingTokens = tokenizeForSimilarity(incomingFp)
        if (incomingTokens.isEmpty()) return null
        val incomingTitleSig = buildTitleSignature(title)

        var bestRule: TtsFeedbackRuleEntity? = null
        var bestScore = 0.0

        for (rule in appRules) {
            val ruleTokens = tokenizeForSimilarity(rule.patternFingerprint)
            if (ruleTokens.isEmpty()) continue
            val similarity = jaccardSimilarity(incomingTokens, ruleTokens)
            val sameTitle = incomingTitleSig.isNotBlank() &&
                rule.titleSignature.isNotBlank() &&
                incomingTitleSig == rule.titleSignature
            val requiredThreshold = if (sameTitle) SAME_TITLE_SIMILARITY_THRESHOLD else SIMILARITY_THRESHOLD

            if (similarity >= requiredThreshold) {
                val isBetter = bestRule == null ||
                    similarity > bestScore + 0.01 ||
                    (kotlin.math.abs(similarity - bestScore) <= 0.01 && rule.createdAt > bestRule.createdAt)
                if (isBetter) {
                    bestScore = similarity
                    bestRule = rule
                }
            }
        }
        return bestRule
    }

    private fun tokenizeForSimilarity(normalized: String): Set<String> {
        return normalized
            .split(' ')
            .map { it.trim() }
            .filter { it.length >= 2 }
            .toSet()
    }

    private fun jaccardSimilarity(a: Set<String>, b: Set<String>): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val intersection = a.count { it in b }
        val union = a.size + b.size - intersection
        return if (union == 0) 0.0 else intersection.toDouble() / union.toDouble()
    }
}
