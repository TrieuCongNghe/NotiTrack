package com.example.engine

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.model.TtsNumberReadMode
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.stringsFor
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.roundToInt

data class TtsVolumeConfig(
    val overrideVolume: Boolean = false,
    val bypassSilentMode: Boolean = false,
    val volumePercent: Int = 85,
    val autoBoostVolume: Boolean = false,
    val interSpeechDelayMs: Int = 1500
)

class NotificationSpeaker(context: Context) {

    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val exceptionHandler = CoroutineExceptionHandler { _, _ -> }
    private val speakerScope = CoroutineScope(SupervisorJob() + Dispatchers.Default + exceptionHandler)

    private var tts: TextToSpeech? = null
    @Volatile
    private var isReady: Boolean = false
    @Volatile
    private var readySignal = CompletableDeferred<Boolean>()

    private val queueLock = Any()
    private val speechQueue = ArrayDeque<QueuedUtterance>()
    private val wakeSignal = Channel<Unit>(Channel.CONFLATED)
    private val activeUtterances = ConcurrentHashMap<String, CompletableDeferred<Unit>>()

    @Volatile
    private var savedStreamType: Int? = null
    @Volatile
    private var savedStreamVolume: Int? = null
    @Volatile
    private var currentFocusRequest: AudioFocusRequest? = null

    private data class QueuedUtterance(
        val text: String,
        val rate: Float,
        val notificationId: Long?,
        val language: AppLanguage,
        val volumeConfig: TtsVolumeConfig
    )

    private val _speakingNotificationId = MutableStateFlow<Long?>(null)
    val speakingNotificationId: StateFlow<Long?> = _speakingNotificationId.asStateFlow()

    init {
        initTts()
        startQueueWorker()
    }

    private fun initTts() {
        val signal = CompletableDeferred<Boolean>()
        readySignal = signal
        isReady = false
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                applyLocale(AppLanguage.VIETNAMESE)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit

                    override fun onDone(utteranceId: String?) {
                        utteranceId?.let { activeUtterances.remove(it)?.complete(Unit) }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        utteranceId?.let { activeUtterances.remove(it)?.complete(Unit) }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        utteranceId?.let { activeUtterances.remove(it)?.complete(Unit) }
                    }

                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        utteranceId?.let { activeUtterances.remove(it)?.complete(Unit) }
                    }
                })
                isReady = true
                signal.complete(true)
            } else {
                isReady = false
                signal.complete(false)
            }
        }
    }

    private fun startQueueWorker() {
        speakerScope.launch {
            while (true) {
                val next = pollNext()
                if (next == null) {
                    wakeSignal.receive()
                    continue
                }

                if (!isReady) {
                    val ok = withTimeoutOrNull(6_000L) { readySignal.await() } ?: false
                    if (!ok) {
                        initTts()
                        val retryOk = withTimeoutOrNull(6_000L) { readySignal.await() } ?: false
                        if (!retryOk) {
                            _speakingNotificationId.value = null
                            continue
                        }
                    }
                }

                val delayMs = next.volumeConfig.interSpeechDelayMs.coerceIn(500, 5000).toLong()
                speakSequentially(next)

                // Wait for inter-announcement delay while holding volume boosted so rapid
                // back-to-back notifications never get clipped or spoken at low restored volume.
                if (hasQueuedItems()) {
                    delay(delayMs)
                } else {
                    val arrivedDuringGrace = waitForNewItemOrGraceTimeout(
                        graceMs = maxOf(delayMs, 1_000L)
                    )
                    if (!arrivedDuringGrace) {
                        _speakingNotificationId.value = null
                        restoreVolumeIfNeeded()
                        abandonAudioFocus()
                    } else {
                        // Ensure a clean audible pause before speaking the newly arrived alert
                        delay(350L)
                    }
                }
            }
        }
    }

    private suspend fun speakSequentially(item: QueuedUtterance) {
        val engine = tts ?: return
        applyLocale(item.language)
        engine.setSpeechRate(item.rate.coerceIn(0.6f, 1.8f))

        val useAlarmStream = item.volumeConfig.bypassSilentMode
        val shouldOverrideStream =
            item.volumeConfig.overrideVolume || item.volumeConfig.autoBoostVolume || useAlarmStream
        val streamType = if (useAlarmStream) AudioManager.STREAM_ALARM else AudioManager.STREAM_MUSIC

        val usage = if (useAlarmStream) {
            AudioAttributes.USAGE_ALARM
        } else {
            AudioAttributes.USAGE_MEDIA
        }
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(usage)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        engine.setAudioAttributes(audioAttributes)

        requestAudioFocus(audioAttributes, streamType)

        val effectivePercent = when {
            item.volumeConfig.autoBoostVolume -> maxOf(item.volumeConfig.volumePercent, 95)
            item.volumeConfig.overrideVolume || useAlarmStream -> item.volumeConfig.volumePercent
            else -> 100
        }.coerceIn(10, 100)

        // Strictly raise AND verify target stream volume BEFORE calling tts.speak()
        if (shouldOverrideStream) {
            ensureVolumeReachedTarget(streamType = streamType, targetPercent = effectivePercent)
        }

        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, streamType)
            // Keep utterance gain at 1.0f because stream volume is already set accurately above
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        }

        val utteranceId = "notitrack_${item.notificationId ?: "n"}_${UUID.randomUUID()}"
        val completion = CompletableDeferred<Unit>()
        activeUtterances[utteranceId] = completion
        _speakingNotificationId.value = item.notificationId

        val speakResult = runCatching {
            engine.speak(item.text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        }.getOrDefault(TextToSpeech.ERROR)

        if (speakResult == TextToSpeech.SUCCESS) {
            withTimeoutOrNull(45_000L) {
                completion.await()
            }
        }
        activeUtterances.remove(utteranceId)
    }

    /**
     * Raises the target audio stream to the configured volume and waits until AudioManager
     * confirms the volume has reached the desired level (+ a brief hardware amp settle delay)
     * so the first syllables are never lost or whispered.
     */
    private suspend fun ensureVolumeReachedTarget(streamType: Int, targetPercent: Int) {
        val maxVol = runCatching { audioManager.getStreamMaxVolume(streamType) }
            .getOrDefault(15)
            .coerceAtLeast(1)
        val desiredVol = ((maxVol * targetPercent) / 100f).roundToInt().coerceIn(1, maxVol)

        // If switching stream types between consecutive alerts, restore the previous stream first
        val prevStream = savedStreamType
        if (prevStream != null && prevStream != streamType) {
            restoreVolumeIfNeeded()
        }

        val initialVol = runCatching { audioManager.getStreamVolume(streamType) }.getOrDefault(desiredVol)
        if (savedStreamType == null) {
            savedStreamType = streamType
            savedStreamVolume = initialVol
        }

        if (initialVol < desiredVol || initialVol != desiredVol) {
            var attempts = 0
            while (attempts < 14) {
                runCatching {
                    audioManager.setStreamVolume(streamType, desiredVol, 0)
                }
                val current = runCatching { audioManager.getStreamVolume(streamType) }.getOrDefault(desiredVol)
                if (current >= desiredVol) {
                    break
                }
                attempts++
                delay(55L)
            }
            // Brief settle buffer for speaker amp / Bluetooth audio routing after volume ramp
            delay(200L)
        } else {
            // Even if already at target, allow tiny settle buffer after audio focus
            delay(80L)
        }
    }

    private suspend fun waitForNewItemOrGraceTimeout(graceMs: Long): Boolean {
        val stepMs = 100L
        var elapsed = 0L
        while (elapsed < graceMs) {
            if (hasQueuedItems()) return true
            delay(stepMs)
            elapsed += stepMs
        }
        return hasQueuedItems()
    }

    private fun requestAudioFocus(audioAttributes: AudioAttributes, streamType: Int) {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (currentFocusRequest == null) {
                    val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                        .setAudioAttributes(audioAttributes)
                        .setAcceptsDelayedFocusGain(false)
                        .build()
                    audioManager.requestAudioFocus(req)
                    currentFocusRequest = req
                }
            } else {
                @Suppress("DEPRECATION")
                audioManager.requestAudioFocus(
                    null,
                    streamType,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                )
            }
        }
    }

    private fun abandonAudioFocus() {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                currentFocusRequest?.let { req ->
                    audioManager.abandonAudioFocusRequest(req)
                }
                currentFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(null)
            }
        }
    }

    private fun applyLocale(language: AppLanguage) {
        val targetLocale = language.toLocale()
        val availability = tts?.isLanguageAvailable(targetLocale) ?: TextToSpeech.LANG_NOT_SUPPORTED
        if (availability >= TextToSpeech.LANG_AVAILABLE) {
            tts?.language = targetLocale
        } else {
            tts?.language = Locale.getDefault()
        }
    }

    private fun pollNext(): QueuedUtterance? = synchronized(queueLock) {
        if (speechQueue.isEmpty()) null else speechQueue.removeFirst()
    }

    private fun hasQueuedItems(): Boolean = synchronized(queueLock) {
        speechQueue.isNotEmpty()
    }

    private fun enqueue(utterance: QueuedUtterance, flush: Boolean) {
        synchronized(queueLock) {
            if (flush) {
                speechQueue.clear()
                runCatching { tts?.stop() }
                activeUtterances.values.forEach { it.complete(Unit) }
                activeUtterances.clear()
            }
            // Cap queue to avoid unbounded backlog if hundreds of alerts fire at once
            while (speechQueue.size >= 20) {
                speechQueue.removeFirst()
            }
            speechQueue.addLast(utterance)
        }
        wakeSignal.trySend(Unit)
    }

    fun speakNotification(
        notificationId: Long?,
        appName: String,
        title: String,
        content: String,
        includeAppName: Boolean,
        speechRate: Float,
        language: AppLanguage = AppLanguage.VIETNAMESE,
        smartFilterEnabled: Boolean = true,
        hideBalance: Boolean = true,
        numberReadMode: TtsNumberReadMode = TtsNumberReadMode.CONTEXT_AUTO,
        customTemplate: String = "",
        volumeConfig: TtsVolumeConfig = TtsVolumeConfig(),
        flush: Boolean = false
    ) {
        val text = SmartTtsFormatter.formatForSpeech(
            appName = appName,
            title = title,
            content = content,
            includeAppName = includeAppName,
            smartFilterEnabled = smartFilterEnabled,
            hideBalance = hideBalance,
            language = language,
            numberReadMode = numberReadMode,
            customTemplate = customTemplate
        )
        if (text.isBlank()) return

        enqueue(
            QueuedUtterance(
                text = text,
                rate = speechRate,
                notificationId = notificationId,
                language = language,
                volumeConfig = volumeConfig
            ),
            flush = flush
        )
    }

    fun speakSample(
        speechRate: Float,
        language: AppLanguage = AppLanguage.VIETNAMESE,
        smartFilterEnabled: Boolean = true,
        hideBalance: Boolean = true,
        includeAppName: Boolean = true,
        volumeConfig: TtsVolumeConfig = TtsVolumeConfig()
    ) {
        val sampleRawTitle = if (language.resolved() == AppLanguage.VIETNAMESE) {
            "Biến động số dư"
        } else {
            "Balance Alert"
        }
        val sampleRawContent = if (language.resolved() == AppLanguage.VIETNAMESE) {
            "TK 003456 GD: +50,000 VND luc 14:25 19/11/2026. SD: 15,420,000 VND. Ma xac thuc 9999. ND: Chuyen tien cafe FT263239182736"
        } else {
            "Acct **3456 Credited +$50.00 at 14:25. Balance: $1,540.00. Code 9999. Ref: FT263239182736 Coffee transfer"
        }
        val text = if (smartFilterEnabled || hideBalance) {
            SmartTtsFormatter.formatForSpeech(
                appName = "MB Bank",
                title = sampleRawTitle,
                content = sampleRawContent,
                includeAppName = includeAppName,
                smartFilterEnabled = smartFilterEnabled,
                hideBalance = hideBalance,
                language = language
            )
        } else {
            stringsFor(language).ttsSampleSentence
        }
        enqueue(
            QueuedUtterance(
                text = text,
                rate = speechRate,
                notificationId = -1L,
                language = language,
                volumeConfig = volumeConfig
            ),
            flush = true
        )
    }

    fun speakDirectMessage(
        text: String,
        speechRate: Float = 1.0f,
        language: AppLanguage = AppLanguage.VIETNAMESE,
        volumeConfig: TtsVolumeConfig = TtsVolumeConfig()
    ) {
        if (text.isBlank()) return
        enqueue(
            QueuedUtterance(
                text = text.trim(),
                rate = speechRate,
                notificationId = null,
                language = language,
                volumeConfig = volumeConfig
            ),
            flush = false
        )
    }

    private fun restoreVolumeIfNeeded() {
        val stream = savedStreamType ?: return
        val prevVol = savedStreamVolume ?: return
        savedStreamType = null
        savedStreamVolume = null
        runCatching {
            audioManager.setStreamVolume(stream, prevVol, 0)
        }
    }

    fun stop() {
        synchronized(queueLock) {
            speechQueue.clear()
        }
        runCatching { tts?.stop() }
        activeUtterances.values.forEach { it.complete(Unit) }
        activeUtterances.clear()
        restoreVolumeIfNeeded()
        abandonAudioFocus()
        _speakingNotificationId.value = null
    }

    fun shutdown() {
        stop()
        runCatching { tts?.shutdown() }
        tts = null
        isReady = false
    }
}
