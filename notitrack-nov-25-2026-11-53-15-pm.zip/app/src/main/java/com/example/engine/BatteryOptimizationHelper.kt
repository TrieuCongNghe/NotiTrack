package com.example.engine

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import com.example.service.NotiTrackListenerService
import kotlinx.coroutines.delay

object BatteryOptimizationHelper {

    @Volatile
    private var lastForceRebindMs: Long = 0L
    private const val AUTO_REBIND_COOLDOWN_MS = 60_000L

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    fun openBatteryOptimizationSettings(context: Context): Boolean {
        return runCatching {
            val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        }.getOrElse {
            openAppDetailsSettings(context)
        }
    }

    fun openAppDetailsSettings(context: Context): Boolean {
        return runCatching {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", context.packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        }.getOrDefault(false)
    }

    fun requestListenerRebind(context: Context): Boolean {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                NotificationListenerService.requestRebind(
                    ComponentName(context.applicationContext, NotiTrackListenerService::class.java)
                )
            }
            true
        }.getOrDefault(false)
    }

    /**
     * Programmatically toggles the NotificationListenerService component state
     * (DISABLED -> ENABLED) and calls requestRebind() to recover from Android / HyperOS / MIUI
     * zombie listener bindings without requiring the user to toggle Notification Access manually.
     */
    suspend fun forceRebindListener(
        context: Context,
        respectCooldown: Boolean = true
    ): Boolean {
        val now = System.currentTimeMillis()
        if (respectCooldown && (now - lastForceRebindMs) < AUTO_REBIND_COOLDOWN_MS) {
            return requestListenerRebind(context)
        }
        lastForceRebindMs = now
        val appContext = context.applicationContext
        val component = ComponentName(appContext, NotiTrackListenerService::class.java)

        return runCatching {
            val pm = appContext.packageManager
            pm.setComponentEnabledSetting(
                component,
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
            delay(250L)
            pm.setComponentEnabledSetting(
                component,
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            delay(150L)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                NotificationListenerService.requestRebind(component)
            }
            true
        }.getOrElse {
            requestListenerRebind(appContext)
        }
    }
}
