package com.example.engine

import com.example.data.model.NotificationEntity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class ConversationThreadSummary(
    val threadKey: String,
    val packageName: String,
    val appName: String,
    val threadTitle: String,
    val categoryLabel: String,
    val totalCount: Int,
    val unreadCount: Int,
    val latestTimestamp: Long,
    val latestSender: String,
    val latestContent: String,
    val hasHighlighted: Boolean,
    val notificationIds: List<Long>,
    val latestNotificationId: Long = 0L,
    val latestNotificationKey: String = ""
)

/**
 * Top-level grouped app summary: each app appears strictly ONCE,
 * containing its grouped conversation/category sub-threads underneath.
 */
data class AppInboxGroup(
    val packageName: String,
    val appName: String,
    val threads: List<ConversationThreadSummary>,
    val totalCount: Int,
    val unreadCount: Int,
    val latestTimestamp: Long,
    val latestThreadTitle: String,
    val latestPreview: String,
    val hasHighlighted: Boolean,
    val notificationIds: List<Long>,
    val latestNotificationId: Long = 0L,
    val latestNotificationKey: String = ""
)

/**
 * Groups notifications in 2 levels:
 * Level 1: Major App (unique per packageName)
 * Level 2: Conversation / Sender / Category threads inside that app
 * Level 3: Chronological chat bubbles inside each thread
 */
object ConversationGrouper {

    fun resolveThreadKey(item: NotificationEntity): String {
        val topic = resolveThreadTitle(item).lowercase(Locale.getDefault()).trim()
        return "${item.packageName}::$topic"
    }

    fun resolveThreadTitle(item: NotificationEntity): String {
        if (item.conversationTitle.isNotBlank()) {
            return item.conversationTitle.trim()
        }
        val cleanTitle = item.title.trim()
        if (cleanTitle.isBlank()) return item.appName

        val colonIdx = cleanTitle.indexOf(':')
        if (colonIdx in 2..36) {
            val left = cleanTitle.substring(0, colonIdx).trim()
            if (left.isNotBlank() && !left.equals("Re", ignoreCase = true)) {
                return stripCountSuffix(left)
            }
        }
        return stripCountSuffix(cleanTitle)
    }

    fun resolveCategoryLabel(item: NotificationEntity): String {
        val cat = item.category.lowercase(Locale.getDefault())
        return when {
            cat.contains("msg") || cat.contains("social") || item.conversationTitle.isNotBlank() -> item.appName
            cat.contains("email") -> "${item.appName} • Email"
            cat.contains("promo") -> "${item.appName} • Promo"
            item.subText.isNotBlank() -> "${item.appName} • ${item.subText}"
            else -> item.appName
        }
    }

    fun buildThreads(notifications: List<NotificationEntity>): List<ConversationThreadSummary> {
        return notifications
            .groupBy { resolveThreadKey(it) }
            .map { (key, list) ->
                val latest = list.maxBy { it.timestamp }
                val title = resolveThreadTitle(latest)
                ConversationThreadSummary(
                    threadKey = key,
                    packageName = latest.packageName,
                    appName = latest.appName,
                    threadTitle = title,
                    categoryLabel = resolveCategoryLabel(latest),
                    totalCount = list.size,
                    unreadCount = list.count { !it.isRead },
                    latestTimestamp = latest.timestamp,
                    latestSender = latest.title.takeIf { it != title }.orEmpty(),
                    latestContent = latest.content.ifBlank { latest.title },
                    hasHighlighted = list.any { it.isHighlighted },
                    notificationIds = list.map { it.id },
                    latestNotificationId = latest.id,
                    latestNotificationKey = latest.notificationKey
                )
            }
            .sortedByDescending { it.latestTimestamp }
    }

    fun buildAppGroups(notifications: List<NotificationEntity>): List<AppInboxGroup> {
        return notifications
            .groupBy { it.packageName }
            .map { (pkg, appNotis) ->
                val threads = buildThreads(appNotis)
                val latestThread = threads.first()
                AppInboxGroup(
                    packageName = pkg,
                    appName = latestThread.appName,
                    threads = threads,
                    totalCount = appNotis.size,
                    unreadCount = appNotis.count { !it.isRead },
                    latestTimestamp = latestThread.latestTimestamp,
                    latestThreadTitle = latestThread.threadTitle,
                    latestPreview = latestThread.latestContent,
                    hasHighlighted = appNotis.any { it.isHighlighted },
                    notificationIds = appNotis.map { it.id },
                    latestNotificationId = latestThread.latestNotificationId,
                    latestNotificationKey = latestThread.latestNotificationKey
                )
            }
            .sortedByDescending { it.latestTimestamp }
    }

    fun formatDateDivider(timestamp: Long, todayLabel: String, yesterdayLabel: String): String {
        val target = Calendar.getInstance().apply { timeInMillis = timestamp }
        val now = Calendar.getInstance()
        val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(timestamp))

        val sameYear = target.get(Calendar.YEAR) == now.get(Calendar.YEAR)
        val dayDiff = now.get(Calendar.DAY_OF_YEAR) - target.get(Calendar.DAY_OF_YEAR)
        return when {
            sameYear && dayDiff == 0 -> "$todayLabel • $dateStr"
            sameYear && dayDiff == 1 -> "$yesterdayLabel • $dateStr"
            else -> dateStr
        }
    }

    private fun stripCountSuffix(title: String): String {
        return title.replace(Regex("""\s*\(\d+\s*[^)]*\)\s*$"""), "").trim().ifBlank { title }
    }
}
