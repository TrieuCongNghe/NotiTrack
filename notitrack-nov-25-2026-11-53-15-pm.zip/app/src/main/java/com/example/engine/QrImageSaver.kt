package com.example.engine

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.DrawableRes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Zero-permission Play-Policy compliant QR code PNG saver.
 * Uses MediaStore on Android 10+ (API 29+) and Document Uri writing on API 24-28.
 */
object QrImageSaver {

    const val DEFAULT_FILE_NAME = "NotiTrack_MBBank_QR.png"

    fun supportsDirectMediaStoreSave(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q

    suspend fun saveDrawableToGallery(
        context: Context,
        @DrawableRes drawableResId: Int,
        fileName: String = DEFAULT_FILE_NAME
    ): Boolean = withContext(Dispatchers.IO) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return@withContext false
        runCatching {
            val bitmap = BitmapFactory.decodeResource(context.resources, drawableResId)
                ?: return@withContext false
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/NotiTrack")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return@withContext false
            try {
                resolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                } ?: return@withContext false
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                true
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                false
            }
        }.getOrDefault(false)
    }

    suspend fun saveDrawableToUri(
        context: Context,
        @DrawableRes drawableResId: Int,
        targetUri: Uri
    ): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val bitmap = BitmapFactory.decodeResource(context.resources, drawableResId)
                ?: return@withContext false
            context.contentResolver.openOutputStream(targetUri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            } ?: false
        }.getOrDefault(false)
    }
}
