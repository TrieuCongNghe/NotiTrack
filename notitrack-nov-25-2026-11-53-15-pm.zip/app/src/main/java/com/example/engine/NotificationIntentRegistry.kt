package com.example.engine

import android.app.ActivityOptions
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.service.NotiTrackListenerService
import java.util.LinkedHashMap

enum class NotificationLaunchResult {
    DEEP_LINK_OPENED,
    FALLBACK_APP_OPENED,
    FAILED
}

/**
 * In-memory LRU registry preserving Android notification contentIntents (PendingIntent)
 * so tapping an app icon on any archived notification jumps directly to the exact
 * conversation / transaction / screen just like tapping the live Android notification.
 *
 * Automatically falls back to the app's launcher Activity if Android has expired the
 * PendingIntent (e.g., after reboot or process kill) or if the notification carried none.
 */
object NotificationIntentRegistry {

    private const val MAX_ENTRIES = 500

    private val lock = Any()

    private val byNotificationKey = object : LinkedHashMap<String, PendingIntent>(128, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, PendingIntent>?): Boolean {
            return size > MAX_ENTRIES
        }
    }

    private val byNotificationId = object : LinkedHashMap<Long, PendingIntent>(128, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, PendingIntent>?): Boolean {
            return size > MAX_ENTRIES
        }
    }

    fun register(notificationKey: String, pendingIntent: PendingIntent?) {
        if (notificationKey.isBlank() || pendingIntent == null) return
        synchronized(lock) {
            byNotificationKey[notificationKey] = pendingIntent
        }
    }

    fun bindId(notificationId: Long, notificationKey: String, pendingIntent: PendingIntent?) {
        val intent = pendingIntent ?: synchronized(lock) {
            if (notificationKey.isNotBlank()) byNotificationKey[notificationKey] else null
        } ?: return
        synchronized(lock) {
            byNotificationId[notificationId] = intent
            if (notificationKey.isNotBlank()) {
                byNotificationKey[notificationKey] = intent
            }
        }
    }

    fun resolve(notificationId: Long?, notificationKey: String?): PendingIntent? {
        synchronized(lock) {
            if (notificationId != null && notificationId > 0L) {
                byNotificationId[notificationId]?.let { return it }
            }
            if (!notificationKey.isNullOrBlank()) {
                byNotificationKey[notificationKey]?.let { return it }
            }
        }
        return null
    }

    private fun evict(notificationId: Long?, notificationKey: String?) {
        synchronized(lock) {
            if (notificationId != null) byNotificationId.remove(notificationId)
            if (!notificationKey.isNullOrBlank()) byNotificationKey.remove(notificationKey)
        }
    }

    fun launchNotificationTarget(
        context: Context,
        packageName: String,
        notificationId: Long? = null,
        notificationKey: String? = null
    ): NotificationLaunchResult {
        // Layer 1: Cached PendingIntent captured when notification was posted
        var pendingIntent = resolve(notificationId, notificationKey)

        // Layer 2: Check currently active Android status bar notifications via listener
        if (pendingIntent == null && !notificationKey.isNullOrBlank()) {
            pendingIntent = NotiTrackListenerService.findActiveContentIntent(notificationKey)
            if (pendingIntent != null && notificationId != null && notificationId > 0L) {
                bindId(notificationId, notificationKey, pendingIntent)
            }
        }

        // Layer 3: Fire original deep-link PendingIntent
        if (pendingIntent != null) {
            val fired = runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    val options = ActivityOptions.makeBasic()
                        .setPendingIntentBackgroundActivityStartMode(
                            ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED
                        )
                        .toBundle()
                    pendingIntent.send(context, 0, null, null, null, null, options)
                } else {
                    pendingIntent.send()
                }
                true
            }.getOrElse {
                evict(notificationId, notificationKey)
                false
            }
            if (fired) {
                return NotificationLaunchResult.DEEP_LINK_OPENED
            }
        }

        // Layer 4: Graceful fallback to the app's launcher Activity
        return runCatching {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                NotificationLaunchResult.FALLBACK_APP_OPENED
            } else {
                NotificationLaunchResult.FAILED
            }
        }.getOrDefault(NotificationLaunchResult.FAILED)
    }
}
