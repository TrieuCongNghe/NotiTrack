package com.example.engine

import com.example.data.model.KeywordAction
import com.example.data.model.KeywordRuleEntity

data class FilterEvaluationResult(
    val shouldBlock: Boolean = false,
    val shouldHighlight: Boolean = false,
    val shouldMuteTts: Boolean = false,
    val shouldHide: Boolean = false,
    val matchedRuleIds: List<Long> = emptyList(),
    val matchedKeywords: List<String> = emptyList()
)

object KeywordFilterEngine {

    private val otpContextRegex = Regex(
        pattern = "(otp|mã\\s*(xác\\s*(thực|nhận)|bảo\\s*mật|pin|đăng\\s*nhập)|verification|security\\s*code|passcode|auth\\s*code)",
        option = RegexOption.IGNORE_CASE
    )
    private val otpDigitsRegex = Regex("(?<!\\d)(\\d{4,8})(?!\\d)")

    fun evaluate(
        packageName: String,
        title: String,
        content: String,
        subText: String,
        rules: List<KeywordRuleEntity>
    ): FilterEvaluationResult {
        val combinedText = listOf(title, content, subText)
            .filter { it.isNotBlank() }
            .joinToString(" ")

        if (combinedText.isBlank() || rules.isEmpty()) {
            return FilterEvaluationResult()
        }

        var shouldBlock = false
        var shouldHighlight = false
        var shouldMuteTts = false
        var shouldHide = false
        val matchedIds = mutableListOf<Long>()
        val matchedTerms = linkedSetOf<String>()

        for (rule in rules) {
            if (!rule.isEnabled) continue
            if (!rule.targetPackage.isNullOrBlank() && rule.targetPackage != packageName) continue

            val hitTerm = findMatchedTerm(combinedText, rule)
            if (hitTerm != null) {
                matchedIds += rule.id
                matchedTerms += hitTerm
                when (rule.action) {
                    KeywordAction.BLOCK -> shouldBlock = true
                    KeywordAction.HIGHLIGHT -> shouldHighlight = true
                    KeywordAction.MUTE_TTS -> shouldMuteTts = true
                    KeywordAction.HIDE -> shouldHide = true
                }
            }
        }

        return FilterEvaluationResult(
            shouldBlock = shouldBlock,
            shouldHighlight = shouldHighlight,
            shouldMuteTts = shouldMuteTts,
            shouldHide = shouldHide,
            matchedRuleIds = matchedIds,
            matchedKeywords = matchedTerms.toList()
        )
    }

    private fun findMatchedTerm(text: String, rule: KeywordRuleEntity): String? {
        if (rule.isRegex) {
            return runCatching {
                val options = if (rule.isCaseSensitive) emptySet() else setOf(RegexOption.IGNORE_CASE)
                val regex = Regex(rule.keywords.trim(), options)
                regex.find(text)?.value
            }.getOrNull()
        }

        val tokens = rule.keywords
            .split(",", "\n", ";")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        for (token in tokens) {
            if (text.contains(token, ignoreCase = !rule.isCaseSensitive)) {
                return token
            }
        }
        return null
    }

    fun isValidRegex(pattern: String): Boolean {
        if (pattern.isBlank()) return false
        return runCatching { Regex(pattern) }.isSuccess
    }

    fun extractOtpCode(title: String, content: String): String? {
        val text = "$title $content"
        if (!otpContextRegex.containsMatchIn(text)) return null
        return otpDigitsRegex.find(text)?.groupValues?.getOrNull(1)
    }
}
