package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class KeywordAction(
    val labelVi: String,
    val shortLabelVi: String,
    val descriptionVi: String
) {
    HIGHLIGHT(
        labelVi = "Nổi bật & Ghim sao",
        shortLabelVi = "Ưu tiên",
        descriptionVi = "Tự động đánh dấu sao và gắn nhãn ưu tiên (phù hợp cho OTP, chuyển khoản, giao hàng)"
    ),
    BLOCK(
        labelVi = "Chặn không lưu",
        shortLabelVi = "Chặn lưu",
        descriptionVi = "Bỏ qua hoàn toàn thông báo rác, quảng cáo chứa từ khóa này"
    ),
    MUTE_TTS(
        labelVi = "Không đọc giọng nói",
        shortLabelVi = "Tắt đọc",
        descriptionVi = "Vẫn lưu thông báo nhưng tắt tự động đọc to để bảo vệ nội dung nhạy cảm"
    ),
    HIDE(
        labelVi = "Ẩn vào mục Nhạy cảm",
        shortLabelVi = "Ẩn riêng tư",
        descriptionVi = "Lưu vào nhóm Nhạy cảm / Đã ẩn thay vì hiển thị trên dòng thời gian chính"
    )
}

@Entity(tableName = "keyword_rules")
data class KeywordRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val keywords: String,
    val action: KeywordAction = KeywordAction.HIGHLIGHT,
    val targetPackage: String? = null,
    val targetAppName: String? = null,
    val isCaseSensitive: Boolean = false,
    val isRegex: Boolean = false,
    val isEnabled: Boolean = true,
    val matchCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
