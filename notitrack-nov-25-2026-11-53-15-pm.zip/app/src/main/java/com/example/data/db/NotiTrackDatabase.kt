package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.AppRuleEntity
import com.example.data.model.KeywordAction
import com.example.data.model.KeywordRuleEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.TtsFeedbackRuleEntity

class NotiTrackTypeConverters {
    @TypeConverter
    fun fromKeywordAction(action: KeywordAction): String = action.name

    @TypeConverter
    fun toKeywordAction(value: String): KeywordAction =
        runCatching { KeywordAction.valueOf(value) }.getOrDefault(KeywordAction.HIGHLIGHT)
}

@Database(
    entities = [
        NotificationEntity::class,
        AppRuleEntity::class,
        KeywordRuleEntity::class,
        TtsFeedbackRuleEntity::class
    ],
    version = 4,
    exportSchema = false
)
@TypeConverters(NotiTrackTypeConverters::class)
abstract class NotiTrackDatabase : RoomDatabase() {
    abstract fun notificationDao(): NotificationDao
    abstract fun appRuleDao(): AppRuleDao
    abstract fun keywordRuleDao(): KeywordRuleDao
    abstract fun ttsFeedbackRuleDao(): TtsFeedbackRuleDao

    companion object {
        @Volatile
        private var INSTANCE: NotiTrackDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE app_rules ADD COLUMN smartTtsEnabled INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE app_rules ADD COLUMN ttsHideBalance INTEGER NOT NULL DEFAULT 1")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE app_rules ADD COLUMN ttsFilterMode TEXT NOT NULL DEFAULT 'ALL'")
                db.execSQL("ALTER TABLE app_rules ADD COLUMN ttsNumberReadMode TEXT NOT NULL DEFAULT 'CONTEXT_AUTO'")
                db.execSQL("ALTER TABLE app_rules ADD COLUMN ttsAutoBoostVolume INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE app_rules ADD COLUMN ttsCustomTemplate TEXT NOT NULL DEFAULT ''")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE app_rules ADD COLUMN ttsNumericRatioPercent INTEGER NOT NULL DEFAULT 0")
                // Align previously smart-filtered apps so anti-ad numeric filter activates out of the box
                db.execSQL("UPDATE app_rules SET ttsFilterMode = 'NUMERIC_ONLY' WHERE smartTtsEnabled = 1 AND ttsFilterMode = 'ALL'")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS tts_feedback_rules (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        packageName TEXT NOT NULL,
                        appName TEXT NOT NULL,
                        patternFingerprint TEXT NOT NULL,
                        titleSignature TEXT NOT NULL,
                        samplePreview TEXT NOT NULL,
                        shouldSpeak INTEGER NOT NULL,
                        matchCount INTEGER NOT NULL,
                        createdAt INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS index_tts_feedback_rules_packageName ON tts_feedback_rules(packageName)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_tts_feedback_rules_createdAt ON tts_feedback_rules(createdAt)")
            }
        }

        fun getInstance(context: Context): NotiTrackDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NotiTrackDatabase::class.java,
                    "notitrack_local.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                    .fallbackToDestructiveMigration(dropAllTables = false)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
