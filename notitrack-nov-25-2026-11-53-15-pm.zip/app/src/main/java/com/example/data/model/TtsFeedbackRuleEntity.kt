package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "tts_feedback_rules",
    indices = [
        Index(value = ["packageName"]),
        Index(value = ["createdAt"])
    ]
)
data class TtsFeedbackRuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val appName: String,
    val patternFingerprint: String,
    val titleSignature: String = "",
    val samplePreview: String,
    val shouldSpeak: Boolean,
    val matchCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
