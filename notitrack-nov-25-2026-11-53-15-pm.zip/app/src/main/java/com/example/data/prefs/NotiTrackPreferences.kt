package com.example.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.engine.DeviceGuardConfig
import com.example.engine.DeviceGuardEngine
import com.example.engine.MotionSensitivity
import com.example.ui.i18n.AppLanguage
import com.example.ui.theme.AppArtTheme
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.MessageDigest

private val Context.notiTrackDataStore: DataStore<Preferences> by preferencesDataStore(name = "notitrack_prefs")

enum class KeepAliveNotifTheme(
    val labelVi: String,
    val startColorHex: Long,
    val endColorHex: Long
) {
    JADE("Ngọc lục bảo", 0xFF0A2E26, 0xFF125948),
    OCEAN("Xanh đại dương", 0xFF0D253F, 0xFF194B78),
    OBSIDIAN("Đen tuyền", 0xFF13171B, 0xFF252E36),
    AMBER("Hổ phách", 0xFF3B2408, 0xFF6D4412),
    CRIMSON("Đỏ rượu vang", 0xFF3E111B, 0xFF6E1E31)
}

data class NotiTrackSettings(
    val biometricEnabled: Boolean = false,
    val pinHash: String = "",
    val autoLockSeconds: Int = 30,
    val flagSecureEnabled: Boolean = false,
    val requireAuthOnDelete: Boolean = false,
    val ttsGlobalEnabled: Boolean = false,
    val ttsSpeechRate: Float = 1.0f,
    val ttsIncludeAppName: Boolean = true,
    val ttsSmartFilterGlobal: Boolean = true,
    val ttsHideBalanceGlobal: Boolean = true,
    val ttsOverrideVolumeEnabled: Boolean = false,
    val ttsBypassSilentMode: Boolean = false,
    val ttsCustomVolumePercent: Int = 85,
    val ttsDelayBetweenMs: Int = 1500,
    val ttsOnlyWhenScreenOff: Boolean = false,
    val ttsNumericRatioPercent: Int = 40,
    val captureNewAppsByDefault: Boolean = true,
    val retentionDays: Int = 30,
    val themeMode: ThemeMode = ThemeMode.DARK,
    val artTheme: AppArtTheme = AppArtTheme.JADE,
    val defaultGroupedView: Boolean = true,
    val chatTimelineGroupingEnabled: Boolean = true,
    val appLanguage: AppLanguage = AppLanguage.VIETNAMESE,
    val keepAliveEnabled: Boolean = true,
    val keepAliveShowTemp: Boolean = true,
    val keepAliveShowLunar: Boolean = true,
    val keepAliveShowCount: Boolean = true,
    val keepAliveShowBattery: Boolean = true,
    val keepAliveTheme: KeepAliveNotifTheme = KeepAliveNotifTheme.JADE,
    // --- Utilities: Low Battery Alert ---
    val lowBatteryAlertEnabled: Boolean = false,
    val lowBatteryThreshold: Int = 20,
    val lowBatteryRingtoneEnabled: Boolean = true,
    val lowBatteryMusicEnabled: Boolean = false,
    val lowBatterySoundUri: String = "",
    val lowBatteryTtsEnabled: Boolean = false,
    val lowBatterySaverPromptEnabled: Boolean = true,
    // --- Utilities: Charging Level Alert ---
    val chargingAlertEnabled: Boolean = false,
    val chargingAlertThreshold: Int = 80,
    val chargingRingtoneEnabled: Boolean = true,
    val chargingMusicEnabled: Boolean = false,
    val chargingSoundUri: String = "",
    val chargingTtsEnabled: Boolean = false,
    val chargingSaverPromptEnabled: Boolean = false,
    // --- Utilities: Full Charge Alert ---
    val fullChargeAlertEnabled: Boolean = false,
    val fullChargeThreshold: Int = 100,
    val fullChargeExtraMinutes: Int = 15,
    val fullChargeRingtoneEnabled: Boolean = true,
    val fullChargeMusicEnabled: Boolean = false,
    val fullChargeSoundUri: String = "",
    val fullChargeTtsEnabled: Boolean = true,
    // --- Utilities: Overheat Temperature Alert ---
    val overheatAlertEnabled: Boolean = false,
    val overheatThresholdC: Int = 42,
    val overheatUseAlarmSound: Boolean = false,
    val overheatSoundUri: String = "",
    val overheatCooldownSeconds: Int = 120,
    // --- Utilities: Charging Anti-Theft Guard ---
    val chargeGuardEnabled: Boolean = false,
    val chargeGuardMinBatteryPercent: Int = 0,
    val chargeGuardDelaySeconds: Int = 3,
    val chargeGuardConfirmDialogEnabled: Boolean = true,
    val chargeGuardConfirmSeconds: Int = 15,
    val chargeGuardFlashEnabled: Boolean = true,
    val chargeGuardVibrateEnabled: Boolean = true,
    // --- Utilities: Active Motion Anti-Theft Guard ---
    val motionGuardEnabled: Boolean = false,
    val motionGuardSensitivity: Int = MotionSensitivity.MEDIUM.level,
    val motionGuardArmDelaySeconds: Int = 5,
    val motionGuardConfirmDialogEnabled: Boolean = true,
    val motionGuardConfirmSeconds: Int = 15,
    val motionGuardFlashEnabled: Boolean = true,
    val motionGuardVibrateEnabled: Boolean = true
) {
    val hasPinConfigured: Boolean get() = pinHash.isNotEmpty()
    val isAppLockActive: Boolean get() = biometricEnabled || hasPinConfigured
    val isDeleteAuthEffective: Boolean get() = requireAuthOnDelete && isAppLockActive
    val hasAnyUtilityMonitorEnabled: Boolean
        get() = lowBatteryAlertEnabled || chargingAlertEnabled || fullChargeAlertEnabled ||
            overheatAlertEnabled || chargeGuardEnabled || motionGuardEnabled

    fun toDeviceGuardConfig(): DeviceGuardConfig = DeviceGuardConfig(
        lowBatteryEnabled = lowBatteryAlertEnabled,
        lowBatteryThreshold = lowBatteryThreshold,
        chargingAlertEnabled = chargingAlertEnabled,
        chargingAlertThreshold = chargingAlertThreshold,
        fullChargeEnabled = fullChargeAlertEnabled,
        fullChargeThreshold = fullChargeThreshold,
        fullChargeExtraMinutes = fullChargeExtraMinutes,
        overheatEnabled = overheatAlertEnabled,
        overheatThresholdC = overheatThresholdC,
        overheatCooldownSeconds = overheatCooldownSeconds,
        chargeGuardEnabled = chargeGuardEnabled,
        chargeGuardMinBatteryPercent = chargeGuardMinBatteryPercent,
        chargeGuardDelaySeconds = chargeGuardDelaySeconds,
        chargeGuardConfirmDialogEnabled = chargeGuardConfirmDialogEnabled,
        chargeGuardConfirmSeconds = DeviceGuardEngine.clampConfirmSeconds(chargeGuardConfirmSeconds),
        motionGuardEnabled = motionGuardEnabled,
        motionGuardSensitivity = motionGuardSensitivity,
        motionGuardArmDelaySeconds = motionGuardArmDelaySeconds,
        motionGuardConfirmDialogEnabled = motionGuardConfirmDialogEnabled,
        motionGuardConfirmSeconds = DeviceGuardEngine.clampConfirmSeconds(motionGuardConfirmSeconds)
    )
}

class NotiTrackPreferences(private val context: Context) {

    private object Keys {
        val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val AUTO_LOCK_SECONDS = intPreferencesKey("auto_lock_seconds")
        val FLAG_SECURE_ENABLED = booleanPreferencesKey("flag_secure_enabled")
        val REQUIRE_AUTH_ON_DELETE = booleanPreferencesKey("require_auth_on_delete")
        val TTS_GLOBAL_ENABLED = booleanPreferencesKey("tts_global_enabled")
        val TTS_SPEECH_RATE = floatPreferencesKey("tts_speech_rate")
        val TTS_INCLUDE_APP_NAME = booleanPreferencesKey("tts_include_app_name")
        val TTS_SMART_FILTER_GLOBAL = booleanPreferencesKey("tts_smart_filter_global")
        val TTS_HIDE_BALANCE_GLOBAL = booleanPreferencesKey("tts_hide_balance_global")
        val TTS_OVERRIDE_VOLUME = booleanPreferencesKey("tts_override_volume")
        val TTS_BYPASS_SILENT = booleanPreferencesKey("tts_bypass_silent")
        val TTS_CUSTOM_VOLUME_PCT = intPreferencesKey("tts_custom_volume_pct")
        val TTS_DELAY_BETWEEN_MS = intPreferencesKey("tts_delay_between_ms")
        val TTS_ONLY_WHEN_SCREEN_OFF = booleanPreferencesKey("tts_only_when_screen_off")
        val TTS_NUMERIC_RATIO_PCT = intPreferencesKey("tts_numeric_ratio_pct")
        val CAPTURE_NEW_APPS = booleanPreferencesKey("capture_new_apps")
        val RETENTION_DAYS = intPreferencesKey("retention_days")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ART_THEME = stringPreferencesKey("art_theme")
        val DEFAULT_GROUPED_VIEW = booleanPreferencesKey("default_grouped_view")
        val CHAT_TIMELINE_GROUPING = booleanPreferencesKey("chat_timeline_grouping")
        val APP_LANGUAGE = stringPreferencesKey("app_language")
        val KEEP_ALIVE_ENABLED = booleanPreferencesKey("keep_alive_enabled")
        val KEEP_ALIVE_SHOW_TEMP = booleanPreferencesKey("keep_alive_show_temp")
        val KEEP_ALIVE_SHOW_LUNAR = booleanPreferencesKey("keep_alive_show_lunar")
        val KEEP_ALIVE_SHOW_COUNT = booleanPreferencesKey("keep_alive_show_count")
        val KEEP_ALIVE_SHOW_BATTERY = booleanPreferencesKey("keep_alive_show_battery")
        val KEEP_ALIVE_THEME = stringPreferencesKey("keep_alive_theme")

        // Low battery
        val LOW_BAT_ENABLED = booleanPreferencesKey("util_low_bat_enabled")
        val LOW_BAT_THRESHOLD = intPreferencesKey("util_low_bat_threshold")
        val LOW_BAT_RINGTONE = booleanPreferencesKey("util_low_bat_ringtone")
        val LOW_BAT_MUSIC = booleanPreferencesKey("util_low_bat_music")
        val LOW_BAT_SOUND_URI = stringPreferencesKey("util_low_bat_sound_uri")
        val LOW_BAT_TTS = booleanPreferencesKey("util_low_bat_tts")
        val LOW_BAT_SAVER = booleanPreferencesKey("util_low_bat_saver")

        // Charging alert
        val CHG_ALERT_ENABLED = booleanPreferencesKey("util_chg_alert_enabled")
        val CHG_ALERT_THRESHOLD = intPreferencesKey("util_chg_alert_threshold")
        val CHG_ALERT_RINGTONE = booleanPreferencesKey("util_chg_alert_ringtone")
        val CHG_ALERT_MUSIC = booleanPreferencesKey("util_chg_alert_music")
        val CHG_ALERT_SOUND_URI = stringPreferencesKey("util_chg_alert_sound_uri")
        val CHG_ALERT_TTS = booleanPreferencesKey("util_chg_alert_tts")
        val CHG_ALERT_SAVER = booleanPreferencesKey("util_chg_alert_saver")

        // Full charge alert
        val FULL_CHG_ENABLED = booleanPreferencesKey("util_full_chg_enabled")
        val FULL_CHG_THRESHOLD = intPreferencesKey("util_full_chg_threshold")
        val FULL_CHG_EXTRA_MINS = intPreferencesKey("util_full_chg_extra_mins")
        val FULL_CHG_RINGTONE = booleanPreferencesKey("util_full_chg_ringtone")
        val FULL_CHG_MUSIC = booleanPreferencesKey("util_full_chg_music")
        val FULL_CHG_SOUND_URI = stringPreferencesKey("util_full_chg_sound_uri")
        val FULL_CHG_TTS = booleanPreferencesKey("util_full_chg_tts")

        // Overheat
        val OVERHEAT_ENABLED = booleanPreferencesKey("util_overheat_enabled")
        val OVERHEAT_THRESHOLD_C = intPreferencesKey("util_overheat_threshold_c")
        val OVERHEAT_USE_ALARM = booleanPreferencesKey("util_overheat_use_alarm")
        val OVERHEAT_SOUND_URI = stringPreferencesKey("util_overheat_sound_uri")
        val OVERHEAT_COOLDOWN_SEC = intPreferencesKey("util_overheat_cooldown_sec")

        // Charge guard
        val CHG_GUARD_ENABLED = booleanPreferencesKey("util_chg_guard_enabled")
        val CHG_GUARD_MIN_BAT = intPreferencesKey("util_chg_guard_min_bat")
        val CHG_GUARD_DELAY_SEC = intPreferencesKey("util_chg_guard_delay_sec")
        val CHG_GUARD_CONFIRM_ENABLED = booleanPreferencesKey("util_chg_guard_confirm_enabled")
        val CHG_GUARD_CONFIRM_SEC = intPreferencesKey("util_chg_guard_confirm_sec")
        val CHG_GUARD_FLASH = booleanPreferencesKey("util_chg_guard_flash")
        val CHG_GUARD_VIBRATE = booleanPreferencesKey("util_chg_guard_vibrate")

        // Motion guard
        val MOT_GUARD_ENABLED = booleanPreferencesKey("util_mot_guard_enabled")
        val MOT_GUARD_SENSITIVITY = intPreferencesKey("util_mot_guard_sensitivity")
        val MOT_GUARD_ARM_DELAY_SEC = intPreferencesKey("util_mot_guard_arm_delay_sec")
        val MOT_GUARD_CONFIRM_ENABLED = booleanPreferencesKey("util_mot_guard_confirm_enabled")
        val MOT_GUARD_CONFIRM_SEC = intPreferencesKey("util_mot_guard_confirm_sec")
        val MOT_GUARD_FLASH = booleanPreferencesKey("util_mot_guard_flash")
        val MOT_GUARD_VIBRATE = booleanPreferencesKey("util_mot_guard_vibrate")
    }

    val settingsFlow: Flow<NotiTrackSettings> = context.notiTrackDataStore.data.map { prefs ->
        NotiTrackSettings(
            biometricEnabled = prefs[Keys.BIOMETRIC_ENABLED] ?: false,
            pinHash = prefs[Keys.PIN_HASH] ?: "",
            autoLockSeconds = prefs[Keys.AUTO_LOCK_SECONDS] ?: 30,
            flagSecureEnabled = prefs[Keys.FLAG_SECURE_ENABLED] ?: false,
            requireAuthOnDelete = prefs[Keys.REQUIRE_AUTH_ON_DELETE] ?: false,
            ttsGlobalEnabled = prefs[Keys.TTS_GLOBAL_ENABLED] ?: false,
            ttsSpeechRate = prefs[Keys.TTS_SPEECH_RATE] ?: 1.0f,
            ttsIncludeAppName = prefs[Keys.TTS_INCLUDE_APP_NAME] ?: true,
            ttsSmartFilterGlobal = prefs[Keys.TTS_SMART_FILTER_GLOBAL] ?: true,
            ttsHideBalanceGlobal = prefs[Keys.TTS_HIDE_BALANCE_GLOBAL] ?: true,
            ttsOverrideVolumeEnabled = prefs[Keys.TTS_OVERRIDE_VOLUME] ?: false,
            ttsBypassSilentMode = prefs[Keys.TTS_BYPASS_SILENT] ?: false,
            ttsCustomVolumePercent = (prefs[Keys.TTS_CUSTOM_VOLUME_PCT] ?: 85).coerceIn(10, 100),
            ttsDelayBetweenMs = (prefs[Keys.TTS_DELAY_BETWEEN_MS] ?: 1500).coerceIn(500, 5000),
            ttsOnlyWhenScreenOff = prefs[Keys.TTS_ONLY_WHEN_SCREEN_OFF] ?: false,
            ttsNumericRatioPercent = (prefs[Keys.TTS_NUMERIC_RATIO_PCT] ?: 40).coerceIn(20, 70),
            captureNewAppsByDefault = prefs[Keys.CAPTURE_NEW_APPS] ?: true,
            retentionDays = prefs[Keys.RETENTION_DAYS] ?: 30,
            themeMode = runCatching {
                ThemeMode.valueOf(prefs[Keys.THEME_MODE] ?: ThemeMode.DARK.name)
            }.getOrDefault(ThemeMode.DARK),
            artTheme = AppArtTheme.fromName(prefs[Keys.ART_THEME]),
            defaultGroupedView = prefs[Keys.DEFAULT_GROUPED_VIEW] ?: true,
            chatTimelineGroupingEnabled = prefs[Keys.CHAT_TIMELINE_GROUPING] ?: true,
            appLanguage = AppLanguage.fromCode(prefs[Keys.APP_LANGUAGE]),
            keepAliveEnabled = prefs[Keys.KEEP_ALIVE_ENABLED] ?: true,
            keepAliveShowTemp = prefs[Keys.KEEP_ALIVE_SHOW_TEMP] ?: true,
            keepAliveShowLunar = prefs[Keys.KEEP_ALIVE_SHOW_LUNAR] ?: true,
            keepAliveShowCount = prefs[Keys.KEEP_ALIVE_SHOW_COUNT] ?: true,
            keepAliveShowBattery = prefs[Keys.KEEP_ALIVE_SHOW_BATTERY] ?: true,
            keepAliveTheme = runCatching {
                KeepAliveNotifTheme.valueOf(prefs[Keys.KEEP_ALIVE_THEME] ?: KeepAliveNotifTheme.JADE.name)
            }.getOrDefault(KeepAliveNotifTheme.JADE),

            lowBatteryAlertEnabled = prefs[Keys.LOW_BAT_ENABLED] ?: false,
            lowBatteryThreshold = (prefs[Keys.LOW_BAT_THRESHOLD] ?: 20).coerceIn(5, 50),
            lowBatteryRingtoneEnabled = prefs[Keys.LOW_BAT_RINGTONE] ?: true,
            lowBatteryMusicEnabled = prefs[Keys.LOW_BAT_MUSIC] ?: false,
            lowBatterySoundUri = prefs[Keys.LOW_BAT_SOUND_URI] ?: "",
            lowBatteryTtsEnabled = prefs[Keys.LOW_BAT_TTS] ?: false,
            lowBatterySaverPromptEnabled = prefs[Keys.LOW_BAT_SAVER] ?: true,

            chargingAlertEnabled = prefs[Keys.CHG_ALERT_ENABLED] ?: false,
            chargingAlertThreshold = (prefs[Keys.CHG_ALERT_THRESHOLD] ?: 80).coerceIn(20, 95),
            chargingRingtoneEnabled = prefs[Keys.CHG_ALERT_RINGTONE] ?: true,
            chargingMusicEnabled = prefs[Keys.CHG_ALERT_MUSIC] ?: false,
            chargingSoundUri = prefs[Keys.CHG_ALERT_SOUND_URI] ?: "",
            chargingTtsEnabled = prefs[Keys.CHG_ALERT_TTS] ?: false,
            chargingSaverPromptEnabled = prefs[Keys.CHG_ALERT_SAVER] ?: false,

            fullChargeAlertEnabled = prefs[Keys.FULL_CHG_ENABLED] ?: false,
            fullChargeThreshold = (prefs[Keys.FULL_CHG_THRESHOLD] ?: 100).coerceIn(80, 100),
            fullChargeExtraMinutes = (prefs[Keys.FULL_CHG_EXTRA_MINS] ?: 15).coerceIn(0, 60),
            fullChargeRingtoneEnabled = prefs[Keys.FULL_CHG_RINGTONE] ?: true,
            fullChargeMusicEnabled = prefs[Keys.FULL_CHG_MUSIC] ?: false,
            fullChargeSoundUri = prefs[Keys.FULL_CHG_SOUND_URI] ?: "",
            fullChargeTtsEnabled = prefs[Keys.FULL_CHG_TTS] ?: true,

            overheatAlertEnabled = prefs[Keys.OVERHEAT_ENABLED] ?: false,
            overheatThresholdC = (prefs[Keys.OVERHEAT_THRESHOLD_C] ?: 42).coerceIn(36, 55),
            overheatUseAlarmSound = prefs[Keys.OVERHEAT_USE_ALARM] ?: false,
            overheatSoundUri = prefs[Keys.OVERHEAT_SOUND_URI] ?: "",
            overheatCooldownSeconds = (prefs[Keys.OVERHEAT_COOLDOWN_SEC] ?: 120).coerceIn(15, 1800),

            chargeGuardEnabled = prefs[Keys.CHG_GUARD_ENABLED] ?: false,
            chargeGuardMinBatteryPercent = (prefs[Keys.CHG_GUARD_MIN_BAT] ?: 0).coerceIn(0, 100),
            chargeGuardDelaySeconds = (prefs[Keys.CHG_GUARD_DELAY_SEC] ?: 3).coerceIn(0, 30),
            chargeGuardConfirmDialogEnabled = prefs[Keys.CHG_GUARD_CONFIRM_ENABLED] ?: true,
            chargeGuardConfirmSeconds = DeviceGuardEngine.clampConfirmSeconds(prefs[Keys.CHG_GUARD_CONFIRM_SEC] ?: 15),
            chargeGuardFlashEnabled = prefs[Keys.CHG_GUARD_FLASH] ?: true,
            chargeGuardVibrateEnabled = prefs[Keys.CHG_GUARD_VIBRATE] ?: true,

            motionGuardEnabled = prefs[Keys.MOT_GUARD_ENABLED] ?: false,
            motionGuardSensitivity = (prefs[Keys.MOT_GUARD_SENSITIVITY] ?: MotionSensitivity.MEDIUM.level).coerceIn(1, 3),
            motionGuardArmDelaySeconds = (prefs[Keys.MOT_GUARD_ARM_DELAY_SEC] ?: 5).coerceIn(0, 30),
            motionGuardConfirmDialogEnabled = prefs[Keys.MOT_GUARD_CONFIRM_ENABLED] ?: true,
            motionGuardConfirmSeconds = DeviceGuardEngine.clampConfirmSeconds(prefs[Keys.MOT_GUARD_CONFIRM_SEC] ?: 15),
            motionGuardFlashEnabled = prefs[Keys.MOT_GUARD_FLASH] ?: true,
            motionGuardVibrateEnabled = prefs[Keys.MOT_GUARD_VIBRATE] ?: true
        )
    }

    suspend fun getSettingsSnapshot(): NotiTrackSettings = settingsFlow.first()

    suspend fun setBiometricEnabled(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.BIOMETRIC_ENABLED] = enabled }
    }

    suspend fun setPin(rawPin: String) {
        val hashed = if (rawPin.isBlank()) "" else hashPin(rawPin)
        context.notiTrackDataStore.edit { it[Keys.PIN_HASH] = hashed }
    }

    suspend fun verifyPin(rawPin: String): Boolean {
        val currentHash = getSettingsSnapshot().pinHash
        return currentHash.isNotEmpty() && currentHash == hashPin(rawPin)
    }

    suspend fun setAutoLockSeconds(seconds: Int) {
        context.notiTrackDataStore.edit { it[Keys.AUTO_LOCK_SECONDS] = seconds }
    }

    suspend fun setFlagSecureEnabled(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.FLAG_SECURE_ENABLED] = enabled }
    }

    suspend fun setRequireAuthOnDelete(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.REQUIRE_AUTH_ON_DELETE] = enabled }
    }

    suspend fun setTtsGlobalEnabled(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.TTS_GLOBAL_ENABLED] = enabled }
    }

    suspend fun setTtsSpeechRate(rate: Float) {
        context.notiTrackDataStore.edit { it[Keys.TTS_SPEECH_RATE] = rate.coerceIn(0.6f, 1.8f) }
    }

    suspend fun setTtsIncludeAppName(include: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.TTS_INCLUDE_APP_NAME] = include }
    }

    suspend fun setTtsSmartFilterGlobal(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.TTS_SMART_FILTER_GLOBAL] = enabled }
    }

    suspend fun setTtsHideBalanceGlobal(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.TTS_HIDE_BALANCE_GLOBAL] = enabled }
    }

    suspend fun setTtsOverrideVolumeEnabled(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.TTS_OVERRIDE_VOLUME] = enabled }
    }

    suspend fun setTtsBypassSilentMode(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.TTS_BYPASS_SILENT] = enabled }
    }

    suspend fun setTtsCustomVolumePercent(percent: Int) {
        context.notiTrackDataStore.edit { it[Keys.TTS_CUSTOM_VOLUME_PCT] = percent.coerceIn(10, 100) }
    }

    suspend fun setTtsDelayBetweenMs(delayMs: Int) {
        context.notiTrackDataStore.edit { it[Keys.TTS_DELAY_BETWEEN_MS] = delayMs.coerceIn(500, 5000) }
    }

    suspend fun setTtsOnlyWhenScreenOff(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.TTS_ONLY_WHEN_SCREEN_OFF] = enabled }
    }

    suspend fun setTtsNumericRatioPercent(percent: Int) {
        context.notiTrackDataStore.edit { it[Keys.TTS_NUMERIC_RATIO_PCT] = percent.coerceIn(20, 70) }
    }

    suspend fun setCaptureNewAppsByDefault(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.CAPTURE_NEW_APPS] = enabled }
    }

    suspend fun setRetentionDays(days: Int) {
        context.notiTrackDataStore.edit { it[Keys.RETENTION_DAYS] = days }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.notiTrackDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setArtTheme(theme: AppArtTheme) {
        context.notiTrackDataStore.edit { it[Keys.ART_THEME] = theme.name }
    }

    suspend fun setDefaultGroupedView(grouped: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.DEFAULT_GROUPED_VIEW] = grouped }
    }

    suspend fun setChatTimelineGroupingEnabled(enabled: Boolean) {
        context.notiTrackDataStore.edit {
            it[Keys.CHAT_TIMELINE_GROUPING] = enabled
            it[Keys.DEFAULT_GROUPED_VIEW] = enabled
        }
    }

    suspend fun setAppLanguage(language: AppLanguage) {
        context.notiTrackDataStore.edit { it[Keys.APP_LANGUAGE] = language.code }
    }

    suspend fun setKeepAliveEnabled(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.KEEP_ALIVE_ENABLED] = enabled }
    }

    suspend fun setKeepAliveShowTemp(show: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.KEEP_ALIVE_SHOW_TEMP] = show }
    }

    suspend fun setKeepAliveShowLunar(show: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.KEEP_ALIVE_SHOW_LUNAR] = show }
    }

    suspend fun setKeepAliveShowCount(show: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.KEEP_ALIVE_SHOW_COUNT] = show }
    }

    suspend fun setKeepAliveShowBattery(show: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.KEEP_ALIVE_SHOW_BATTERY] = show }
    }

    suspend fun setKeepAliveTheme(theme: KeepAliveNotifTheme) {
        context.notiTrackDataStore.edit { it[Keys.KEEP_ALIVE_THEME] = theme.name }
    }

    // --- Utilities Setters ---

    suspend fun updateUtilitiesSettings(transform: (NotiTrackSettings) -> NotiTrackSettings) {
        val updated = transform(getSettingsSnapshot())
        context.notiTrackDataStore.edit { prefs ->
            prefs[Keys.LOW_BAT_ENABLED] = updated.lowBatteryAlertEnabled
            prefs[Keys.LOW_BAT_THRESHOLD] = updated.lowBatteryThreshold.coerceIn(5, 50)
            prefs[Keys.LOW_BAT_RINGTONE] = updated.lowBatteryRingtoneEnabled
            prefs[Keys.LOW_BAT_MUSIC] = updated.lowBatteryMusicEnabled
            prefs[Keys.LOW_BAT_SOUND_URI] = updated.lowBatterySoundUri
            prefs[Keys.LOW_BAT_TTS] = updated.lowBatteryTtsEnabled
            prefs[Keys.LOW_BAT_SAVER] = updated.lowBatterySaverPromptEnabled

            prefs[Keys.CHG_ALERT_ENABLED] = updated.chargingAlertEnabled
            prefs[Keys.CHG_ALERT_THRESHOLD] = updated.chargingAlertThreshold.coerceIn(20, 95)
            prefs[Keys.CHG_ALERT_RINGTONE] = updated.chargingRingtoneEnabled
            prefs[Keys.CHG_ALERT_MUSIC] = updated.chargingMusicEnabled
            prefs[Keys.CHG_ALERT_SOUND_URI] = updated.chargingSoundUri
            prefs[Keys.CHG_ALERT_TTS] = updated.chargingTtsEnabled
            prefs[Keys.CHG_ALERT_SAVER] = updated.chargingSaverPromptEnabled

            prefs[Keys.FULL_CHG_ENABLED] = updated.fullChargeAlertEnabled
            prefs[Keys.FULL_CHG_THRESHOLD] = updated.fullChargeThreshold.coerceIn(80, 100)
            prefs[Keys.FULL_CHG_EXTRA_MINS] = updated.fullChargeExtraMinutes.coerceIn(0, 60)
            prefs[Keys.FULL_CHG_RINGTONE] = updated.fullChargeRingtoneEnabled
            prefs[Keys.FULL_CHG_MUSIC] = updated.fullChargeMusicEnabled
            prefs[Keys.FULL_CHG_SOUND_URI] = updated.fullChargeSoundUri
            prefs[Keys.FULL_CHG_TTS] = updated.fullChargeTtsEnabled

            prefs[Keys.OVERHEAT_ENABLED] = updated.overheatAlertEnabled
            prefs[Keys.OVERHEAT_THRESHOLD_C] = updated.overheatThresholdC.coerceIn(36, 55)
            prefs[Keys.OVERHEAT_USE_ALARM] = updated.overheatUseAlarmSound
            prefs[Keys.OVERHEAT_SOUND_URI] = updated.overheatSoundUri
            prefs[Keys.OVERHEAT_COOLDOWN_SEC] = updated.overheatCooldownSeconds.coerceIn(15, 1800)

            prefs[Keys.CHG_GUARD_ENABLED] = updated.chargeGuardEnabled
            prefs[Keys.CHG_GUARD_MIN_BAT] = updated.chargeGuardMinBatteryPercent.coerceIn(0, 100)
            prefs[Keys.CHG_GUARD_DELAY_SEC] = updated.chargeGuardDelaySeconds.coerceIn(0, 30)
            prefs[Keys.CHG_GUARD_CONFIRM_ENABLED] = updated.chargeGuardConfirmDialogEnabled
            prefs[Keys.CHG_GUARD_CONFIRM_SEC] = DeviceGuardEngine.clampConfirmSeconds(updated.chargeGuardConfirmSeconds)
            prefs[Keys.CHG_GUARD_FLASH] = updated.chargeGuardFlashEnabled
            prefs[Keys.CHG_GUARD_VIBRATE] = updated.chargeGuardVibrateEnabled

            prefs[Keys.MOT_GUARD_ENABLED] = updated.motionGuardEnabled
            prefs[Keys.MOT_GUARD_SENSITIVITY] = updated.motionGuardSensitivity.coerceIn(1, 3)
            prefs[Keys.MOT_GUARD_ARM_DELAY_SEC] = updated.motionGuardArmDelaySeconds.coerceIn(0, 30)
            prefs[Keys.MOT_GUARD_CONFIRM_ENABLED] = updated.motionGuardConfirmDialogEnabled
            prefs[Keys.MOT_GUARD_CONFIRM_SEC] = DeviceGuardEngine.clampConfirmSeconds(updated.motionGuardConfirmSeconds)
            prefs[Keys.MOT_GUARD_FLASH] = updated.motionGuardFlashEnabled
            prefs[Keys.MOT_GUARD_VIBRATE] = updated.motionGuardVibrateEnabled
        }
    }

    suspend fun setMotionGuardEnabled(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.MOT_GUARD_ENABLED] = enabled }
    }

    suspend fun restoreFromBackup(restored: NotiTrackSettings) {
        context.notiTrackDataStore.edit { prefs ->
            prefs[Keys.AUTO_LOCK_SECONDS] = restored.autoLockSeconds
            prefs[Keys.FLAG_SECURE_ENABLED] = restored.flagSecureEnabled
            prefs[Keys.REQUIRE_AUTH_ON_DELETE] = restored.requireAuthOnDelete
            prefs[Keys.TTS_GLOBAL_ENABLED] = restored.ttsGlobalEnabled
            prefs[Keys.TTS_SPEECH_RATE] = restored.ttsSpeechRate.coerceIn(0.6f, 1.8f)
            prefs[Keys.TTS_INCLUDE_APP_NAME] = restored.ttsIncludeAppName
            prefs[Keys.TTS_SMART_FILTER_GLOBAL] = restored.ttsSmartFilterGlobal
            prefs[Keys.TTS_HIDE_BALANCE_GLOBAL] = restored.ttsHideBalanceGlobal
            prefs[Keys.TTS_OVERRIDE_VOLUME] = restored.ttsOverrideVolumeEnabled
            prefs[Keys.TTS_BYPASS_SILENT] = restored.ttsBypassSilentMode
            prefs[Keys.TTS_CUSTOM_VOLUME_PCT] = restored.ttsCustomVolumePercent.coerceIn(10, 100)
            prefs[Keys.TTS_DELAY_BETWEEN_MS] = restored.ttsDelayBetweenMs.coerceIn(500, 5000)
            prefs[Keys.TTS_ONLY_WHEN_SCREEN_OFF] = restored.ttsOnlyWhenScreenOff
            prefs[Keys.TTS_NUMERIC_RATIO_PCT] = restored.ttsNumericRatioPercent.coerceIn(20, 70)
            prefs[Keys.CAPTURE_NEW_APPS] = restored.captureNewAppsByDefault
            prefs[Keys.RETENTION_DAYS] = restored.retentionDays
            prefs[Keys.THEME_MODE] = restored.themeMode.name
            prefs[Keys.ART_THEME] = restored.artTheme.name
            prefs[Keys.DEFAULT_GROUPED_VIEW] = restored.defaultGroupedView
            prefs[Keys.CHAT_TIMELINE_GROUPING] = restored.chatTimelineGroupingEnabled
            prefs[Keys.APP_LANGUAGE] = restored.appLanguage.code
            prefs[Keys.KEEP_ALIVE_ENABLED] = restored.keepAliveEnabled
            prefs[Keys.KEEP_ALIVE_SHOW_TEMP] = restored.keepAliveShowTemp
            prefs[Keys.KEEP_ALIVE_SHOW_LUNAR] = restored.keepAliveShowLunar
            prefs[Keys.KEEP_ALIVE_SHOW_COUNT] = restored.keepAliveShowCount
            prefs[Keys.KEEP_ALIVE_SHOW_BATTERY] = restored.keepAliveShowBattery
            prefs[Keys.KEEP_ALIVE_THEME] = restored.keepAliveTheme.name
        }
    }

    companion object {
        fun hashPin(pin: String): String {
            val digest = MessageDigest.getInstance("SHA-256")
            val bytes = digest.digest("notitrack_salt_v1:$pin".toByteArray(Charsets.UTF_8))
            return bytes.joinToString("") { "%02x".format(it) }
        }
    }
}
