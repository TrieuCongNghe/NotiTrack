package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "notifications",
    indices = [
        Index(value = ["packageName"]),
        Index(value = ["timestamp"]),
        Index(value = ["isHidden"])
    ]
)
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val appName: String,
    val title: String,
    val content: String,
    val subText: String = "",
    val conversationTitle: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val notificationKey: String = "",
    val category: String = "",
    val isRead: Boolean = false,
    val isStarred: Boolean = false,
    val isHighlighted: Boolean = false,
    val isHidden: Boolean = false,
    val matchedKeywords: String = "",
    val wasSpoken: Boolean = false,
    val detectedOtp: String? = null
)

data class AppNotificationSummary(
    val packageName: String,
    val appName: String,
    val totalCount: Int,
    val unreadCount: Int,
    val latestTimestamp: Long,
    val latestTitle: String,
    val latestContent: String,
    val hasHighlighted: Boolean
)
