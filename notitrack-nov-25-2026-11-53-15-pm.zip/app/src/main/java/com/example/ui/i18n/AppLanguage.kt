package com.example.ui.i18n

import java.util.Locale

enum class AppLanguage(
    val code: String,
    val nativeLabel: String,
    val bcp47Tag: String
) {
    SYSTEM("system", "Auto / Hệ thống", ""),
    VIETNAMESE("vi", "Tiếng Việt", "vi-VN"),
    ENGLISH("en", "English", "en-US"),
    CHINESE("zh", "中文 (简体)", "zh-CN"),
    JAPANESE("ja", "日本語", "ja-JP"),
    KOREAN("ko", "한국어", "ko-KR"),
    SPANISH("es", "Español", "es-ES"),
    FRENCH("fr", "Français", "fr-FR"),
    GERMAN("de", "Deutsch", "de-DE");

    fun resolved(): AppLanguage {
        if (this != SYSTEM) return this
        return when (Locale.getDefault().language.lowercase(Locale.ROOT)) {
            "vi" -> VIETNAMESE
            "en" -> ENGLISH
            "zh" -> CHINESE
            "ja" -> JAPANESE
            "ko" -> KOREAN
            "es" -> SPANISH
            "fr" -> FRENCH
            "de" -> GERMAN
            else -> ENGLISH
        }
    }

    fun toLocale(): Locale {
        val target = resolved()
        return if (target.bcp47Tag.isNotEmpty()) Locale.forLanguageTag(target.bcp47Tag)
        else Locale.getDefault()
    }

    companion object {
        fun fromCode(code: String?): AppLanguage =
            entries.firstOrNull { it.code == code } ?: VIETNAMESE
    }
}
