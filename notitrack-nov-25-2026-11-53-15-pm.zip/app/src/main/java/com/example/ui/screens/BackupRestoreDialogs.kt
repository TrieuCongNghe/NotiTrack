package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.BackupPreview
import com.example.engine.BackupSelection
import com.example.engine.RestoreMode
import com.example.ui.i18n.LocalAppStrings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BackupExportOptionsDialog(
    notificationsCount: Int,
    appRulesCount: Int,
    keywordRulesCount: Int,
    feedbackRulesCount: Int,
    onDismiss: () -> Unit,
    onConfirmExport: (BackupSelection) -> Unit
) {
    val s = LocalAppStrings.current
    var selection by remember { mutableStateOf(BackupSelection()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.CloudUpload,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = s.backupDialogTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = s.backupDialogDesc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))

                BackupOptionCheckRow(
                    label = s.backupOptNotifications(notificationsCount),
                    checked = selection.includeNotifications,
                    onCheckedChange = { selection = selection.copy(includeNotifications = it) },
                    testTag = "backup_opt_notifications"
                )
                BackupOptionCheckRow(
                    label = s.backupOptAppRules(appRulesCount),
                    checked = selection.includeAppRules,
                    onCheckedChange = { selection = selection.copy(includeAppRules = it) },
                    testTag = "backup_opt_app_rules"
                )
                BackupOptionCheckRow(
                    label = s.backupOptKeywordRules(keywordRulesCount),
                    checked = selection.includeKeywordRules,
                    onCheckedChange = { selection = selection.copy(includeKeywordRules = it) },
                    testTag = "backup_opt_keyword_rules"
                )
                BackupOptionCheckRow(
                    label = s.backupOptFeedbackRules(feedbackRulesCount),
                    checked = selection.includeTtsFeedback,
                    onCheckedChange = { selection = selection.copy(includeTtsFeedback = it) },
                    testTag = "backup_opt_feedback_rules"
                )
                BackupOptionCheckRow(
                    label = s.backupOptSettings,
                    checked = selection.includeSettings,
                    onCheckedChange = { selection = selection.copy(includeSettings = it) },
                    testTag = "backup_opt_settings"
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmExport(selection) },
                enabled = selection.hasAnySelected,
                modifier = Modifier.testTag("backup_confirm_choose_location")
            ) {
                Text(s.backupChooseLocation)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(s.cancel)
            }
        }
    )
}

@Composable
private fun BackupOptionCheckRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onCheckedChange(!checked) }
            .testTag(testTag),
        shape = RoundedCornerShape(10.dp),
        color = if (checked) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
        } else {
            MaterialTheme.colorScheme.surfaceContainer
        }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = checked,
                onCheckedChange = onCheckedChange
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BackupRestoreConfirmDialog(
    preview: BackupPreview,
    onDismiss: () -> Unit,
    onConfirmRestore: (RestoreMode) -> Unit
) {
    val s = LocalAppStrings.current
    var selectedMode by remember { mutableStateOf(RestoreMode.MERGE) }
    val formattedDate = remember(preview.exportedAt) {
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(preview.exportedAt))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.CloudDownload,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = s.restoreDialogTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = s.restorePreviewDate(formattedDate),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    FlowRow(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (preview.payload.notifications != null) {
                            PreviewCountChip(s.backupOptNotifications(preview.notificationCount))
                        }
                        if (preview.payload.appRules != null) {
                            PreviewCountChip(s.backupOptAppRules(preview.appRuleCount))
                        }
                        if (preview.payload.keywordRules != null) {
                            PreviewCountChip(s.backupOptKeywordRules(preview.keywordRuleCount))
                        }
                        if (preview.payload.ttsFeedbackRules != null) {
                            PreviewCountChip(s.backupOptFeedbackRules(preview.ttsFeedbackCount))
                        }
                        if (preview.hasSettings) {
                            PreviewCountChip(s.backupOptSettings)
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                RestoreModeCard(
                    selected = selectedMode == RestoreMode.MERGE,
                    title = s.restoreModeMergeTitle,
                    description = s.restoreModeMergeDesc,
                    isDestructive = false,
                    onClick = { selectedMode = RestoreMode.MERGE },
                    testTag = "restore_mode_merge"
                )

                RestoreModeCard(
                    selected = selectedMode == RestoreMode.REPLACE,
                    title = s.restoreModeReplaceTitle,
                    description = s.restoreModeReplaceDesc,
                    isDestructive = true,
                    onClick = { selectedMode = RestoreMode.REPLACE },
                    testTag = "restore_mode_replace"
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmRestore(selectedMode) },
                colors = if (selectedMode == RestoreMode.REPLACE) {
                    ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                } else {
                    ButtonDefaults.buttonColors()
                },
                modifier = Modifier.testTag("restore_confirm_button")
            ) {
                Text(s.restoreConfirmAction)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(s.cancel)
            }
        }
    )
}

@Composable
private fun PreviewCountChip(text: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.secondaryContainer
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun RestoreModeCard(
    selected: Boolean,
    title: String,
    description: String,
    isDestructive: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val activeBorder = if (isDestructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
    val activeContainer = if (isDestructive) {
        MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f)
    } else {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(10.dp),
        color = if (selected) activeContainer else MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(
            width = if (selected) 1.5.dp else 1.dp,
            color = if (selected) activeBorder else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            RadioButton(
                selected = selected,
                onClick = onClick
            )
            Column(modifier = Modifier.padding(top = 6.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
