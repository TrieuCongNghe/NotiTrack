package com.example.ui.screens

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColor
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PowerOff
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.NotiTrackApplication
import com.example.engine.AntiTheftPhase
import com.example.engine.AntiTheftRuntimeController
import com.example.engine.AntiTheftRuntimeState
import com.example.engine.AntiTheftTriggerReason
import com.example.engine.BiometricAuthHelper
import com.example.ui.i18n.AppLanguage
import com.example.ui.theme.NotiTrackTheme
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.launch

/**
 * Play-safe lock-screen full-screen Activity for Anti-Theft confirmation countdown (<= 120s)
 * and active alarm lock state:
 * - Shows over lock screen & wakes screen without needing SYSTEM_ALERT_WINDOW Overlay permission
 * - Blocks Back button and Volume hardware keys while active
 * - Re-launches itself if hidden/minimized during ALARM_RINGING until 4-digit PIN is verified
 */
class AntiTheftAlarmActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        configureLockScreenWindow()

        val app = application as NotiTrackApplication

        setContent {
            val runtimeState by AntiTheftRuntimeController.state.collectAsStateWithLifecycle()
            val settings by app.preferences.settingsFlow.collectAsStateWithLifecycle(initialValue = null)
            val scope = rememberCoroutineScope()

            LaunchedEffect(runtimeState.phase) {
                if (runtimeState.phase == AntiTheftPhase.IDLE) {
                    finish()
                }
            }

            NotiTrackTheme(
                themeMode = ThemeMode.DARK,
                artTheme = settings?.artTheme ?: com.example.ui.theme.AppArtTheme.JADE
            ) {
                val isVi = (settings?.appLanguage ?: AppLanguage.VIETNAMESE).resolved() == AppLanguage.VIETNAMESE
                val biometricUsable = remember {
                    BiometricAuthHelper.checkHardwareStatus(this@AntiTheftAlarmActivity).isUsable
                }
                val allowBiometricInConfirm = runtimeState.phase == AntiTheftPhase.AWAITING_CONFIRM &&
                    (settings?.biometricEnabled == true) && biometricUsable

                AntiTheftAlarmScreen(
                    state = runtimeState,
                    isVietnamese = isVi,
                    allowBiometric = allowBiometricInConfirm,
                    hasPinConfigured = settings?.hasPinConfigured ?: true,
                    onRequestBiometric = {
                        if (runtimeState.phase == AntiTheftPhase.AWAITING_CONFIRM) {
                            BiometricAuthHelper.authenticate(
                                activity = this@AntiTheftAlarmActivity,
                                title = if (isVi) "Xác nhận chủ thiết bị" else "Verify Device Owner",
                                subtitle = if (isVi) "Quét vân tay để hủy chuông báo trộm" else "Use fingerprint to disarm anti-theft",
                                negativeButtonText = if (isVi) "Dùng mã PIN" else "Use PIN",
                                mismatchMessage = if (isVi) "Vân tay không khớp" else "Fingerprint mismatch",
                                onSuccess = {
                                    disarmAndClose(app, runtimeState.reason)
                                },
                                onFailureOrCancel = { }
                            )
                        }
                    },
                    onVerifyPin = { enteredPin, onResult ->
                        scope.launch {
                            val hasPin = app.preferences.getSettingsSnapshot().hasPinConfigured
                            val ok = if (!hasPin) true else app.preferences.verifyPin(enteredPin)
                            if (ok) {
                                disarmAndClose(app, runtimeState.reason)
                            }
                            onResult(ok)
                        }
                    }
                )
            }
        }
    }

    private fun disarmAndClose(app: NotiTrackApplication, reason: AntiTheftTriggerReason?) {
        AntiTheftRuntimeController.disarmAll(this)
        if (reason == AntiTheftTriggerReason.DEVICE_MOVED) {
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                app.preferences.setMotionGuardEnabled(false)
            }
        }
        finish()
    }

    private fun configureLockScreenWindow() {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val km = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            km?.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
    }

    override fun onResume() {
        super.onResume()
        AntiTheftRuntimeController.onAlarmActivityVisibilityChanged(true)
    }

    override fun onStop() {
        super.onStop()
        AntiTheftRuntimeController.onAlarmActivityVisibilityChanged(false)
        if (AntiTheftRuntimeController.state.value.phase == AntiTheftPhase.ALARM_RINGING) {
            AntiTheftRuntimeController.ensureAlarmActivityInFront(this)
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val phase = AntiTheftRuntimeController.state.value.phase
        if (phase == AntiTheftPhase.ALARM_RINGING || phase == AntiTheftPhase.AWAITING_CONFIRM) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_VOLUME_DOWN,
                KeyEvent.KEYCODE_VOLUME_UP,
                KeyEvent.KEYCODE_VOLUME_MUTE,
                KeyEvent.KEYCODE_BACK -> return true
            }
        }
        return super.dispatchKeyEvent(event)
    }
}

@Composable
private fun AntiTheftAlarmScreen(
    state: AntiTheftRuntimeState,
    isVietnamese: Boolean,
    allowBiometric: Boolean,
    hasPinConfigured: Boolean,
    onRequestBiometric: () -> Unit,
    onVerifyPin: (String, (Boolean) -> Unit) -> Unit
) {
    // Strictly block Back navigation while anti-theft confirmation or alarm is active
    BackHandler(enabled = true) {}

    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }

    val isRinging = state.phase == AntiTheftPhase.ALARM_RINGING
    val infiniteTransition = rememberInfiniteTransition(label = "alarm_pulse")
    val pulseBgTop by infiniteTransition.animateColor(
        initialValue = if (isRinging) Color(0xFF54060E) else Color(0xFF0A1D2B),
        targetValue = if (isRinging) Color(0xFFA80D1E) else Color(0xFF14364E),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isRinging) 420 else 1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alarm_bg_pulse"
    )

    val reasonTitle = when (state.reason) {
        AntiTheftTriggerReason.CHARGER_UNPLUGGED ->
            if (isVietnamese) "PHÁT HIỆN RÚT SẠC!" else "CHARGER DISCONNECTED!"
        AntiTheftTriggerReason.DEVICE_MOVED ->
            if (isVietnamese) "PHÁT HIỆN DI CHUYỂN MÁY!" else "DEVICE MOVEMENT DETECTED!"
        null ->
            if (isVietnamese) "BÁO ĐỘNG CHỐNG TRỘM" else "ANTI-THEFT ALERT"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        pulseBgTop,
                        if (isRinging) Color(0xFF1B0408) else Color(0xFF07111C),
                        Color(0xFF05070B)
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (isRinging) {
                Box(
                    modifier = Modifier
                        .size(92.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFF1744).copy(alpha = 0.25f))
                        .border(2.dp, Color(0xFFFF5252), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.NotificationsActive,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                }
            } else {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(104.dp)) {
                    val progress = if (state.totalConfirmSeconds > 0) {
                        (state.remainingConfirmSeconds.toFloat() / state.totalConfirmSeconds.toFloat()).coerceIn(0f, 1f)
                    } else 1f
                    CircularProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxSize(),
                        color = Color(0xFFF6B94D),
                        trackColor = Color.White.copy(alpha = 0.16f),
                        strokeWidth = 6.dp
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${state.remainingConfirmSeconds}s",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = reasonTitle,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = if (isRinging) Color(0xFFFF8A80) else Color(0xFFFFE082),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (isRinging) {
                    if (isVietnamese) "Còi báo động đang khóa âm lượng tối đa.\nNhập đúng mã PIN 4 số để tắt báo động."
                    else "Siren is locked at maximum volume.\nEnter your 4-digit PIN to stop the alarm."
                } else {
                    if (isVietnamese) "Xác nhận bạn là chủ thiết bị trong ${state.remainingConfirmSeconds} giây bằng mã PIN 4 số hoặc vân tay."
                    else "Verify you are the owner within ${state.remainingConfirmSeconds}s using PIN or fingerprint."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.85f),
                textAlign = TextAlign.Center
            )

            if (isRinging) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AlarmStatusPill(
                        icon = Icons.Filled.VolumeUp,
                        label = if (isVietnamese) "Khóa Max" else "Vol Max"
                    )
                    if (state.flashEnabled) {
                        AlarmStatusPill(
                            icon = Icons.Filled.FlashOn,
                            label = "Flash"
                        )
                    }
                    if (state.vibrateEnabled) {
                        AlarmStatusPill(
                            icon = Icons.Filled.Vibration,
                            label = if (isVietnamese) "Rung mạnh" else "Vibrate"
                        )
                    }
                }
            }

            AnimatedVisibility(visible = !pinError.isNullOrBlank()) {
                Surface(
                    modifier = Modifier.padding(top = 12.dp),
                    color = Color(0xFFFF1744).copy(alpha = 0.85f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = pinError.orEmpty(),
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            if (allowBiometric) {
                Button(
                    onClick = onRequestBiometric,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF4FD8B8),
                        contentColor = Color(0xFF002D24)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("antitheft_biometric_button")
                ) {
                    Icon(Icons.Filled.Fingerprint, contentDescription = null, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isVietnamese) "Tắt nhanh bằng Vân tay" else "Disarm with Fingerprint",
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            if (!hasPinConfigured) {
                Button(
                    onClick = { onVerifyPin("0000") {} },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Icon(Icons.Filled.PowerOff, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isVietnamese) "Tắt báo động" else "Stop Alarm", fontWeight = FontWeight.Bold)
                }
            } else {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(4) { idx ->
                        val filled = idx < pinInput.length
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(
                                    if (filled) Color(0xFFFFD54F) else Color.White.copy(alpha = 0.2f)
                                )
                                .border(1.5.dp, Color.White.copy(alpha = 0.55f), CircleShape)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                val rows = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("", "0", "DEL")
                )
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    rows.forEach { row ->
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            row.forEach { key ->
                                when (key) {
                                    "" -> Spacer(modifier = Modifier.size(66.dp))
                                    "DEL" -> {
                                        Box(
                                            modifier = Modifier
                                                .size(66.dp)
                                                .clip(CircleShape)
                                                .clickable {
                                                    if (pinInput.isNotEmpty()) pinInput = pinInput.dropLast(1)
                                                }
                                                .testTag("alarm_pin_backspace"),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.Backspace,
                                                contentDescription = "Backspace",
                                                tint = Color.White
                                            )
                                        }
                                    }
                                    else -> {
                                        Box(
                                            modifier = Modifier
                                                .size(66.dp)
                                                .clip(CircleShape)
                                                .background(Color.White.copy(alpha = 0.14f))
                                                .border(1.dp, Color.White.copy(alpha = 0.24f), CircleShape)
                                                .clickable {
                                                    if (pinInput.length < 4) {
                                                        pinError = null
                                                        val updated = pinInput + key
                                                        pinInput = updated
                                                        if (updated.length == 4) {
                                                            onVerifyPin(updated) { ok ->
                                                                if (!ok) {
                                                                    pinError = if (isVietnamese) "Mã PIN 4 số không đúng!"
                                                                    else "Incorrect 4-digit PIN!"
                                                                    pinInput = ""
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                .testTag("alarm_pin_key_$key"),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = key,
                                                style = MaterialTheme.typography.headlineSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AlarmStatusPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = Color.White.copy(alpha = 0.15f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(icon, contentDescription = null, tint = Color(0xFFFFD54F), modifier = Modifier.size(14.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.SemiBold)
        }
    }
}
