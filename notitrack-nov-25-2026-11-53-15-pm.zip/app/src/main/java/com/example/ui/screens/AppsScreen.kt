package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AppRuleEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.TtsFilterMode
import com.example.data.model.TtsNumberReadMode
import com.example.data.prefs.NotiTrackSettings
import com.example.ui.components.AppIconAvatar
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassSwitch
import com.example.ui.components.NotiTrackSearchBar
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.LocalGlassStyle
import com.example.ui.viewmodel.AppsFilter

@Composable
fun AppsScreen(
    allRulesCount: Int,
    capturingCount: Int,
    ttsActiveCount: Int,
    filteredRules: List<AppRuleEntity>,
    allNotifications: List<NotificationEntity>,
    settings: NotiTrackSettings,
    query: String,
    activeFilter: AppsFilter,
    onQueryChange: (String) -> Unit,
    onFilterChange: (AppsFilter) -> Unit,
    onUpdateRule: (AppRuleEntity) -> Unit,
    onSetCaptureAll: (Boolean) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val s = LocalAppStrings.current
    var advancedEditingRule by remember { mutableStateOf<AppRuleEntity?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = s.appsTitle,
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = s.appsSubtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        val glass = LocalGlassStyle.current
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = if (glass.isDark) 0.45f else 0.72f),
            borderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = s.appsCountSummary(capturingCount, allRulesCount),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = s.appsTtsSummary(ttsActiveCount),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
                TextButton(
                    onClick = { onSetCaptureAll(true) },
                    modifier = Modifier.testTag("apps_enable_all_button")
                ) {
                    Text(s.appsEnableAll)
                }
                TextButton(
                    onClick = { onSetCaptureAll(false) },
                    modifier = Modifier.testTag("apps_disable_all_button")
                ) {
                    Text(s.appsDisableAll)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        NotiTrackSearchBar(
            query = query,
            placeholder = s.appsSearchHint,
            onQueryChange = onQueryChange,
            testTag = "apps_search_input"
        )

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(AppsFilter.entries) { filter ->
                FilterChip(
                    selected = activeFilter == filter,
                    onClick = { onFilterChange(filter) },
                    label = {
                        Text(
                            text = s.appsFilterLabels[filter] ?: filter.labelVi,
                            style = MaterialTheme.typography.labelLarge
                        )
                    },
                    modifier = Modifier.testTag("apps_filter_${filter.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredRules, key = { it.packageName }) { rule ->
                AppRuleCard(
                    rule = rule,
                    onToggleCapture = { checked ->
                        onUpdateRule(rule.copy(captureEnabled = checked))
                    },
                    onToggleTts = { checked ->
                        onUpdateRule(
                            rule.copy(
                                captureEnabled = if (checked) true else rule.captureEnabled,
                                readAloudEnabled = checked
                            )
                        )
                    },
                    onToggleAutoDismiss = { checked ->
                        onUpdateRule(
                            rule.copy(
                                captureEnabled = if (checked) true else rule.captureEnabled,
                                autoDismissEnabled = checked
                            )
                        )
                    },
                    onToggleSmartTts = { checked ->
                        onUpdateRule(
                            rule.copy(
                                smartTtsEnabled = checked,
                                ttsFilterMode = if (checked) TtsFilterMode.NUMERIC_ONLY.name else TtsFilterMode.ALL.name
                            )
                        )
                    },
                    onToggleHideBalance = { checked ->
                        onUpdateRule(rule.copy(ttsHideBalance = checked))
                    },
                    onOpenAdvancedTts = {
                        advancedEditingRule = rule
                    }
                )
            }
        }
    }

    advancedEditingRule?.let { editing ->
        val appSamples = remember(allNotifications, editing.packageName) {
            allNotifications.filter { it.packageName == editing.packageName }
        }
        AdvancedTtsRuleDialog(
            rule = editing,
            appSamples = appSamples,
            settings = settings,
            onDismiss = { advancedEditingRule = null },
            onSave = { updated ->
                onUpdateRule(updated)
                advancedEditingRule = null
                onShowMessage(s.msgAdvTtsSaved)
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AppRuleCard(
    rule: AppRuleEntity,
    onToggleCapture: (Boolean) -> Unit,
    onToggleTts: (Boolean) -> Unit,
    onToggleAutoDismiss: (Boolean) -> Unit,
    onToggleSmartTts: (Boolean) -> Unit,
    onToggleHideBalance: (Boolean) -> Unit,
    onOpenAdvancedTts: () -> Unit
) {
    val s = LocalAppStrings.current
    val hasAdvancedCustom = rule.resolvedFilterMode() != TtsFilterMode.NUMERIC_ONLY ||
        rule.ttsNumericRatioPercent in 20..70 ||
        rule.resolvedNumberReadMode() != TtsNumberReadMode.CONTEXT_AUTO ||
        rule.ttsAutoBoostVolume ||
        rule.ttsCustomTemplate.isNotBlank()

    val glass = LocalGlassStyle.current
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("app_rule_card_${rule.packageName}"),
        containerColor = if (rule.captureEnabled) glass.cardElevatedFill else glass.cardFill,
        borderColor = if (rule.captureEnabled) glass.cardBorder
        else glass.cardBorder.copy(alpha = 0.45f)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AppIconAvatar(
                    packageName = rule.packageName,
                    appName = rule.appName,
                    size = 42.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = rule.appName,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = rule.packageName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                GlassSwitch(
                    checked = rule.captureEnabled,
                    onCheckedChange = onToggleCapture,
                    modifier = Modifier.testTag("app_capture_switch_${rule.packageName}")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                FilterChip(
                    selected = rule.readAloudEnabled,
                    onClick = { onToggleTts(!rule.readAloudEnabled) },
                    enabled = rule.captureEnabled,
                    label = {
                        Text(
                            text = s.appsChipTts,
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.RecordVoiceOver,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.tertiaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onTertiaryContainer,
                        selectedLeadingIconColor = MaterialTheme.colorScheme.onTertiaryContainer
                    ),
                    modifier = Modifier.testTag("app_tts_chip_${rule.packageName}")
                )

                FilterChip(
                    selected = rule.autoDismissEnabled,
                    onClick = { onToggleAutoDismiss(!rule.autoDismissEnabled) },
                    enabled = rule.captureEnabled,
                    label = {
                        Text(
                            text = s.appsChipAutoDismiss,
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.CleaningServices,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        selectedLeadingIconColor = MaterialTheme.colorScheme.onSecondaryContainer
                    ),
                    modifier = Modifier.testTag("app_dismiss_chip_${rule.packageName}")
                )
            }

            // Smart TTS + Gear button + Hide Balance only visible when Read-Aloud is ON for this app
            AnimatedVisibility(
                visible = rule.captureEnabled && rule.readAloudEnabled,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                FlowRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        FilterChip(
                            selected = rule.smartTtsEnabled,
                            onClick = { onToggleSmartTts(!rule.smartTtsEnabled) },
                            label = {
                                Text(
                                    text = s.appsChipSmartTts,
                                    style = MaterialTheme.typography.labelMedium,
                                    maxLines = 1
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.AutoFixHigh,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.testTag("app_smart_tts_chip_${rule.packageName}")
                        )

                        Box {
                            IconButton(
                                onClick = onOpenAdvancedTts,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("app_adv_tts_gear_${rule.packageName}")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Settings,
                                    contentDescription = s.advTtsGearDesc,
                                    tint = if (hasAdvancedCustom) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    },
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            if (hasAdvancedCustom) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(top = 10.dp, end = 10.dp)
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.secondary)
                                )
                            }
                        }
                    }

                    FilterChip(
                        selected = rule.ttsHideBalance,
                        onClick = { onToggleHideBalance(!rule.ttsHideBalance) },
                        label = {
                            Text(
                                text = s.appsChipHideBalance,
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.MoneyOff,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        modifier = Modifier.testTag("app_hide_balance_chip_${rule.packageName}")
                    )
                }
            }
        }
    }
}
