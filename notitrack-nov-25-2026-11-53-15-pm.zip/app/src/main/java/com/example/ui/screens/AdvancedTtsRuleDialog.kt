package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlin.math.roundToInt
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AppRuleEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.TtsFilterMode
import com.example.data.model.TtsNumberReadMode
import com.example.data.prefs.NotiTrackSettings
import com.example.engine.SmartTtsFormatter
import com.example.engine.SmartTtsTemplateEngine
import com.example.ui.components.AppIconAvatar
import com.example.ui.i18n.LocalAppStrings

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdvancedTtsRuleDialog(
    rule: AppRuleEntity,
    appSamples: List<NotificationEntity>,
    settings: NotiTrackSettings,
    onDismiss: () -> Unit,
    onSave: (AppRuleEntity) -> Unit
) {
    val s = LocalAppStrings.current

    var filterMode by remember(rule) { mutableStateOf(rule.resolvedFilterMode()) }
    var numberMode by remember(rule) { mutableStateOf(rule.resolvedNumberReadMode()) }
    var autoBoost by remember(rule) { mutableStateOf(rule.ttsAutoBoostVolume) }
    var useCustomRatio by remember(rule) {
        mutableStateOf(
            rule.ttsNumericRatioPercent in SmartTtsTemplateEngine.MIN_NUMERIC_RATIO_PERCENT..SmartTtsTemplateEngine.MAX_NUMERIC_RATIO_PERCENT
        )
    }
    var customRatioPercent by remember(rule, settings.ttsNumericRatioPercent) {
        mutableIntStateOf(
            rule.effectiveNumericRatioPercent(settings.ttsNumericRatioPercent)
        )
    }
    val effectiveRatioThreshold = if (useCustomRatio) customRatioPercent else settings.ttsNumericRatioPercent

    val existingParsed = remember(rule.ttsCustomTemplate) {
        SmartTtsTemplateEngine.parseTemplate(rule.ttsCustomTemplate)
    }

    var selectedSampleText by remember(rule, appSamples) {
        val initial = existingParsed?.sampleText?.takeIf { it.isNotBlank() }
            ?: appSamples.firstOrNull()?.let { buildCombinedSampleText(it) }
            ?: ""
        mutableStateOf(initial)
    }

    var selectedTokenIndices by remember(rule, selectedSampleText) {
        val initialIndices = if (existingParsed != null && existingParsed.sampleText == selectedSampleText) {
            existingParsed.selectedIndices.toSet()
        } else {
            emptySet()
        }
        mutableStateOf(initialIndices)
    }

    val tokens = remember(selectedSampleText) {
        SmartTtsTemplateEngine.tokenize(selectedSampleText)
    }

    val draftTemplate = remember(selectedSampleText, selectedTokenIndices) {
        if (selectedSampleText.isBlank() || selectedTokenIndices.isEmpty()) ""
        else SmartTtsTemplateEngine.buildSerializedTemplate(selectedSampleText, selectedTokenIndices)
    }

    val livePreview = remember(
        selectedSampleText,
        draftTemplate,
        rule.smartTtsEnabled,
        rule.ttsHideBalance,
        numberMode,
        settings.ttsIncludeAppName,
        settings.appLanguage
    ) {
        if (selectedSampleText.isBlank()) ""
        else SmartTtsFormatter.formatForSpeech(
            appName = rule.appName,
            title = "",
            content = selectedSampleText,
            includeAppName = settings.ttsIncludeAppName,
            smartFilterEnabled = rule.smartTtsEnabled,
            hideBalance = rule.ttsHideBalance,
            language = settings.appLanguage,
            numberReadMode = numberMode,
            customTemplate = draftTemplate
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AppIconAvatar(
                    packageName = rule.packageName,
                    appName = rule.appName,
                    size = 34.dp
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = s.advTtsTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = rule.appName,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Section 1: Numeric-rich (Balance alerts) vs Read All (including promos)
                Text(
                    text = s.advTtsFilterModeLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterModeOptionCard(
                        selected = filterMode == TtsFilterMode.NUMERIC_ONLY,
                        title = s.advTtsFilterNumeric,
                        description = s.advTtsFilterNumericDesc,
                        onClick = { filterMode = TtsFilterMode.NUMERIC_ONLY },
                        testTag = "adv_tts_mode_numeric"
                    )
                    FilterModeOptionCard(
                        selected = filterMode == TtsFilterMode.ALL,
                        title = s.advTtsFilterAll,
                        description = s.advTtsFilterAllDesc,
                        onClick = { filterMode = TtsFilterMode.ALL },
                        testTag = "adv_tts_mode_all"
                    )
                }

                if (filterMode == TtsFilterMode.NUMERIC_ONLY) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                FilterChip(
                                    selected = !useCustomRatio,
                                    onClick = { useCustomRatio = false },
                                    label = {
                                        Text(
                                            text = s.advTtsRatioUseGlobal(settings.ttsNumericRatioPercent),
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    modifier = Modifier.testTag("adv_tts_ratio_global_chip")
                                )
                                FilterChip(
                                    selected = useCustomRatio,
                                    onClick = { useCustomRatio = true },
                                    label = {
                                        Text(
                                            text = s.advTtsRatioCustom(customRatioPercent),
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    modifier = Modifier.testTag("adv_tts_ratio_custom_chip")
                                )
                            }
                            if (useCustomRatio) {
                                Slider(
                                    value = customRatioPercent.toFloat(),
                                    onValueChange = { raw ->
                                        customRatioPercent = ((raw / 5f).roundToInt() * 5).coerceIn(
                                            SmartTtsTemplateEngine.MIN_NUMERIC_RATIO_PERCENT,
                                            SmartTtsTemplateEngine.MAX_NUMERIC_RATIO_PERCENT
                                        )
                                    },
                                    valueRange = SmartTtsTemplateEngine.MIN_NUMERIC_RATIO_PERCENT.toFloat()..SmartTtsTemplateEngine.MAX_NUMERIC_RATIO_PERCENT.toFloat(),
                                    steps = 9,
                                    modifier = Modifier.testTag("adv_tts_ratio_slider")
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                // Section 2: Sample Notification Highlight Picker
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoFixHigh,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = s.advTtsSampleSection,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                if (appSamples.isEmpty() && selectedSampleText.isBlank()) {
                    Surface(
                        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = s.advTtsSampleEmptyNotice,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                    }
                } else {
                    if (appSamples.isNotEmpty()) {
                        Text(
                            text = s.advTtsSamplePickHint,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            appSamples.take(5).forEach { sample ->
                                val combined = buildCombinedSampleText(sample)
                                val isCurrent = combined == selectedSampleText
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable {
                                            selectedSampleText = combined
                                            selectedTokenIndices = emptySet()
                                        },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isCurrent) {
                                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                                    } else {
                                        MaterialTheme.colorScheme.surfaceContainer
                                    },
                                    border = BorderStroke(
                                        1.dp,
                                        if (isCurrent) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.outlineVariant
                                    )
                                ) {
                                    Text(
                                        text = combined,
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }
                        }
                    }

                    if (selectedSampleText.isNotBlank() && filterMode == TtsFilterMode.NUMERIC_ONLY) {
                        val sampleRatio = remember(selectedSampleText) {
                            SmartTtsTemplateEngine.calculateNumericRatioPercent("", selectedSampleText)
                        }
                        val samplePasses = sampleRatio >= effectiveRatioThreshold
                        Surface(
                            color = if (samplePasses) {
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
                            } else {
                                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.65f)
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (samplePasses) {
                                    s.advTtsSampleNumericPass(sampleRatio, effectiveRatioThreshold)
                                } else {
                                    s.advTtsSampleNumericSkip(sampleRatio, effectiveRatioThreshold)
                                },
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = if (samplePasses) {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onErrorContainer
                                },
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }

                    if (tokens.isNotEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = s.advTtsSampleTapHint,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f)
                            )
                            if (selectedTokenIndices.isNotEmpty()) {
                                TextButton(
                                    onClick = { selectedTokenIndices = emptySet() },
                                    modifier = Modifier.testTag("adv_tts_clear_highlight")
                                ) {
                                    Text(s.advTtsSampleClearTemplate, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            tokens.forEachIndexed { idx, word ->
                                val highlighted = idx in selectedTokenIndices
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            selectedTokenIndices = if (highlighted) {
                                                selectedTokenIndices - idx
                                            } else {
                                                selectedTokenIndices + idx
                                            }
                                        }
                                        .testTag("adv_tts_token_$idx"),
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (highlighted) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.surfaceContainerHigh
                                    }
                                ) {
                                    Text(
                                        text = word,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (highlighted) {
                                            MaterialTheme.colorScheme.onPrimary
                                        } else {
                                            MaterialTheme.colorScheme.onSurface
                                        },
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }

                        if (livePreview.isNotBlank()) {
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.GraphicEq,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.secondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = s.advTtsSamplePreviewLabel,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "\"$livePreview\"",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                // Section 3: Number Reading Style
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Numbers,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = s.advTtsNumberModeLabel,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val numberOptions = listOf(
                        TtsNumberReadMode.CONTEXT_AUTO to s.advTtsNumberAuto,
                        TtsNumberReadMode.EXACT_DIGITS to s.advTtsNumberExact,
                        TtsNumberReadMode.NATURAL_WORDS to s.advTtsNumberNatural
                    )
                    numberOptions.forEach { (mode, label) ->
                        FilterChip(
                            selected = numberMode == mode,
                            onClick = { numberMode = mode },
                            label = { Text(label, style = MaterialTheme.typography.labelMedium) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.testTag("adv_tts_number_${mode.name.lowercase()}")
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                // Section 4: Auto-boost volume for this app
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { autoBoost = !autoBoost }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.VolumeUp,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = s.advTtsAutoBoostTitle,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = s.advTtsAutoBoostDesc,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Switch(
                        checked = autoBoost,
                        onCheckedChange = { autoBoost = it },
                        modifier = Modifier.testTag("adv_tts_auto_boost_switch")
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        rule.copy(
                            ttsFilterMode = filterMode.name,
                            ttsNumberReadMode = numberMode.name,
                            ttsAutoBoostVolume = autoBoost,
                            ttsCustomTemplate = draftTemplate,
                            ttsNumericRatioPercent = if (useCustomRatio) customRatioPercent else 0
                        )
                    )
                },
                modifier = Modifier.testTag("adv_tts_save_button")
            ) {
                Text(s.save)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(s.cancel)
            }
        }
    )
}

@Composable
private fun FilterModeOptionCard(
    selected: Boolean,
    title: String,
    description: String,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(10.dp),
        color = if (selected) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
        } else {
            MaterialTheme.colorScheme.surfaceContainer
        },
        border = BorderStroke(
            1.dp,
            if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.Top
        ) {
            RadioButton(
                selected = selected,
                onClick = onClick
            )
            Column(modifier = Modifier.padding(top = 6.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun buildCombinedSampleText(notification: NotificationEntity): String {
    return listOf(notification.title.trim(), notification.content.trim())
        .filter { it.isNotBlank() }
        .distinct()
        .joinToString(" ")
}
