package com.example.ui.screens

import android.content.Context
import android.media.RingtoneManager
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.BatterySaver
import androidx.compose.material.icons.filled.DeviceThermostat
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhonelinkRing
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.prefs.NotiTrackSettings
import com.example.engine.AntiTheftRuntimeState
import com.example.engine.DeviceGuardEngine
import com.example.engine.MotionSensitivity
import com.example.ui.i18n.AppLanguage
import kotlin.math.roundToInt

enum class UtilitySoundTarget {
    LOW_BATTERY,
    CHARGING,
    FULL_CHARGE,
    OVERHEAT
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsUtilitiesContent(
    settings: NotiTrackSettings,
    antiTheftState: AntiTheftRuntimeState,
    onUpdateUtilities: ((NotiTrackSettings) -> NotiTrackSettings) -> Unit,
    onPickUtilitySound: (UtilitySoundTarget, String) -> Unit,
    onRequestToggleChargeGuard: (Boolean) -> Unit,
    onRequestToggleMotionGuard: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val isVi = settings.appLanguage.resolved() == AppLanguage.VIETNAMESE

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // 1. Low Battery Alert
        UtilityCardHeader(
            title = if (isVi) "Cảnh báo % pin yếu" else "Low Battery Alert",
            subtitle = if (isVi) "Nhắc sạc pin kịp thời bằng chuông, nhạc hoặc giọng nói"
            else "Alert with ringtone, custom audio, or voice readout when battery drops low",
            icon = Icons.Filled.BatteryAlert,
            accentColor = MaterialTheme.colorScheme.error,
            checked = settings.lowBatteryAlertEnabled,
            onCheckedChange = { on -> onUpdateUtilities { it.copy(lowBatteryAlertEnabled = on) } },
            testTag = "util_low_battery_switch"
        ) {
            Text(
                text = if (isVi) "Ngưỡng cảnh báo pin yếu: ${settings.lowBatteryThreshold}%"
                else "Low battery threshold: ${settings.lowBatteryThreshold}%",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Slider(
                value = settings.lowBatteryThreshold.toFloat(),
                onValueChange = { raw ->
                    val snapped = ((raw / 5f).roundToInt() * 5).coerceIn(5, 50)
                    onUpdateUtilities { it.copy(lowBatteryThreshold = snapped) }
                },
                valueRange = 5f..50f,
                steps = 8,
                modifier = Modifier.testTag("util_low_bat_slider")
            )
            UtilityAlertChannelsSection(
                context = context,
                isVi = isVi,
                ringtoneChecked = settings.lowBatteryRingtoneEnabled,
                onRingtoneChange = { on -> onUpdateUtilities { it.copy(lowBatteryRingtoneEnabled = on) } },
                musicChecked = settings.lowBatteryMusicEnabled,
                onMusicChange = { on -> onUpdateUtilities { it.copy(lowBatteryMusicEnabled = on) } },
                soundUri = settings.lowBatterySoundUri,
                onPickSound = { onPickUtilitySound(UtilitySoundTarget.LOW_BATTERY, settings.lowBatterySoundUri) },
                ttsChecked = settings.lowBatteryTtsEnabled,
                onTtsChange = { on -> onUpdateUtilities { it.copy(lowBatteryTtsEnabled = on) } },
                showBatterySaverOption = true,
                batterySaverChecked = settings.lowBatterySaverPromptEnabled,
                onBatterySaverChange = { on -> onUpdateUtilities { it.copy(lowBatterySaverPromptEnabled = on) } },
                prefixTag = "low_bat"
            )
        }

        // 2. Charging Level Alert
        UtilityCardHeader(
            title = if (isVi) "Cảnh báo Sạc pin" else "Charging Level Alert",
            subtitle = if (isVi) "Báo khi đang cắm sạc đạt tới mức % mong muốn"
            else "Notify while charging once battery reaches your chosen target %",
            icon = Icons.Filled.BatteryChargingFull,
            accentColor = MaterialTheme.colorScheme.primary,
            checked = settings.chargingAlertEnabled,
            onCheckedChange = { on -> onUpdateUtilities { it.copy(chargingAlertEnabled = on) } },
            testTag = "util_charging_switch"
        ) {
            Text(
                text = if (isVi) "Mức % pin báo khi đang sạc: ${settings.chargingAlertThreshold}%"
                else "Target charging level: ${settings.chargingAlertThreshold}%",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Slider(
                value = settings.chargingAlertThreshold.toFloat(),
                onValueChange = { raw ->
                    val snapped = ((raw / 5f).roundToInt() * 5).coerceIn(20, 95)
                    onUpdateUtilities { it.copy(chargingAlertThreshold = snapped) }
                },
                valueRange = 20f..95f,
                steps = 14,
                modifier = Modifier.testTag("util_charging_slider")
            )
            UtilityAlertChannelsSection(
                context = context,
                isVi = isVi,
                ringtoneChecked = settings.chargingRingtoneEnabled,
                onRingtoneChange = { on -> onUpdateUtilities { it.copy(chargingRingtoneEnabled = on) } },
                musicChecked = settings.chargingMusicEnabled,
                onMusicChange = { on -> onUpdateUtilities { it.copy(chargingMusicEnabled = on) } },
                soundUri = settings.chargingSoundUri,
                onPickSound = { onPickUtilitySound(UtilitySoundTarget.CHARGING, settings.chargingSoundUri) },
                ttsChecked = settings.chargingTtsEnabled,
                onTtsChange = { on -> onUpdateUtilities { it.copy(chargingTtsEnabled = on) } },
                showBatterySaverOption = true,
                batterySaverChecked = settings.chargingSaverPromptEnabled,
                onBatterySaverChange = { on -> onUpdateUtilities { it.copy(chargingSaverPromptEnabled = on) } },
                prefixTag = "charging"
            )
        }

        // 3. Full Charge Alert (with 100% extra soak minutes!)
        UtilityCardHeader(
            title = if (isVi) "Cảnh báo sạc đầy" else "Full Charge Alert",
            subtitle = if (isVi) "Bảo vệ tuổi thọ pin, hỗ trợ hẹn thêm phút sạc no khi đạt 100%"
            else "Protect battery health with optional extra trickle-charge soak timer at 100%",
            icon = Icons.Filled.BatteryFull,
            accentColor = MaterialTheme.colorScheme.tertiary,
            checked = settings.fullChargeAlertEnabled,
            onCheckedChange = { on -> onUpdateUtilities { it.copy(fullChargeAlertEnabled = on) } },
            testTag = "util_full_charge_switch"
        ) {
            Text(
                text = if (isVi) "Ngưỡng báo sạc đầy: ${settings.fullChargeThreshold}%"
                else "Full charge threshold: ${settings.fullChargeThreshold}%",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Slider(
                value = settings.fullChargeThreshold.toFloat(),
                onValueChange = { raw ->
                    val snapped = ((raw / 5f).roundToInt() * 5).coerceIn(80, 100)
                    onUpdateUtilities { it.copy(fullChargeThreshold = snapped) }
                },
                valueRange = 80f..100f,
                steps = 3,
                modifier = Modifier.testTag("util_full_charge_slider")
            )

            AnimatedVisibility(visible = settings.fullChargeThreshold == 100) {
                Column(modifier = Modifier.padding(top = 6.dp, bottom = 4.dp)) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (isVi) {
                                    if (settings.fullChargeExtraMinutes == 0)
                                        "Báo ngay khi vừa chạm 100% (0 phút thêm)"
                                    else
                                        "Sạc thêm để no pin: +${settings.fullChargeExtraMinutes} phút sau khi đạt 100%"
                                } else {
                                    if (settings.fullChargeExtraMinutes == 0)
                                        "Alert immediately at 100% (0 extra min)"
                                    else
                                        "Extra soak time at 100%: +${settings.fullChargeExtraMinutes} min"
                                },
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Slider(
                                value = settings.fullChargeExtraMinutes.toFloat(),
                                onValueChange = { raw ->
                                    val snapped = ((raw / 5f).roundToInt() * 5).coerceIn(0, 60)
                                    onUpdateUtilities { it.copy(fullChargeExtraMinutes = snapped) }
                                },
                                valueRange = 0f..60f,
                                steps = 11,
                                modifier = Modifier.testTag("util_full_charge_extra_mins_slider")
                            )
                        }
                    }
                }
            }

            UtilityAlertChannelsSection(
                context = context,
                isVi = isVi,
                ringtoneChecked = settings.fullChargeRingtoneEnabled,
                onRingtoneChange = { on -> onUpdateUtilities { it.copy(fullChargeRingtoneEnabled = on) } },
                musicChecked = settings.fullChargeMusicEnabled,
                onMusicChange = { on -> onUpdateUtilities { it.copy(fullChargeMusicEnabled = on) } },
                soundUri = settings.fullChargeSoundUri,
                onPickSound = { onPickUtilitySound(UtilitySoundTarget.FULL_CHARGE, settings.fullChargeSoundUri) },
                ttsChecked = settings.fullChargeTtsEnabled,
                onTtsChange = { on -> onUpdateUtilities { it.copy(fullChargeTtsEnabled = on) } },
                showBatterySaverOption = false,
                batterySaverChecked = false,
                onBatterySaverChange = {},
                prefixTag = "full_chg"
            )
        }

        // 4. Overheat Temperature Alert
        UtilityCardHeader(
            title = if (isVi) "Cảnh báo nhiệt độ quá nóng" else "Overheat Temperature Alert",
            subtitle = if (isVi) "Theo dõi cảm biến nhiệt độ pin & nhắc hạ nhiệt chống chai pin"
            else "Monitor live battery thermal sensor and warn before overheating",
            icon = Icons.Filled.DeviceThermostat,
            accentColor = Color(0xFFFF7A45),
            checked = settings.overheatAlertEnabled,
            onCheckedChange = { on -> onUpdateUtilities { it.copy(overheatAlertEnabled = on) } },
            testTag = "util_overheat_switch"
        ) {
            Text(
                text = if (isVi) "Ngưỡng nhiệt độ cảnh báo: ${settings.overheatThresholdC}°C"
                else "Overheat threshold: ${settings.overheatThresholdC}°C",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Slider(
                value = settings.overheatThresholdC.toFloat(),
                onValueChange = { raw ->
                    onUpdateUtilities { it.copy(overheatThresholdC = raw.roundToInt().coerceIn(36, 55)) }
                },
                valueRange = 36f..55f,
                steps = 18,
                modifier = Modifier.testTag("util_overheat_temp_slider")
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isVi) "Kiểu cảnh báo:" else "Alert style:",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = !settings.overheatUseAlarmSound,
                    onClick = { onUpdateUtilities { it.copy(overheatUseAlarmSound = false) } },
                    label = { Text(if (isVi) "Thông báo tiêu chuẩn" else "Notification") },
                    leadingIcon = {
                        Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier.testTag("util_overheat_mode_notif")
                )
                FilterChip(
                    selected = settings.overheatUseAlarmSound,
                    onClick = { onUpdateUtilities { it.copy(overheatUseAlarmSound = true) } },
                    label = { Text(if (isVi) "Đổ chuông báo động" else "Alarm Ringtone") },
                    leadingIcon = {
                        Icon(Icons.Filled.Warning, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier.testTag("util_overheat_mode_alarm")
                )
            }

            if (settings.overheatUseAlarmSound) {
                Spacer(modifier = Modifier.height(6.dp))
                SoundPickerRow(
                    context = context,
                    isVi = isVi,
                    soundUri = settings.overheatSoundUri,
                    onPick = { onPickUtilitySound(UtilitySoundTarget.OVERHEAT, settings.overheatSoundUri) },
                    testTag = "util_overheat_pick_sound"
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isVi) "Báo lại sau mỗi: ${settings.overheatCooldownSeconds} giây (chống spam)"
                else "Repeat alert cooldown: ${settings.overheatCooldownSeconds}s (anti-spam)",
                style = MaterialTheme.typography.titleSmall
            )
            Slider(
                value = settings.overheatCooldownSeconds.toFloat(),
                onValueChange = { raw ->
                    val snapped = ((raw / 15f).roundToInt() * 15).coerceIn(15, 600)
                    onUpdateUtilities { it.copy(overheatCooldownSeconds = snapped) }
                },
                valueRange = 15f..600f,
                steps = 38,
                modifier = Modifier.testTag("util_overheat_cooldown_slider")
            )
        }

        // 5. Charging Anti-Theft Guard
        UtilityCardHeader(
            title = if (isVi) "Cảnh báo trộm khi sạc" else "Charging Anti-Theft Guard",
            subtitle = if (isVi) "Tự động canh giữ khi cắm sạc — rút dây trái phép sẽ hú còi, nháy Flash & khóa màn hình"
            else "Arms automatically while plugged in — unauthorized unplug triggers loud alarm & flash strobe",
            icon = Icons.Filled.Power,
            accentColor = MaterialTheme.colorScheme.secondary,
            statusBadge = when {
                antiTheftState.isChargeGuardArmed -> if (isVi) "ĐANG BẢO VỆ" else "ARMED"
                settings.chargeGuardEnabled -> if (isVi) "CHỜ CẮM SẠC" else "STANDBY"
                else -> null
            },
            checked = settings.chargeGuardEnabled,
            onCheckedChange = onRequestToggleChargeGuard,
            testTag = "util_charge_guard_switch"
        ) {
            Text(
                text = if (isVi) {
                    if (settings.chargeGuardMinBatteryPercent == 0)
                        "Tự kích hoạt ngay khi cắm sạc (mọi mức pin)"
                    else
                        "Tự bật khi cắm sạc và pin ≥ ${settings.chargeGuardMinBatteryPercent}%"
                } else {
                    if (settings.chargeGuardMinBatteryPercent == 0)
                        "Arm immediately on plug-in (any battery %)"
                    else
                        "Auto-arm on plug-in when battery ≥ ${settings.chargeGuardMinBatteryPercent}%"
                },
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Slider(
                value = settings.chargeGuardMinBatteryPercent.toFloat(),
                onValueChange = { raw ->
                    val snapped = ((raw / 5f).roundToInt() * 5).coerceIn(0, 100)
                    onUpdateUtilities { it.copy(chargeGuardMinBatteryPercent = snapped) }
                },
                valueRange = 0f..100f,
                steps = 19,
                modifier = Modifier.testTag("util_charge_guard_min_bat_slider")
            )

            Text(
                text = if (isVi) "Độ trễ sau khi rút sạc: ${settings.chargeGuardDelaySeconds} giây"
                else "Unplug grace delay: ${settings.chargeGuardDelaySeconds}s",
                style = MaterialTheme.typography.titleSmall
            )
            Slider(
                value = settings.chargeGuardDelaySeconds.toFloat(),
                onValueChange = { raw ->
                    onUpdateUtilities { it.copy(chargeGuardDelaySeconds = raw.roundToInt().coerceIn(0, 30)) }
                },
                valueRange = 0f..30f,
                steps = 29,
                modifier = Modifier.testTag("util_charge_guard_delay_slider")
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            SettingSwitchRow(
                title = if (isVi) "Hộp thoại xác nhận chủ động rút sạc" else "Owner unplug confirmation dialog",
                subtitle = if (isVi) "Cho phép nhập PIN 4 số hoặc vân tay để tắt trước khi còi hú"
                else "Allow entering 4-digit PIN or fingerprint to cancel before siren starts",
                checked = settings.chargeGuardConfirmDialogEnabled,
                onCheckedChange = { on -> onUpdateUtilities { it.copy(chargeGuardConfirmDialogEnabled = on) } },
                testTag = "util_charge_guard_confirm_switch"
            )

            AnimatedVisibility(visible = settings.chargeGuardConfirmDialogEnabled) {
                Column(modifier = Modifier.padding(bottom = 8.dp)) {
                    val confirmSec = DeviceGuardEngine.clampConfirmSeconds(settings.chargeGuardConfirmSeconds)
                    Text(
                        text = if (isVi) "Thời gian xác nhận tối đa: $confirmSec giây (≤ 120s)"
                        else "Confirmation window: ${confirmSec}s (max 120s)",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Slider(
                        value = confirmSec.toFloat(),
                        onValueChange = { raw ->
                            val snapped = ((raw / 5f).roundToInt() * 5).coerceIn(5, 120)
                            onUpdateUtilities { it.copy(chargeGuardConfirmSeconds = snapped) }
                        },
                        valueRange = 5f..120f,
                        steps = 22,
                        modifier = Modifier.testTag("util_charge_guard_confirm_slider")
                    )
                }
            }

            SettingSwitchRow(
                title = if (isVi) "Nháy đèn Flash khi báo động" else "Strobe rear Flash on alarm",
                subtitle = "",
                checked = settings.chargeGuardFlashEnabled,
                onCheckedChange = { on -> onUpdateUtilities { it.copy(chargeGuardFlashEnabled = on) } },
                testTag = "util_charge_guard_flash_switch",
                leadingIcon = Icons.Filled.FlashlightOn
            )
            SettingSwitchRow(
                title = if (isVi) "Rung mạnh liên tục" else "Strong continuous vibration",
                subtitle = "",
                checked = settings.chargeGuardVibrateEnabled,
                onCheckedChange = { on -> onUpdateUtilities { it.copy(chargeGuardVibrateEnabled = on) } },
                testTag = "util_charge_guard_vibrate_switch",
                leadingIcon = Icons.Filled.Vibration
            )

            AntiTheftProtectionNotice(isVi = isVi)
        }

        // 6. Active Motion Anti-Theft Guard
        UtilityCardHeader(
            title = if (isVi) "Báo trộm chủ động (Cảm biến dịch chuyển)" else "Active Motion Anti-Theft Guard",
            subtitle = if (isVi) "Phát hiện nhấc hoặc di chuyển điện thoại — bật nhanh bằng nút Khiên ở Hộp thư"
            else "Detects movement or pickup using live accelerometer — also toggleable from Inbox Shield FAB",
            icon = Icons.Filled.Shield,
            accentColor = MaterialTheme.colorScheme.error,
            statusBadge = when {
                antiTheftState.motionArmingCountdownSec > 0 ->
                    if (isVi) "BẬT SAU ${antiTheftState.motionArmingCountdownSec}s" else "ARMING ${antiTheftState.motionArmingCountdownSec}s"
                antiTheftState.isMotionGuardArmed -> if (isVi) "ĐANG CANH GIỮ" else "ARMED"
                else -> null
            },
            checked = settings.motionGuardEnabled,
            onCheckedChange = onRequestToggleMotionGuard,
            testTag = "util_motion_guard_switch"
        ) {
            Text(
                text = if (isVi) "Độ nhạy cảm biến dịch chuyển:" else "Motion sensor sensitivity:",
                style = MaterialTheme.typography.titleSmall
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MotionSensitivity.entries.forEach { sens ->
                    val label = when (sens) {
                        MotionSensitivity.LOW -> if (isVi) "Thấp (ít báo giả)" else "Low"
                        MotionSensitivity.MEDIUM -> if (isVi) "Vừa (Khuyên dùng)" else "Medium"
                        MotionSensitivity.HIGH -> if (isVi) "Cao (siêu nhạy)" else "High"
                    }
                    FilterChip(
                        selected = settings.motionGuardSensitivity == sens.level,
                        onClick = { onUpdateUtilities { it.copy(motionGuardSensitivity = sens.level) } },
                        label = { Text(label, style = MaterialTheme.typography.labelMedium) },
                        modifier = Modifier.testTag("util_motion_sens_${sens.name.lowercase()}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isVi) "Độ trễ chuẩn bị đặt máy: ${settings.motionGuardArmDelaySeconds} giây"
                else "Arming settle delay: ${settings.motionGuardArmDelaySeconds}s",
                style = MaterialTheme.typography.titleSmall
            )
            Slider(
                value = settings.motionGuardArmDelaySeconds.toFloat(),
                onValueChange = { raw ->
                    onUpdateUtilities { it.copy(motionGuardArmDelaySeconds = raw.roundToInt().coerceIn(0, 30)) }
                },
                valueRange = 0f..30f,
                steps = 29,
                modifier = Modifier.testTag("util_motion_arm_delay_slider")
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            SettingSwitchRow(
                title = if (isVi) "Hộp thoại xác nhận trước khi hú còi" else "Pre-alarm owner confirmation dialog",
                subtitle = if (isVi) "Nhập PIN 4 số hoặc vân tay trong thời gian đếm ngược để hủy báo động"
                else "Enter 4-digit PIN or biometric during countdown to cancel alarm",
                checked = settings.motionGuardConfirmDialogEnabled,
                onCheckedChange = { on -> onUpdateUtilities { it.copy(motionGuardConfirmDialogEnabled = on) } },
                testTag = "util_motion_guard_confirm_switch"
            )

            AnimatedVisibility(visible = settings.motionGuardConfirmDialogEnabled) {
                Column(modifier = Modifier.padding(bottom = 8.dp)) {
                    val confirmSec = DeviceGuardEngine.clampConfirmSeconds(settings.motionGuardConfirmSeconds)
                    Text(
                        text = if (isVi) "Thời gian xác nhận tối đa: $confirmSec giây (≤ 120s)"
                        else "Confirmation window: ${confirmSec}s (max 120s)",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Slider(
                        value = confirmSec.toFloat(),
                        onValueChange = { raw ->
                            val snapped = ((raw / 5f).roundToInt() * 5).coerceIn(5, 120)
                            onUpdateUtilities { it.copy(motionGuardConfirmSeconds = snapped) }
                        },
                        valueRange = 5f..120f,
                        steps = 22,
                        modifier = Modifier.testTag("util_motion_guard_confirm_slider")
                    )
                }
            }

            SettingSwitchRow(
                title = if (isVi) "Nháy đèn Flash khi báo động" else "Strobe rear Flash on alarm",
                subtitle = "",
                checked = settings.motionGuardFlashEnabled,
                onCheckedChange = { on -> onUpdateUtilities { it.copy(motionGuardFlashEnabled = on) } },
                testTag = "util_motion_guard_flash_switch",
                leadingIcon = Icons.Filled.FlashlightOn
            )
            SettingSwitchRow(
                title = if (isVi) "Rung mạnh liên tục" else "Strong continuous vibration",
                subtitle = "",
                checked = settings.motionGuardVibrateEnabled,
                onCheckedChange = { on -> onUpdateUtilities { it.copy(motionGuardVibrateEnabled = on) } },
                testTag = "util_motion_guard_vibrate_switch",
                leadingIcon = Icons.Filled.Vibration
            )

            AntiTheftProtectionNotice(isVi = isVi)
        }
    }
}

@Composable
private fun UtilityCardHeader(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String,
    statusBadge: String? = null,
    expandedContent: @Composable () -> Unit
) {
    SettingsCard(title = title) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = accentColor.copy(alpha = 0.16f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.size(40.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                if (statusBadge != null) {
                    Surface(
                        color = accentColor.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.55f))
                    ) {
                        Text(
                            text = statusBadge,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = accentColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            com.example.ui.components.GlassSwitch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                modifier = Modifier.testTag(testTag)
            )
        }

        AnimatedVisibility(visible = checked) {
            Column(modifier = Modifier.padding(top = 12.dp)) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(10.dp))
                expandedContent()
            }
        }
    }
}

@Composable
private fun UtilityAlertChannelsSection(
    context: Context,
    isVi: Boolean,
    ringtoneChecked: Boolean,
    onRingtoneChange: (Boolean) -> Unit,
    musicChecked: Boolean,
    onMusicChange: (Boolean) -> Unit,
    soundUri: String,
    onPickSound: () -> Unit,
    ttsChecked: Boolean,
    onTtsChange: (Boolean) -> Unit,
    showBatterySaverOption: Boolean,
    batterySaverChecked: Boolean,
    onBatterySaverChange: (Boolean) -> Unit,
    prefixTag: String
) {
    SettingSwitchRow(
        title = if (isVi) "Đổ chuông thông báo" else "Notification ringtone",
        subtitle = "",
        checked = ringtoneChecked,
        onCheckedChange = onRingtoneChange,
        testTag = "util_${prefixTag}_ringtone",
        leadingIcon = Icons.Filled.PhonelinkRing
    )
    SettingSwitchRow(
        title = if (isVi) "Phát nhạc thông báo tùy chọn" else "Custom notification sound",
        subtitle = "",
        checked = musicChecked,
        onCheckedChange = onMusicChange,
        testTag = "util_${prefixTag}_music",
        leadingIcon = Icons.Filled.MusicNote
    )
    AnimatedVisibility(visible = musicChecked) {
        SoundPickerRow(
            context = context,
            isVi = isVi,
            soundUri = soundUri,
            onPick = onPickSound,
            testTag = "util_${prefixTag}_pick_sound"
        )
    }
    SettingSwitchRow(
        title = if (isVi) "Đọc to bằng giọng nói (TTS)" else "Voice announcement (TTS)",
        subtitle = "",
        checked = ttsChecked,
        onCheckedChange = onTtsChange,
        testTag = "util_${prefixTag}_tts",
        leadingIcon = Icons.Filled.RecordVoiceOver
    )
    if (showBatterySaverOption) {
        SettingSwitchRow(
            title = if (isVi) "Nhắc bật Tiết kiệm pin (nút mở nhanh)" else "Battery Saver quick-action prompt",
            subtitle = if (isVi) "Kèm nút mở thẳng Cài đặt Tiết kiệm pin hệ thống trong thông báo cảnh báo"
            else "Includes a 1-tap button on the alert notification to open Android Battery Saver",
            checked = batterySaverChecked,
            onCheckedChange = onBatterySaverChange,
            testTag = "util_${prefixTag}_saver",
            leadingIcon = Icons.Filled.BatterySaver
        )
    }
}

@Composable
private fun SoundPickerRow(
    context: Context,
    isVi: Boolean,
    soundUri: String,
    onPick: () -> Unit,
    testTag: String
) {
    val resolvedName = remember(soundUri) {
        if (soundUri.isBlank()) {
            if (isVi) "Nhạc chuông mặc định hệ thống" else "System default sound"
        } else {
            runCatching {
                RingtoneManager.getRingtone(context, Uri.parse(soundUri))?.getTitle(context)
            }.getOrNull().orEmpty().ifBlank {
                if (isVi) "Âm thanh đã chọn" else "Selected custom sound"
            }
        }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = resolvedName,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        OutlinedButton(
            onClick = onPick,
            modifier = Modifier.testTag(testTag)
        ) {
            Icon(Icons.Filled.MusicNote, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(if (isVi) "Chọn nhạc" else "Pick sound")
        }
    }
}

@Composable
private fun AntiTheftProtectionNotice(isVi: Boolean) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.35f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.GppGood,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = if (isVi) {
                    "Khi còi báo trộm đã reo: âm lượng báo thức tự khóa tối đa, chặn nút giảm âm/Back và tự hiện lại màn hình báo động. Bắt buộc nhập đúng mã PIN 4 số (dùng chung tab Bảo mật) để tắt còi."
                } else {
                    "Once siren rings: alarm volume locks at maximum, volume/Back keys are blocked, and alarm screen re-appears if hidden. Only your 4-digit Security PIN stops the siren."
                },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
        }
    }
}
