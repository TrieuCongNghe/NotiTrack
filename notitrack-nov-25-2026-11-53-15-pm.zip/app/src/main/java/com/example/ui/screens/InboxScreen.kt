package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.NotificationEntity
import com.example.data.model.TtsFeedbackRuleEntity
import com.example.engine.AntiTheftRuntimeState
import com.example.engine.AppInboxGroup
import com.example.engine.ConversationThreadSummary
import com.example.engine.SmartTtsTemplateEngine
import com.example.engine.TtsFeedbackEngine
import com.example.ui.components.AppIconAvatar
import com.example.ui.components.GlassCard
import com.example.ui.components.ListenerAccessBanner
import com.example.ui.components.NotiTrackSearchBar
import com.example.ui.components.OtpCopyPill
import com.example.ui.components.formatFullTimestamp
import com.example.ui.components.formatRelativeTimestamp
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.LocalGlassStyle
import com.example.ui.viewmodel.InboxFilter

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun InboxScreen(
    allNotifications: List<NotificationEntity>,
    notifications: List<NotificationEntity>,
    appInboxGroups: List<AppInboxGroup>,
    activeAppGroup: AppInboxGroup?,
    conversationThreads: List<ConversationThreadSummary>,
    activeThread: ConversationThreadSummary?,
    activeThreadMessages: List<NotificationEntity>,
    ttsFeedbackRules: List<TtsFeedbackRuleEntity>,
    isChatGroupedView: Boolean,
    unreadCount: Int,
    inboxResetTrigger: Int,
    inboxPulseEpoch: Int,
    antiTheftState: AntiTheftRuntimeState,
    motionGuardEnabled: Boolean,
    query: String,
    activeFilter: InboxFilter,
    isListenerEnabled: Boolean,
    isLockConfigured: Boolean,
    speakingNotificationId: Long?,
    onQueryChange: (String) -> Unit,
    onFilterChange: (InboxFilter) -> Unit,
    onToggleChatGroupedView: () -> Unit,
    onOpenAppGroup: (String?) -> Unit,
    onOpenThread: (String?) -> Unit,
    onMarkAllRead: () -> Unit,
    onToggleMotionGuardQuick: () -> Unit,
    onMarkRead: (Long) -> Unit,
    onToggleStar: (NotificationEntity) -> Unit,
    onToggleHidden: (NotificationEntity) -> Unit,
    onDeleteNotification: (Long) -> Unit,
    onDeleteNotificationsByIds: (List<Long>) -> Unit,
    onDeleteReadOnly: (List<Long>?) -> Unit,
    onClearAllNotifications: () -> Unit,
    onToggleSpeak: (NotificationEntity) -> Unit,
    onSubmitTtsFeedback: (NotificationEntity, Boolean) -> Unit,
    onOpenAppTarget: (packageName: String, appName: String, notificationId: Long?, notificationKey: String?) -> Unit,
    onOpenListenerSettings: () -> Unit,
    onSendTestNotification: () -> Unit,
    onLockNow: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val s = LocalAppStrings.current

    var inspectedNotification by remember { mutableStateOf<NotificationEntity?>(null) }
    var selectionMode by remember { mutableStateOf(false) }
    var selectedNotificationIds by remember { mutableStateOf(emptySet<Long>()) }
    var pendingDeleteTargets by remember { mutableStateOf<List<NotificationEntity>?>(null) }
    var pendingClearAllArchive by remember { mutableStateOf(false) }

    val visibleIds = remember(notifications) { notifications.map { it.id }.toSet() }
    val inboxListState = rememberLazyListState()
    val isFabExpanded by remember {
        derivedStateOf { inboxListState.firstVisibleItemIndex == 0 }
    }

    // 3.5-second luminous attention blink on unread items when launching app or entering Inbox
    val unreadPulse = remember { Animatable(0f) }
    LaunchedEffect(inboxPulseEpoch, unreadCount > 0) {
        if (unreadCount > 0) {
            unreadPulse.snapTo(0f)
            repeat(3) {
                unreadPulse.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
                unreadPulse.animateTo(0.15f, tween(520, easing = FastOutSlowInEasing))
            }
            unreadPulse.animateTo(0f, tween(380))
        } else {
            unreadPulse.snapTo(0f)
        }
    }

    LaunchedEffect(inboxResetTrigger) {
        if (inboxResetTrigger > 0) {
            inspectedNotification = null
            selectionMode = false
            selectedNotificationIds = emptySet()
            inboxListState.animateScrollToItem(0)
        }
    }

    if (selectionMode && activeThread == null && activeAppGroup == null) {
        BackHandler {
            selectionMode = false
            selectedNotificationIds = emptySet()
        }
    }

    if (activeThread != null) {
        ChatTimelineView(
            thread = activeThread,
            messages = activeThreadMessages,
            ttsFeedbackRules = ttsFeedbackRules,
            speakingNotificationId = speakingNotificationId,
            onBack = { onOpenThread(null) },
            onInspectNotification = { item ->
                if (!item.isRead) onMarkRead(item.id)
                inspectedNotification = item
            },
            onCopyOtp = { code ->
                copyToClipboard(context, "OTP", code)
                onShowMessage(s.inboxCopiedOtp(code))
            },
            onToggleSpeak = onToggleSpeak,
            onToggleStar = onToggleStar,
            onOpenAppTarget = onOpenAppTarget,
            onRequestBulkDelete = { targets ->
                pendingClearAllArchive = false
                pendingDeleteTargets = targets
            },
            modifier = modifier
        )
    } else if (isChatGroupedView && activeAppGroup != null) {
        AppThreadsLevelView(
            appGroup = activeAppGroup,
            allNotifications = notifications,
            onBack = { onOpenAppGroup(null) },
            onOpenThread = onOpenThread,
            onOpenAppTarget = onOpenAppTarget,
            onRequestBulkDelete = { targets ->
                pendingClearAllArchive = false
                pendingDeleteTargets = targets
            },
            modifier = modifier
        )
    } else {
        Box(modifier = modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(10.dp))

            if (selectionMode) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    selectionMode = false
                                    selectedNotificationIds = emptySet()
                                },
                                modifier = Modifier.testTag("inbox_exit_select_mode")
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = s.close)
                            }
                            Text(
                                text = s.inboxSelectedCount(selectedNotificationIds.size),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            val allSelected = visibleIds.isNotEmpty() && selectedNotificationIds.containsAll(visibleIds)
                            IconButton(
                                onClick = {
                                    selectedNotificationIds = if (allSelected) emptySet() else visibleIds
                                },
                                modifier = Modifier.testTag("inbox_select_all_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.SelectAll,
                                    contentDescription = if (allSelected) s.inboxDeselectAll else s.inboxSelectAll
                                )
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    val targets = notifications.filter { it.id in selectedNotificationIds }
                                    if (targets.isNotEmpty()) {
                                        pendingClearAllArchive = false
                                        pendingDeleteTargets = targets
                                    }
                                },
                                enabled = selectedNotificationIds.isNotEmpty(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error,
                                    contentColor = MaterialTheme.colorScheme.onError
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("inbox_delete_selected_button")
                            ) {
                                Icon(Icons.Filled.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(s.inboxDeleteSelected, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }

                            OutlinedButton(
                                onClick = {
                                    if (allNotifications.isNotEmpty()) {
                                        pendingClearAllArchive = true
                                        pendingDeleteTargets = allNotifications
                                    }
                                },
                                enabled = allNotifications.isNotEmpty(),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                ),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.45f)),
                                modifier = Modifier.testTag("inbox_delete_all_archive_button")
                            ) {
                                Icon(Icons.Filled.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(s.inboxDeleteAll, maxLines = 1)
                            }
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = s.appName,
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isListenerEnabled) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.error
                                    )
                            )
                            Text(
                                text = if (isListenerEnabled) s.listenerActive else s.listenerInactive,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = onToggleChatGroupedView,
                        modifier = Modifier.testTag("toggle_grouped_view_button")
                    ) {
                        Icon(
                            imageVector = if (isChatGroupedView) Icons.AutoMirrored.Filled.ViewList else Icons.Filled.Forum,
                            contentDescription = if (isChatGroupedView) s.inboxTimeline else s.inboxGrouped,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(
                        onClick = {
                            selectionMode = true
                            selectedNotificationIds = emptySet()
                        },
                        enabled = notifications.isNotEmpty(),
                        modifier = Modifier.testTag("inbox_enter_select_mode")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Checklist,
                            contentDescription = s.inboxSelectMode,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(
                        onClick = onMarkAllRead,
                        modifier = Modifier.testTag("mark_all_read_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DoneAll,
                            contentDescription = s.inboxMarkAllRead,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (isLockConfigured) {
                        IconButton(
                            onClick = onLockNow,
                            modifier = Modifier.testTag("quick_lock_app_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = s.inboxLockNow,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            NotiTrackSearchBar(
                query = query,
                placeholder = s.inboxSearchHint,
                onQueryChange = onQueryChange,
                testTag = "inbox_search_input"
            )

            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(InboxFilter.entries) { filter ->
                    FilterChip(
                        selected = activeFilter == filter,
                        onClick = { onFilterChange(filter) },
                        label = {
                            Text(
                                text = s.inboxFilterLabels[filter] ?: filter.labelVi,
                                style = MaterialTheme.typography.labelLarge
                            )
                        },
                        modifier = Modifier.testTag("inbox_filter_${filter.name.lowercase()}")
                    )
                }
            }

            if (isChatGroupedView && conversationThreads.isNotEmpty() && !selectionMode) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Forum,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = s.inboxChatGroupingHint,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        onClick = {
                            pendingClearAllArchive = true
                            pendingDeleteTargets = allNotifications
                        },
                        modifier = Modifier.testTag("inbox_quick_clear_all_button")
                    ) {
                        Text(
                            text = s.inboxDeleteAll,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(10.dp))
            }

            LazyColumn(
                state = inboxListState,
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 92.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (!isListenerEnabled) {
                    item(key = "listener_banner") {
                        ListenerAccessBanner(onGrantAccess = onOpenListenerSettings)
                    }
                }

                if (isChatGroupedView) {
                    if (appInboxGroups.isEmpty()) {
                        item(key = "empty_grouped") {
                            EmptyInboxCard(
                                isListenerEnabled = isListenerEnabled,
                                onGrantAccess = onOpenListenerSettings,
                                onSendTestNotification = onSendTestNotification
                            )
                        }
                    } else {
                        items(appInboxGroups, key = { it.packageName }) { appGroup ->
                            val isAppSelected = appGroup.notificationIds.isNotEmpty() &&
                                appGroup.notificationIds.all { it in selectedNotificationIds }
                            AppInboxGroupCard(
                                group = appGroup,
                                unreadPulseFraction = unreadPulse.value,
                                selectionMode = selectionMode,
                                isSelected = isAppSelected,
                                onOpenAppTarget = {
                                    onOpenAppTarget(
                                        appGroup.packageName,
                                        appGroup.appName,
                                        appGroup.latestNotificationId,
                                        appGroup.latestNotificationKey
                                    )
                                },
                                onClick = {
                                    if (selectionMode) {
                                        selectedNotificationIds = if (isAppSelected) {
                                            selectedNotificationIds - appGroup.notificationIds.toSet()
                                        } else {
                                            selectedNotificationIds + appGroup.notificationIds
                                        }
                                    } else {
                                        onOpenAppGroup(appGroup.packageName)
                                    }
                                },
                                onLongClick = {
                                    if (!selectionMode) {
                                        selectionMode = true
                                        selectedNotificationIds = appGroup.notificationIds.toSet()
                                    } else {
                                        selectedNotificationIds = if (isAppSelected) {
                                            selectedNotificationIds - appGroup.notificationIds.toSet()
                                        } else {
                                            selectedNotificationIds + appGroup.notificationIds
                                        }
                                    }
                                }
                            )
                        }
                    }
                } else {
                    if (notifications.isEmpty()) {
                        item(key = "empty_timeline") {
                            EmptyInboxCard(
                                isListenerEnabled = isListenerEnabled,
                                onGrantAccess = onOpenListenerSettings,
                                onSendTestNotification = onSendTestNotification
                            )
                        }
                    } else {
                        items(notifications, key = { it.id }) { item ->
                            val isSelected = item.id in selectedNotificationIds
                            val matchedFeedback = remember(item.id, ttsFeedbackRules) {
                                TtsFeedbackEngine.findBestMatch(
                                    packageName = item.packageName,
                                    title = item.title,
                                    content = item.content,
                                    rules = ttsFeedbackRules
                                )
                            }
                            NotificationCard(
                                item = item,
                                unreadPulseFraction = unreadPulse.value,
                                matchedFeedback = matchedFeedback,
                                isSpeaking = speakingNotificationId == item.id,
                                selectionMode = selectionMode,
                                isSelected = isSelected,
                                onOpenAppTarget = {
                                    onOpenAppTarget(
                                        item.packageName,
                                        item.appName,
                                        item.id,
                                        item.notificationKey
                                    )
                                },
                                onClick = {
                                    if (selectionMode) {
                                        selectedNotificationIds = if (isSelected) {
                                            selectedNotificationIds - item.id
                                        } else {
                                            selectedNotificationIds + item.id
                                        }
                                    } else {
                                        if (!item.isRead) onMarkRead(item.id)
                                        inspectedNotification = item
                                    }
                                },
                                onLongClick = {
                                    if (!selectionMode) {
                                        selectionMode = true
                                        selectedNotificationIds = setOf(item.id)
                                    } else {
                                        selectedNotificationIds = if (isSelected) {
                                            selectedNotificationIds - item.id
                                        } else {
                                            selectedNotificationIds + item.id
                                        }
                                    }
                                },
                                onCopyOtp = { code ->
                                    copyToClipboard(context, "OTP", code)
                                    onShowMessage(s.inboxCopiedOtp(code))
                                },
                                onToggleSpeak = { onToggleSpeak(item) },
                                onToggleStar = { onToggleStar(item) }
                            )
                        }
                    }
                }
            }
            }

            if (!selectionMode) {
                val isGuardActive = motionGuardEnabled || antiTheftState.isMotionGuardArmed
                val guardPulseTransition = rememberInfiniteTransition(label = "shield_fab_pulse")
                val guardScale by guardPulseTransition.animateFloat(
                    initialValue = 1f,
                    targetValue = if (isGuardActive) 1.07f else 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(750, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "shield_fab_scale"
                )
                val shieldBg by animateColorAsState(
                    targetValue = if (isGuardActive) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.surfaceContainerHigh,
                    animationSpec = tween(260),
                    label = "shield_fab_bg"
                )
                val shieldFg by animateColorAsState(
                    targetValue = if (isGuardActive) MaterialTheme.colorScheme.onError
                    else MaterialTheme.colorScheme.primary,
                    animationSpec = tween(260),
                    label = "shield_fab_fg"
                )

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 16.dp, bottom = 16.dp),
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ExtendedFloatingActionButton(
                        onClick = onToggleMotionGuardQuick,
                        expanded = isFabExpanded || isGuardActive,
                        icon = {
                            Icon(
                                imageVector = if (isGuardActive) Icons.Filled.Shield else Icons.Outlined.Shield,
                                contentDescription = s.inboxShieldFabArm
                            )
                        },
                        text = {
                            val label = when {
                                antiTheftState.motionArmingCountdownSec > 0 ->
                                    "${s.inboxShieldFabArmed} (${antiTheftState.motionArmingCountdownSec}s)"
                                isGuardActive -> s.inboxShieldFabArmed
                                else -> s.inboxShieldFabArm
                            }
                            Text(text = label, fontWeight = FontWeight.Bold)
                        },
                        containerColor = shieldBg,
                        contentColor = shieldFg,
                        modifier = Modifier
                            .scale(if (isGuardActive) guardScale else 1f)
                            .testTag("inbox_fab_motion_guard")
                    )

                    ExtendedFloatingActionButton(
                        onClick = onMarkAllRead,
                        expanded = isFabExpanded && unreadCount > 0,
                        icon = {
                            Icon(
                                imageVector = Icons.Filled.DoneAll,
                                contentDescription = s.inboxMarkAllRead
                            )
                        },
                        text = {
                            Text(
                                text = if (unreadCount > 0) "${s.inboxFabMarkAllRead} ($unreadCount)" else s.inboxFabMarkAllRead,
                                fontWeight = FontWeight.SemiBold
                            )
                        },
                        containerColor = if (unreadCount > 0) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.surfaceContainerHigh
                        },
                        contentColor = if (unreadCount > 0) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.testTag("inbox_fab_mark_all_read")
                    )
                }
            }
        }
    }

    pendingDeleteTargets?.let { targets ->
        val unreadCount = targets.count { !it.isRead }
        val targetIds = targets.map { it.id }
        BulkDeleteConfirmDialog(
            totalCount = targets.size,
            unreadCount = unreadCount,
            onDismiss = {
                pendingDeleteTargets = null
                pendingClearAllArchive = false
            },
            onDeleteOnlyRead = {
                if (pendingClearAllArchive) {
                    onDeleteReadOnly(null)
                } else {
                    onDeleteReadOnly(targetIds)
                }
                pendingDeleteTargets = null
                pendingClearAllArchive = false
                selectionMode = false
                selectedNotificationIds = emptySet()
            },
            onDeleteAll = {
                if (pendingClearAllArchive) {
                    onClearAllNotifications()
                } else {
                    onDeleteNotificationsByIds(targetIds)
                }
                pendingDeleteTargets = null
                pendingClearAllArchive = false
                selectionMode = false
                selectedNotificationIds = emptySet()
            }
        )
    }

    inspectedNotification?.let { selected ->
        val latestState = allNotifications.find { it.id == selected.id } ?: selected
        val matchedFeedback = remember(latestState.id, ttsFeedbackRules) {
            TtsFeedbackEngine.findBestMatch(
                packageName = latestState.packageName,
                title = latestState.title,
                content = latestState.content,
                rules = ttsFeedbackRules
            )
        }
        NotificationDetailBottomSheet(
            notification = latestState,
            matchedFeedback = matchedFeedback,
            isSpeaking = speakingNotificationId == latestState.id,
            onDismiss = { inspectedNotification = null },
            onOpenAppTarget = {
                onOpenAppTarget(
                    latestState.packageName,
                    latestState.appName,
                    latestState.id,
                    latestState.notificationKey
                )
            },
            onSubmitTtsFeedback = { shouldSpeak ->
                onSubmitTtsFeedback(latestState, shouldSpeak)
            },
            onCopyAll = {
                copyToClipboard(context, latestState.title, "${latestState.title}\n${latestState.content}")
                onShowMessage(s.inboxCopied)
            },
            onCopyOtp = { otp ->
                copyToClipboard(context, "OTP", otp)
                onShowMessage(s.inboxCopiedOtp(otp))
            },
            onShare = {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, latestState.title)
                    putExtra(
                        Intent.EXTRA_TEXT,
                        "[${latestState.appName}] ${latestState.title}\n${latestState.content}"
                    )
                }
                context.startActivity(Intent.createChooser(shareIntent, s.inboxShareTitle))
            },
            onToggleSpeak = { onToggleSpeak(latestState) },
            onToggleStar = { onToggleStar(latestState) },
            onToggleHidden = { onToggleHidden(latestState) },
            onDelete = {
                onDeleteNotification(latestState.id)
                inspectedNotification = null
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppInboxGroupCard(
    group: AppInboxGroup,
    unreadPulseFraction: Float,
    selectionMode: Boolean,
    isSelected: Boolean,
    onOpenAppTarget: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val s = LocalAppStrings.current
    val glass = LocalGlassStyle.current
    val hasUnread = group.unreadCount > 0
    val pulse = if (hasUnread) unreadPulseFraction else 0f
    val baseBg = when {
        isSelected -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
        group.hasHighlighted -> lerp(glass.cardElevatedFill, MaterialTheme.colorScheme.secondaryContainer, 0.35f)
        hasUnread -> lerp(
            glass.cardElevatedFill,
            MaterialTheme.colorScheme.primaryContainer,
            0.28f + 0.24f * pulse
        )
        else -> glass.cardFill
    }
    val borderColor = when {
        isSelected -> MaterialTheme.colorScheme.primary
        group.hasHighlighted -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.68f)
        hasUnread -> MaterialTheme.colorScheme.primary.copy(alpha = 0.55f + 0.45f * pulse)
        else -> glass.cardBorder.copy(alpha = 0.6f)
    }

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clip(glass.cardShape)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("app_inbox_group_${group.packageName}"),
        containerColor = baseBg,
        borderColor = borderColor,
        borderWidth = if (isSelected || (hasUnread && pulse > 0.2f)) 1.6.dp else 1.dp
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selectionMode) {
                Icon(
                    imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .padding(end = 10.dp)
                        .size(22.dp)
                )
            }

            AppIconAvatar(
                packageName = group.packageName,
                appName = group.appName,
                size = 48.dp,
                onClick = if (selectionMode) null else onOpenAppTarget,
                clickContentDescription = s.launchDeepLinkDesc(group.appName),
                modifier = Modifier.testTag("app_group_icon_${group.packageName}")
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = group.appName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (group.unreadCount > 0) FontWeight.Bold else FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = formatRelativeTimestamp(group.latestTimestamp, s),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = s.inboxThreadsSummary(group.threads.size, group.totalCount),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                val preview = if (group.latestThreadTitle.isNotBlank() &&
                    !group.latestThreadTitle.equals(group.appName, ignoreCase = true)
                ) {
                    "${group.latestThreadTitle}: ${group.latestPreview}"
                } else {
                    group.latestPreview
                }
                Text(
                    text = preview,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = if (group.unreadCount > 0) FontWeight.Medium else FontWeight.Normal,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (group.unreadCount > 0) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    Text(
                        text = if (group.unreadCount > 0) "${group.unreadCount}" else "${group.totalCount}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (group.unreadCount > 0) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                    )
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppThreadsLevelView(
    appGroup: AppInboxGroup,
    allNotifications: List<NotificationEntity>,
    onBack: () -> Unit,
    onOpenThread: (String) -> Unit,
    onOpenAppTarget: (packageName: String, appName: String, notificationId: Long?, notificationKey: String?) -> Unit,
    onRequestBulkDelete: (List<NotificationEntity>) -> Unit,
    modifier: Modifier = Modifier
) {
    val s = LocalAppStrings.current
    var selectionMode by remember(appGroup.packageName) { mutableStateOf(false) }
    var selectedIds by remember(appGroup.packageName) { mutableStateOf(emptySet<Long>()) }

    BackHandler {
        if (selectionMode) {
            selectionMode = false
            selectedIds = emptySet()
        } else {
            onBack()
        }
    }

    val appNotificationEntities = remember(allNotifications, appGroup.notificationIds) {
        val idSet = appGroup.notificationIds.toSet()
        allNotifications.filter { it.id in idSet }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        if (selectionMode) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        selectionMode = false
                        selectedIds = emptySet()
                    }) {
                        Icon(Icons.Filled.Close, contentDescription = s.close)
                    }
                    Text(
                        text = s.inboxSelectedCount(selectedIds.size),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    val allSelected = appGroup.notificationIds.isNotEmpty() &&
                        selectedIds.containsAll(appGroup.notificationIds)
                    IconButton(onClick = {
                        selectedIds = if (allSelected) emptySet() else appGroup.notificationIds.toSet()
                    }) {
                        Icon(
                            imageVector = Icons.Filled.SelectAll,
                            contentDescription = if (allSelected) s.inboxDeselectAll else s.inboxSelectAll
                        )
                    }
                    IconButton(
                        enabled = selectedIds.isNotEmpty(),
                        onClick = {
                            val targets = appNotificationEntities.filter { it.id in selectedIds }
                            if (targets.isNotEmpty()) {
                                onRequestBulkDelete(targets)
                                selectionMode = false
                                selectedIds = emptySet()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Delete,
                            contentDescription = s.inboxDeleteSelected,
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        } else {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceContainerLowest,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("app_group_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = s.back)
                    }
                    AppIconAvatar(
                        packageName = appGroup.packageName,
                        appName = appGroup.appName,
                        size = 40.dp,
                        onClick = {
                            onOpenAppTarget(
                                appGroup.packageName,
                                appGroup.appName,
                                appGroup.latestNotificationId,
                                appGroup.latestNotificationKey
                            )
                        },
                        clickContentDescription = s.launchDeepLinkDesc(appGroup.appName),
                        modifier = Modifier.testTag("app_threads_header_icon")
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = appGroup.appName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = s.inboxThreadsSummary(appGroup.threads.size, appGroup.totalCount),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = {
                            selectionMode = true
                            selectedIds = emptySet()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Checklist,
                            contentDescription = s.inboxSelectMode,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = {
                            if (appNotificationEntities.isNotEmpty()) {
                                onRequestBulkDelete(appNotificationEntities)
                            }
                        },
                        modifier = Modifier.testTag("app_group_delete_all_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteSweep,
                            contentDescription = s.delete,
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(appGroup.threads, key = { it.threadKey }) { thread ->
                val isThreadSelected = thread.notificationIds.isNotEmpty() &&
                    thread.notificationIds.all { it in selectedIds }
                ConversationThreadCard(
                    thread = thread,
                    selectionMode = selectionMode,
                    isSelected = isThreadSelected,
                    onOpenAppTarget = {
                        onOpenAppTarget(
                            thread.packageName,
                            thread.appName,
                            thread.latestNotificationId,
                            thread.latestNotificationKey
                        )
                    },
                    onClick = {
                        if (selectionMode) {
                            selectedIds = if (isThreadSelected) {
                                selectedIds - thread.notificationIds.toSet()
                            } else {
                                selectedIds + thread.notificationIds
                            }
                        } else {
                            onOpenThread(thread.threadKey)
                        }
                    },
                    onLongClick = {
                        if (!selectionMode) {
                            selectionMode = true
                            selectedIds = thread.notificationIds.toSet()
                        } else {
                            selectedIds = if (isThreadSelected) {
                                selectedIds - thread.notificationIds.toSet()
                            } else {
                                selectedIds + thread.notificationIds
                            }
                        }
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ConversationThreadCard(
    thread: ConversationThreadSummary,
    selectionMode: Boolean,
    isSelected: Boolean,
    onOpenAppTarget: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val s = LocalAppStrings.current
    val glass = LocalGlassStyle.current
    val hasUnread = thread.unreadCount > 0
    val bgColor = when {
        isSelected -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
        thread.hasHighlighted -> lerp(glass.cardElevatedFill, MaterialTheme.colorScheme.secondaryContainer, 0.35f)
        hasUnread -> lerp(glass.cardElevatedFill, MaterialTheme.colorScheme.primaryContainer, 0.28f)
        else -> glass.cardFill
    }
    val borderColor = when {
        isSelected -> MaterialTheme.colorScheme.primary
        thread.hasHighlighted -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.65f)
        hasUnread -> MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
        else -> glass.cardBorder.copy(alpha = 0.6f)
    }

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clip(glass.cardShape)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("thread_card_${thread.threadKey.hashCode()}"),
        containerColor = bgColor,
        borderColor = borderColor,
        borderWidth = if (isSelected || hasUnread) 1.4.dp else 1.dp
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selectionMode) {
                Icon(
                    imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .padding(end = 10.dp)
                        .size(22.dp)
                )
            }

            AppIconAvatar(
                packageName = thread.packageName,
                appName = thread.appName,
                size = 46.dp,
                onClick = if (selectionMode) null else onOpenAppTarget,
                clickContentDescription = s.launchDeepLinkDesc(thread.appName),
                modifier = Modifier.testTag("thread_icon_${thread.threadKey.hashCode()}")
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = thread.threadTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (thread.unreadCount > 0) FontWeight.Bold else FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = formatRelativeTimestamp(thread.latestTimestamp, s),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = thread.categoryLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                val preview = if (thread.latestSender.isNotBlank()) {
                    "${thread.latestSender}: ${thread.latestContent}"
                } else {
                    thread.latestContent
                }
                Text(
                    text = preview,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = if (thread.unreadCount > 0) FontWeight.Medium else FontWeight.Normal,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (thread.unreadCount > 0) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    Text(
                        text = if (thread.unreadCount > 0) "${thread.unreadCount}" else "${thread.totalCount}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (thread.unreadCount > 0) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                    )
                }
                if (thread.unreadCount > 0 && thread.totalCount > thread.unreadCount) {
                    Text(
                        text = "/${thread.totalCount}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
private fun NotificationCard(
    item: NotificationEntity,
    unreadPulseFraction: Float,
    matchedFeedback: TtsFeedbackRuleEntity?,
    isSpeaking: Boolean,
    selectionMode: Boolean,
    isSelected: Boolean,
    onOpenAppTarget: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onCopyOtp: (String) -> Unit,
    onToggleSpeak: () -> Unit,
    onToggleStar: () -> Unit
) {
    val s = LocalAppStrings.current
    val glass = LocalGlassStyle.current
    val isUnread = !item.isRead
    val pulse = if (isUnread) unreadPulseFraction else 0f

    val goldAccent = Color(0xFFF59E0B)
    val hiddenTint = if (glass.isDark) Color(0xCC1E1930) else Color(0xD9EAE4F8)
    val hiddenBorder = Color(0xFF8B5CF6)

    val bgColor = when {
        isSelected -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.68f)
        item.isHidden -> hiddenTint
        item.isStarred -> lerp(glass.cardElevatedFill, goldAccent, if (glass.isDark) 0.16f else 0.12f)
        item.isHighlighted -> lerp(glass.cardElevatedFill, MaterialTheme.colorScheme.secondaryContainer, 0.36f)
        isUnread -> lerp(
            glass.cardElevatedFill,
            MaterialTheme.colorScheme.primaryContainer,
            0.28f + 0.28f * pulse
        )
        else -> glass.cardFill
    }

    val borderColor = when {
        isSelected -> MaterialTheme.colorScheme.primary
        item.isHidden -> hiddenBorder.copy(alpha = 0.72f)
        item.isStarred -> goldAccent.copy(alpha = 0.78f)
        item.isHighlighted -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.75f)
        isUnread -> MaterialTheme.colorScheme.primary.copy(alpha = 0.58f + 0.42f * pulse)
        else -> glass.cardBorder.copy(alpha = 0.55f)
    }

    val borderWidth = when {
        isSelected -> 1.8.dp
        isUnread && pulse > 0.2f -> 1.8.dp
        item.isStarred || item.isHighlighted || item.isHidden || isUnread -> 1.3.dp
        else -> 0.9.dp
    }

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clip(glass.cardShape)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("notification_card_${item.id}"),
        containerColor = bgColor,
        borderColor = borderColor,
        borderWidth = borderWidth
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                if (selectionMode) {
                    Icon(
                        imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                        contentDescription = null,
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .padding(top = 8.dp, end = 10.dp)
                            .size(22.dp)
                    )
                }
                AppIconAvatar(
                    packageName = item.packageName,
                    appName = item.appName,
                    size = 40.dp,
                    onClick = if (selectionMode) null else onOpenAppTarget,
                    clickContentDescription = s.launchDeepLinkDesc(item.appName),
                    modifier = Modifier.testTag("notification_icon_${item.id}")
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isUnread) {
                            Box(
                                modifier = Modifier
                                    .size((8 + 2 * pulse).dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text(
                            text = item.appName,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (isUnread) FontWeight.Bold else FontWeight.SemiBold,
                            color = if (item.isStarred) goldAccent
                            else if (item.isHidden) hiddenBorder
                            else MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = formatRelativeTimestamp(item.timestamp, s),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Visual state & category distinction pills (Unread / Pinned / Priority / Hidden / Category)
                    val categoryLabel = remember(item.category, item.subText) {
                        resolveCategoryPill(item.category, item.subText)
                    }
                    if (isUnread || item.isStarred || item.isHighlighted || item.isHidden || categoryLabel != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (isUnread) {
                                MiniStateBadge(
                                    text = s.inboxBadgeUnread,
                                    container = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f + 0.18f * pulse),
                                    content = MaterialTheme.colorScheme.primary
                                )
                            }
                            if (item.isStarred) {
                                MiniStateBadge(
                                    text = "★ ${s.inboxBadgePinned}",
                                    container = goldAccent.copy(alpha = 0.22f),
                                    content = goldAccent
                                )
                            }
                            if (item.isHighlighted) {
                                MiniStateBadge(
                                    text = s.inboxBadgePriority,
                                    container = MaterialTheme.colorScheme.secondary.copy(alpha = 0.22f),
                                    content = MaterialTheme.colorScheme.secondary
                                )
                            }
                            if (item.isHidden) {
                                MiniStateBadge(
                                    text = s.inboxBadgeHidden,
                                    container = hiddenBorder.copy(alpha = 0.24f),
                                    content = hiddenBorder
                                )
                            }
                            if (categoryLabel != null) {
                                MiniStateBadge(
                                    text = categoryLabel,
                                    container = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.18f),
                                    content = MaterialTheme.colorScheme.tertiary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (isUnread) FontWeight.Bold else FontWeight.Medium,
                        color = if (isUnread) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.84f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (item.content.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = item.content,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isUnread) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f)
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (item.matchedKeywords.isNotBlank() || !item.detectedOtp.isNullOrBlank() || matchedFeedback != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    item.detectedOtp?.let { otp ->
                        OtpCopyPill(otpCode = otp, onCopy = { onCopyOtp(otp) })
                    }
                    if (item.matchedKeywords.isNotBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "#${item.matchedKeywords}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    matchedFeedback?.let { rule ->
                        Surface(
                            color = if (rule.shouldSpeak) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.errorContainer
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = if (rule.shouldSpeak) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff,
                                    contentDescription = null,
                                    tint = if (rule.shouldSpeak) {
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.onErrorContainer
                                    },
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = if (rule.shouldSpeak) s.feedbackBadgeSpeak else s.feedbackBadgeMute,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (rule.shouldSpeak) {
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.onErrorContainer
                                    },
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            if (!selectionMode) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onToggleSpeak,
                        modifier = Modifier.testTag("speak_notification_${item.id}")
                    ) {
                        Icon(
                            imageVector = if (isSpeaking) Icons.Filled.StopCircle else Icons.Filled.VolumeUp,
                            contentDescription = if (isSpeaking) s.stopSpeak else s.speak,
                            tint = if (isSpeaking) MaterialTheme.colorScheme.tertiary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = onToggleStar,
                        modifier = Modifier.testTag("star_notification_${item.id}")
                    ) {
                        Icon(
                            imageVector = if (item.isStarred) Icons.Filled.Star else Icons.Outlined.StarOutline,
                            contentDescription = s.inboxPinStar,
                            tint = if (item.isStarred) MaterialTheme.colorScheme.secondary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyInboxCard(
    isListenerEnabled: Boolean,
    onGrantAccess: () -> Unit,
    onSendTestNotification: () -> Unit
) {
    val s = LocalAppStrings.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_inbox_1795064150853),
                contentDescription = s.inboxEmptyTitle,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(176.dp)
                    .clip(MaterialTheme.shapes.medium)
            )
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = s.inboxEmptyTitle,
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = s.inboxEmptyDesc,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            if (!isListenerEnabled) {
                Button(
                    onClick = onGrantAccess,
                    modifier = Modifier.testTag("empty_grant_listener_button")
                ) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(s.grantAccess)
                }
            } else {
                OutlinedButton(
                    onClick = onSendTestNotification,
                    modifier = Modifier.testTag("empty_send_test_notification_button")
                ) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(s.sendTest)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotificationDetailBottomSheet(
    notification: NotificationEntity,
    matchedFeedback: TtsFeedbackRuleEntity?,
    isSpeaking: Boolean,
    onDismiss: () -> Unit,
    onOpenAppTarget: () -> Unit,
    onSubmitTtsFeedback: (Boolean) -> Unit,
    onCopyAll: () -> Unit,
    onCopyOtp: (String) -> Unit,
    onShare: () -> Unit,
    onToggleSpeak: () -> Unit,
    onToggleStar: () -> Unit,
    onToggleHidden: () -> Unit,
    onDelete: () -> Unit
) {
    val s = LocalAppStrings.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val numericDensity = remember(notification.title, notification.content) {
        SmartTtsTemplateEngine.calculateNumericRatioPercent(notification.title, notification.content)
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIconAvatar(
                    packageName = notification.packageName,
                    appName = notification.appName,
                    size = 46.dp,
                    onClick = onOpenAppTarget,
                    clickContentDescription = s.launchDeepLinkDesc(notification.appName),
                    modifier = Modifier.testTag("detail_app_icon")
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = notification.appName,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = formatFullTimestamp(notification.timestamp),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onToggleStar) {
                    Icon(
                        imageVector = if (notification.isStarred) Icons.Filled.Star else Icons.Outlined.StarOutline,
                        contentDescription = s.inboxPinStar,
                        tint = if (notification.isStarred) MaterialTheme.colorScheme.secondary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = notification.title,
                style = MaterialTheme.typography.titleLarge
            )
            if (notification.subText.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = notification.subText,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            if (notification.content.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = notification.content,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            if (!notification.detectedOtp.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(14.dp))
                OtpCopyPill(
                    otpCode = notification.detectedOtp,
                    onCopy = { onCopyOtp(notification.detectedOtp) }
                )
            }

            if (notification.matchedKeywords.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = s.inboxMatchedKeywords(notification.matchedKeywords),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // TTS Feedback Learning Card
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = s.feedbackSectionTitle,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerHigh
                        ) {
                            Text(
                                text = s.feedbackNumericDensityLabel(numericDensity),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val isSpeakSelected = matchedFeedback?.shouldSpeak == true
                        val isMuteSelected = matchedFeedback?.shouldSpeak == false

                        if (isSpeakSelected) {
                            Button(
                                onClick = { onSubmitTtsFeedback(true) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("detail_feedback_speak_button")
                            ) {
                                Icon(Icons.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(s.feedbackShouldSpeakBtn, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        } else {
                            OutlinedButton(
                                onClick = { onSubmitTtsFeedback(true) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("detail_feedback_speak_button")
                            ) {
                                Icon(Icons.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(s.feedbackShouldSpeakBtn, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }

                        if (isMuteSelected) {
                            Button(
                                onClick = { onSubmitTtsFeedback(false) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error,
                                    contentColor = MaterialTheme.colorScheme.onError
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("detail_feedback_mute_button")
                            ) {
                                Icon(Icons.Filled.VolumeOff, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(s.feedbackDoNotSpeakBtn, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        } else {
                            OutlinedButton(
                                onClick = { onSubmitTtsFeedback(false) },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                ),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.45f)),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("detail_feedback_mute_button")
                            ) {
                                Icon(Icons.Filled.VolumeOff, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(s.feedbackDoNotSpeakBtn, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onToggleSpeak,
                    modifier = Modifier.weight(1f).testTag("detail_speak_button")
                ) {
                    Icon(
                        imageVector = if (isSpeaking) Icons.Filled.StopCircle else Icons.Filled.VolumeUp,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isSpeaking) s.stopSpeak else s.speak)
                }
                OutlinedButton(
                    onClick = onCopyAll,
                    modifier = Modifier.weight(1f).testTag("detail_copy_button")
                ) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(s.copy)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onToggleHidden,
                    modifier = Modifier.weight(1f).testTag("detail_hide_button")
                ) {
                    Icon(
                        imageVector = if (notification.isHidden) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (notification.isHidden) s.inboxShowAgain else s.inboxHidePrivate)
                }
                OutlinedButton(
                    onClick = onShare,
                    modifier = Modifier.testTag("detail_share_button")
                ) {
                    Icon(Icons.Filled.Share, contentDescription = s.share)
                }
                OutlinedButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("detail_delete_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = s.delete,
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
private fun MiniStateBadge(
    text: String,
    container: Color,
    content: Color
) {
    Surface(
        color = container,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(0.8.dp, content.copy(alpha = 0.45f))
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = content,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
        )
    }
}

private fun resolveCategoryPill(category: String, subText: String): String? {
    val c = category.lowercase()
    return when {
        c.contains("msg") -> "Tin nhắn"
        c.contains("email") -> "Email"
        c.contains("social") -> "Xã hội"
        c.contains("promo") -> "Ưu đãi"
        c.contains("transport") || c.contains("navigation") -> "Di chuyển"
        c.contains("alarm") || c.contains("reminder") || c.contains("event") -> "Nhắc nhở"
        c.contains("call") -> "Cuộc gọi"
        subText.isNotBlank() && subText.length <= 18 -> subText.trim()
        else -> null
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}
