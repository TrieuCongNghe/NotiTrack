package com.example.service

import android.app.KeyguardManager
import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.example.NotiTrackApplication
import com.example.engine.BatteryOptimizationHelper
import com.example.engine.NotificationIntentRegistry
import com.example.engine.TestNotificationDispatcher
import com.example.engine.TtsVolumeConfig
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.lang.ref.WeakReference

class NotiTrackListenerService : NotificationListenerService() {

    private val exceptionHandler = CoroutineExceptionHandler { _, _ -> }
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO + exceptionHandler)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        activeInstance = WeakReference(this)
        markConnected(true)
        val app = application as? NotiTrackApplication ?: return
        serviceScope.launch {
            val settings = app.preferences.getSettingsSnapshot()
            if (settings.keepAliveEnabled) {
                KeepAliveService.start(applicationContext)
            }
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        markConnected(false)
        BatteryOptimizationHelper.requestListenerRebind(applicationContext)
        val app = application as? NotiTrackApplication ?: return
        serviceScope.launch {
            delay(3_500L)
            if (!isConnected && app.repository.isNotificationListenerEnabled()) {
                BatteryOptimizationHelper.forceRebindListener(applicationContext, respectCooldown = true)
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        activeInstance = WeakReference(this)
        markConnected(true)
        lastEventTimestampMs = System.currentTimeMillis()

        val statusBarNoti = sbn ?: return
        val notification = statusBarNoti.notification ?: return
        val extras = notification.extras ?: return

        val pkg = statusBarNoti.packageName ?: return
        val isSelfTest = extras.getBoolean(TestNotificationDispatcher.EXTRA_IS_NOTITRACK_TEST, false)

        if (pkg == applicationContext.packageName && !isSelfTest) return

        val isGroupSummary = (notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0
        if (isGroupSummary || statusBarNoti.isOngoing) return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()
        val shortText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val textLines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.mapNotNull { it?.toString()?.trim()?.takeIf { line -> line.isNotEmpty() } }
            ?.joinToString("\n")
            .orEmpty()
        val content = bigText.ifBlank { shortText }.ifBlank { textLines }
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.trim().orEmpty()
        val conversationTitle = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)
            ?.toString()?.trim().orEmpty()

        if (title.isBlank() && content.isBlank()) return

        val appLabel = resolveAppName(pkg)
        val postTime = if (statusBarNoti.postTime > 0L) statusBarNoti.postTime else System.currentTimeMillis()
        val key = statusBarNoti.key.orEmpty()
        val category = notification.category.orEmpty()
        val contentIntent: PendingIntent? = notification.contentIntent

        // Cache original PendingIntent immediately so tapping the app icon deep-links directly
        NotificationIntentRegistry.register(key, contentIntent)

        val app = application as? NotiTrackApplication ?: return
        val repo = app.repository
        val speaker = app.speaker

        serviceScope.launch {
            val settings = repo.preferences.getSettingsSnapshot()
            val strings = com.example.ui.i18n.stringsFor(settings.appLanguage)
            val normalizedContent = if (
                content.equals("Sensitive notification content hidden", ignoreCase = true) ||
                title.equals("Sensitive notification content hidden", ignoreCase = true)
            ) {
                strings.androidRedactedNotice
            } else {
                content
            }

            // When "Only speak when screen is off" is ON, allow speaking both when screen is off
            // AND when screen is lit on the Lock Screen; mute only when unlocked & actively in use.
            val canSpeakByScreenState = !settings.ttsOnlyWhenScreenOff || isScreenOffOrLocked()

            val outcome = repo.processIncomingNotification(
                packageName = pkg,
                appName = appLabel,
                title = title.ifBlank { appLabel },
                content = normalizedContent,
                subText = subText,
                conversationTitle = conversationTitle,
                notificationKey = key,
                category = category,
                timestamp = postTime,
                canSpeakByScreenState = canSpeakByScreenState
            )

            if (outcome.savedId != null) {
                NotificationIntentRegistry.bindId(outcome.savedId, key, contentIntent)
            }

            if (outcome.shouldAutoDismiss && statusBarNoti.isClearable) {
                runCatching { cancelNotification(statusBarNoti.key) }
            }

            if (outcome.shouldSpeak && outcome.savedId != null) {
                speaker.speakNotification(
                    notificationId = outcome.savedId,
                    appName = appLabel,
                    title = title,
                    content = normalizedContent,
                    includeAppName = settings.ttsIncludeAppName,
                    speechRate = settings.ttsSpeechRate,
                    language = settings.appLanguage,
                    smartFilterEnabled = outcome.useSmartTts,
                    hideBalance = outcome.hideBalanceInTts,
                    numberReadMode = outcome.numberReadMode,
                    customTemplate = outcome.customTemplate,
                    volumeConfig = TtsVolumeConfig(
                        overrideVolume = settings.ttsOverrideVolumeEnabled,
                        bypassSilentMode = settings.ttsBypassSilentMode,
                        volumePercent = settings.ttsCustomVolumePercent,
                        autoBoostVolume = outcome.autoBoostVolume,
                        interSpeechDelayMs = settings.ttsDelayBetweenMs
                    ),
                    flush = false
                )
            }
        }
    }

    private fun isScreenOffOrLocked(): Boolean {
        val powerManager = applicationContext.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val keyguardManager = applicationContext.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val isInteractive = powerManager?.isInteractive ?: true
        val isLocked = keyguardManager?.isKeyguardLocked ?: false
        return !isInteractive || isLocked
    }

    private fun resolveAppName(packageName: String): String {
        return runCatching {
            val pm = applicationContext.packageManager
            val appInfo = pm.getApplicationInfo(packageName, PackageManager.GET_META_DATA)
            pm.getApplicationLabel(appInfo).toString().ifBlank { packageName }
        }.getOrDefault(packageName)
    }

    override fun onDestroy() {
        if (activeInstance?.get() === this) {
            activeInstance = null
        }
        markConnected(false)
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        @Volatile
        private var activeInstance: WeakReference<NotiTrackListenerService>? = null

        @Volatile
        var isConnected: Boolean = false
            private set

        @Volatile
        var lastEventTimestampMs: Long = 0L
            private set

        private val _connectionState = MutableStateFlow(false)
        val connectionState: StateFlow<Boolean> = _connectionState.asStateFlow()

        private fun markConnected(connected: Boolean) {
            isConnected = connected
            _connectionState.value = connected
        }

        fun findActiveContentIntent(notificationKey: String): PendingIntent? {
            if (notificationKey.isBlank()) return null
            val service = activeInstance?.get() ?: return null
            return runCatching {
                service.activeNotifications
                    ?.firstOrNull { it.key == notificationKey }
                    ?.notification
                    ?.contentIntent
            }.getOrNull()
        }
    }
}
