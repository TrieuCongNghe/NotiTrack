package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.NotiTrackApplication
import com.example.engine.BatteryOptimizationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val app = context.applicationContext as? NotiTrackApplication
                val settings = app?.preferences?.getSettingsSnapshot()
                val hasAccess = app?.repository?.isNotificationListenerEnabled() == true
                if (hasAccess) {
                    BatteryOptimizationHelper.forceRebindListener(context, respectCooldown = false)
                } else {
                    BatteryOptimizationHelper.requestListenerRebind(context)
                }
                if (settings?.keepAliveEnabled == true && hasAccess) {
                    KeepAliveService.start(context)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
