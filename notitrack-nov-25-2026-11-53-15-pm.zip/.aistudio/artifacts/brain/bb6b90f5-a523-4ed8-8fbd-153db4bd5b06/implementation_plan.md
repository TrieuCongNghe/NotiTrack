# Kế Hoạch Nâng Cấp NotiTrack — Tiện Ích Bảo Vệ Thiết Bị & Giao Diện Glassmorphism 6 Chủ Đề Art

Kế hoạch này mô tả kiến trúc, trải nghiệm người dùng và lộ trình kỹ thuật cho đợt nâng cấp lớn của **NotiTrack**: bổ sung tab **Tiện ích** (giám sát pin, nhiệt độ và hệ thống báo trộm chủ động / khi sạc), tăng cường bảo mật thao tác xóa thông báo, cập nhật thanh thông báo duy trì gọn nhẹ, đồng thời khoác lên toàn ứng dụng ngôn ngữ thiết kế **Glassmorphism** mượt mà với **6 bộ chủ đề Art độc quyền**.

---

## Điểm Cần Lưu Ý & Các Quyết Định Đã Chốt

Các phương án dưới đây đã được xác nhận ở bước trao đổi trước và sẽ được áp dụng xuyên suốt quá trình triển khai:

- **6 Chủ đề Art Glassmorphism (Đa phong cách):** Ngọc Bích, Cực Quang, Anh Đào, Cyberpunk, Hoàng Hôn và Pha Lê — mỗi chủ đề đều có hình nền nghệ thuật toàn màn hình riêng, bảng màu đồng bộ và phong cách nút bấm/công tắc/thanh trượt kính tương ứng.
- **Bảo vệ màn hình báo động chống trộm (Chuẩn Google Play, không cần quyền vẽ đè Overlay):** Sử dụng màn hình báo động toàn màn hình hiển thị trên màn hình khóa (`showWhenLocked`, `turnScreenOn`, `USE_FULL_SCREEN_INTENT`, `FLAG_KEEP_SCREEN_ON`), chặn nút Back, tự động gọi lại màn hình nếu bị ẩn và liên tục khóa âm lượng kênh báo thức (`STREAM_ALARM`) ở mức tối đa cho đến khi nhập đúng mã PIN 4 số.
- **Xử lý nhắc Tiết kiệm pin:** Khi kích hoạt cảnh báo Pin yếu hoặc Sạc pin có bật tùy chọn Tiết kiệm pin, ứng dụng hiển thị thông báo kèm **nút thao tác nhanh mở thẳng cài đặt Tiết kiệm pin hệ thống** (do Android giới hạn ứng dụng thường không được tự bật công tắc này ngầm).
- **Bố trí nút nổi Báo trộm chủ động trên Hộp thư:** Xếp gọn 2 nút nổi theo chiều dọc ở góc dưới phải — **nút Khiên Báo trộm chủ động** nằm phía trên **nút Đánh dấu tất cả đã đọc**.
- **Điều kiện mã PIN 4 số dùng chung:** Khi bật Báo trộm khi sạc hoặc Báo trộm chủ động mà người dùng chưa thiết lập mã PIN, ứng dụng sẽ mở hộp thoại yêu cầu tạo mã PIN 4 số dùng chung với tab **Bảo mật** ngay lập tức để đảm bảo luôn có thể tắt còi an toàn.

---

## 1. Tổng Quan & Mục Tiêu Cốt Lõi

Đợt nâng cấp mở rộng NotiTrack từ trình quản lý & đọc thông báo thông minh thành trung tâm bảo vệ thông báo và thiết bị toàn diện với 4 trụ cột:

1. **Tab "Tiện ích" trong Cài đặt:** Tập hợp toàn bộ bộ công cụ giám sát phần cứng thực tế (Pin yếu, Sạc pin, Sạc đầy có trễ phút "no pin", Quá nhiệt °C, Báo trộm khi rút sạc, và Báo trộm chủ động bằng cảm biến chuyển động).
2. **Bảo vệ xóa thông báo ở tab Bảo mật:** Tùy chọn yêu cầu nhập PIN hoặc Vân tay trước khi xóa một thông báo, xóa nhiều mục, xóa hội thoại hoặc xóa toàn bộ lịch sử.
3. **Giao diện Glassmorphism & Chuyển động mượt mà:** Thiết kế kính mờ có chiều sâu trên nền 6 bức tranh nghệ thuật toàn màn hình, hiệu ứng thanh trượt tab mượt, phản hồi nút/công tắc đàn hồi, cùng hệ thống phân loại thẻ thông báo rõ nét và hiệu ứng phát sáng nhấp nháy nhẹ cho thông báo chưa đọc khi mở Hộp thư.
4. **Thanh thông báo chống tắt (Keep-Alive) thông minh hơn:** Bổ sung biểu tượng icon siêu gọn hiển thị trạng thái đang canh giữ của Báo trộm khi sạc / Báo trộm chủ động mà không làm chật hay cắt chữ các chỉ số nhiệt độ, âm lịch, thông báo chưa đọc và phần trăm pin.

---

## 2. Trải Nghiệm Người Dùng & Thiết Kế Giao Diện

### 2.1. Ngôn Ngữ Glassmorphism & 6 Chủ Đề Art Độc Quyền

Toàn bộ các màn hình sử dụng kiến trúc nền 3 lớp: **Hình nền Art toàn màn hình (9:16)** → **Lớp phủ điều tiết độ tương phản (Atmospheric Scrim)** giúp chữ luôn sắc nét tuyệt đối → **Các thẻ kính mờ (Frosted Glass Cards)** có viền sáng mép trên (specular highlight) và bóng chiều sâu tinh tế.

| # | Tên Chủ Đề | Phong Cách Art Nền | Bảng Màu Chủ Đạo & Điểm Nhấn | Phong Cách Thành Phần |
|---|---|---|---|---|
| 1 | **Ngọc Bích** (*Jade Vault*) | Vân đá ngọc bích trừu tượng kết hợp ánh vàng kim mờ | Xanh ngọc sâu + Bạc hà sáng + Vàng đồng | Thẻ kính sắc nét, công tắc viên nang ngọc phát sáng |
| 2 | **Cực Quang** (*Aurora Night*) | Bầu trời đêm phương Bắc với dải cực quang uốn lượn | Xanh tím đêm + Lục bảo + Tím cực quang | Viền kính chuyển sắc lạnh, thanh trượt tab ánh sáng |
| 3 | **Anh Đào** (*Sakura Blossom*) | Cánh hoa anh đào rơi nhẹ trên nền chiều dịu dàng | Hồng phấn thanh lịch + Đỏ rượu nhẹ + Trắng sứ | Bo góc mềm mại hơn, nút kính tông hồng ngọc dịu mắt |
| 4 | **Cyberpunk** (*Cyberpunk Neon*) | Đường chân trời đô thị tương lai ánh đèn neon | Đêm tím than + Xanh Cyan Neon + Hồng Magenta | Viền kính phát sáng neon mảnh, công tắc góc cạnh hiện đại |
| 5 | **Hoàng Hôn** (*Ocean Sunset*) | Mặt biển lặng phản chiếu ánh hoàng hôn rực rỡ | Cam san hô + Tím hoàng hôn + Xanh đại dương | Kính ánh ấm, nút bấm và chip chuyển sắc hoàng hôn |
| 6 | **Pha Lê** (*Crystal Frost*) | Khối pha lê băng khúc xạ ánh sáng tối giản tinh khiết | Xanh băng trong trẻo + Bạch kim + Xanh lam nhạt | Kính trong suốt sáng sủa, đường viền bạc sắc sảo |

Người dùng chọn chủ đề trực tiếp tại **Cài đặt → Chung** thông qua lưới thẻ xem trước trực quan hiển thị ảnh Art thu nhỏ, bảng màu, nhãn chủ đề và áp dụng tức thì không cần khởi động lại ứng dụng.

### 2.2. Chuyển Động Mượt Mà & Phản Hồi Xúc Giác Trực Quan

- **Thanh trượt kính (Sliding Glass Pill):** Thanh điều hướng dưới cùng và dải tab con trong Cài đặt (*Chung / Đọc to / Tiện ích / Bảo mật*) có nền kính trượt mượt theo lò xo (`spring`) mỗi khi chuyển tab.
- **Chuyển cảnh tab mượt mà:** Chuyển giữa các tab và tab con dùng hoạt ảnh trượt + mờ dần nhẹ (`AnimatedContent`), loại bỏ cảm giác giật cục.
- **Công tắc & Nút bấm tùy biến theo chủ đề:** Công tắc gạt dạng kính có hiệu ứng co giãn nút tròn mượt mà và phát sáng nhẹ khi bật; các nút chính, chip lọc và nút nổi có hiệu ứng nhún nhẹ (`scale` spring) khi chạm.

### 2.3. Phân Biệt Rõ Nét & Hiệu Ứng Nhấp Nháy Thông Báo Ở Hộp Thư

- **Hiệu ứng nhấp nháy chú ý cho thông báo chưa đọc:** Mỗi khi mở ứng dụng hoặc quay trở lại Hộp thư, các thẻ thông báo **chưa đọc / mới đến** sẽ tự động phát sáng nhấp nháy dịu ở viền và lớp phủ sáng trong khoảng **3–4 giây** rồi dịu về trạng thái nổi bật tĩnh để người dùng nhận diện ngay tin mới mà không gây mỏi mắt.
- **Phân tách trực quan từng trạng thái thẻ:**
  - **Chưa đọc:** Nền kính sáng/đậm màu chủ đạo hơn, viền phát sáng rõ, chấm chỉ báo màu nhấn và tiêu đề in đậm.
  - **Đã đọc:** Nền kính dịu và trong hơn, viền mảnh trung tính giúp nhường sự chú ý cho tin mới.
  - **Đã ghim / Sao:** Viền ánh vàng hổ phách + nền pha ánh vàng nhẹ + biểu tượng Ghim/Sao nổi bật.
  - **Nổi bật (Trùng từ khóa quan trọng):** Nền kính pha sắc nhấn cảnh báo/ưu tiên kèm dải màu dọc bên trái thẻ.
  - **Đã ẩn / Riêng tư:** Nền kính tối hơn kèm biểu tượng khóa riêng tư để dễ phân biệt khi mở chế độ xem mục ẩn.
  - **Danh mục (Ngân hàng, Tin nhắn, Mạng xã hội, Mua sắm, Hệ thống...):** Chip danh mục mang mã màu riêng biệt dễ quét mắt.
- **Cụm 2 nút nổi xếp dọc ở Hộp thư:**
  - Nút trên: **Nút Khiên Báo trộm chủ động** — đổi màu & phát xung nhịp sáng khi đang ở chế độ canh giữ (nhấn để bật/tắt nhanh; nếu đang bật sẽ yêu cầu xác thực PIN/Vân tay để tắt an toàn).
  - Nút dưới: **Nút Đánh dấu tất cả đã đọc** (giữ nguyên vị trí quen thuộc).

### 2.4. Bố Cục Tab "Tiện Ích" Trong Cài Đặt

Trong tab **Cài đặt**, dải tab con được mở rộng thành **4 mục**: `Chung` · `Đọc to` · `Tiện ích` · `Bảo mật`. Tab **Tiện ích** gồm 6 thẻ kính có thể thu gọn/mở rộng gọn gàng:

1. **Cảnh báo Pin yếu:** Công tắc bật/tắt, thanh kéo ngưỡng % (5%–50%), các nút chọn kênh cảnh báo (*Đổ chuông thông báo*, *Nhạc thông báo tùy chọn*, *Đọc giọng nói TTS*, *Kèm nút mở Tiết kiệm pin*).
2. **Cảnh báo Sạc pin:** Công tắc bật/tắt, thanh kéo ngưỡng % khi đang sạc (20%–95%), các tùy chọn kênh cảnh báo tương tự (*Chuông*, *Nhạc*, *TTS*, *Nút mở Tiết kiệm pin*).
3. **Cảnh báo Sạc đầy:** Công tắc bật/tắt, thanh kéo ngưỡng % (80%–100%). Khi người dùng chọn đúng **100%**, tự động mở thêm mục **Chờ thêm để no Pin (0–60 phút)** đếm thời gian sau khi đạt 100% rồi mới phát thông báo.
4. **Cảnh báo Quá nhiệt điện thoại:** Công tắc bật/tắt, thanh kéo ngưỡng nhiệt độ (**38°C–50°C**), chọn kiểu âm thanh (*Chuông thông báo* hoặc *Chuông báo thức*) kèm trình chọn nhạc chuông hệ thống, và thanh chỉnh **Khoảng cách lặp lại (giây)** để tránh báo liên tục.
5. **Báo trộm khi sạc:** Công tắc bật/tắt, ngưỡng % pin tối thiểu khi cắm sạc để tự động kích hoạt canh giữ, số giây trễ sau khi rút sạc trước khi hú còi, tùy chọn **Rung mạnh**, tùy chọn **Nháy đèn Flash**, và mục **Hộp thoại xác nhận chủ máy rút sạc** (bật/tắt + số giây đếm ngược tùy chỉnh **5–120 giây**, giới hạn cứng không vượt quá 120 giây).
6. **Báo trộm chủ động (Cảm biến chuyển động):** Công tắc bật/tắt đồng bộ tức thì với nút Khiên trên Hộp thư, mức **Độ nhạy chuyển động** (*Nhẹ / Vừa / Nhạy*), thời gian đệm đặt máy xuống (giây), cùng các tùy chọn *Hộp thoại xác nhận (≤ 120s)*, *Nháy Flash* và *Rung mạnh*.

### 2.5. Bảo Mật Khi Xóa Thông Báo & Thanh Thông Báo Duy Trì

- **Tab Bảo mật:** Thêm mục **"Yêu cầu PIN/Vân tay khi xoá thông báo"** (chỉ cho phép bật khi đã có mã PIN hoặc Vân tay; nếu chưa thiết lập sẽ nhắc thiết lập trước). Khi bật, mọi thao tác xóa (xóa 1 tin, xóa nhiều tin đang chọn, xóa nhóm hội thoại, xóa tất cả) đều mở hộp thoại xác thực PIN/Vân tay trước khi thực thi.
- **Thanh thông báo duy trì (Keep-Alive):** Thêm khu vực **chỉ hiển thị biểu tượng (icon-only)** cực gọn trên hàng trạng thái bên cạnh nhãn bảo vệ (icon ổ khóa tia sét cho *Báo trộm khi sạc đang canh giữ*, icon khiên rung cho *Báo trộm chủ động đang bật*), giữ nguyên không gian rộng rãi cho nhiệt độ, ngày âm lịch, số thông báo chưa đọc và phần trăm pin.

---

## 3. Các Quyết Định Thiết Kế & Cân Nhắc Kỹ Thuật

| Hạng Mục | Quyết Định Triển Khai | Lý Do & Lợi Ích |
|---|---|---|
| **Hợp nhất dịch vụ nền** | Tích hợp bộ giám sát Pin, Nhiệt độ và Cảm biến chống trộm vào dịch vụ nền `KeepAliveService` hiện có | Tránh chạy nhiều Foreground Service gây hai thông báo song song và tiết kiệm pin tối đa; tái sử dụng luôn luồng `ACTION_BATTERY_CHANGED` đang hoạt động. |
| **Nháy đèn Flash không cần quyền Camera** | Dùng `CameraManager.setTorchMode(cameraId, on/off)` trên Android 6.0+ | Đáp ứng chuẩn quyền tối thiểu của Google Play, không cần xin quyền nguy hiểm `CAMERA` từ người dùng. |
| **Chống tắt còi khi báo động đã kêu** | Màn hình toàn màn hình khóa (`AntiTheftAlarmActivity`) + vòng lặp giữ max `STREAM_ALARM` + chặn phím Back/Volume + tự mở lại nếu rời màn hình | Bảo vệ cao nhất có thể trong giới hạn chính sách Google Play mà không cần quyền vẽ đè `SYSTEM_ALERT_WINDOW` phức tạp. |
| **Hộp thoại xác nhận ≤ 120 giây** | Kiểm soát cứng giá trị cấu hình trong khoảng 5–120 giây; cho phép mở bằng PIN 4 số hoặc Vân tay trước khi còi hú, nhưng khi còi đã hú chỉ cho tắt bằng PIN 4 số | Đúng kịch bản thực tế: thuận tiện cho chủ máy khi rút sạc nhầm, nhưng đủ chặt chẽ để kẻ gian không thể tắt khi báo động đã kích hoạt. |
| **Đếm giờ "no pin" ở 100%** | Bắt đầu bộ đếm thời gian trễ theo phút kể từ thời điểm pin chạm 100% và vẫn đang cắm sạc; tự hủy bộ đếm ngay nếu người dùng rút sạc sớm | Tránh báo nhầm sau khi đã rút sạc và tính chính xác thời gian sạc bồi thêm. |
| **Cảm biến chống trộm chủ động** | Dùng `SensorManager` với cảm biến gia tốc tuyến tính (`TYPE_LINEAR_ACCELERATION`, dự phòng lọc trọng lực trên `TYPE_ACCELEROMETER`) + thời gian đệm đặt máy | Hoạt động trên mọi máy Android kể cả máy không có con quay hồi chuyển; giảm tối đa báo động giả khi người dùng vừa bấm nút và đặt điện thoại xuống bàn. |

---

## 4. Kiến Trúc Kỹ Thuật & Chiến Lược Dữ Liệu

### 4.1. Sơ Đồ Kiến Trúc Tích Hợp

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        LỚP GIAO DIỆN (JETPACK COMPOSE)                     │
│  ┌──────────────────────┐  ┌─────────────────────┐  ┌───────────────────┐  │
│  │ Hệ Thống 6 Chủ Đề Art│  │ Màn Hình Hộp Thư    │  │ Tab Cài Đặt       │  │
│  │ + Kính Mờ Glass UI   │  │ • Nhấp nháy tin mới │  │ • Chung (6 Theme) │  │
│  │ • Ảnh Art 9:16       │  │ • Phân màu thẻ rõ   │  │ • Đọc to          │  │
│  │ • Sliding Pill/Spring│  │ • 2 Nút nổi xếp dọc │  │ • Tiện ích (Mới)  │  │
│  │ • Custom Glass Switch│  │ • Khóa PIN khi xóa  │  │ • Bảo mật (+Xóa)  │  │
│  └──────────┬───────────┘  └──────────┬──────────┘  └─────────┬─────────┘  │
└─────────────┼─────────────────────────┼───────────────────────┼────────────┘
              │                         │                       │
              ▼                         ▼                       ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                   LỚP TRẠNG THÁI & LƯU TRỮ CẤU HÌNH                        │
│  • StateFlow trung tâm (trạng thái canh giữ, đếm ngược, chủ đề hiện tại)   │
│  • DataStore Preferences (cấu hình Pin, Quá nhiệt, Chống trộm, PIN, Theme) │
└───────────────────────────────────────┬────────────────────────────────────┘
                                        │
                                        ▼
┌────────────────────────────────────────────────────────────────────────────┐
│             DỊCH VỤ NỀN HỢP NHẤT (KEEP-ALIVE + DEVICE GUARD)               │
│  ┌────────────────────┐  ┌─────────────────────┐  ┌─────────────────────┐  │
│  │ Bộ Giám Sát Pin &  │  │ Bộ Canh Giữ Chống   │  │ Thanh Thông Báo     │  │
│  │ Nhiệt Độ Thực Tế   │  │ Trộm (Sạc & Chuyển  │  │ Keep-Alive Gọn Nhẹ  │  │
│  │ • Pin yếu / Sạc    │  │ Động Gia Tốc Kế)    │  │ • Nhiệt độ, Âm lịch │  │
│  │ • 100% + Phút trễ  │  │ • Đếm ngược ≤120s   │  │ • Chưa đọc, Pin %   │  │
│  │ • Quá nhiệt °C     │  │ • Kích hoạt báo động│  │ • Icon Chống trộm   │  │
│  └─────────┬──────────┘  └──────────┬──────────┘  └─────────────────────┘  │
└────────────┼────────────────────────┼──────────────────────────────────────┘
             │                        │
             ▼                        ▼
┌─────────────────────────┐  ┌───────────────────────────────────────────────┐
│ KÊNH CẢNH BÁO TIỆN ÍCH  │  │ MÀN HÌNH BÁO ĐỘNG TOÀN MÀN HÌNH KHÓA          │
│ • Chuông / Nhạc tùy chọn│  │ • Trạng thái 1: Xác nhận chủ máy (≤120s,      │
│ • Đọc TTS giọng nói     │  │   hỗ trợ PIN 4 số hoặc Vân tay)               │
│ • Nút mở Tiết kiệm pin  │  │ • Trạng thái 2: CÒI HÚ TOÀN LỰC               │
│                         │  │   - Khóa max STREAM_ALARM & chống phím âm     │
│                         │  │   - Nháy Flash (CameraManager) + Rung mạnh    │
│                         │  │   - Tự mở lại khi bị ẩn, chỉ tắt bằng PIN 4 số│
└─────────────────────────┘  └───────────────────────────────────────────────┘
```

### 4.2. Luồng Hoạt Động Chi Tiết Của Hệ Thống Chống Trộm

```
[Đang Canh Giữ: Rút sạc HOẶC Phát hiện chuyển động]
                        │
                        ▼
        (Nếu có thời gian trễ rút sạc > 0s)
          Đếm chờ ngắn — cắm sạc lại thì hủy
                        │
                        ▼
     ┌─ Hộp thoại xác nhận (≤120s) đang BẬT? ─┐
     │ CÓ                                     │ KHÔNG
     ▼                                        ▼
[Mở màn hình đếm ngược xác nhận]              │
 • Nhập PIN 4 số hoặc quét Vân tay            │
 • Thành công → Hủy & trở về bình thường      │
 • Hết giờ đếm ngược ─────────────────────────┤
                                              ▼
                       ┌──────────────────────────────────────────┐
                       │       KÍCH HOẠT BÁO ĐỘNG TOÀN LỰC        │
                       │ • Bật còi STREAM_ALARM + khóa âm lượng   │
                       │ • Nháy đèn Flash mặt sau liên tục        │
                       │ • Rung cường độ mạnh (nếu bật)           │
                       │ • Khóa nút Back & tự mở lại nếu bị ẩn    │
                       └────────────────────┬─────────────────────┘
                                            │
                                            ▼
                           [Nhập đúng mã PIN 4 số dùng chung]
                                            │
                                            ▼
                         [Tắt còi, tắt Flash, dừng rung, mở khóa]
```

### 4.3. Chiến Lược Lưu Trữ & Quyền Hệ Thống

- **Cấu hình cục bộ (DataStore Preferences):** Lưu toàn bộ ngưỡng pin (yếu / sạc / đầy + số phút no pin), ngưỡng nhiệt độ °C và chu kỳ lặp (giây), cấu hình báo trộm khi sạc & báo trộm chủ động (ngưỡng %, giây trễ, bật/tắt xác nhận, thời gian xác nhận ≤ 120s, độ nhạy cảm biến, bật/tắt rung & flash), URI nhạc chuông tùy chọn, khóa xác thực khi xóa thông báo và chủ đề Art hiện tại. Toàn bộ cài đặt này hoạt động tức thì qua `Flow` và không phá vỡ dữ liệu thông báo Room hiện có.
- **Quyền khai báo bổ sung (chuẩn Play Policy):** Chỉ bổ sung các quyền chuẩn cần thiết cho báo động là `VIBRATE`, `USE_FULL_SCREEN_INTENT` và `WAKE_LOCK` — tuyệt đối không yêu cầu quyền vẽ đè `SYSTEM_ALERT_WINDOW`, không yêu cầu quyền `CAMERA` và không yêu cầu quyền đọc bộ nhớ rộng.
- **Tài nguyên nghệ thuật (6 ảnh Art):** Tạo sẵn 6 hình nền nghệ thuật tỉ lệ `9:16` sắc nét đóng gói trực tiếp trong ứng dụng tương ứng 6 chủ đề để tải tức thì, mượt mà ngay cả khi không có mạng.
- **Kiểm thử tự động:** Bổ sung unit test cho toàn bộ logic nhạy cảm gồm thuật toán kích hoạt cảnh báo pin yếu/sạc/đầy kèm phút trễ no pin, bộ giới hạn khoảng nghỉ quá nhiệt, bộ lọc gia tốc phát hiện chuyển động, ràng buộc giới hạn đếm ngược ≤ 120 giây và vòng đời chuyển trạng thái chống trộm.
