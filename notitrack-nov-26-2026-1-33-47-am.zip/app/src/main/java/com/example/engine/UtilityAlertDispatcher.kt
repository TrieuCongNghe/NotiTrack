package com.example.engine

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.NotiTrackApplication
import com.example.R
import com.example.data.prefs.NotiTrackSettings
import com.example.ui.i18n.AppLanguage
import kotlin.math.roundToInt

/**
 * Dispatches real device utility alerts (Low Battery, Charging Target, Full Charge, Overheat)
 * with ringtone/alarm sound, custom picked audio URI, optional TTS voice announcement,
 * and quick-action PendingIntent to Android Battery Saver settings.
 */
object UtilityAlertDispatcher {

    private const val CHANNEL_UTIL_SILENT = "notitrack_utility_alerts_v1"
    private const val CHANNEL_UTIL_SOUND = "notitrack_utility_sound_v1"
    private const val CHANNEL_OVERHEAT_ALARM = "notitrack_overheat_alarm_v1"

    private const val NOTIF_ID_LOW_BATTERY = 5101
    private const val NOTIF_ID_CHARGING_LEVEL = 5102
    private const val NOTIF_ID_FULL_CHARGE = 5103
    private const val NOTIF_ID_OVERHEAT = 5104

    fun dispatchLowBattery(
        context: Context,
        settings: NotiTrackSettings,
        batteryPercent: Int
    ) {
        val isVi = settings.appLanguage.resolved() == AppLanguage.VIETNAMESE
        val title = if (isVi) "Cảnh báo Pin yếu ($batteryPercent%)" else "Low Battery Alert ($batteryPercent%)"
        val body = if (isVi) {
            "Pin thiết bị đã giảm xuống $batteryPercent% (ngưỡng ${settings.lowBatteryThreshold}%). Hãy chuẩn bị cắm sạc hoặc bật Tiết kiệm pin."
        } else {
            "Battery dropped to $batteryPercent% (threshold ${settings.lowBatteryThreshold}%). Prepare to charge or enable Battery Saver."
        }
        postUtilityNotification(
            context = context,
            notificationId = NOTIF_ID_LOW_BATTERY,
            title = title,
            body = body,
            playRingtone = settings.lowBatteryRingtoneEnabled,
            playCustomMusic = settings.lowBatteryMusicEnabled,
            customSoundUri = settings.lowBatterySoundUri,
            useAlarmStream = false,
            includeBatterySaverAction = settings.lowBatterySaverPromptEnabled,
            isVi = isVi
        )
        if (settings.lowBatteryTtsEnabled) {
            speakUtilityAlert(
                context = context,
                settings = settings,
                text = if (isVi) "Cảnh báo pin yếu, hiện còn $batteryPercent phần trăm."
                else "Low battery warning, currently at $batteryPercent percent."
            )
        }
    }

    fun dispatchChargingLevel(
        context: Context,
        settings: NotiTrackSettings,
        batteryPercent: Int
    ) {
        val isVi = settings.appLanguage.resolved() == AppLanguage.VIETNAMESE
        val title = if (isVi) "Cảnh báo Sạc pin ($batteryPercent%)" else "Plug In Charger Alert ($batteryPercent%)"
        val body = if (isVi) {
            "Pin chỉ còn $batteryPercent% (lớp cảnh báo 2: ngưỡng ${settings.chargingAlertThreshold}%). Hãy cắm sạc ngay để tránh hết pin!"
        } else {
            "Battery is down to $batteryPercent% (tier-2 reminder: ${settings.chargingAlertThreshold}%). Please plug in your charger now!"
        }
        postUtilityNotification(
            context = context,
            notificationId = NOTIF_ID_CHARGING_LEVEL,
            title = title,
            body = body,
            playRingtone = settings.chargingRingtoneEnabled,
            playCustomMusic = settings.chargingMusicEnabled,
            customSoundUri = settings.chargingSoundUri,
            useAlarmStream = false,
            includeBatterySaverAction = settings.chargingSaverPromptEnabled,
            isVi = isVi
        )
        if (settings.chargingTtsEnabled) {
            speakUtilityAlert(
                context = context,
                settings = settings,
                text = if (isVi) "Cảnh báo sạc pin, pin chỉ còn $batteryPercent phần trăm, vui lòng cắm sạc ngay."
                else "Charger reminder, battery is at $batteryPercent percent, please plug in now."
            )
        }
    }

    fun dispatchFullCharge(
        context: Context,
        settings: NotiTrackSettings,
        batteryPercent: Int,
        extraMinutesWaited: Int
    ) {
        val isVi = settings.appLanguage.resolved() == AppLanguage.VIETNAMESE
        val title = if (isVi) "Pin đã sạc đầy ($batteryPercent%)" else "Battery Fully Charged ($batteryPercent%)"
        val body = if (isVi) {
            if (extraMinutesWaited > 0) {
                "Pin đã đạt $batteryPercent% và sạc bồi thêm $extraMinutesWaited phút để no pin. Bạn có thể rút sạc."
            } else {
                "Pin đã đạt ngưỡng sạc đầy $batteryPercent%. Bạn có thể rút sạc để bảo vệ tuổi thọ pin."
            }
        } else {
            if (extraMinutesWaited > 0) {
                "Battery reached $batteryPercent% plus $extraMinutesWaited extra minutes for a full top-off. Ready to unplug."
            } else {
                "Battery reached your full-charge target ($batteryPercent%). Ready to unplug."
            }
        }
        postUtilityNotification(
            context = context,
            notificationId = NOTIF_ID_FULL_CHARGE,
            title = title,
            body = body,
            playRingtone = settings.fullChargeRingtoneEnabled,
            playCustomMusic = settings.fullChargeMusicEnabled,
            customSoundUri = settings.fullChargeSoundUri,
            useAlarmStream = false,
            includeBatterySaverAction = false,
            isVi = isVi
        )
        if (settings.fullChargeTtsEnabled) {
            speakUtilityAlert(
                context = context,
                settings = settings,
                text = if (isVi) {
                    if (extraMinutesWaited > 0) "Pin đã sạc no 100 phần trăm sau $extraMinutesWaited phút bồi thêm. Vui lòng rút sạc."
                    else "Pin đã sạc đầy $batteryPercent phần trăm. Vui lòng rút sạc."
                } else {
                    "Battery is fully charged at $batteryPercent percent. Please unplug."
                }
            )
        }
    }

    fun dispatchOverheat(
        context: Context,
        settings: NotiTrackSettings,
        tempCelsius: Float
    ) {
        val isVi = settings.appLanguage.resolved() == AppLanguage.VIETNAMESE
        val rounded = tempCelsius.roundToInt()
        val title = if (isVi) "Cảnh báo điện thoại quá nóng ($rounded°C)" else "Device Overheat Warning ($rounded°C)"
        val body = if (isVi) {
            "Nhiệt độ thiết bị đạt ${String.format("%.1f", tempCelsius)}°C (ngưỡng ${settings.overheatThresholdC}°C). Nên tạm nghỉ hoặc rút sạc để hạ nhiệt."
        } else {
            "Device temperature reached ${String.format("%.1f", tempCelsius)}°C (limit ${settings.overheatThresholdC}°C). Pause heavy tasks or unplug."
        }
        postUtilityNotification(
            context = context,
            notificationId = NOTIF_ID_OVERHEAT,
            title = title,
            body = body,
            playRingtone = true,
            playCustomMusic = settings.overheatSoundUri.isNotBlank(),
            customSoundUri = settings.overheatSoundUri,
            useAlarmStream = settings.overheatUseAlarmSound,
            includeBatterySaverAction = false,
            isVi = isVi
        )
    }

    private fun postUtilityNotification(
        context: Context,
        notificationId: Int,
        title: String,
        body: String,
        playRingtone: Boolean,
        playCustomMusic: Boolean,
        customSoundUri: String,
        useAlarmStream: Boolean,
        includeBatterySaverAction: Boolean,
        isVi: Boolean
    ) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        ensureChannels(manager, isVi)

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPending = PendingIntent.getActivity(
            context,
            notificationId,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val channelId = when {
            useAlarmStream -> CHANNEL_OVERHEAT_ALARM
            playRingtone && !playCustomMusic -> CHANNEL_UTIL_SOUND
            else -> CHANNEL_UTIL_SILENT
        }

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(if (useAlarmStream) NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_STATUS)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(contentPending)

        if (includeBatterySaverAction) {
            val saverIntent = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val saverPending = PendingIntent.getActivity(
                context,
                notificationId + 50,
                saverIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(
                0,
                if (isVi) "Mở Tiết kiệm pin" else "Open Battery Saver",
                saverPending
            )
        }

        runCatching { manager.notify(notificationId, builder.build()) }

        // Play custom picked ringtone/music URI or alarm tone explicitly when requested
        if (playCustomMusic || (playRingtone && useAlarmStream)) {
            playAlertTone(
                context = context,
                customUriString = if (playCustomMusic) customSoundUri else "",
                useAlarmStream = useAlarmStream
            )
        }
    }

    private fun playAlertTone(
        context: Context,
        customUriString: String,
        useAlarmStream: Boolean
    ) {
        runCatching {
            val uri = if (customUriString.isNotBlank()) {
                Uri.parse(customUriString)
            } else {
                RingtoneManager.getDefaultUri(
                    if (useAlarmStream) RingtoneManager.TYPE_ALARM else RingtoneManager.TYPE_NOTIFICATION
                )
            }
            val ringtone = RingtoneManager.getRingtone(context, uri) ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ringtone.audioAttributes = AudioAttributes.Builder()
                    .setUsage(
                        if (useAlarmStream) AudioAttributes.USAGE_ALARM
                        else AudioAttributes.USAGE_NOTIFICATION
                    )
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            }
            ringtone.play()
        }
    }

    private fun speakUtilityAlert(
        context: Context,
        settings: NotiTrackSettings,
        text: String
    ) {
        val app = context.applicationContext as? NotiTrackApplication ?: return
        app.speaker.speakDirectMessage(
            text = text,
            speechRate = settings.ttsSpeechRate,
            language = settings.appLanguage,
            volumeConfig = TtsVolumeConfig(
                overrideVolume = settings.ttsOverrideVolumeEnabled,
                bypassSilentMode = settings.ttsBypassSilentMode,
                volumePercent = settings.ttsCustomVolumePercent,
                autoBoostVolume = false,
                interSpeechDelayMs = settings.ttsDelayBetweenMs
            )
        )
    }

    private fun ensureChannels(manager: NotificationManager, isVi: Boolean) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val silentCh = NotificationChannel(
            CHANNEL_UTIL_SILENT,
            if (isVi) "Tiện ích pin & thiết bị" else "Battery & Device Utilities",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            setSound(null, null)
            enableVibration(true)
        }
        val soundCh = NotificationChannel(
            CHANNEL_UTIL_SOUND,
            if (isVi) "Cảnh báo pin có chuông" else "Battery Alerts (Sound)",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            enableVibration(true)
        }
        val alarmCh = NotificationChannel(
            CHANNEL_OVERHEAT_ALARM,
            if (isVi) "Cảnh báo quá nhiệt khẩn cấp" else "Overheat Emergency Alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            enableVibration(true)
            val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            setSound(alarmUri, attrs)
        }
        manager.createNotificationChannel(silentCh)
        manager.createNotificationChannel(soundCh)
        manager.createNotificationChannel(alarmCh)
    }
}
