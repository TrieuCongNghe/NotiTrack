package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.NotiTrackApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Automatically restores the persistent keep-alive status bar notification if the user
 * swipes it away on Android 14+ (where ongoing notifications became user-dismissible).
 */
class KeepAliveDismissReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != KeepAliveService.ACTION_REPOST_KEEP_ALIVE_BROADCAST) return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val app = context.applicationContext as? NotiTrackApplication
                val settings = app?.preferences?.getSettingsSnapshot()
                if (settings?.keepAliveEnabled == true || settings?.hasAnyUtilityMonitorEnabled == true) {
                    KeepAliveService.repost(context.applicationContext)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
