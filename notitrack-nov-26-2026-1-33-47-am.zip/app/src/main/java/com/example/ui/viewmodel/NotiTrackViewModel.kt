package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppRuleEntity
import com.example.data.model.KeywordAction
import com.example.data.model.KeywordRuleEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.TtsFeedbackRuleEntity
import com.example.data.model.TtsNumberReadMode
import com.example.data.prefs.KeepAliveNotifTheme
import com.example.data.prefs.NotiTrackSettings
import com.example.data.repository.NotiTrackRepository
import com.example.engine.AntiTheftRuntimeController
import com.example.engine.AntiTheftRuntimeState
import com.example.engine.AppInboxGroup
import com.example.engine.BackupPayload
import com.example.engine.BackupPreview
import com.example.engine.BackupRestoreEngine
import com.example.engine.BackupSelection
import com.example.engine.BatteryOptimizationHelper
import com.example.engine.ConversationGrouper
import com.example.engine.ConversationThreadSummary
import com.example.engine.NotificationIntentRegistry
import com.example.engine.NotificationLaunchResult
import com.example.engine.NotificationSpeaker
import com.example.engine.RestoreMode
import com.example.engine.TtsFeedbackEngine
import com.example.engine.TtsVolumeConfig
import com.example.engine.UtilityAlertDispatcher
import com.example.service.KeepAliveService
import com.example.service.NotiTrackListenerService
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.stringsFor
import com.example.ui.screens.UtilitySoundTarget
import com.example.ui.theme.AppArtTheme
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class NotiTrackTab(val route: String) {
    INBOX("inbox"),
    APPS("apps"),
    FILTERS("filters"),
    SETTINGS("settings")
}

enum class InboxFilter(val labelVi: String) {
    ALL("Tất cả"),
    UNREAD("Chưa đọc"),
    STARRED("Đã ghim"),
    HIGHLIGHTED("Từ khóa ưu tiên"),
    HIDDEN("Nhạy cảm / Đã ẩn")
}

enum class AppsFilter(val labelVi: String) {
    ALL("Tất cả"),
    CAPTURING("Đang ghi nhận"),
    TTS_ACTIVE("Đang đọc to"),
    AUTO_DISMISS("Ẩn thanh trạng thái")
}

data class KeywordPreset(
    val titleVi: String,
    val keywords: String,
    val action: KeywordAction
)

class NotiTrackViewModel(
    private val appContext: Context,
    private val repository: NotiTrackRepository,
    private val speaker: NotificationSpeaker
) : ViewModel() {

    val settings: StateFlow<NotiTrackSettings> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), NotiTrackSettings())

    val allNotifications: StateFlow<List<NotificationEntity>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val appRules: StateFlow<List<AppRuleEntity>> = repository.allAppRules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val keywordRules: StateFlow<List<KeywordRuleEntity>> = repository.allKeywordRules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val ttsFeedbackRules: StateFlow<List<TtsFeedbackRuleEntity>> = repository.allTtsFeedbackRules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val speakingNotificationId: StateFlow<Long?> = speaker.speakingNotificationId

    val antiTheftState: StateFlow<AntiTheftRuntimeState> = AntiTheftRuntimeController.state

    private val _currentTab = MutableStateFlow(NotiTrackTab.INBOX)
    val currentTab: StateFlow<NotiTrackTab> = _currentTab.asStateFlow()

    private val _isListenerEnabled = MutableStateFlow(repository.isNotificationListenerEnabled())
    val isListenerEnabled: StateFlow<Boolean> = _isListenerEnabled.asStateFlow()

    private val _isIgnoringBatteryOptimizations = MutableStateFlow(
        BatteryOptimizationHelper.isIgnoringBatteryOptimizations(appContext)
    )
    val isIgnoringBatteryOptimizations: StateFlow<Boolean> = _isIgnoringBatteryOptimizations.asStateFlow()

    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private var lockInitialized = false
    private var backgroundTimestampMs: Long? = null

    private val _inboxQuery = MutableStateFlow("")
    val inboxQuery: StateFlow<String> = _inboxQuery.asStateFlow()

    private val _inboxFilter = MutableStateFlow(InboxFilter.ALL)
    val inboxFilter: StateFlow<InboxFilter> = _inboxFilter.asStateFlow()

    private val _selectedAppPackage = MutableStateFlow<String?>(null)
    val selectedAppPackage: StateFlow<String?> = _selectedAppPackage.asStateFlow()

    private val _selectedThreadKey = MutableStateFlow<String?>(null)
    val selectedThreadKey: StateFlow<String?> = _selectedThreadKey.asStateFlow()

    private val _appsQuery = MutableStateFlow("")
    val appsQuery: StateFlow<String> = _appsQuery.asStateFlow()

    private val _appsFilter = MutableStateFlow(AppsFilter.ALL)
    val appsFilter: StateFlow<AppsFilter> = _appsFilter.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private val _inboxResetTrigger = MutableStateFlow(0)
    val inboxResetTrigger: StateFlow<Int> = _inboxResetTrigger.asStateFlow()

    private val _inboxPulseEpoch = MutableStateFlow(1)
    val inboxPulseEpoch: StateFlow<Int> = _inboxPulseEpoch.asStateFlow()

    private fun currentStrings() = stringsFor(settings.value.appLanguage)

    val filteredNotifications: StateFlow<List<NotificationEntity>> = combine(
        allNotifications,
        _inboxQuery,
        _inboxFilter
    ) { items, query, filter ->
        val trimmed = query.trim()
        items.filter { item ->
            val filterMatch = when (filter) {
                InboxFilter.ALL -> !item.isHidden
                InboxFilter.UNREAD -> !item.isRead && !item.isHidden
                InboxFilter.STARRED -> item.isStarred
                InboxFilter.HIGHLIGHTED -> item.isHighlighted
                InboxFilter.HIDDEN -> item.isHidden
            }
            val queryMatch = trimmed.isEmpty() ||
                item.title.contains(trimmed, ignoreCase = true) ||
                item.content.contains(trimmed, ignoreCase = true) ||
                item.appName.contains(trimmed, ignoreCase = true) ||
                item.conversationTitle.contains(trimmed, ignoreCase = true) ||
                item.matchedKeywords.contains(trimmed, ignoreCase = true) ||
                (item.detectedOtp?.contains(trimmed) == true)
            filterMatch && queryMatch
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val appInboxGroups: StateFlow<List<AppInboxGroup>> = combine(
        filteredNotifications
    ) { (matching) ->
        ConversationGrouper.buildAppGroups(matching)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val activeAppGroup: StateFlow<AppInboxGroup?> = combine(
        appInboxGroups,
        _selectedAppPackage
    ) { groups, pkg ->
        if (pkg == null) null else groups.find { it.packageName == pkg }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val conversationThreads: StateFlow<List<ConversationThreadSummary>> = combine(
        filteredNotifications
    ) { (matching) ->
        ConversationGrouper.buildThreads(matching)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val activeThreadSummary: StateFlow<ConversationThreadSummary?> = combine(
        conversationThreads,
        _selectedThreadKey
    ) { threads, key ->
        if (key == null) null else threads.find { it.threadKey == key }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    /**
     * Notifications inside the currently opened conversation thread, ordered chronologically
     * (oldest -> newest) to render as a messaging-app chat timeline.
     */
    val activeThreadNotifications: StateFlow<List<NotificationEntity>> = combine(
        filteredNotifications,
        _selectedThreadKey
    ) { matching, key ->
        if (key == null) emptyList()
        else matching
            .filter { ConversationGrouper.resolveThreadKey(it) == key }
            .sortedBy { it.timestamp }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val filteredAppRules: StateFlow<List<AppRuleEntity>> = combine(
        appRules,
        _appsQuery,
        _appsFilter
    ) { rules, query, filter ->
        val trimmed = query.trim()
        rules.filter { rule ->
            val filterMatch = when (filter) {
                AppsFilter.ALL -> true
                AppsFilter.CAPTURING -> rule.captureEnabled
                AppsFilter.TTS_ACTIVE -> rule.readAloudEnabled
                AppsFilter.AUTO_DISMISS -> rule.autoDismissEnabled
            }
            val queryMatch = trimmed.isEmpty() ||
                rule.appName.contains(trimmed, ignoreCase = true) ||
                rule.packageName.contains(trimmed, ignoreCase = true)
            filterMatch && queryMatch
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        viewModelScope.launch {
            val initialSettings = repository.preferences.getSettingsSnapshot()
            if (initialSettings.isAppLockActive && !lockInitialized) {
                _isLocked.value = true
            }
            lockInitialized = true
            repository.syncInstalledAppRules()
            syncKeepAliveService(initialSettings)
        }
    }

    fun refreshSystemStatus() {
        val listenerOn = repository.isNotificationListenerEnabled()
        _isListenerEnabled.value = listenerOn
        _isIgnoringBatteryOptimizations.value = BatteryOptimizationHelper.isIgnoringBatteryOptimizations(appContext)
        viewModelScope.launch {
            repository.syncInstalledAppRules()
            val currentSettings = repository.preferences.getSettingsSnapshot()
            if (listenerOn) {
                if (!NotiTrackListenerService.isConnected) {
                    BatteryOptimizationHelper.forceRebindListener(appContext, respectCooldown = true)
                } else {
                    BatteryOptimizationHelper.requestListenerRebind(appContext)
                }
            }
            syncKeepAliveService(currentSettings)
        }
    }

    private fun syncKeepAliveService(currentSettings: NotiTrackSettings) {
        val shouldRun = currentSettings.keepAliveEnabled || currentSettings.hasAnyUtilityMonitorEnabled
        if (shouldRun) {
            KeepAliveService.start(appContext)
        } else {
            KeepAliveService.stop(appContext)
        }
    }

    fun ensureKeepAliveRunning() {
        viewModelScope.launch {
            val currentSettings = repository.preferences.getSettingsSnapshot()
            syncKeepAliveService(currentSettings)
        }
    }

    fun setKeepAliveEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setKeepAliveEnabled(enabled)
            val updated = repository.preferences.getSettingsSnapshot()
            if (enabled || updated.hasAnyUtilityMonitorEnabled) {
                KeepAliveService.start(appContext)
            } else {
                KeepAliveService.stop(appContext)
            }
            showMessage(if (enabled) currentStrings().msgKeepAliveOn else currentStrings().msgKeepAliveOff)
        }
    }

    fun setKeepAliveShowTemp(show: Boolean) {
        viewModelScope.launch { repository.preferences.setKeepAliveShowTemp(show) }
    }

    fun setKeepAliveShowLunar(show: Boolean) {
        viewModelScope.launch { repository.preferences.setKeepAliveShowLunar(show) }
    }

    fun setKeepAliveShowCount(show: Boolean) {
        viewModelScope.launch { repository.preferences.setKeepAliveShowCount(show) }
    }

    fun setKeepAliveShowBattery(show: Boolean) {
        viewModelScope.launch { repository.preferences.setKeepAliveShowBattery(show) }
    }

    fun setKeepAliveTheme(theme: KeepAliveNotifTheme) {
        viewModelScope.launch { repository.preferences.setKeepAliveTheme(theme) }
    }

    fun rebindListenerService() {
        viewModelScope.launch {
            BatteryOptimizationHelper.forceRebindListener(appContext, respectCooldown = false)
            if (settings.value.keepAliveEnabled || settings.value.hasAnyUtilityMonitorEnabled) {
                KeepAliveService.start(appContext)
            }
            showMessage(currentStrings().msgServiceRebound)
        }
    }

    fun setAppLanguage(language: AppLanguage) {
        viewModelScope.launch {
            repository.preferences.setAppLanguage(language)
            if (settings.value.keepAliveEnabled || settings.value.hasAnyUtilityMonitorEnabled) {
                KeepAliveService.start(appContext)
            }
        }
    }

    fun onAppBackgrounded() {
        backgroundTimestampMs = System.currentTimeMillis()
    }

    fun onAppForegrounded() {
        refreshSystemStatus()
        if (_currentTab.value == NotiTrackTab.INBOX) {
            _inboxPulseEpoch.value = _inboxPulseEpoch.value + 1
        }
        val bgTime = backgroundTimestampMs ?: return
        backgroundTimestampMs = null
        val currentSettings = settings.value
        if (!currentSettings.isAppLockActive) return
        val elapsedSeconds = (System.currentTimeMillis() - bgTime) / 1000L
        if (elapsedSeconds >= currentSettings.autoLockSeconds) {
            _isLocked.value = true
        }
    }

    fun unlockApp() {
        _isLocked.value = false
        if (_currentTab.value == NotiTrackTab.INBOX) {
            _inboxPulseEpoch.value = _inboxPulseEpoch.value + 1
        }
    }

    fun lockAppNow() {
        if (settings.value.isAppLockActive) {
            _isLocked.value = true
        } else {
            showMessage(currentStrings().msgNeedLockFirst)
        }
    }

    fun verifyPinAndUnlock(rawPin: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = repository.preferences.verifyPin(rawPin)
            if (ok) {
                _isLocked.value = false
                if (_currentTab.value == NotiTrackTab.INBOX) {
                    _inboxPulseEpoch.value = _inboxPulseEpoch.value + 1
                }
            }
            onResult(ok)
        }
    }

    fun verifyPinOnly(rawPin: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = repository.preferences.verifyPin(rawPin)
            onResult(ok)
        }
    }

    fun selectTab(tab: NotiTrackTab) {
        if (tab == NotiTrackTab.INBOX && _currentTab.value == NotiTrackTab.INBOX) {
            _selectedThreadKey.value = null
            _selectedAppPackage.value = null
            _inboxResetTrigger.value = _inboxResetTrigger.value + 1
            _inboxPulseEpoch.value = _inboxPulseEpoch.value + 1
        } else {
            _currentTab.value = tab
            if (tab == NotiTrackTab.INBOX) {
                _inboxPulseEpoch.value = _inboxPulseEpoch.value + 1
            }
        }
    }

    fun updateInboxQuery(query: String) {
        _inboxQuery.value = query
    }

    fun selectInboxFilter(filter: InboxFilter) {
        _inboxFilter.value = filter
    }

    fun openAppGroup(packageName: String?) {
        if (packageName == null) {
            _selectedThreadKey.value = null
            _selectedAppPackage.value = null
            return
        }
        _selectedAppPackage.value = packageName
        val group = appInboxGroups.value.find { it.packageName == packageName }
        if (group != null && group.threads.size == 1) {
            openConversationThread(group.threads.first().threadKey)
        } else {
            _selectedThreadKey.value = null
        }
    }

    fun openConversationThread(threadKey: String?) {
        if (threadKey == null) {
            val currentGroup = activeAppGroup.value
            _selectedThreadKey.value = null
            if (currentGroup != null && currentGroup.threads.size <= 1) {
                _selectedAppPackage.value = null
            }
            return
        }
        _selectedThreadKey.value = threadKey
        val unreadIds = allNotifications.value
            .filter { !it.isRead && ConversationGrouper.resolveThreadKey(it) == threadKey }
            .map { it.id }
        if (unreadIds.isNotEmpty()) {
            viewModelScope.launch { repository.markIdsRead(unreadIds) }
        }
    }

    fun setChatTimelineGroupingEnabled(enabled: Boolean) {
        _selectedThreadKey.value = null
        _selectedAppPackage.value = null
        viewModelScope.launch {
            repository.preferences.setChatTimelineGroupingEnabled(enabled)
        }
    }

    fun toggleChatTimelineGrouping() {
        setChatTimelineGroupingEnabled(!settings.value.chatTimelineGroupingEnabled)
    }

    fun markNotificationRead(id: Long) {
        viewModelScope.launch { repository.markRead(id) }
    }

    fun markAllRead() {
        viewModelScope.launch {
            val hasUnread = allNotifications.value.any { !it.isRead }
            if (!hasUnread) {
                showMessage(currentStrings().msgAllAlreadyRead)
                return@launch
            }
            repository.markAllRead()
            showMessage(currentStrings().msgMarkedAllRead)
        }
    }

    fun toggleStar(notification: NotificationEntity) {
        viewModelScope.launch {
            repository.toggleStar(notification.id, !notification.isStarred)
        }
    }

    fun toggleHidden(notification: NotificationEntity) {
        viewModelScope.launch {
            val nextHidden = !notification.isHidden
            repository.toggleHidden(notification.id, nextHidden)
            showMessage(
                if (nextHidden) currentStrings().msgMovedToHidden
                else currentStrings().msgRestoredToMain
            )
        }
    }

    fun deleteNotification(id: Long) {
        viewModelScope.launch {
            if (speakingNotificationId.value == id) speaker.stop()
            repository.deleteNotification(id)
            showMessage(currentStrings().msgDeletedOne)
        }
    }

    fun deleteNotificationsByIds(ids: List<Long>) {
        if (ids.isEmpty()) return
        viewModelScope.launch {
            val speakingId = speakingNotificationId.value
            if (speakingId != null && speakingId in ids) {
                speaker.stop()
            }
            repository.deleteNotificationsByIds(ids)
            val currentThread = _selectedThreadKey.value
            if (currentThread != null) {
                val remaining = activeThreadNotifications.value.count { it.id !in ids }
                if (remaining == 0) {
                    _selectedThreadKey.value = null
                }
            }
            showMessage(
                if (ids.size == 1) currentStrings().msgDeletedOne
                else currentStrings().msgDeletedMany(ids.size)
            )
        }
    }

    fun deleteReadNotificationsOnly(candidateIds: List<Long>? = null) {
        viewModelScope.launch {
            if (candidateIds == null) {
                val readCount = allNotifications.value.count { it.isRead }
                if (readCount > 0) {
                    repository.deleteReadNotifications()
                    showMessage(currentStrings().msgDeletedMany(readCount))
                }
            } else {
                val readIds = allNotifications.value
                    .filter { it.isRead && it.id in candidateIds }
                    .map { it.id }
                if (readIds.isNotEmpty()) {
                    deleteNotificationsByIds(readIds)
                }
            }
        }
    }

    fun toggleSpeakNotification(notification: NotificationEntity) {
        if (speakingNotificationId.value == notification.id) {
            speaker.stop()
            return
        }
        val currentSettings = settings.value
        val rule = appRules.value.find { it.packageName == notification.packageName }
        val useSmartTts = rule?.smartTtsEnabled ?: currentSettings.ttsSmartFilterGlobal
        val hideBalance = rule?.ttsHideBalance ?: currentSettings.ttsHideBalanceGlobal
        val numberReadMode = rule?.resolvedNumberReadMode() ?: TtsNumberReadMode.CONTEXT_AUTO
        val customTemplate = rule?.ttsCustomTemplate.orEmpty()
        val volumeConfig = TtsVolumeConfig(
            overrideVolume = currentSettings.ttsOverrideVolumeEnabled,
            bypassSilentMode = currentSettings.ttsBypassSilentMode,
            volumePercent = currentSettings.ttsCustomVolumePercent,
            autoBoostVolume = rule?.ttsAutoBoostVolume ?: false,
            interSpeechDelayMs = currentSettings.ttsDelayBetweenMs
        )
        speaker.speakNotification(
            notificationId = notification.id,
            appName = notification.appName,
            title = notification.title,
            content = notification.content,
            includeAppName = currentSettings.ttsIncludeAppName,
            speechRate = currentSettings.ttsSpeechRate,
            language = currentSettings.appLanguage,
            smartFilterEnabled = useSmartTts,
            hideBalance = hideBalance,
            numberReadMode = numberReadMode,
            customTemplate = customTemplate,
            volumeConfig = volumeConfig,
            flush = true
        )
    }

    fun speakSampleVoice() {
        val currentSettings = settings.value
        val volumeConfig = TtsVolumeConfig(
            overrideVolume = currentSettings.ttsOverrideVolumeEnabled,
            bypassSilentMode = currentSettings.ttsBypassSilentMode,
            volumePercent = currentSettings.ttsCustomVolumePercent,
            autoBoostVolume = false,
            interSpeechDelayMs = currentSettings.ttsDelayBetweenMs
        )
        speaker.speakSample(
            speechRate = currentSettings.ttsSpeechRate,
            language = currentSettings.appLanguage,
            smartFilterEnabled = currentSettings.ttsSmartFilterGlobal,
            hideBalance = currentSettings.ttsHideBalanceGlobal,
            includeAppName = currentSettings.ttsIncludeAppName,
            volumeConfig = volumeConfig
        )
    }

    fun stopSpeaking() {
        speaker.stop()
    }

    fun updateAppsQuery(query: String) {
        _appsQuery.value = query
    }

    fun selectAppsFilter(filter: AppsFilter) {
        _appsFilter.value = filter
    }

    fun updateAppRule(rule: AppRuleEntity) {
        viewModelScope.launch {
            repository.upsertAppRule(rule)
        }
    }

    fun setCaptureForAllApps(enabled: Boolean) {
        viewModelScope.launch {
            repository.setCaptureForAllApps(enabled)
            showMessage(
                if (enabled) currentStrings().msgEnabledAllApps
                else currentStrings().msgDisabledAllApps
            )
        }
    }

    fun saveKeywordRule(
        existingId: Long?,
        keywords: String,
        action: KeywordAction,
        targetPackage: String?,
        targetAppName: String?,
        isCaseSensitive: Boolean,
        isRegex: Boolean
    ) {
        if (keywords.isBlank()) return
        viewModelScope.launch {
            if (existingId != null) {
                val existing = keywordRules.value.find { it.id == existingId }
                if (existing != null) {
                    repository.updateKeywordRule(
                        existing.copy(
                            keywords = keywords.trim(),
                            action = action,
                            targetPackage = targetPackage,
                            targetAppName = targetAppName,
                            isCaseSensitive = isCaseSensitive,
                            isRegex = isRegex
                        )
                    )
                    showMessage(currentStrings().msgRuleUpdated)
                    return@launch
                }
            }
            repository.addKeywordRule(
                keywords = keywords,
                action = action,
                targetPackage = targetPackage,
                targetAppName = targetAppName,
                isCaseSensitive = isCaseSensitive,
                isRegex = isRegex
            )
            showMessage(currentStrings().msgRuleAdded)
        }
    }

    fun addPresetRule(preset: KeywordPreset) {
        viewModelScope.launch {
            repository.addKeywordRule(
                keywords = preset.keywords,
                action = preset.action,
                targetPackage = null,
                targetAppName = null,
                isCaseSensitive = false,
                isRegex = false
            )
            showMessage(currentStrings().msgPresetAdded(preset.titleVi))
        }
    }

    fun toggleKeywordRule(rule: KeywordRuleEntity, enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleKeywordRule(rule.id, enabled)
        }
    }

    fun deleteKeywordRule(id: Long) {
        viewModelScope.launch {
            repository.deleteKeywordRule(id)
            showMessage(currentStrings().msgRuleDeleted)
        }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setBiometricEnabled(enabled)
            showMessage(
                if (enabled) currentStrings().msgBiometricOn
                else currentStrings().msgBiometricOff
            )
        }
    }

    fun setPin(rawPin: String) {
        viewModelScope.launch {
            repository.preferences.setPin(rawPin)
            showMessage(
                if (rawPin.isBlank()) currentStrings().msgPinCleared
                else currentStrings().msgPinSaved
            )
        }
    }

    fun setFlagSecure(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setFlagSecureEnabled(enabled)
        }
    }

    fun setRequireAuthOnDelete(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setRequireAuthOnDelete(enabled)
        }
    }

    fun setAutoLockSeconds(seconds: Int) {
        viewModelScope.launch {
            repository.preferences.setAutoLockSeconds(seconds)
        }
    }

    fun setTtsGlobalEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsGlobalEnabled(enabled)
            repository.setReadAloudForAllApps(enabled)
            showMessage(
                if (enabled) currentStrings().msgTtsAllOn
                else currentStrings().msgTtsAllOff
            )
        }
    }

    fun setTtsSpeechRate(rate: Float) {
        viewModelScope.launch {
            repository.preferences.setTtsSpeechRate(rate)
        }
    }

    fun setTtsIncludeAppName(include: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsIncludeAppName(include)
        }
    }

    fun setTtsSmartFilterGlobal(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsSmartFilterGlobal(enabled)
            repository.setSmartTtsForAllApps(enabled)
            showMessage(
                if (enabled) currentStrings().msgSmartTtsAllOn
                else currentStrings().msgSmartTtsAllOff
            )
        }
    }

    fun setTtsHideBalanceGlobal(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsHideBalanceGlobal(enabled)
            repository.setHideBalanceForAllApps(enabled)
            showMessage(
                if (enabled) currentStrings().msgHideBalanceAllOn
                else currentStrings().msgHideBalanceAllOff
            )
        }
    }

    fun setTtsOverrideVolumeEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsOverrideVolumeEnabled(enabled)
        }
    }

    fun setTtsBypassSilentMode(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsBypassSilentMode(enabled)
        }
    }

    fun setTtsCustomVolumePercent(percent: Int) {
        viewModelScope.launch {
            repository.preferences.setTtsCustomVolumePercent(percent)
        }
    }

    fun setTtsDelayBetweenMs(delayMs: Int) {
        viewModelScope.launch {
            repository.preferences.setTtsDelayBetweenMs(delayMs)
        }
    }

    fun setTtsOnlyWhenScreenOff(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsOnlyWhenScreenOff(enabled)
        }
    }

    fun setTtsNumericRatioPercent(percent: Int) {
        viewModelScope.launch {
            repository.preferences.setTtsNumericRatioPercent(percent)
        }
    }

    fun submitTtsFeedback(notification: NotificationEntity, shouldSpeak: Boolean) {
        viewModelScope.launch {
            val fingerprint = TtsFeedbackEngine.buildFingerprint(notification.title, notification.content)
            val existingSame = ttsFeedbackRules.value.firstOrNull {
                it.packageName == notification.packageName &&
                    it.patternFingerprint == fingerprint &&
                    it.shouldSpeak == shouldSpeak
            }
            if (existingSame != null) {
                repository.deleteTtsFeedbackRule(existingSame.id)
                showMessage(currentStrings().feedbackRemovedMsg)
            } else {
                repository.recordTtsFeedback(notification, shouldSpeak)
                showMessage(
                    if (shouldSpeak) currentStrings().feedbackSavedSpeakMsg(notification.appName)
                    else currentStrings().feedbackSavedMuteMsg(notification.appName)
                )
            }
        }
    }

    fun toggleTtsFeedbackRule(rule: TtsFeedbackRuleEntity) {
        viewModelScope.launch {
            repository.toggleTtsFeedbackDecision(rule)
        }
    }

    fun deleteTtsFeedbackRule(id: Long) {
        viewModelScope.launch {
            repository.deleteTtsFeedbackRule(id)
            showMessage(currentStrings().feedbackRemovedMsg)
        }
    }

    fun clearAllTtsFeedbackRules() {
        viewModelScope.launch {
            repository.clearAllTtsFeedbackRules()
            showMessage(currentStrings().feedbackClearedAllMsg)
        }
    }

    fun openNotificationTarget(
        packageName: String,
        appName: String,
        notificationId: Long? = null,
        notificationKey: String? = null
    ) {
        val result = NotificationIntentRegistry.launchNotificationTarget(
            context = appContext,
            packageName = packageName,
            notificationId = notificationId,
            notificationKey = notificationKey
        )
        when (result) {
            NotificationLaunchResult.DEEP_LINK_OPENED -> Unit
            NotificationLaunchResult.FALLBACK_APP_OPENED -> {
                showMessage(currentStrings().launchFallbackMsg(appName))
            }
            NotificationLaunchResult.FAILED -> {
                showMessage(currentStrings().launchFailedMsg(appName))
            }
        }
    }

    fun setCaptureNewAppsByDefault(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setCaptureNewAppsByDefault(enabled)
        }
    }

    fun setRetentionDays(days: Int) {
        viewModelScope.launch {
            repository.preferences.setRetentionDays(days)
            repository.applyRetentionCleanup(days)
            showMessage(
                if (days == 0) currentStrings().msgRetentionNever
                else currentStrings().msgRetentionDays(days)
            )
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            repository.preferences.setThemeMode(mode)
        }
    }

    fun setArtTheme(theme: AppArtTheme) {
        viewModelScope.launch {
            repository.preferences.setArtTheme(theme)
        }
    }

    fun updateUtilitiesSettings(transform: (NotiTrackSettings) -> NotiTrackSettings) {
        viewModelScope.launch {
            repository.preferences.updateUtilitiesSettings(transform)
            val updated = repository.preferences.getSettingsSnapshot()
            syncKeepAliveService(updated)
        }
    }

    fun testUtilityAlert(target: UtilitySoundTarget) {
        viewModelScope.launch {
            val current = repository.preferences.getSettingsSnapshot()
            when (target) {
                UtilitySoundTarget.LOW_BATTERY -> {
                    UtilityAlertDispatcher.dispatchLowBattery(
                        context = appContext,
                        settings = current,
                        batteryPercent = current.lowBatteryThreshold
                    )
                }
                UtilitySoundTarget.CHARGING -> {
                    UtilityAlertDispatcher.dispatchChargingLevel(
                        context = appContext,
                        settings = current,
                        batteryPercent = current.chargingAlertThreshold
                    )
                }
                UtilitySoundTarget.FULL_CHARGE -> {
                    UtilityAlertDispatcher.dispatchFullCharge(
                        context = appContext,
                        settings = current,
                        batteryPercent = current.fullChargeThreshold,
                        extraMinutesWaited = if (current.fullChargeThreshold == 100) current.fullChargeExtraMinutes else 0
                    )
                }
                UtilitySoundTarget.OVERHEAT -> {
                    UtilityAlertDispatcher.dispatchOverheat(
                        context = appContext,
                        settings = current,
                        tempCelsius = current.overheatThresholdC.toFloat()
                    )
                }
            }
            val isVi = current.appLanguage.resolved() == AppLanguage.VIETNAMESE
            showMessage(
                if (isVi) "Đã gửi thông báo thử nghiệm Tiện ích"
                else "Utility test alert sent"
            )
        }
    }

    fun setMotionGuardEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setMotionGuardEnabled(enabled)
            val updated = repository.preferences.getSettingsSnapshot()
            syncKeepAliveService(updated)
            showMessage(
                if (enabled) currentStrings().motionGuardArmedMsg(updated.motionGuardArmDelaySeconds)
                else currentStrings().motionGuardDisarmedMsg
            )
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            speaker.stop()
            repository.clearAllNotifications()
            _selectedThreadKey.value = null
            _selectedAppPackage.value = null
            showMessage(currentStrings().msgClearedAll)
        }
    }

    fun generateExportText(onReady: (String) -> Unit) {
        viewModelScope.launch {
            val content = repository.buildExportText()
            onReady(content)
        }
    }

    fun exportBackupJson(selection: BackupSelection, onReady: (String) -> Unit) {
        viewModelScope.launch {
            runCatching {
                repository.exportBackupJson(selection)
            }.onSuccess { json ->
                onReady(json)
            }.onFailure {
                showMessage(currentStrings().backupFailedMsg)
            }
        }
    }

    fun parseBackupJson(rawJson: String, onSuccess: (BackupPreview) -> Unit) {
        val result = BackupRestoreEngine.parseBackupJson(rawJson)
        result.onSuccess { preview ->
            if (preview.totalItemCount == 0) {
                showMessage(currentStrings().restoreInvalidFileMsg)
            } else {
                onSuccess(preview)
            }
        }.onFailure {
            showMessage(currentStrings().restoreInvalidFileMsg)
        }
    }

    fun restoreBackup(payload: BackupPayload, mode: RestoreMode) {
        viewModelScope.launch {
            runCatching {
                repository.restoreBackup(payload, mode)
            }.onSuccess { summary ->
                _selectedThreadKey.value = null
                _selectedAppPackage.value = null
                val updatedSettings = repository.preferences.getSettingsSnapshot()
                syncKeepAliveService(updatedSettings)
                showMessage(
                    currentStrings().restoreSuccessMsg(
                        summary.notificationsRestored,
                        summary.appRulesRestored,
                        summary.keywordRulesRestored,
                        summary.feedbackRulesRestored
                    )
                )
            }.onFailure {
                showMessage(currentStrings().restoreInvalidFileMsg)
            }
        }
    }

    fun showMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearMessage() {
        _snackbarMessage.value = null
    }

    class Factory(
        private val appContext: Context,
        private val repository: NotiTrackRepository,
        private val speaker: NotificationSpeaker
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return NotiTrackViewModel(appContext, repository, speaker) as T
        }
    }
}
