package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.view.View
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.NotiTrackApplication
import com.example.R
import com.example.data.prefs.KeepAliveNotifTheme
import com.example.data.prefs.NotiTrackSettings
import com.example.engine.BatteryOptimizationHelper
import com.example.engine.VietnameseLunarCalendar
import com.example.ui.i18n.stringsFor
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlin.math.roundToInt

class KeepAliveService : Service() {

    private val exceptionHandler = CoroutineExceptionHandler { _, _ -> }
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO + exceptionHandler)

    private data class DeviceTelemetry(
        val tempCelsius: Float = 32f,
        val batteryPercent: Int = 100,
        val isCharging: Boolean = false,
        val dayTick: Long = System.currentTimeMillis() / 60_000L
    )

    private val telemetryFlow = MutableStateFlow(DeviceTelemetry())
    private var receiverRegistered = false
    private var foregroundStarted = false

    private val systemStatusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_BATTERY_CHANGED -> updateTelemetryFromIntent(intent)
                Intent.ACTION_DATE_CHANGED,
                Intent.ACTION_TIME_CHANGED,
                Intent.ACTION_TIMEZONE_CHANGED -> {
                    telemetryFlow.value = telemetryFlow.value.copy(
                        dayTick = System.currentTimeMillis()
                    )
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        registerTelemetryReceiver()
        val initialBattery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (initialBattery != null) {
            updateTelemetryFromIntent(initialBattery)
        }
        promoteInitialForeground()
        startLiveNotificationObserver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (!foregroundStarted) {
            promoteInitialForeground()
        }
        telemetryFlow.value = telemetryFlow.value.copy(dayTick = System.currentTimeMillis())
        BatteryOptimizationHelper.requestListenerRebind(this)
        return START_STICKY
    }

    private fun registerTelemetryReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
        }
        runCatching {
            ContextCompat.registerReceiver(
                this,
                systemStatusReceiver,
                filter,
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            receiverRegistered = true
        }
    }

    private fun updateTelemetryFromIntent(intent: Intent) {
        val rawTemp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 320)
        val tempC = (rawTemp / 10f).coerceIn(0f, 99f)
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val pct = if (level >= 0) ((level * 100f) / scale).roundToInt().coerceIn(0, 100) else 100
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val prev = telemetryFlow.value
        if (prev.tempCelsius != tempC || prev.batteryPercent != pct || prev.isCharging != charging) {
            telemetryFlow.value = prev.copy(
                tempCelsius = tempC,
                batteryPercent = pct,
                isCharging = charging
            )
        }
    }

    private fun promoteInitialForeground() {
        val app = application as? NotiTrackApplication
        val settings = runCatching {
            app?.let { runBlocking { it.preferences.getSettingsSnapshot() } }
        }.getOrNull() ?: NotiTrackSettings()
        val notification = buildStatusNotification(
            settings = settings,
            telemetry = telemetryFlow.value,
            totalCount = 0
        )
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            foregroundStarted = true
        }
    }

    private fun startLiveNotificationObserver() {
        val app = application as? NotiTrackApplication ?: return
        serviceScope.launch {
            combine(
                app.preferences.settingsFlow,
                app.repository.totalNotificationCount,
                telemetryFlow
            ) { settings, count, telemetry ->
                Triple(settings, count, telemetry)
            }.collect { (settings, count, telemetry) ->
                if (!settings.keepAliveEnabled) return@collect
                val notification = buildStatusNotification(settings, telemetry, count)
                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                runCatching {
                    manager.notify(NOTIFICATION_ID, notification)
                }
            }
        }
    }

    private fun buildStatusNotification(
        settings: NotiTrackSettings,
        telemetry: DeviceTelemetry,
        totalCount: Int
    ): Notification {
        val strings = stringsFor(settings.appLanguage)
        ensureChannel(strings.keepAliveChannelName)

        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val tempText = "${telemetry.tempCelsius.roundToInt()}°C"
        val lunarDate = VietnameseLunarCalendar.today()
        val lunarFullText = lunarDate.formatDdMmYyyy()
        val lunarShortText = lunarDate.formatShort()
        val countShortText = "$totalCount"
        val countFullText = "$totalCount ${strings.keepAliveCountShort}"
        val bolt = if (telemetry.isCharging) "⚡" else ""
        val batteryShortText = "$bolt${telemetry.batteryPercent}%"
        val batteryFullText = "${strings.keepAliveBatteryShort} $bolt${telemetry.batteryPercent}%"

        val summaryParts = buildList {
            if (settings.keepAliveShowTemp) add(tempText)
            if (settings.keepAliveShowLunar) add("$lunarFullText ${strings.keepAliveLunarShort}")
            if (settings.keepAliveShowCount) add(countFullText)
            if (settings.keepAliveShowBattery) add(batteryFullText)
        }
        val fallbackSummary = if (summaryParts.isNotEmpty()) {
            summaryParts.joinToString(" • ")
        } else {
            strings.keepAliveNotifText
        }

        val bgRes = when (settings.keepAliveTheme) {
            KeepAliveNotifTheme.JADE -> R.drawable.bg_keep_alive_jade
            KeepAliveNotifTheme.OCEAN -> R.drawable.bg_keep_alive_ocean
            KeepAliveNotifTheme.OBSIDIAN -> R.drawable.bg_keep_alive_obsidian
            KeepAliveNotifTheme.AMBER -> R.drawable.bg_keep_alive_amber
            KeepAliveNotifTheme.CRIMSON -> R.drawable.bg_keep_alive_crimson
        }

        val anyVisible = settings.keepAliveShowTemp || settings.keepAliveShowLunar ||
            settings.keepAliveShowCount || settings.keepAliveShowBattery

        val compactViews = RemoteViews(packageName, R.layout.notification_keep_alive_compact).apply {
            setInt(R.id.keep_alive_root, "setBackgroundResource", bgRes)

            setViewVisibility(R.id.pill_temp, if (settings.keepAliveShowTemp) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_temp, tempText)

            setViewVisibility(R.id.pill_lunar, if (settings.keepAliveShowLunar) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_lunar, lunarShortText)

            setViewVisibility(R.id.pill_count, if (settings.keepAliveShowCount) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_count, countShortText)

            setViewVisibility(R.id.pill_battery, if (settings.keepAliveShowBattery) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_battery, batteryShortText)

            setViewVisibility(R.id.keep_alive_pills_row, if (anyVisible) View.VISIBLE else View.GONE)
            setViewVisibility(R.id.keep_alive_fallback_line, if (anyVisible) View.GONE else View.VISIBLE)
            setTextViewText(R.id.keep_alive_fallback_line, strings.keepAliveNotifText)
        }

        val expandedViews = RemoteViews(packageName, R.layout.notification_keep_alive).apply {
            setInt(R.id.keep_alive_root, "setBackgroundResource", bgRes)
            setTextViewText(R.id.keep_alive_title, strings.appName)
            setTextViewText(R.id.keep_alive_badge, strings.keepAliveActiveBadge)

            val showRow1 = settings.keepAliveShowTemp || settings.keepAliveShowLunar
            val showRow2 = settings.keepAliveShowCount || settings.keepAliveShowBattery

            setViewVisibility(R.id.keep_alive_row_1, if (showRow1) View.VISIBLE else View.GONE)
            setViewVisibility(R.id.pill_temp, if (settings.keepAliveShowTemp) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_temp, tempText)

            setViewVisibility(R.id.pill_lunar, if (settings.keepAliveShowLunar) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_lunar, "$lunarFullText ${strings.keepAliveLunarShort}")

            setViewVisibility(R.id.keep_alive_row_2, if (showRow2) View.VISIBLE else View.GONE)
            setViewVisibility(R.id.pill_count, if (settings.keepAliveShowCount) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_count, countFullText)

            setViewVisibility(R.id.pill_battery, if (settings.keepAliveShowBattery) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_battery, batteryFullText)

            setViewVisibility(R.id.keep_alive_fallback_line, if (anyVisible) View.GONE else View.VISIBLE)
            setTextViewText(R.id.keep_alive_fallback_line, strings.keepAliveNotifText)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(strings.appName)
            .setContentText(fallbackSummary)
            .setCustomContentView(compactViews)
            .setCustomBigContentView(expandedViews)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setColor(settings.keepAliveTheme.endColorHex.toInt())
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun ensureChannel(channelName: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                channelName,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setShowBadge(false)
                enableLights(false)
                enableVibration(false)
                setSound(null, null)
            }
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            runCatching { unregisterReceiver(systemStatusReceiver) }
            receiverRegistered = false
        }
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "notitrack_keep_alive_v2"
        const val NOTIFICATION_ID = 4091
        const val ACTION_START = "com.trieuz.notitrack.action.START_KEEP_ALIVE"
        const val ACTION_STOP = "com.trieuz.notitrack.action.STOP_KEEP_ALIVE"

        fun start(context: Context) {
            runCatching {
                val intent = Intent(context, KeepAliveService::class.java).apply {
                    action = ACTION_START
                }
                ContextCompat.startForegroundService(context, intent)
            }
        }

        fun stop(context: Context) {
            runCatching {
                val intent = Intent(context, KeepAliveService::class.java).apply {
                    action = ACTION_STOP
                }
                context.startService(intent)
            }
        }
    }
}
