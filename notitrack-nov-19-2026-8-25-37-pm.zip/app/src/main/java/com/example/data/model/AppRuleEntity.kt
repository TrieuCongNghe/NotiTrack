package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TtsFilterMode {
    ALL,
    NUMERIC_ONLY
}

enum class TtsNumberReadMode {
    CONTEXT_AUTO,
    EXACT_DIGITS,
    NATURAL_WORDS
}

@Entity(tableName = "app_rules")
data class AppRuleEntity(
    @PrimaryKey val packageName: String,
    val appName: String,
    val captureEnabled: Boolean = true,
    val readAloudEnabled: Boolean = false,
    val autoDismissEnabled: Boolean = false,
    val smartTtsEnabled: Boolean = true,
    val ttsHideBalance: Boolean = true,
    val ttsFilterMode: String = TtsFilterMode.ALL.name,
    val ttsNumberReadMode: String = TtsNumberReadMode.CONTEXT_AUTO.name,
    val ttsAutoBoostVolume: Boolean = false,
    val ttsCustomTemplate: String = "",
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun resolvedFilterMode(): TtsFilterMode =
        runCatching { TtsFilterMode.valueOf(ttsFilterMode) }.getOrDefault(TtsFilterMode.ALL)

    fun resolvedNumberReadMode(): TtsNumberReadMode =
        runCatching { TtsNumberReadMode.valueOf(ttsNumberReadMode) }.getOrDefault(TtsNumberReadMode.CONTEXT_AUTO)

    val hasCustomTemplate: Boolean get() = ttsCustomTemplate.isNotBlank()
}
