package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AppRuleEntity
import com.example.data.model.KeywordRuleEntity
import com.example.data.model.NotificationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun observeAllNotifications(): Flow<List<NotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications")
    fun observeTotalCount(): Flow<Int>

    @Query("SELECT * FROM notifications WHERE packageName = :packageName ORDER BY timestamp DESC")
    fun observeByPackage(packageName: String): Flow<List<NotificationEntity>>

    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    suspend fun getAllSnapshot(): List<NotificationEntity>

    @Query(
        """
        SELECT COUNT(*) FROM notifications
        WHERE packageName = :packageName
          AND title = :title
          AND content = :content
          AND timestamp >= :sinceTimestamp
        """
    )
    suspend fun countRecentDuplicates(
        packageName: String,
        title: String,
        content: String,
        sinceTimestamp: Long
    ): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(notification: NotificationEntity): Long

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markRead(id: Long)

    @Query("UPDATE notifications SET isRead = 1 WHERE id IN (:ids)")
    suspend fun markIdsRead(ids: List<Long>)

    @Query("UPDATE notifications SET isRead = 1 WHERE packageName = :packageName")
    suspend fun markPackageRead(packageName: String)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllRead()

    @Query("UPDATE notifications SET isStarred = :starred WHERE id = :id")
    suspend fun setStarred(id: Long, starred: Boolean)

    @Query("UPDATE notifications SET isHidden = :hidden WHERE id = :id")
    suspend fun setHidden(id: Long, hidden: Boolean)

    @Query("DELETE FROM notifications WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM notifications WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("DELETE FROM notifications WHERE isRead = 1")
    suspend fun deleteReadNotifications()

    @Query("DELETE FROM notifications WHERE packageName = :packageName")
    suspend fun deleteByPackage(packageName: String)

    @Query("DELETE FROM notifications WHERE timestamp < :olderThan AND isStarred = 0")
    suspend fun deleteOlderThan(olderThan: Long)

    @Query("DELETE FROM notifications")
    suspend fun deleteAll()
}

@Dao
interface AppRuleDao {
    @Query("SELECT * FROM app_rules ORDER BY appName COLLATE NOCASE ASC")
    fun observeAllRules(): Flow<List<AppRuleEntity>>

    @Query("SELECT * FROM app_rules WHERE packageName = :packageName LIMIT 1")
    suspend fun getRuleForPackage(packageName: String): AppRuleEntity?

    @Query("SELECT * FROM app_rules")
    suspend fun getAllSnapshot(): List<AppRuleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(rule: AppRuleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(rules: List<AppRuleEntity>)

    @Query("UPDATE app_rules SET captureEnabled = :enabled, updatedAt = :now")
    suspend fun setCaptureForAll(enabled: Boolean, now: Long = System.currentTimeMillis())

    @Query("UPDATE app_rules SET readAloudEnabled = :enabled, updatedAt = :now")
    suspend fun setReadAloudForAll(enabled: Boolean, now: Long = System.currentTimeMillis())

    @Query("UPDATE app_rules SET smartTtsEnabled = :enabled, updatedAt = :now")
    suspend fun setSmartTtsForAll(enabled: Boolean, now: Long = System.currentTimeMillis())

    @Query("UPDATE app_rules SET ttsHideBalance = :enabled, updatedAt = :now")
    suspend fun setHideBalanceForAll(enabled: Boolean, now: Long = System.currentTimeMillis())
}

@Dao
interface KeywordRuleDao {
    @Query("SELECT * FROM keyword_rules ORDER BY createdAt DESC")
    fun observeAllRules(): Flow<List<KeywordRuleEntity>>

    @Query("SELECT * FROM keyword_rules WHERE isEnabled = 1")
    suspend fun getEnabledRulesSnapshot(): List<KeywordRuleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(rule: KeywordRuleEntity): Long

    @Update
    suspend fun update(rule: KeywordRuleEntity)

    @Query("UPDATE keyword_rules SET isEnabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: Long, enabled: Boolean)

    @Query("UPDATE keyword_rules SET matchCount = matchCount + 1 WHERE id IN (:ids)")
    suspend fun incrementMatchCounts(ids: List<Long>)

    @Query("DELETE FROM keyword_rules WHERE id = :id")
    suspend fun deleteById(id: Long)
}
