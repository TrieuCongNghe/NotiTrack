package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.NotificationEntity
import com.example.engine.AppInboxGroup
import com.example.engine.ConversationThreadSummary
import com.example.ui.components.AppIconAvatar
import com.example.ui.components.ListenerAccessBanner
import com.example.ui.components.NotiTrackSearchBar
import com.example.ui.components.OtpCopyPill
import com.example.ui.components.formatFullTimestamp
import com.example.ui.components.formatRelativeTimestamp
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.viewmodel.InboxFilter

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun InboxScreen(
    allNotifications: List<NotificationEntity>,
    notifications: List<NotificationEntity>,
    appInboxGroups: List<AppInboxGroup>,
    activeAppGroup: AppInboxGroup?,
    conversationThreads: List<ConversationThreadSummary>,
    activeThread: ConversationThreadSummary?,
    activeThreadMessages: List<NotificationEntity>,
    isChatGroupedView: Boolean,
    query: String,
    activeFilter: InboxFilter,
    isListenerEnabled: Boolean,
    isLockConfigured: Boolean,
    speakingNotificationId: Long?,
    onQueryChange: (String) -> Unit,
    onFilterChange: (InboxFilter) -> Unit,
    onToggleChatGroupedView: () -> Unit,
    onOpenAppGroup: (String?) -> Unit,
    onOpenThread: (String?) -> Unit,
    onMarkAllRead: () -> Unit,
    onMarkRead: (Long) -> Unit,
    onToggleStar: (NotificationEntity) -> Unit,
    onToggleHidden: (NotificationEntity) -> Unit,
    onDeleteNotification: (Long) -> Unit,
    onDeleteNotificationsByIds: (List<Long>) -> Unit,
    onDeleteReadOnly: (List<Long>?) -> Unit,
    onClearAllNotifications: () -> Unit,
    onToggleSpeak: (NotificationEntity) -> Unit,
    onOpenListenerSettings: () -> Unit,
    onSendTestNotification: () -> Unit,
    onLockNow: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val s = LocalAppStrings.current

    var inspectedNotification by remember { mutableStateOf<NotificationEntity?>(null) }
    var selectionMode by remember { mutableStateOf(false) }
    var selectedNotificationIds by remember { mutableStateOf(emptySet<Long>()) }
    var pendingDeleteTargets by remember { mutableStateOf<List<NotificationEntity>?>(null) }
    var pendingClearAllArchive by remember { mutableStateOf(false) }

    val visibleIds = remember(notifications) { notifications.map { it.id }.toSet() }

    if (selectionMode && activeThread == null && activeAppGroup == null) {
        BackHandler {
            selectionMode = false
            selectedNotificationIds = emptySet()
        }
    }

    if (activeThread != null) {
        ChatTimelineView(
            thread = activeThread,
            messages = activeThreadMessages,
            speakingNotificationId = speakingNotificationId,
            onBack = { onOpenThread(null) },
            onInspectNotification = { item ->
                if (!item.isRead) onMarkRead(item.id)
                inspectedNotification = item
            },
            onCopyOtp = { code ->
                copyToClipboard(context, "OTP", code)
                onShowMessage(s.inboxCopiedOtp(code))
            },
            onToggleSpeak = onToggleSpeak,
            onToggleStar = onToggleStar,
            onRequestBulkDelete = { targets ->
                pendingClearAllArchive = false
                pendingDeleteTargets = targets
            },
            modifier = modifier
        )
    } else if (isChatGroupedView && activeAppGroup != null) {
        AppThreadsLevelView(
            appGroup = activeAppGroup,
            allNotifications = notifications,
            onBack = { onOpenAppGroup(null) },
            onOpenThread = onOpenThread,
            onRequestBulkDelete = { targets ->
                pendingClearAllArchive = false
                pendingDeleteTargets = targets
            },
            modifier = modifier
        )
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            if (selectionMode) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    selectionMode = false
                                    selectedNotificationIds = emptySet()
                                },
                                modifier = Modifier.testTag("inbox_exit_select_mode")
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = s.close)
                            }
                            Text(
                                text = s.inboxSelectedCount(selectedNotificationIds.size),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            val allSelected = visibleIds.isNotEmpty() && selectedNotificationIds.containsAll(visibleIds)
                            IconButton(
                                onClick = {
                                    selectedNotificationIds = if (allSelected) emptySet() else visibleIds
                                },
                                modifier = Modifier.testTag("inbox_select_all_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.SelectAll,
                                    contentDescription = if (allSelected) s.inboxDeselectAll else s.inboxSelectAll
                                )
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    val targets = notifications.filter { it.id in selectedNotificationIds }
                                    if (targets.isNotEmpty()) {
                                        pendingClearAllArchive = false
                                        pendingDeleteTargets = targets
                                    }
                                },
                                enabled = selectedNotificationIds.isNotEmpty(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error,
                                    contentColor = MaterialTheme.colorScheme.onError
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("inbox_delete_selected_button")
                            ) {
                                Icon(Icons.Filled.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(s.inboxDeleteSelected, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }

                            OutlinedButton(
                                onClick = {
                                    if (allNotifications.isNotEmpty()) {
                                        pendingClearAllArchive = true
                                        pendingDeleteTargets = allNotifications
                                    }
                                },
                                enabled = allNotifications.isNotEmpty(),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                ),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.45f)),
                                modifier = Modifier.testTag("inbox_delete_all_archive_button")
                            ) {
                                Icon(Icons.Filled.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(s.inboxDeleteAll, maxLines = 1)
                            }
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = s.appName,
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isListenerEnabled) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.error
                                    )
                            )
                            Text(
                                text = if (isListenerEnabled) s.listenerActive else s.listenerInactive,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = onToggleChatGroupedView,
                        modifier = Modifier.testTag("toggle_grouped_view_button")
                    ) {
                        Icon(
                            imageVector = if (isChatGroupedView) Icons.AutoMirrored.Filled.ViewList else Icons.Filled.Forum,
                            contentDescription = if (isChatGroupedView) s.inboxTimeline else s.inboxGrouped,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(
                        onClick = {
                            selectionMode = true
                            selectedNotificationIds = emptySet()
                        },
                        enabled = notifications.isNotEmpty(),
                        modifier = Modifier.testTag("inbox_enter_select_mode")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Checklist,
                            contentDescription = s.inboxSelectMode,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(
                        onClick = onMarkAllRead,
                        modifier = Modifier.testTag("mark_all_read_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DoneAll,
                            contentDescription = s.inboxMarkAllRead,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (isLockConfigured) {
                        IconButton(
                            onClick = onLockNow,
                            modifier = Modifier.testTag("quick_lock_app_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = s.inboxLockNow,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            NotiTrackSearchBar(
                query = query,
                placeholder = s.inboxSearchHint,
                onQueryChange = onQueryChange,
                testTag = "inbox_search_input"
            )

            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(InboxFilter.entries) { filter ->
                    FilterChip(
                        selected = activeFilter == filter,
                        onClick = { onFilterChange(filter) },
                        label = {
                            Text(
                                text = s.inboxFilterLabels[filter] ?: filter.labelVi,
                                style = MaterialTheme.typography.labelLarge
                            )
                        },
                        modifier = Modifier.testTag("inbox_filter_${filter.name.lowercase()}")
                    )
                }
            }

            if (isChatGroupedView && conversationThreads.isNotEmpty() && !selectionMode) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Forum,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = s.inboxChatGroupingHint,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(
                        onClick = {
                            pendingClearAllArchive = true
                            pendingDeleteTargets = allNotifications
                        },
                        modifier = Modifier.testTag("inbox_quick_clear_all_button")
                    ) {
                        Text(
                            text = s.inboxDeleteAll,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(10.dp))
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (!isListenerEnabled) {
                    item(key = "listener_banner") {
                        ListenerAccessBanner(onGrantAccess = onOpenListenerSettings)
                    }
                }

                if (isChatGroupedView) {
                    if (appInboxGroups.isEmpty()) {
                        item(key = "empty_grouped") {
                            EmptyInboxCard(
                                isListenerEnabled = isListenerEnabled,
                                onGrantAccess = onOpenListenerSettings,
                                onSendTestNotification = onSendTestNotification
                            )
                        }
                    } else {
                        items(appInboxGroups, key = { it.packageName }) { appGroup ->
                            val isAppSelected = appGroup.notificationIds.isNotEmpty() &&
                                appGroup.notificationIds.all { it in selectedNotificationIds }
                            AppInboxGroupCard(
                                group = appGroup,
                                selectionMode = selectionMode,
                                isSelected = isAppSelected,
                                onClick = {
                                    if (selectionMode) {
                                        selectedNotificationIds = if (isAppSelected) {
                                            selectedNotificationIds - appGroup.notificationIds.toSet()
                                        } else {
                                            selectedNotificationIds + appGroup.notificationIds
                                        }
                                    } else {
                                        onOpenAppGroup(appGroup.packageName)
                                    }
                                },
                                onLongClick = {
                                    if (!selectionMode) {
                                        selectionMode = true
                                        selectedNotificationIds = appGroup.notificationIds.toSet()
                                    } else {
                                        selectedNotificationIds = if (isAppSelected) {
                                            selectedNotificationIds - appGroup.notificationIds.toSet()
                                        } else {
                                            selectedNotificationIds + appGroup.notificationIds
                                        }
                                    }
                                }
                            )
                        }
                    }
                } else {
                    if (notifications.isEmpty()) {
                        item(key = "empty_timeline") {
                            EmptyInboxCard(
                                isListenerEnabled = isListenerEnabled,
                                onGrantAccess = onOpenListenerSettings,
                                onSendTestNotification = onSendTestNotification
                            )
                        }
                    } else {
                        items(notifications, key = { it.id }) { item ->
                            val isSelected = item.id in selectedNotificationIds
                            NotificationCard(
                                item = item,
                                isSpeaking = speakingNotificationId == item.id,
                                selectionMode = selectionMode,
                                isSelected = isSelected,
                                onClick = {
                                    if (selectionMode) {
                                        selectedNotificationIds = if (isSelected) {
                                            selectedNotificationIds - item.id
                                        } else {
                                            selectedNotificationIds + item.id
                                        }
                                    } else {
                                        if (!item.isRead) onMarkRead(item.id)
                                        inspectedNotification = item
                                    }
                                },
                                onLongClick = {
                                    if (!selectionMode) {
                                        selectionMode = true
                                        selectedNotificationIds = setOf(item.id)
                                    } else {
                                        selectedNotificationIds = if (isSelected) {
                                            selectedNotificationIds - item.id
                                        } else {
                                            selectedNotificationIds + item.id
                                        }
                                    }
                                },
                                onCopyOtp = { code ->
                                    copyToClipboard(context, "OTP", code)
                                    onShowMessage(s.inboxCopiedOtp(code))
                                },
                                onToggleSpeak = { onToggleSpeak(item) },
                                onToggleStar = { onToggleStar(item) }
                            )
                        }
                    }
                }
            }
        }
    }

    pendingDeleteTargets?.let { targets ->
        val unreadCount = targets.count { !it.isRead }
        val targetIds = targets.map { it.id }
        BulkDeleteConfirmDialog(
            totalCount = targets.size,
            unreadCount = unreadCount,
            onDismiss = {
                pendingDeleteTargets = null
                pendingClearAllArchive = false
            },
            onDeleteOnlyRead = {
                if (pendingClearAllArchive) {
                    onDeleteReadOnly(null)
                } else {
                    onDeleteReadOnly(targetIds)
                }
                pendingDeleteTargets = null
                pendingClearAllArchive = false
                selectionMode = false
                selectedNotificationIds = emptySet()
            },
            onDeleteAll = {
                if (pendingClearAllArchive) {
                    onClearAllNotifications()
                } else {
                    onDeleteNotificationsByIds(targetIds)
                }
                pendingDeleteTargets = null
                pendingClearAllArchive = false
                selectionMode = false
                selectedNotificationIds = emptySet()
            }
        )
    }

    inspectedNotification?.let { selected ->
        val latestState = allNotifications.find { it.id == selected.id } ?: selected
        NotificationDetailBottomSheet(
            notification = latestState,
            isSpeaking = speakingNotificationId == latestState.id,
            onDismiss = { inspectedNotification = null },
            onCopyAll = {
                copyToClipboard(context, latestState.title, "${latestState.title}\n${latestState.content}")
                onShowMessage(s.inboxCopied)
            },
            onCopyOtp = { otp ->
                copyToClipboard(context, "OTP", otp)
                onShowMessage(s.inboxCopiedOtp(otp))
            },
            onShare = {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, latestState.title)
                    putExtra(
                        Intent.EXTRA_TEXT,
                        "[${latestState.appName}] ${latestState.title}\n${latestState.content}"
                    )
                }
                context.startActivity(Intent.createChooser(shareIntent, s.inboxShareTitle))
            },
            onToggleSpeak = { onToggleSpeak(latestState) },
            onToggleStar = { onToggleStar(latestState) },
            onToggleHidden = { onToggleHidden(latestState) },
            onDelete = {
                onDeleteNotification(latestState.id)
                inspectedNotification = null
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppInboxGroupCard(
    group: AppInboxGroup,
    selectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val s = LocalAppStrings.current
    val bgColor = if (isSelected) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
    } else {
        MaterialTheme.colorScheme.surfaceContainerLowest
    }
    val borderColor = when {
        isSelected -> MaterialTheme.colorScheme.primary
        group.hasHighlighted -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f)
        group.unreadCount > 0 -> MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
        else -> MaterialTheme.colorScheme.outlineVariant
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("app_inbox_group_${group.packageName}"),
        shape = MaterialTheme.shapes.medium,
        color = bgColor,
        border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selectionMode) {
                Icon(
                    imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .padding(end = 10.dp)
                        .size(22.dp)
                )
            }

            AppIconAvatar(
                packageName = group.packageName,
                appName = group.appName,
                size = 48.dp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = group.appName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (group.unreadCount > 0) FontWeight.Bold else FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = formatRelativeTimestamp(group.latestTimestamp, s),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = s.inboxThreadsSummary(group.threads.size, group.totalCount),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                val preview = if (group.latestThreadTitle.isNotBlank() &&
                    !group.latestThreadTitle.equals(group.appName, ignoreCase = true)
                ) {
                    "${group.latestThreadTitle}: ${group.latestPreview}"
                } else {
                    group.latestPreview
                }
                Text(
                    text = preview,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = if (group.unreadCount > 0) FontWeight.Medium else FontWeight.Normal,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (group.unreadCount > 0) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    Text(
                        text = if (group.unreadCount > 0) "${group.unreadCount}" else "${group.totalCount}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (group.unreadCount > 0) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                    )
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppThreadsLevelView(
    appGroup: AppInboxGroup,
    allNotifications: List<NotificationEntity>,
    onBack: () -> Unit,
    onOpenThread: (String) -> Unit,
    onRequestBulkDelete: (List<NotificationEntity>) -> Unit,
    modifier: Modifier = Modifier
) {
    val s = LocalAppStrings.current
    var selectionMode by remember(appGroup.packageName) { mutableStateOf(false) }
    var selectedIds by remember(appGroup.packageName) { mutableStateOf(emptySet<Long>()) }

    BackHandler {
        if (selectionMode) {
            selectionMode = false
            selectedIds = emptySet()
        } else {
            onBack()
        }
    }

    val appNotificationEntities = remember(allNotifications, appGroup.notificationIds) {
        val idSet = appGroup.notificationIds.toSet()
        allNotifications.filter { it.id in idSet }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        if (selectionMode) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        selectionMode = false
                        selectedIds = emptySet()
                    }) {
                        Icon(Icons.Filled.Close, contentDescription = s.close)
                    }
                    Text(
                        text = s.inboxSelectedCount(selectedIds.size),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    val allSelected = appGroup.notificationIds.isNotEmpty() &&
                        selectedIds.containsAll(appGroup.notificationIds)
                    IconButton(onClick = {
                        selectedIds = if (allSelected) emptySet() else appGroup.notificationIds.toSet()
                    }) {
                        Icon(
                            imageVector = Icons.Filled.SelectAll,
                            contentDescription = if (allSelected) s.inboxDeselectAll else s.inboxSelectAll
                        )
                    }
                    IconButton(
                        enabled = selectedIds.isNotEmpty(),
                        onClick = {
                            val targets = appNotificationEntities.filter { it.id in selectedIds }
                            if (targets.isNotEmpty()) {
                                onRequestBulkDelete(targets)
                                selectionMode = false
                                selectedIds = emptySet()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Delete,
                            contentDescription = s.inboxDeleteSelected,
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        } else {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceContainerLowest,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("app_group_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = s.back)
                    }
                    AppIconAvatar(
                        packageName = appGroup.packageName,
                        appName = appGroup.appName,
                        size = 40.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = appGroup.appName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = s.inboxThreadsSummary(appGroup.threads.size, appGroup.totalCount),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = {
                            selectionMode = true
                            selectedIds = emptySet()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Checklist,
                            contentDescription = s.inboxSelectMode,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = {
                            if (appNotificationEntities.isNotEmpty()) {
                                onRequestBulkDelete(appNotificationEntities)
                            }
                        },
                        modifier = Modifier.testTag("app_group_delete_all_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteSweep,
                            contentDescription = s.delete,
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(appGroup.threads, key = { it.threadKey }) { thread ->
                val isThreadSelected = thread.notificationIds.isNotEmpty() &&
                    thread.notificationIds.all { it in selectedIds }
                ConversationThreadCard(
                    thread = thread,
                    selectionMode = selectionMode,
                    isSelected = isThreadSelected,
                    onClick = {
                        if (selectionMode) {
                            selectedIds = if (isThreadSelected) {
                                selectedIds - thread.notificationIds.toSet()
                            } else {
                                selectedIds + thread.notificationIds
                            }
                        } else {
                            onOpenThread(thread.threadKey)
                        }
                    },
                    onLongClick = {
                        if (!selectionMode) {
                            selectionMode = true
                            selectedIds = thread.notificationIds.toSet()
                        } else {
                            selectedIds = if (isThreadSelected) {
                                selectedIds - thread.notificationIds.toSet()
                            } else {
                                selectedIds + thread.notificationIds
                            }
                        }
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ConversationThreadCard(
    thread: ConversationThreadSummary,
    selectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val s = LocalAppStrings.current
    val bgColor = if (isSelected) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
    } else {
        MaterialTheme.colorScheme.surfaceContainerLowest
    }
    val borderColor = when {
        isSelected -> MaterialTheme.colorScheme.primary
        thread.hasHighlighted -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f)
        thread.unreadCount > 0 -> MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
        else -> MaterialTheme.colorScheme.outlineVariant
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("thread_card_${thread.threadKey.hashCode()}"),
        shape = MaterialTheme.shapes.medium,
        color = bgColor,
        border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selectionMode) {
                Icon(
                    imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .padding(end = 10.dp)
                        .size(22.dp)
                )
            }

            AppIconAvatar(
                packageName = thread.packageName,
                appName = thread.appName,
                size = 46.dp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = thread.threadTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (thread.unreadCount > 0) FontWeight.Bold else FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = formatRelativeTimestamp(thread.latestTimestamp, s),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = thread.categoryLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                val preview = if (thread.latestSender.isNotBlank()) {
                    "${thread.latestSender}: ${thread.latestContent}"
                } else {
                    thread.latestContent
                }
                Text(
                    text = preview,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = if (thread.unreadCount > 0) FontWeight.Medium else FontWeight.Normal,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (thread.unreadCount > 0) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    Text(
                        text = if (thread.unreadCount > 0) "${thread.unreadCount}" else "${thread.totalCount}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (thread.unreadCount > 0) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                    )
                }
                if (thread.unreadCount > 0 && thread.totalCount > thread.unreadCount) {
                    Text(
                        text = "/${thread.totalCount}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NotificationCard(
    item: NotificationEntity,
    isSpeaking: Boolean,
    selectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onCopyOtp: (String) -> Unit,
    onToggleSpeak: () -> Unit,
    onToggleStar: () -> Unit
) {
    val s = LocalAppStrings.current
    val bgColor = if (isSelected) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
    } else {
        MaterialTheme.colorScheme.surfaceContainerLowest
    }
    val borderColor = when {
        isSelected -> MaterialTheme.colorScheme.primary
        item.isHighlighted -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.55f)
        !item.isRead -> MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
        else -> MaterialTheme.colorScheme.outlineVariant
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("notification_card_${item.id}"),
        shape = MaterialTheme.shapes.medium,
        color = bgColor,
        border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                if (selectionMode) {
                    Icon(
                        imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                        contentDescription = null,
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .padding(top = 8.dp, end = 10.dp)
                            .size(22.dp)
                    )
                }
                AppIconAvatar(
                    packageName = item.packageName,
                    appName = item.appName,
                    size = 40.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!item.isRead) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text(
                            text = item.appName,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = formatRelativeTimestamp(item.timestamp, s),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (!item.isRead) FontWeight.Bold else FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (item.content.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = item.content,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (item.matchedKeywords.isNotBlank() || !item.detectedOtp.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    item.detectedOtp?.let { otp ->
                        OtpCopyPill(otpCode = otp, onCopy = { onCopyOtp(otp) })
                    }
                    if (item.matchedKeywords.isNotBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "#${item.matchedKeywords}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            if (!selectionMode) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onToggleSpeak,
                        modifier = Modifier.testTag("speak_notification_${item.id}")
                    ) {
                        Icon(
                            imageVector = if (isSpeaking) Icons.Filled.StopCircle else Icons.Filled.VolumeUp,
                            contentDescription = if (isSpeaking) s.stopSpeak else s.speak,
                            tint = if (isSpeaking) MaterialTheme.colorScheme.tertiary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = onToggleStar,
                        modifier = Modifier.testTag("star_notification_${item.id}")
                    ) {
                        Icon(
                            imageVector = if (item.isStarred) Icons.Filled.Star else Icons.Outlined.StarOutline,
                            contentDescription = s.inboxPinStar,
                            tint = if (item.isStarred) MaterialTheme.colorScheme.secondary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyInboxCard(
    isListenerEnabled: Boolean,
    onGrantAccess: () -> Unit,
    onSendTestNotification: () -> Unit
) {
    val s = LocalAppStrings.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_inbox_1795064150853),
                contentDescription = s.inboxEmptyTitle,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(176.dp)
                    .clip(MaterialTheme.shapes.medium)
            )
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = s.inboxEmptyTitle,
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = s.inboxEmptyDesc,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            if (!isListenerEnabled) {
                Button(
                    onClick = onGrantAccess,
                    modifier = Modifier.testTag("empty_grant_listener_button")
                ) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(s.grantAccess)
                }
            } else {
                OutlinedButton(
                    onClick = onSendTestNotification,
                    modifier = Modifier.testTag("empty_send_test_notification_button")
                ) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(s.sendTest)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotificationDetailBottomSheet(
    notification: NotificationEntity,
    isSpeaking: Boolean,
    onDismiss: () -> Unit,
    onCopyAll: () -> Unit,
    onCopyOtp: (String) -> Unit,
    onShare: () -> Unit,
    onToggleSpeak: () -> Unit,
    onToggleStar: () -> Unit,
    onToggleHidden: () -> Unit,
    onDelete: () -> Unit
) {
    val s = LocalAppStrings.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIconAvatar(
                    packageName = notification.packageName,
                    appName = notification.appName,
                    size = 46.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = notification.appName,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = formatFullTimestamp(notification.timestamp),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onToggleStar) {
                    Icon(
                        imageVector = if (notification.isStarred) Icons.Filled.Star else Icons.Outlined.StarOutline,
                        contentDescription = s.inboxPinStar,
                        tint = if (notification.isStarred) MaterialTheme.colorScheme.secondary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = notification.title,
                style = MaterialTheme.typography.titleLarge
            )
            if (notification.subText.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = notification.subText,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            if (notification.content.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = notification.content,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            if (!notification.detectedOtp.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(14.dp))
                OtpCopyPill(
                    otpCode = notification.detectedOtp,
                    onCopy = { onCopyOtp(notification.detectedOtp) }
                )
            }

            if (notification.matchedKeywords.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = s.inboxMatchedKeywords(notification.matchedKeywords),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onToggleSpeak,
                    modifier = Modifier.weight(1f).testTag("detail_speak_button")
                ) {
                    Icon(
                        imageVector = if (isSpeaking) Icons.Filled.StopCircle else Icons.Filled.VolumeUp,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isSpeaking) s.stopSpeak else s.speak)
                }
                OutlinedButton(
                    onClick = onCopyAll,
                    modifier = Modifier.weight(1f).testTag("detail_copy_button")
                ) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(s.copy)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onToggleHidden,
                    modifier = Modifier.weight(1f).testTag("detail_hide_button")
                ) {
                    Icon(
                        imageVector = if (notification.isHidden) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (notification.isHidden) s.inboxShowAgain else s.inboxHidePrivate)
                }
                OutlinedButton(
                    onClick = onShare,
                    modifier = Modifier.testTag("detail_share_button")
                ) {
                    Icon(Icons.Filled.Share, contentDescription = s.share)
                }
                OutlinedButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("detail_delete_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = s.delete,
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}
