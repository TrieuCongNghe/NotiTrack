package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.NotificationEntity
import com.example.engine.ConversationGrouper
import com.example.engine.ConversationThreadSummary
import com.example.ui.components.AppIconAvatar
import com.example.ui.components.OtpCopyPill
import com.example.ui.components.formatClockTime
import com.example.ui.i18n.LocalAppStrings

@Composable
fun BulkDeleteConfirmDialog(
    totalCount: Int,
    unreadCount: Int,
    onDismiss: () -> Unit,
    onDeleteOnlyRead: (() -> Unit)?,
    onDeleteAll: () -> Unit
) {
    val s = LocalAppStrings.current
    val readCount = (totalCount - unreadCount).coerceAtLeast(0)

    if (unreadCount > 0) {
        AlertDialog(
            onDismissRequest = onDismiss,
            icon = {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.errorContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.WarningAmber,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            title = {
                Text(
                    text = s.inboxUnreadWarnTitle,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = s.inboxUnreadWarnBody(totalCount, unreadCount),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (readCount > 0 && onDeleteOnlyRead != null) {
                        FilledTonalButton(
                            onClick = onDeleteOnlyRead,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("delete_only_read_button")
                        ) {
                            Text(s.inboxDeleteOnlyRead(readCount))
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = onDeleteAll,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    ),
                    modifier = Modifier.testTag("confirm_force_delete_all_button")
                ) {
                    Text(s.inboxDeleteForceAll)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("cancel_delete_dialog_button")
                ) {
                    Text(s.cancel)
                }
            }
        )
    } else {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(s.inboxDeleteConfirmTitle) },
            text = { Text(s.inboxDeleteConfirmBody(totalCount)) },
            confirmButton = {
                Button(
                    onClick = onDeleteAll,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    ),
                    modifier = Modifier.testTag("confirm_delete_button")
                ) {
                    Text(s.delete)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("cancel_delete_dialog_button")
                ) {
                    Text(s.cancel)
                }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatTimelineView(
    thread: ConversationThreadSummary,
    messages: List<NotificationEntity>,
    speakingNotificationId: Long?,
    onBack: () -> Unit,
    onInspectNotification: (NotificationEntity) -> Unit,
    onCopyOtp: (String) -> Unit,
    onToggleSpeak: (NotificationEntity) -> Unit,
    onToggleStar: (NotificationEntity) -> Unit,
    onRequestBulkDelete: (List<NotificationEntity>) -> Unit,
    modifier: Modifier = Modifier
) {
    val s = LocalAppStrings.current
    var selectionMode by remember(thread.threadKey) { mutableStateOf(false) }
    var selectedIds by remember(thread.threadKey) { mutableStateOf(emptySet<Long>()) }
    val listState = rememberLazyListState()

    LaunchedEffect(thread.threadKey, messages.size) {
        if (messages.isNotEmpty()) {
            listState.scrollToItem(messages.lastIndex)
        }
    }

    BackHandler {
        if (selectionMode) {
            selectionMode = false
            selectedIds = emptySet()
        } else {
            onBack()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        if (selectionMode) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.medium)
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f))
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        selectionMode = false
                        selectedIds = emptySet()
                    },
                    modifier = Modifier.testTag("thread_exit_select_mode")
                ) {
                    Icon(Icons.Filled.Close, contentDescription = s.close)
                }
                Text(
                    text = s.inboxSelectedCount(selectedIds.size),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = {
                        selectedIds = if (selectedIds.size == messages.size) {
                            emptySet()
                        } else {
                            messages.map { it.id }.toSet()
                        }
                    },
                    modifier = Modifier.testTag("thread_select_all_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.SelectAll,
                        contentDescription = if (selectedIds.size == messages.size) s.inboxDeselectAll else s.inboxSelectAll
                    )
                }
                IconButton(
                    onClick = {
                        val targets = messages.filter { it.id in selectedIds }
                        if (targets.isNotEmpty()) {
                            onRequestBulkDelete(targets)
                            selectionMode = false
                            selectedIds = emptySet()
                        }
                    },
                    enabled = selectedIds.isNotEmpty(),
                    modifier = Modifier.testTag("thread_delete_selected_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = s.inboxDeleteSelected,
                        tint = if (selectedIds.isNotEmpty()) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("back_from_chat_thread")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = s.back
                    )
                }
                AppIconAvatar(
                    packageName = thread.packageName,
                    appName = thread.appName,
                    size = 38.dp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = thread.threadTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${thread.categoryLabel} • ${s.inboxSavedCount(messages.size)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(
                    onClick = {
                        selectionMode = true
                        selectedIds = emptySet()
                    },
                    modifier = Modifier.testTag("thread_enter_select_mode")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Checklist,
                        contentDescription = s.inboxSelectMode,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(
                    onClick = { onRequestBulkDelete(messages) },
                    modifier = Modifier.testTag("thread_delete_all_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteSweep,
                        contentDescription = s.inboxDeleteAll,
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(messages, key = { _, item -> item.id }) { index, item ->
                val currentDateLabel = ConversationGrouper.formatDateDivider(
                    timestamp = item.timestamp,
                    todayLabel = s.today,
                    yesterdayLabel = s.yesterday
                )
                val prevDateLabel = if (index > 0) {
                    ConversationGrouper.formatDateDivider(
                        timestamp = messages[index - 1].timestamp,
                        todayLabel = s.today,
                        yesterdayLabel = s.yesterday
                    )
                } else null

                if (currentDateLabel != prevDateLabel) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceContainerHigh,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = currentDateLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                val isSelected = item.id in selectedIds
                val showSenderHeader = item.title.isNotBlank() &&
                    !item.title.equals(thread.threadTitle, ignoreCase = true)

                ChatMessageBubble(
                    item = item,
                    showSenderHeader = showSenderHeader,
                    isSpeaking = speakingNotificationId == item.id,
                    selectionMode = selectionMode,
                    isSelected = isSelected,
                    onClick = {
                        if (selectionMode) {
                            selectedIds = if (isSelected) selectedIds - item.id else selectedIds + item.id
                        } else {
                            onInspectNotification(item)
                        }
                    },
                    onLongClick = {
                        if (!selectionMode) {
                            selectionMode = true
                            selectedIds = setOf(item.id)
                        } else {
                            selectedIds = if (isSelected) selectedIds - item.id else selectedIds + item.id
                        }
                    },
                    onCopyOtp = onCopyOtp,
                    onToggleSpeak = { onToggleSpeak(item) },
                    onToggleStar = { onToggleStar(item) }
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatMessageBubble(
    item: NotificationEntity,
    showSenderHeader: Boolean,
    isSpeaking: Boolean,
    selectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onCopyOtp: (String) -> Unit,
    onToggleSpeak: () -> Unit,
    onToggleStar: () -> Unit
) {
    val s = LocalAppStrings.current
    val bubbleShape = RoundedCornerShape(
        topStart = 4.dp,
        topEnd = 18.dp,
        bottomEnd = 18.dp,
        bottomStart = 18.dp
    )
    val containerColor = when {
        isSelected -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)
        item.isHighlighted -> MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f)
        else -> MaterialTheme.colorScheme.surfaceContainerLowest
    }
    val borderColor = when {
        isSelected -> MaterialTheme.colorScheme.primary
        item.isHighlighted -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.55f)
        else -> MaterialTheme.colorScheme.outlineVariant
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.Start
    ) {
        if (selectionMode) {
            Icon(
                imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .padding(top = 10.dp, end = 8.dp)
                    .size(22.dp)
            )
        }

        Surface(
            modifier = Modifier
                .widthIn(max = 520.dp)
                .fillMaxWidth(0.94f)
                .clip(bubbleShape)
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = onLongClick
                )
                .testTag("chat_bubble_${item.id}"),
            shape = bubbleShape,
            color = containerColor,
            border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor)
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                if (showSenderHeader) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                }

                Text(
                    text = item.content.ifBlank { item.title },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (!item.detectedOtp.isNullOrBlank() || item.matchedKeywords.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        item.detectedOtp?.let { otp ->
                            OtpCopyPill(otpCode = otp, onCopy = { onCopyOtp(otp) })
                        }
                        if (item.matchedKeywords.isNotBlank()) {
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "#${item.matchedKeywords}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = formatClockTime(item.timestamp),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = if (item.isRead) Icons.Filled.DoneAll else Icons.Filled.Done,
                        contentDescription = null,
                        tint = if (item.isRead) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    IconButton(
                        onClick = onToggleSpeak,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("chat_speak_${item.id}")
                    ) {
                        Icon(
                            imageVector = if (isSpeaking) Icons.Filled.StopCircle else Icons.Filled.VolumeUp,
                            contentDescription = if (isSpeaking) s.stopSpeak else s.speak,
                            tint = if (isSpeaking) MaterialTheme.colorScheme.tertiary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onToggleStar,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("chat_star_${item.id}")
                    ) {
                        Icon(
                            imageVector = if (item.isStarred) Icons.Filled.Star else Icons.Outlined.StarOutline,
                            contentDescription = s.inboxPinStar,
                            tint = if (item.isStarred) MaterialTheme.colorScheme.secondary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
