package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppRuleEntity
import com.example.data.model.KeywordAction
import com.example.data.model.KeywordRuleEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.TtsNumberReadMode
import com.example.data.prefs.KeepAliveNotifTheme
import com.example.data.prefs.NotiTrackSettings
import com.example.data.repository.NotiTrackRepository
import com.example.engine.AppInboxGroup
import com.example.engine.BatteryOptimizationHelper
import com.example.engine.ConversationGrouper
import com.example.engine.ConversationThreadSummary
import com.example.engine.NotificationSpeaker
import com.example.engine.TtsVolumeConfig
import com.example.service.KeepAliveService
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.stringsFor
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class NotiTrackTab(val route: String) {
    INBOX("inbox"),
    APPS("apps"),
    FILTERS("filters"),
    SETTINGS("settings")
}

enum class InboxFilter(val labelVi: String) {
    ALL("Tất cả"),
    UNREAD("Chưa đọc"),
    STARRED("Đã ghim"),
    HIGHLIGHTED("Từ khóa ưu tiên"),
    HIDDEN("Nhạy cảm / Đã ẩn")
}

enum class AppsFilter(val labelVi: String) {
    ALL("Tất cả"),
    CAPTURING("Đang ghi nhận"),
    TTS_ACTIVE("Đang đọc to"),
    AUTO_DISMISS("Ẩn thanh trạng thái")
}

data class KeywordPreset(
    val titleVi: String,
    val keywords: String,
    val action: KeywordAction
)

class NotiTrackViewModel(
    private val appContext: Context,
    private val repository: NotiTrackRepository,
    private val speaker: NotificationSpeaker
) : ViewModel() {

    val settings: StateFlow<NotiTrackSettings> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), NotiTrackSettings())

    val allNotifications: StateFlow<List<NotificationEntity>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val appRules: StateFlow<List<AppRuleEntity>> = repository.allAppRules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val keywordRules: StateFlow<List<KeywordRuleEntity>> = repository.allKeywordRules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val speakingNotificationId: StateFlow<Long?> = speaker.speakingNotificationId

    private val _currentTab = MutableStateFlow(NotiTrackTab.INBOX)
    val currentTab: StateFlow<NotiTrackTab> = _currentTab.asStateFlow()

    private val _isListenerEnabled = MutableStateFlow(repository.isNotificationListenerEnabled())
    val isListenerEnabled: StateFlow<Boolean> = _isListenerEnabled.asStateFlow()

    private val _isIgnoringBatteryOptimizations = MutableStateFlow(
        BatteryOptimizationHelper.isIgnoringBatteryOptimizations(appContext)
    )
    val isIgnoringBatteryOptimizations: StateFlow<Boolean> = _isIgnoringBatteryOptimizations.asStateFlow()

    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private var lockInitialized = false
    private var backgroundTimestampMs: Long? = null

    private val _inboxQuery = MutableStateFlow("")
    val inboxQuery: StateFlow<String> = _inboxQuery.asStateFlow()

    private val _inboxFilter = MutableStateFlow(InboxFilter.ALL)
    val inboxFilter: StateFlow<InboxFilter> = _inboxFilter.asStateFlow()

    private val _selectedAppPackage = MutableStateFlow<String?>(null)
    val selectedAppPackage: StateFlow<String?> = _selectedAppPackage.asStateFlow()

    private val _selectedThreadKey = MutableStateFlow<String?>(null)
    val selectedThreadKey: StateFlow<String?> = _selectedThreadKey.asStateFlow()

    private val _appsQuery = MutableStateFlow("")
    val appsQuery: StateFlow<String> = _appsQuery.asStateFlow()

    private val _appsFilter = MutableStateFlow(AppsFilter.ALL)
    val appsFilter: StateFlow<AppsFilter> = _appsFilter.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private fun currentStrings() = stringsFor(settings.value.appLanguage)

    val filteredNotifications: StateFlow<List<NotificationEntity>> = combine(
        allNotifications,
        _inboxQuery,
        _inboxFilter
    ) { items, query, filter ->
        val trimmed = query.trim()
        items.filter { item ->
            val filterMatch = when (filter) {
                InboxFilter.ALL -> !item.isHidden
                InboxFilter.UNREAD -> !item.isRead && !item.isHidden
                InboxFilter.STARRED -> item.isStarred
                InboxFilter.HIGHLIGHTED -> item.isHighlighted
                InboxFilter.HIDDEN -> item.isHidden
            }
            val queryMatch = trimmed.isEmpty() ||
                item.title.contains(trimmed, ignoreCase = true) ||
                item.content.contains(trimmed, ignoreCase = true) ||
                item.appName.contains(trimmed, ignoreCase = true) ||
                item.conversationTitle.contains(trimmed, ignoreCase = true) ||
                item.matchedKeywords.contains(trimmed, ignoreCase = true) ||
                (item.detectedOtp?.contains(trimmed) == true)
            filterMatch && queryMatch
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val appInboxGroups: StateFlow<List<AppInboxGroup>> = combine(
        filteredNotifications
    ) { (matching) ->
        ConversationGrouper.buildAppGroups(matching)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val activeAppGroup: StateFlow<AppInboxGroup?> = combine(
        appInboxGroups,
        _selectedAppPackage
    ) { groups, pkg ->
        if (pkg == null) null else groups.find { it.packageName == pkg }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val conversationThreads: StateFlow<List<ConversationThreadSummary>> = combine(
        filteredNotifications
    ) { (matching) ->
        ConversationGrouper.buildThreads(matching)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val activeThreadSummary: StateFlow<ConversationThreadSummary?> = combine(
        conversationThreads,
        _selectedThreadKey
    ) { threads, key ->
        if (key == null) null else threads.find { it.threadKey == key }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    /**
     * Notifications inside the currently opened conversation thread, ordered chronologically
     * (oldest -> newest) to render as a messaging-app chat timeline.
     */
    val activeThreadNotifications: StateFlow<List<NotificationEntity>> = combine(
        filteredNotifications,
        _selectedThreadKey
    ) { matching, key ->
        if (key == null) emptyList()
        else matching
            .filter { ConversationGrouper.resolveThreadKey(it) == key }
            .sortedBy { it.timestamp }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val filteredAppRules: StateFlow<List<AppRuleEntity>> = combine(
        appRules,
        _appsQuery,
        _appsFilter
    ) { rules, query, filter ->
        val trimmed = query.trim()
        rules.filter { rule ->
            val filterMatch = when (filter) {
                AppsFilter.ALL -> true
                AppsFilter.CAPTURING -> rule.captureEnabled
                AppsFilter.TTS_ACTIVE -> rule.readAloudEnabled
                AppsFilter.AUTO_DISMISS -> rule.autoDismissEnabled
            }
            val queryMatch = trimmed.isEmpty() ||
                rule.appName.contains(trimmed, ignoreCase = true) ||
                rule.packageName.contains(trimmed, ignoreCase = true)
            filterMatch && queryMatch
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        viewModelScope.launch {
            val initialSettings = repository.preferences.getSettingsSnapshot()
            if (initialSettings.isAppLockActive && !lockInitialized) {
                _isLocked.value = true
            }
            lockInitialized = true
            repository.syncInstalledAppRules()
            syncKeepAliveService(initialSettings.keepAliveEnabled)
        }
    }

    fun refreshSystemStatus() {
        val listenerOn = repository.isNotificationListenerEnabled()
        _isListenerEnabled.value = listenerOn
        _isIgnoringBatteryOptimizations.value = BatteryOptimizationHelper.isIgnoringBatteryOptimizations(appContext)
        viewModelScope.launch {
            repository.syncInstalledAppRules()
            val currentSettings = repository.preferences.getSettingsSnapshot()
            if (listenerOn) {
                BatteryOptimizationHelper.requestListenerRebind(appContext)
            }
            syncKeepAliveService(currentSettings.keepAliveEnabled)
        }
    }

    private fun syncKeepAliveService(enabled: Boolean) {
        if (enabled && repository.isNotificationListenerEnabled()) {
            KeepAliveService.start(appContext)
        } else if (!enabled) {
            KeepAliveService.stop(appContext)
        }
    }

    fun setKeepAliveEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setKeepAliveEnabled(enabled)
            if (enabled) {
                KeepAliveService.start(appContext)
                showMessage(currentStrings().msgKeepAliveOn)
            } else {
                KeepAliveService.stop(appContext)
                showMessage(currentStrings().msgKeepAliveOff)
            }
        }
    }

    fun setKeepAliveShowTemp(show: Boolean) {
        viewModelScope.launch { repository.preferences.setKeepAliveShowTemp(show) }
    }

    fun setKeepAliveShowLunar(show: Boolean) {
        viewModelScope.launch { repository.preferences.setKeepAliveShowLunar(show) }
    }

    fun setKeepAliveShowCount(show: Boolean) {
        viewModelScope.launch { repository.preferences.setKeepAliveShowCount(show) }
    }

    fun setKeepAliveShowBattery(show: Boolean) {
        viewModelScope.launch { repository.preferences.setKeepAliveShowBattery(show) }
    }

    fun setKeepAliveTheme(theme: KeepAliveNotifTheme) {
        viewModelScope.launch { repository.preferences.setKeepAliveTheme(theme) }
    }

    fun rebindListenerService() {
        BatteryOptimizationHelper.requestListenerRebind(appContext)
        if (settings.value.keepAliveEnabled && repository.isNotificationListenerEnabled()) {
            KeepAliveService.start(appContext)
        }
        showMessage(currentStrings().msgServiceRebound)
    }

    fun setAppLanguage(language: AppLanguage) {
        viewModelScope.launch {
            repository.preferences.setAppLanguage(language)
            if (settings.value.keepAliveEnabled && repository.isNotificationListenerEnabled()) {
                KeepAliveService.start(appContext)
            }
        }
    }

    fun onAppBackgrounded() {
        backgroundTimestampMs = System.currentTimeMillis()
    }

    fun onAppForegrounded() {
        refreshSystemStatus()
        val bgTime = backgroundTimestampMs ?: return
        backgroundTimestampMs = null
        val currentSettings = settings.value
        if (!currentSettings.isAppLockActive) return
        val elapsedSeconds = (System.currentTimeMillis() - bgTime) / 1000L
        if (elapsedSeconds >= currentSettings.autoLockSeconds) {
            _isLocked.value = true
        }
    }

    fun unlockApp() {
        _isLocked.value = false
    }

    fun lockAppNow() {
        if (settings.value.isAppLockActive) {
            _isLocked.value = true
        } else {
            showMessage(currentStrings().msgNeedLockFirst)
        }
    }

    fun verifyPinAndUnlock(rawPin: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = repository.preferences.verifyPin(rawPin)
            if (ok) {
                _isLocked.value = false
            }
            onResult(ok)
        }
    }

    fun selectTab(tab: NotiTrackTab) {
        _currentTab.value = tab
    }

    fun updateInboxQuery(query: String) {
        _inboxQuery.value = query
    }

    fun selectInboxFilter(filter: InboxFilter) {
        _inboxFilter.value = filter
    }

    fun openAppGroup(packageName: String?) {
        if (packageName == null) {
            _selectedThreadKey.value = null
            _selectedAppPackage.value = null
            return
        }
        _selectedAppPackage.value = packageName
        val group = appInboxGroups.value.find { it.packageName == packageName }
        if (group != null && group.threads.size == 1) {
            openConversationThread(group.threads.first().threadKey)
        } else {
            _selectedThreadKey.value = null
        }
    }

    fun openConversationThread(threadKey: String?) {
        if (threadKey == null) {
            val currentGroup = activeAppGroup.value
            _selectedThreadKey.value = null
            if (currentGroup != null && currentGroup.threads.size <= 1) {
                _selectedAppPackage.value = null
            }
            return
        }
        _selectedThreadKey.value = threadKey
        val unreadIds = allNotifications.value
            .filter { !it.isRead && ConversationGrouper.resolveThreadKey(it) == threadKey }
            .map { it.id }
        if (unreadIds.isNotEmpty()) {
            viewModelScope.launch { repository.markIdsRead(unreadIds) }
        }
    }

    fun setChatTimelineGroupingEnabled(enabled: Boolean) {
        _selectedThreadKey.value = null
        _selectedAppPackage.value = null
        viewModelScope.launch {
            repository.preferences.setChatTimelineGroupingEnabled(enabled)
        }
    }

    fun toggleChatTimelineGrouping() {
        setChatTimelineGroupingEnabled(!settings.value.chatTimelineGroupingEnabled)
    }

    fun markNotificationRead(id: Long) {
        viewModelScope.launch { repository.markRead(id) }
    }

    fun markAllRead() {
        viewModelScope.launch {
            repository.markAllRead()
            showMessage(currentStrings().msgMarkedAllRead)
        }
    }

    fun toggleStar(notification: NotificationEntity) {
        viewModelScope.launch {
            repository.toggleStar(notification.id, !notification.isStarred)
        }
    }

    fun toggleHidden(notification: NotificationEntity) {
        viewModelScope.launch {
            val nextHidden = !notification.isHidden
            repository.toggleHidden(notification.id, nextHidden)
            showMessage(
                if (nextHidden) currentStrings().msgMovedToHidden
                else currentStrings().msgRestoredToMain
            )
        }
    }

    fun deleteNotification(id: Long) {
        viewModelScope.launch {
            if (speakingNotificationId.value == id) speaker.stop()
            repository.deleteNotification(id)
            showMessage(currentStrings().msgDeletedOne)
        }
    }

    fun deleteNotificationsByIds(ids: List<Long>) {
        if (ids.isEmpty()) return
        viewModelScope.launch {
            val speakingId = speakingNotificationId.value
            if (speakingId != null && speakingId in ids) {
                speaker.stop()
            }
            repository.deleteNotificationsByIds(ids)
            val currentThread = _selectedThreadKey.value
            if (currentThread != null) {
                val remaining = activeThreadNotifications.value.count { it.id !in ids }
                if (remaining == 0) {
                    _selectedThreadKey.value = null
                }
            }
            showMessage(
                if (ids.size == 1) currentStrings().msgDeletedOne
                else currentStrings().msgDeletedMany(ids.size)
            )
        }
    }

    fun deleteReadNotificationsOnly(candidateIds: List<Long>? = null) {
        viewModelScope.launch {
            if (candidateIds == null) {
                val readCount = allNotifications.value.count { it.isRead }
                if (readCount > 0) {
                    repository.deleteReadNotifications()
                    showMessage(currentStrings().msgDeletedMany(readCount))
                }
            } else {
                val readIds = allNotifications.value
                    .filter { it.isRead && it.id in candidateIds }
                    .map { it.id }
                if (readIds.isNotEmpty()) {
                    deleteNotificationsByIds(readIds)
                }
            }
        }
    }

    fun toggleSpeakNotification(notification: NotificationEntity) {
        if (speakingNotificationId.value == notification.id) {
            speaker.stop()
            return
        }
        val currentSettings = settings.value
        val rule = appRules.value.find { it.packageName == notification.packageName }
        val useSmartTts = rule?.smartTtsEnabled ?: currentSettings.ttsSmartFilterGlobal
        val hideBalance = rule?.ttsHideBalance ?: currentSettings.ttsHideBalanceGlobal
        val numberReadMode = rule?.resolvedNumberReadMode() ?: TtsNumberReadMode.CONTEXT_AUTO
        val customTemplate = rule?.ttsCustomTemplate.orEmpty()
        val volumeConfig = TtsVolumeConfig(
            overrideVolume = currentSettings.ttsOverrideVolumeEnabled,
            bypassSilentMode = currentSettings.ttsBypassSilentMode,
            volumePercent = currentSettings.ttsCustomVolumePercent,
            autoBoostVolume = rule?.ttsAutoBoostVolume ?: false
        )
        speaker.speakNotification(
            notificationId = notification.id,
            appName = notification.appName,
            title = notification.title,
            content = notification.content,
            includeAppName = currentSettings.ttsIncludeAppName,
            speechRate = currentSettings.ttsSpeechRate,
            language = currentSettings.appLanguage,
            smartFilterEnabled = useSmartTts,
            hideBalance = hideBalance,
            numberReadMode = numberReadMode,
            customTemplate = customTemplate,
            volumeConfig = volumeConfig,
            flush = true
        )
    }

    fun speakSampleVoice() {
        val currentSettings = settings.value
        val volumeConfig = TtsVolumeConfig(
            overrideVolume = currentSettings.ttsOverrideVolumeEnabled,
            bypassSilentMode = currentSettings.ttsBypassSilentMode,
            volumePercent = currentSettings.ttsCustomVolumePercent,
            autoBoostVolume = false
        )
        speaker.speakSample(
            speechRate = currentSettings.ttsSpeechRate,
            language = currentSettings.appLanguage,
            smartFilterEnabled = currentSettings.ttsSmartFilterGlobal,
            hideBalance = currentSettings.ttsHideBalanceGlobal,
            includeAppName = currentSettings.ttsIncludeAppName,
            volumeConfig = volumeConfig
        )
    }

    fun stopSpeaking() {
        speaker.stop()
    }

    fun updateAppsQuery(query: String) {
        _appsQuery.value = query
    }

    fun selectAppsFilter(filter: AppsFilter) {
        _appsFilter.value = filter
    }

    fun updateAppRule(rule: AppRuleEntity) {
        viewModelScope.launch {
            repository.upsertAppRule(rule)
        }
    }

    fun setCaptureForAllApps(enabled: Boolean) {
        viewModelScope.launch {
            repository.setCaptureForAllApps(enabled)
            showMessage(
                if (enabled) currentStrings().msgEnabledAllApps
                else currentStrings().msgDisabledAllApps
            )
        }
    }

    fun saveKeywordRule(
        existingId: Long?,
        keywords: String,
        action: KeywordAction,
        targetPackage: String?,
        targetAppName: String?,
        isCaseSensitive: Boolean,
        isRegex: Boolean
    ) {
        if (keywords.isBlank()) return
        viewModelScope.launch {
            if (existingId != null) {
                val existing = keywordRules.value.find { it.id == existingId }
                if (existing != null) {
                    repository.updateKeywordRule(
                        existing.copy(
                            keywords = keywords.trim(),
                            action = action,
                            targetPackage = targetPackage,
                            targetAppName = targetAppName,
                            isCaseSensitive = isCaseSensitive,
                            isRegex = isRegex
                        )
                    )
                    showMessage(currentStrings().msgRuleUpdated)
                    return@launch
                }
            }
            repository.addKeywordRule(
                keywords = keywords,
                action = action,
                targetPackage = targetPackage,
                targetAppName = targetAppName,
                isCaseSensitive = isCaseSensitive,
                isRegex = isRegex
            )
            showMessage(currentStrings().msgRuleAdded)
        }
    }

    fun addPresetRule(preset: KeywordPreset) {
        viewModelScope.launch {
            repository.addKeywordRule(
                keywords = preset.keywords,
                action = preset.action,
                targetPackage = null,
                targetAppName = null,
                isCaseSensitive = false,
                isRegex = false
            )
            showMessage(currentStrings().msgPresetAdded(preset.titleVi))
        }
    }

    fun toggleKeywordRule(rule: KeywordRuleEntity, enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleKeywordRule(rule.id, enabled)
        }
    }

    fun deleteKeywordRule(id: Long) {
        viewModelScope.launch {
            repository.deleteKeywordRule(id)
            showMessage(currentStrings().msgRuleDeleted)
        }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setBiometricEnabled(enabled)
            showMessage(
                if (enabled) currentStrings().msgBiometricOn
                else currentStrings().msgBiometricOff
            )
        }
    }

    fun setPin(rawPin: String) {
        viewModelScope.launch {
            repository.preferences.setPin(rawPin)
            showMessage(
                if (rawPin.isBlank()) currentStrings().msgPinCleared
                else currentStrings().msgPinSaved
            )
        }
    }

    fun setFlagSecure(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setFlagSecureEnabled(enabled)
        }
    }

    fun setAutoLockSeconds(seconds: Int) {
        viewModelScope.launch {
            repository.preferences.setAutoLockSeconds(seconds)
        }
    }

    fun setTtsGlobalEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsGlobalEnabled(enabled)
            repository.setReadAloudForAllApps(enabled)
            showMessage(
                if (enabled) currentStrings().msgTtsAllOn
                else currentStrings().msgTtsAllOff
            )
        }
    }

    fun setTtsSpeechRate(rate: Float) {
        viewModelScope.launch {
            repository.preferences.setTtsSpeechRate(rate)
        }
    }

    fun setTtsIncludeAppName(include: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsIncludeAppName(include)
        }
    }

    fun setTtsSmartFilterGlobal(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsSmartFilterGlobal(enabled)
            repository.setSmartTtsForAllApps(enabled)
            showMessage(
                if (enabled) currentStrings().msgSmartTtsAllOn
                else currentStrings().msgSmartTtsAllOff
            )
        }
    }

    fun setTtsHideBalanceGlobal(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsHideBalanceGlobal(enabled)
            repository.setHideBalanceForAllApps(enabled)
            showMessage(
                if (enabled) currentStrings().msgHideBalanceAllOn
                else currentStrings().msgHideBalanceAllOff
            )
        }
    }

    fun setTtsOverrideVolumeEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsOverrideVolumeEnabled(enabled)
        }
    }

    fun setTtsBypassSilentMode(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsBypassSilentMode(enabled)
        }
    }

    fun setTtsCustomVolumePercent(percent: Int) {
        viewModelScope.launch {
            repository.preferences.setTtsCustomVolumePercent(percent)
        }
    }

    fun setCaptureNewAppsByDefault(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setCaptureNewAppsByDefault(enabled)
        }
    }

    fun setRetentionDays(days: Int) {
        viewModelScope.launch {
            repository.preferences.setRetentionDays(days)
            repository.applyRetentionCleanup(days)
            showMessage(
                if (days == 0) currentStrings().msgRetentionNever
                else currentStrings().msgRetentionDays(days)
            )
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            repository.preferences.setThemeMode(mode)
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            speaker.stop()
            repository.clearAllNotifications()
            _selectedThreadKey.value = null
            _selectedAppPackage.value = null
            showMessage(currentStrings().msgClearedAll)
        }
    }

    fun generateExportText(onReady: (String) -> Unit) {
        viewModelScope.launch {
            val content = repository.buildExportText()
            onReady(content)
        }
    }

    fun showMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearMessage() {
        _snackbarMessage.value = null
    }

    class Factory(
        private val appContext: Context,
        private val repository: NotiTrackRepository,
        private val speaker: NotificationSpeaker
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return NotiTrackViewModel(appContext, repository, speaker) as T
        }
    }
}
