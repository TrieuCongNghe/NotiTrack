package com.example.engine

/**
 * Handles:
 * 1. Numeric-only message filtering (separates balance/transaction alerts from promo ads).
 * 2. Interactive highlight template serialization & dynamic extraction for future notifications.
 */
object SmartTtsTemplateEngine {

    private val TOKEN_SPLIT_REGEX = Regex("""[^\s|]+""")
    private val CURRENCY_CUE_REGEX = Regex(
        """(?i)(vnđ|vnd|đồng|\d+\s*đ\b|usd|\$|€|eur|¥|jpy|krw|số\s*dư|so\s*du|\bsd\b|\bgd\b|biến\s*động|chuyển\s*khoản|nhận\s*tiền|thanh\s*toán|rút\s*tiền|tài\s*khoản|\bstk\b|\btk\b|otp|mã\s*xác|credited|debited|balance|transfer|payment)"""
    )
    private val SIGNED_OR_FORMATTED_NUMBER_REGEX = Regex(
        """(?i)[+\-]\s*(?:vnđ|vnd|đ|usd|\$|€|eur|¥|jpy|krw)?\s*\d[\d.,]*|\b\d{1,3}(?:[.,]\d{3})+\b"""
    )
    private val PROMO_CUE_REGEX = Regex(
        """(?i)\b(ưu\s*đãi|khuyến\s*mãi|flash\s*sale|voucher|mã\s*giảm|giảm\s*giá|quà\s*tặng|săn\s*deal|miễn\s*phí\s*vận|freeship|hot\s*deal|sale\s*sốc|hoàn\s*xu|promo|discount|coupon)\b"""
    )
    private val DIGIT_RUN_REGEX = Regex("""\d+""")

    data class TemplateSpan(
        val startIndex: Int,
        val endIndex: Int,
        val leftAnchor: String,
        val rightAnchor: String,
        val sampleText: String
    )

    data class ParsedTemplate(
        val sampleText: String,
        val selectedIndices: List<Int>,
        val spans: List<TemplateSpan>
    )

    /**
     * Returns true when a notification appears to be a numeric/transaction/OTP alert
     * rather than a marketing/promotional message.
     */
    fun passesNumericOnlyFilter(title: String, content: String): Boolean {
        val combined = "$title $content".trim()
        if (combined.isBlank()) return false

        val digitRuns = DIGIT_RUN_REGEX.findAll(combined).map { it.value }.toList()
        if (digitRuns.isEmpty()) return false

        val totalDigits = digitRuns.sumOf { it.length }
        val hasSignedOrThousands = SIGNED_OR_FORMATTED_NUMBER_REGEX.containsMatchIn(combined)
        val hasCurrencyCue = CURRENCY_CUE_REGEX.containsMatchIn(combined)
        val hasPromoCue = PROMO_CUE_REGEX.containsMatchIn(combined)

        // Signed/formatted amounts with banking cue always pass even if promo words appear
        if (hasSignedOrThousands && hasCurrencyCue) return true

        // Pure promo with only small numbers (like "Giảm 50% hôm nay") is filtered out
        if (hasPromoCue && !hasSignedOrThousands && totalDigits < 6) return false

        // Transaction / OTP / numeric-rich alert: >= 4 digits total with currency cue, or >= 2 numeric groups with >= 5 digits
        return (hasCurrencyCue && totalDigits >= 3) ||
            (digitRuns.size >= 2 && totalDigits >= 5) ||
            digitRuns.any { it.length >= 4 }
    }

    fun tokenize(text: String): List<String> {
        return TOKEN_SPLIT_REGEX.findAll(text.trim()).map { it.value }.toList()
    }

    fun buildSerializedTemplate(sampleText: String, selectedIndices: Set<Int>): String {
        val tokens = tokenize(sampleText)
        val sorted = selectedIndices.filter { it in tokens.indices }.sorted()
        if (sorted.isEmpty()) return ""

        val spans = groupContiguousIndices(sorted).map { (start, end) ->
            val left = tokens.getOrNull(start - 1)?.let(::normalizeAnchor).orEmpty()
            val right = tokens.getOrNull(end + 1)?.let(::normalizeAnchor).orEmpty()
            val snippet = tokens.subList(start, end + 1).joinToString(" ")
            TemplateSpan(start, end, left, right, snippet)
        }

        val indicesPart = sorted.joinToString(",")
        val spansPart = spans.joinToString(";;") { span ->
            listOf(
                span.startIndex.toString(),
                span.endIndex.toString(),
                escape(span.leftAnchor),
                escape(span.rightAnchor),
                escape(span.sampleText)
            ).joinToString("::")
        }
        return "v1||$indicesPart||$spansPart||${escape(sampleText)}"
    }

    fun parseTemplate(serialized: String): ParsedTemplate? {
        if (!serialized.startsWith("v1||")) return null
        val parts = serialized.split("||", limit = 4)
        if (parts.size < 4) return null

        val indices = parts[1].split(",").mapNotNull { it.toIntOrNull() }
        if (indices.isEmpty()) return null

        val spans = parts[2].split(";;").mapNotNull { rawSpan ->
            val fields = rawSpan.split("::", limit = 5)
            if (fields.size < 5) return@mapNotNull null
            val start = fields[0].toIntOrNull() ?: return@mapNotNull null
            val end = fields[1].toIntOrNull() ?: return@mapNotNull null
            TemplateSpan(
                startIndex = start,
                endIndex = end,
                leftAnchor = unescape(fields[2]),
                rightAnchor = unescape(fields[3]),
                sampleText = unescape(fields[4])
            )
        }
        if (spans.isEmpty()) return null
        return ParsedTemplate(
            sampleText = unescape(parts[3]),
            selectedIndices = indices,
            spans = spans
        )
    }

    /**
     * Dynamically applies a user-highlighted template to a new incoming notification.
     * Matches static anchors around highlighted slots first, falling back to token positions.
     */
    fun applyTemplate(serializedTemplate: String, incomingText: String): String? {
        val parsed = parseTemplate(serializedTemplate) ?: return null
        val incomingTokens = tokenize(incomingText)
        if (incomingTokens.isEmpty()) return null

        val extractedParts = mutableListOf<String>()
        var searchCursor = 0

        for (span in parsed.spans) {
            val expectedLen = (span.endIndex - span.startIndex + 1).coerceAtLeast(1)
            val matched = extractSpan(incomingTokens, span, expectedLen, searchCursor)
            if (matched != null) {
                val (text, nextCursor) = matched
                if (text.isNotBlank()) {
                    extractedParts.add(text)
                }
                searchCursor = nextCursor
            }
        }

        val result = extractedParts.joinToString(" ").replace(Regex("\\s+"), " ").trim()
        return result.ifBlank { null }
    }

    private fun extractSpan(
        tokens: List<String>,
        span: TemplateSpan,
        expectedLen: Int,
        searchFrom: Int
    ): Pair<String, Int>? {
        val leftAnchor = span.leftAnchor
        val rightAnchor = span.rightAnchor

        // Strategy 1: Match left anchor (and optional right anchor)
        if (leftAnchor.isNotEmpty()) {
            val leftIdx = findAnchorIndex(tokens, leftAnchor, searchFrom)
            if (leftIdx >= 0 && leftIdx + 1 < tokens.size) {
                val start = leftIdx + 1
                val endExclusive = if (rightAnchor.isNotEmpty()) {
                    val rightIdx = findAnchorIndex(tokens, rightAnchor, start)
                    if (rightIdx > start && (rightIdx - start) <= expectedLen + 6) {
                        rightIdx
                    } else {
                        (start + expectedLen).coerceAtMost(tokens.size)
                    }
                } else {
                    (start + expectedLen).coerceAtMost(tokens.size)
                }
                if (endExclusive > start) {
                    return tokens.subList(start, endExclusive).joinToString(" ") to endExclusive
                }
            }
        }

        // Strategy 2: Match right anchor alone
        if (rightAnchor.isNotEmpty()) {
            val rightIdx = findAnchorIndex(tokens, rightAnchor, searchFrom)
            if (rightIdx > 0) {
                val start = (rightIdx - expectedLen).coerceAtLeast(searchFrom)
                if (rightIdx > start) {
                    return tokens.subList(start, rightIdx).joinToString(" ") to rightIdx
                }
            }
        }

        // Strategy 3: Positional fallback when notification structure matches sample
        if (span.startIndex in tokens.indices) {
            val endExclusive = (span.endIndex + 1).coerceAtMost(tokens.size)
            if (endExclusive > span.startIndex) {
                return tokens.subList(span.startIndex, endExclusive).joinToString(" ") to endExclusive
            }
        }

        return null
    }

    private fun findAnchorIndex(tokens: List<String>, anchor: String, fromIndex: Int): Int {
        for (i in fromIndex.coerceAtLeast(0) until tokens.size) {
            if (normalizeAnchor(tokens[i]).equals(anchor, ignoreCase = true)) {
                return i
            }
        }
        return -1
    }

    private fun normalizeAnchor(token: String): String {
        val trimmed = token.trim()
        // Pure dynamic numbers/amounts should not act as fixed text anchors
        if (Regex("""^[+\-]?[\d.,:/%]+$""").matches(trimmed)) return ""
        return trimmed.trim(',', '.', ';', '(', ')', '[', ']')
    }

    private fun groupContiguousIndices(sorted: List<Int>): List<Pair<Int, Int>> {
        val result = mutableListOf<Pair<Int, Int>>()
        var start = sorted.first()
        var prev = start
        for (i in 1 until sorted.size) {
            val cur = sorted[i]
            if (cur == prev + 1) {
                prev = cur
            } else {
                result.add(start to prev)
                start = cur
                prev = cur
            }
        }
        result.add(start to prev)
        return result
    }

    private fun escape(value: String): String = value
        .replace("%", "%25")
        .replace("|", "%7C")
        .replace(";", "%3B")
        .replace(":", "%3A")

    private fun unescape(value: String): String = value
        .replace("%3A", ":")
        .replace("%3B", ";")
        .replace("%7C", "|")
        .replace("%25", "%")
}
