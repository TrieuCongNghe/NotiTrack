package com.example.engine

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.model.TtsNumberReadMode
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.stringsFor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID
import kotlin.math.roundToInt

data class TtsVolumeConfig(
    val overrideVolume: Boolean = false,
    val bypassSilentMode: Boolean = false,
    val volumePercent: Int = 85,
    val autoBoostVolume: Boolean = false
)

class NotificationSpeaker(context: Context) {

    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var tts: TextToSpeech? = null
    private var isReady: Boolean = false
    private var pendingSpeech: PendingUtterance? = null

    @Volatile
    private var savedStreamType: Int? = null

    @Volatile
    private var savedStreamVolume: Int? = null

    private data class PendingUtterance(
        val text: String,
        val rate: Float,
        val notificationId: Long?,
        val language: AppLanguage,
        val volumeConfig: TtsVolumeConfig
    )

    private val _speakingNotificationId = MutableStateFlow<Long?>(null)
    val speakingNotificationId: StateFlow<Long?> = _speakingNotificationId.asStateFlow()

    init {
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                applyLocale(AppLanguage.VIETNAMESE)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) {
                        restoreVolumeIfNeeded()
                        _speakingNotificationId.value = null
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        restoreVolumeIfNeeded()
                        _speakingNotificationId.value = null
                    }
                    override fun onError(utteranceId: String?, errorCode: Int) {
                        restoreVolumeIfNeeded()
                        _speakingNotificationId.value = null
                    }
                })
                isReady = true
                pendingSpeech?.let { pending ->
                    pendingSpeech = null
                    speakInternal(
                        text = pending.text,
                        rate = pending.rate,
                        notificationId = pending.notificationId,
                        language = pending.language,
                        volumeConfig = pending.volumeConfig,
                        flush = true
                    )
                }
            }
        }
    }

    private fun applyLocale(language: AppLanguage) {
        val targetLocale = language.toLocale()
        val availability = tts?.isLanguageAvailable(targetLocale) ?: TextToSpeech.LANG_NOT_SUPPORTED
        if (availability >= TextToSpeech.LANG_AVAILABLE) {
            tts?.language = targetLocale
        } else {
            tts?.language = Locale.getDefault()
        }
    }

    fun speakNotification(
        notificationId: Long?,
        appName: String,
        title: String,
        content: String,
        includeAppName: Boolean,
        speechRate: Float,
        language: AppLanguage = AppLanguage.VIETNAMESE,
        smartFilterEnabled: Boolean = true,
        hideBalance: Boolean = true,
        numberReadMode: TtsNumberReadMode = TtsNumberReadMode.CONTEXT_AUTO,
        customTemplate: String = "",
        volumeConfig: TtsVolumeConfig = TtsVolumeConfig(),
        flush: Boolean = false
    ) {
        val text = SmartTtsFormatter.formatForSpeech(
            appName = appName,
            title = title,
            content = content,
            includeAppName = includeAppName,
            smartFilterEnabled = smartFilterEnabled,
            hideBalance = hideBalance,
            language = language,
            numberReadMode = numberReadMode,
            customTemplate = customTemplate
        )
        if (text.isBlank()) return

        if (!isReady) {
            pendingSpeech = PendingUtterance(text, speechRate, notificationId, language, volumeConfig)
            return
        }
        speakInternal(text, speechRate, notificationId, language, volumeConfig, flush)
    }

    fun speakSample(
        speechRate: Float,
        language: AppLanguage = AppLanguage.VIETNAMESE,
        smartFilterEnabled: Boolean = true,
        hideBalance: Boolean = true,
        includeAppName: Boolean = true,
        volumeConfig: TtsVolumeConfig = TtsVolumeConfig()
    ) {
        val sampleRawTitle = if (language.resolved() == AppLanguage.VIETNAMESE) {
            "Biến động số dư"
        } else {
            "Balance Alert"
        }
        val sampleRawContent = if (language.resolved() == AppLanguage.VIETNAMESE) {
            "TK 003456 GD: +50,000 VND luc 14:25 19/11/2026. SD: 15,420,000 VND. Ma xac thuc 9999. ND: Chuyen tien cafe FT263239182736"
        } else {
            "Acct **3456 Credited +$50.00 at 14:25. Balance: $1,540.00. Code 9999. Ref: FT263239182736 Coffee transfer"
        }
        val text = if (smartFilterEnabled || hideBalance) {
            SmartTtsFormatter.formatForSpeech(
                appName = "MB Bank",
                title = sampleRawTitle,
                content = sampleRawContent,
                includeAppName = includeAppName,
                smartFilterEnabled = smartFilterEnabled,
                hideBalance = hideBalance,
                language = language
            )
        } else {
            stringsFor(language).ttsSampleSentence
        }
        if (!isReady) {
            pendingSpeech = PendingUtterance(text, speechRate, -1L, language, volumeConfig)
            return
        }
        speakInternal(text, speechRate, -1L, language, volumeConfig, flush = true)
    }

    private fun speakInternal(
        text: String,
        rate: Float,
        notificationId: Long?,
        language: AppLanguage,
        volumeConfig: TtsVolumeConfig,
        flush: Boolean
    ) {
        applyLocale(language)
        tts?.setSpeechRate(rate.coerceIn(0.6f, 1.8f))

        val useAlarmStream = volumeConfig.bypassSilentMode
        val shouldOverrideStream = volumeConfig.overrideVolume || volumeConfig.autoBoostVolume || useAlarmStream
        val streamType = if (useAlarmStream) AudioManager.STREAM_ALARM else AudioManager.STREAM_MUSIC

        val usage = if (useAlarmStream) {
            AudioAttributes.USAGE_ALARM
        } else {
            AudioAttributes.USAGE_MEDIA
        }
        tts?.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(usage)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )

        val effectivePercent = when {
            volumeConfig.autoBoostVolume -> maxOf(volumeConfig.volumePercent, 95)
            volumeConfig.overrideVolume || useAlarmStream -> volumeConfig.volumePercent
            else -> 100
        }.coerceIn(10, 100)

        if (shouldOverrideStream) {
            applyTemporaryStreamVolume(streamType, effectivePercent)
        }

        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, streamType)
            putFloat(
                TextToSpeech.Engine.KEY_PARAM_VOLUME,
                if (shouldOverrideStream) (effectivePercent / 100f).coerceIn(0.2f, 1.0f) else 1.0f
            )
        }

        val queueMode = if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        val utteranceId = "notitrack_${notificationId ?: UUID.randomUUID()}"
        _speakingNotificationId.value = notificationId
        tts?.speak(text, queueMode, params, utteranceId)
    }

    private fun applyTemporaryStreamVolume(streamType: Int, targetPercent: Int) {
        runCatching {
            val maxVol = audioManager.getStreamMaxVolume(streamType).coerceAtLeast(1)
            val currentVol = audioManager.getStreamVolume(streamType)
            if (savedStreamType == null) {
                savedStreamType = streamType
                savedStreamVolume = currentVol
            }
            val desiredVol = ((maxVol * targetPercent) / 100f).roundToInt().coerceIn(1, maxVol)
            if (desiredVol != currentVol) {
                audioManager.setStreamVolume(streamType, desiredVol, 0)
            }
        }
    }

    private fun restoreVolumeIfNeeded() {
        val stream = savedStreamType ?: return
        val prevVol = savedStreamVolume ?: return
        savedStreamType = null
        savedStreamVolume = null
        runCatching {
            audioManager.setStreamVolume(stream, prevVol, 0)
        }
    }

    fun stop() {
        tts?.stop()
        restoreVolumeIfNeeded()
        _speakingNotificationId.value = null
    }

    fun shutdown() {
        tts?.stop()
        restoreVolumeIfNeeded()
        tts?.shutdown()
        tts = null
        isReady = false
        _speakingNotificationId.value = null
    }
}
