# NotiTrack — Kế hoạch Nâng cấp Ngôn ngữ, Giao diện Tối, Thanh thông báo & Chống trộm

Bản nâng cấp toàn diện này tinh chỉnh lại toàn bộ câu từ thông báo theo hướng tự nhiên chuyên nghiệp với 20 ngôn ngữ phổ biến, sửa dứt điểm lỗi chữ đen trên nền tối và lỗi báo trộm chuyển động tự kích hoạt, tối ưu thanh thông báo chống tắt có nút mở rộng kèm chọn kiểu hiển thị, tăng cường khóa màn hình báo động chống trộm, giữ trạng thái tab Cài đặt và làm nổi bật phân loại thẻ thông báo trong Hộp thư.

---

## Quyết định đã xác nhận từ bạn

> [!IMPORTANT]
> Các lựa chọn bạn đã xác nhận ở bước trao đổi trước được áp dụng trực tiếp vào thiết kế bên dưới:

- **Tăng cường khóa màn hình báo trộm**: Kết hợp **Lớp phủ toàn màn hình** (quyền *Hiển thị trên ứng dụng khác* để phủ đè lên Home, Đa nhiệm và Cài đặt), **Ghim màn hình Android (Screen Pinning)** và **ẩn thanh điều hướng/trạng thái (Immersive Mode)** cùng còi báo động chạy bền bỉ ở dịch vụ nền.
- **Thanh thông báo chống tắt**: Nâng cấp kênh thông báo im lặng để **hiển thị sẵn nút mũi tên xổ xuống** mượt mà trên HyperOS/Android, đồng thời thêm **tùy chọn kiểu Gọn hoặc Đầy đủ** ngay trong tab Cài đặt → Thông báo.
- **Phân biệt thẻ thông báo & viền nhấp nháy Hộp thư**: Áp dụng **nền màu riêng rõ nét theo trạng thái/phân loại** kết hợp **viền phát sáng nhấp nháy nổi bật** cho thông báo mới chưa đọc.
- **Lỗi báo trộm chuyển động tự hiện bảng nhập PIN khi đang tắt**: Xác định là lỗi kỹ thuật đồng bộ cảm biến & trạng thái lưu trữ; giữ nguyên nút bật nhanh ở Hộp thư và xử lý triệt để nguyên nhân gốc rễ.

---

## 1. Tổng quan & Mục tiêu

- **Ngôn từ tự nhiên & 20 ngôn ngữ**: Loại bỏ toàn bộ chú thích kỹ thuật và cụm từ trong dấu ngoặc máy móc (như *(lớp cảnh báo 2: ngưỡng ...)*, *(ngưỡng ...)*, *(6 mẫu nghệ thuật)*, *Hiện thông báo tiêu chuẩn...*, *(TTS)*, *(chống spam)*, *(≤ 120s)*...) trên mọi thông báo hệ thống, câu đọc giọng nói và màn hình ứng dụng; đồng thời mở rộng sang **20 ngôn ngữ phổ biến** kèm bộ chọn ngôn ngữ gọn gàng có tìm kiếm.
- **Trải nghiệm hình ảnh nhất quán**: Sửa lỗi kế thừa màu chữ đen trên giao diện tối và thanh trạng thái, đồng thời nâng tầm khả năng quét mắt nhanh trong Hộp thư nhờ hệ màu phân biệt rõ ràng giữa Chưa đọc, Đã đọc, Ghim sao, Ưu tiên, Riêng tư và từng danh mục nội dung.
- **Độ tin cậy thực tế cao hơn**: Thanh thông báo treo mở rộng dễ dàng ngay trên HyperOS/Android mới, màn hình báo trộm chống thoát tối đa trong giới hạn an toàn của Android, chuyển qua lại các tab không mất vị trí đang xem ở Cài đặt, và cảm biến chống trộm tuyệt đối không còn hiện hộp thoại PIN ngoài ý muốn khi tính năng đang tắt.

---

## 2. Trải nghiệm người dùng & Thiết kế trực quan

### 2.1. Ngôn từ tự nhiên & Bộ chọn 20 ngôn ngữ
- **Thông báo Tiện ích ngắn gọn, tự nhiên**:
  - *Pin yếu*: **Pin yếu** — *"Pin điện thoại chỉ còn 15%. Hãy chuẩn bị sạc hoặc bật chế độ Tiết kiệm pin."*
  - *Nhắc cắm sạc*: **Hãy cắm sạc pin** — *"Pin hiện chỉ còn 5%. Vui lòng cắm sạc ngay để tránh sập nguồn."*
  - *Sạc đầy*: **Pin đã sạc đầy** — *"Pin đã đạt 100% và sạc thêm 15 phút. Bạn có thể rút sạc để bảo vệ pin."*
  - *Quá nhiệt*: **Thiết bị đang quá nóng** — *"Nhiệt độ máy đã lên 36,0°C. Hãy tạm dừng tác vụ nặng hoặc rút sạc để hạ nhiệt."*
- **Toàn app không còn chú thích kỹ thuật**: Rà soát mọi tiêu đề thẻ, mô tả, hộp thoại xác nhận, thông báo nhanh (Snackbar), nhãn Tiện ích và màn hình Báo động để chuyển toàn bộ sang hệ thống đa ngôn ngữ tập trung.
- **20 ngôn ngữ phổ biến** (+ *Tự động theo hệ thống*): Tiếng Việt, English, 中文 (简体), 繁體中文, 日本語, 한국어, Español, Français, Deutsch, Português, Русский, Italiano, ไทย, Bahasa Indonesia, Bahasa Melayu, हिन्दी, العربية, Türkçe, Polski, Nederlands.
- **Giao diện chọn ngôn ngữ gọn gàng**: Thay vì trải dài 21 thẻ chip gây rối mắt ở tab Cài đặt → Chung, hiển thị một hàng chọn ngôn ngữ hiện đại mở bảng danh sách cuộn có ô tìm kiếm nhanh theo tên ngôn ngữ.

### 2.2. Sửa triệt để lỗi chữ đen ở chế độ Tối
- **Nguyên nhân gốc**: Khung nền nghệ thuật và các thẻ kính mờ (`GlassCard`) không thiết lập màu chữ mặc định (`contentColor`) khớp với `onSurface`/`onBackground` của bảng màu tối, khiến mọi dòng chữ không chỉ định màu riêng bị rơi về màu đen mặc định, đồng thời icon thanh trạng thái trên cùng cũng giữ màu tối.
- **Cải thiện**:
  - Cung cấp màu nội dung chuẩn theo bảng màu Sáng/Tối ở cả tầng chủ đề tổng, `Scaffold` và từng thẻ kính.
  - Đồng bộ tự động màu icon thanh trạng thái & thanh điều hướng hệ thống sang sáng khi dùng chế độ Tối và tối khi dùng chế độ Sáng.

### 2.3. Thanh thông báo chống tắt có nút xổ & tùy chọn Gọn / Đầy đủ
- Chuyển kênh thông báo treo sang mức **ưu tiên tiêu chuẩn nhưng hoàn toàn im lặng** (không chuông, không rung, không chấm đỏ) để HyperOS/Android luôn hiển thị **mũi tên mở rộng** rõ ràng thay vì gom gọn ẩn vào khu vực thu nhỏ buộc phải nhấn giữ.
- Bổ sung bộ chọn **Kiểu hiển thị thanh thông báo** ngay dưới phần xem trước ở tab *Thông báo*:
  - **Gọn (có nút mở rộng)**: Hiển thị 1 dòng gọn gàng và nhấn mũi tên để xổ đầy đủ 2 hàng thông số.
  - **Đầy đủ**: Hiển thị ngay cả 2 hàng thông số đầy đủ (nhiệt độ, âm lịch, số tin chưa đọc, pin và biểu tượng chống trộm) mà không cần chạm mở rộng.

### 2.4. Hệ màu phân biệt & Viền phát sáng nhấp nháy nổi bật ở Hộp thư
- Mỗi trạng thái thẻ có **thanh nhấn màu dọc cạnh trái (4dp)**, **màu nền kính pha sắc rõ rệt**, **viền đậm hơn** và **nhãn màu đặc trưng** tối ưu độ tương phản cho cả Chế độ Sáng và Chế độ Tối:
  - **Chưa đọc**: Nền sắc màu chủ đạo rõ nét + **viền phát sáng nhấp nháy 2 lớp nổi bật** cùng chấm phát sáng co giãn trong vài giây khi mở ứng dụng hoặc chuyển vào Hộp thư.
  - **Ghim / Yêu thích**: Nền ánh vàng hổ phách ấm + thanh nhấn & viền vàng kim nổi bật.
  - **Ưu tiên (khớp từ khóa)**: Nền sắc hồng san hô/accent riêng + thanh nhấn đậm.
  - **Riêng tư / Đã ẩn**: Nền tím chàm sâu riêng biệt + thanh nhấn tím.
  - **Phân loại nội dung**: Nhãn màu tách biệt rõ ràng cho *Ngân hàng / Giao dịch* (xanh ngọc), *OTP / Bảo mật* (xanh dương), *Tin nhắn* (xanh lam nhạt), *Giao hàng* (cam ấm), *Email / Hệ thống* (tím nhạt).
  - **Đã đọc thường**: Nền kính trung tính dịu nhẹ để mọi thông báo chưa đọc và quan trọng lập tức nổi bật khi lướt qua.

### 2.5. Giữ nguyên tab phụ & vị trí cuộn của Cài đặt
- Khi bạn đang mở bất kỳ mục nào trong Cài đặt (ví dụ *Tiện ích* hoặc *Thông báo*) và chuyển sang *Hộp thư*, *Ứng dụng* hoặc *Bộ lọc*, ứng dụng sẽ **giữ nguyên đúng tab phụ và vị trí cuộn** khi bạn quay lại *Cài đặt*.
- Chỉ khi bạn **đang ở màn hình Cài đặt và chạm thêm lần nữa vào biểu tượng tab Cài đặt** trên thanh điều hướng, ứng dụng mới đưa bạn về trang đầu (*Chung*) và cuộn lên đầu trang.

---

## 3. Quyết định sản phẩm & Xử lý kỹ thuật trọng tâm

### 3.1. Tăng cường khóa màn hình Báo trộm tối đa trong chuẩn Android
> [!NOTE]
> Android ở cấp hệ điều hành không cho phép ứng dụng thông thường chặn hoàn toàn nút cứng Nguồn hay buộc tắt ở mức nhân hệ thống, nhưng việc kết hợp 3 lớp bảo vệ chính thức bên dưới sẽ ngăn chặn gần như triệt để việc thoát về màn hình chính hoặc mở Cài đặt để buộc dừng ứng dụng.

- **Lớp 1 — Lớp phủ khóa toàn màn hình (`SYSTEM_ALERT_WINDOW`)**: Khi người dùng cấp quyền *Hiển thị trên ứng dụng khác* (có mục trạng thái & nút cấp quyền nhanh ngay trong tab *Tiện ích*), lúc còi báo động kích hoạt, ứng dụng gắn thêm một cửa sổ lớp phủ toàn màn hình không thể đóng chứa bàn phím mã PIN 4 số. Dù kẻ gian bấm Home, mở Đa nhiệm hay kéo thanh trạng thái vào Cài đặt để bấm *Buộc dừng*, lớp phủ vẫn ghim chặt trên cùng chặn mọi thao tác chạm cho đến khi nhập đúng mã PIN 4 số.
- **Lớp 2 — Ghim màn hình Android (`startLockTask`)**: Khi còi báo động bắt đầu reo, màn hình báo động tự kích hoạt chế độ Ghim màn hình của Android nhằm vô hiệu hóa thanh điều hướng, chuyển ứng dụng và kéo thông báo; tự động gỡ ghim ngay khi xác thực đúng PIN.
- **Lớp 3 — Toàn màn hình ẩn thanh điều hướng + Giám sát tức thì**: Ẩn cả thanh trạng thái và thanh điều hướng dạng *Immersive Sticky*, đẩy còi hú + khóa âm lượng tối đa + nháy Flash + rung mạnh chạy bền bỉ ở tầng dịch vụ nền (không phụ thuộc vòng đời giao diện), đồng thời kích hoạt kéo màn hình trở lại gần như tức thì ngay khi có tín hiệu rời ứng dụng.

### 3.2. Sửa triệt để lỗi Báo trộm chuyển động tự hiện hộp thoại PIN khi đang tắt
- **Nguyên nhân gốc đã phát hiện trong mã nguồn**:
  1. **Tranh chấp luồng khi vừa tắt báo động**: Ngay sau khi nhập PIN tắt cảnh báo chuyển động, trạng thái runtime bị đưa về rảnh *trước* khi cờ `motionGuardEnabled = false` kịp ghi xong vào bộ nhớ cài đặt — chỉ 16ms sau cảm biến gia tốc bắn thêm sự kiện và lập tức mở lại hộp thoại PIN lần nữa.
  2. **Thiếu đồng bộ bộ nhớ & tự bật lại ngầm**: Biến lưu cấu hình trong dịch vụ nền không đánh dấu đồng bộ đa luồng (`@Volatile`) giữa luồng cảm biến và luồng đọc cài đặt, khiến cảm biến có thể tiếp tục chạy hoặc tự kích hoạt lại sau khi hệ thống khởi động lại dịch vụ nền dù người dùng không bật.
  3. **Nhiễu đơn lẻ từ cảm biến**: Chỉ cần 1 mẫu dao động bất thường ngay khi vừa đăng ký cảm biến là có thể vượt ngưỡng.
- **Giải pháp triệt để**:
  - Hủy đăng ký cảm biến ngay lập tức ở mức đồng bộ và hủy mọi bộ đếm chờ trước khi đặt lại trạng thái; khóa một khoảng nghỉ an toàn sau khi tắt báo động.
  - Kiểm tra trực tiếp cả cờ trạng thái đồng bộ lẫn giá trị thực tế từ kho cài đặt trước khi cho phép bất kỳ cảnh báo `DEVICE_MOVED` nào được khởi chạy — nếu chức năng đang Tắt thì lập tức bỏ qua và gỡ cảm biến.
  - Bổ sung giai đoạn ổn định cảm biến ban đầu (bỏ qua 500ms đầu) và yêu cầu chuyển động liên tục (3 mẫu liên tiếp vượt ngưỡng) để triệt tiêu báo giả.
  - Đảm bảo sau khi khởi động lại thiết bị hoặc khôi phục tiến trình nền lạnh, Báo trộm chủ động luôn ở trạng thái Tắt cho tới khi chính người dùng chủ động bật lại.

---

## 4. Kiến trúc hệ thống & Luồng trạng thái *(Tham khảo kỹ thuật)*

```
┌────────────────────────────────────────────────────────────────────────────┐
│                           NotiTrack UI & State                             │
│                                                                            │
│  ┌──────────────────────┐   ┌───────────────────────────────────────────┐  │
│  │  NotiTrackTheme      │   │  NotiTrackViewModel (State Persistence)   │  │
│  │  • LocalContentColor │   │  • currentTab                             │  │
│  │  • System Bar Icons  │   │  • activeSettingsSubTab (preserved!)      │  │
│  │  • GlassStyleSpec    │   │  • settingsScrollPositions / resetTrigger │  │
│  └──────────┬───────────┘   └─────────────────────┬─────────────────────┘  │
│             │                                     │                        │
│  ┌──────────▼────────────┐  ┌─────────────────────▼─────────────────────┐  │
│  │  Localized Copy (20)  │  │  Screens & Components                     │  │
│  │  • AppStrings (full)  │  │  • Inbox (High-contrast cards + glow)     │  │
│  │  • Natural UI + TTS   │  │  • Settings (20-lang picker, Keep-Alive   │  │
│  │  • Utility Alerts     │  │    Compact/Full toggle, Overlay setup)    │  │
│  └───────────────────────┘  └───────────────────────────────────────────┘  │
└───────────────────────────────────────┬────────────────────────────────────┘
                                        │
┌───────────────────────────────────────▼────────────────────────────────────┐
│                     Background Services & Anti-Theft Guard                 │
│                                                                            │
│  ┌────────────────────────────────┐   ┌─────────────────────────────────┐  │
│  │ KeepAliveService (Foreground)  │   │ AntiTheftRuntimeController      │  │
│  │ • Silent DEFAULT channel (v3)  │   │ • Strict motionGuardEnabled     │  │
│  │   → Native expand chevron      │   │   double-gate + disarm cooldown │  │
│  │ • Compact vs Full RemoteViews  │   │ • AntiTheftOverlayManager       │  │
│  │ • Verified Motion Sensor       │──▶│   (TYPE_APPLICATION_OVERLAY)    │  │
│  │   (warm-up + 3-sample filter   │   │ • AntiTheftAlarmActivity        │  │
│  │   + instant sync unregister)   │   │   (startLockTask + Immersive)   │  │
│  └────────────────────────────────┘   └─────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────────┘
```

### Luồng tương tác & Kiểm chứng chính
- **Đổi ngôn ngữ**: Chạm mục *Ngôn ngữ hiển thị* ở tab *Chung* → mở bảng chọn 20 ngôn ngữ có tìm kiếm → chọn ngôn ngữ mới → toàn bộ giao diện, nhãn Tiện ích, thông báo pin/nhiệt độ, thanh treo và giọng đọc cập nhật tức thì.
- **Báo động chống trộm khi rút sạc / di chuyển**:
  - Trước khi reo (nếu bật hộp thoại xác nhận): Đếm ngược cho phép tắt bằng PIN 4 số hoặc Vân tay.
  - Khi còi đã reo: Chạy đồng thời Còi âm lượng tối đa + Flash + Rung + Ghim màn hình + Lớp phủ toàn màn hình (nếu đã cấp quyền) → bắt buộc nhập đúng PIN 4 số để tắt toàn bộ, đồng thời gỡ cảm biến và khóa cửa sổ tránh kích hoạt lặp.
- **Điều hướng tab Cài đặt**: Đang ở *Cài đặt → Tiện ích (cuộn giữa trang)* → chuyển sang *Hộp thư* → quay lại *Cài đặt* → vẫn giữ đúng *Tiện ích* và vị trí cuộn → bấm *Cài đặt* thêm 1 lần nữa → quay về tab *Chung* ở đầu trang.
- **Kiểm tra chất lượng**: Biên dịch toàn dự án và chạy bộ kiểm thử đơn vị để xác minh logic lọc chuyển động chống báo giả, chế độ hiển thị thanh thông báo, độ phủ 20 ngôn ngữ và các luật cảnh báo pin/nhiệt độ.
