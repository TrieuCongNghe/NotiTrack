package com.example.engine

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.NotiTrackApplication
import com.example.R
import com.example.data.prefs.NotiTrackSettings
import com.example.ui.i18n.UtilitiesStrings
import com.example.ui.i18n.stringsFor
import java.util.Locale

/**
 * Dispatches real device utility alerts (Low Battery, Charging Reminder, Full Charge, Overheat)
 * with natural localized copy across all 20 supported languages, optional ringtone/custom audio,
 * optional TTS voice readout, and quick-action PendingIntent to Android Battery Saver settings.
 */
object UtilityAlertDispatcher {

    private const val CHANNEL_UTIL_SILENT = "notitrack_utility_alerts_v1"
    private const val CHANNEL_UTIL_SOUND = "notitrack_utility_sound_v1"
    private const val CHANNEL_OVERHEAT_ALARM = "notitrack_overheat_alarm_v1"

    private const val NOTIF_ID_LOW_BATTERY = 5101
    private const val NOTIF_ID_CHARGING_LEVEL = 5102
    private const val NOTIF_ID_FULL_CHARGE = 5103
    private const val NOTIF_ID_OVERHEAT = 5104

    fun dispatchLowBattery(
        context: Context,
        settings: NotiTrackSettings,
        batteryPercent: Int
    ) {
        val u = stringsFor(settings.appLanguage).utilities
        postUtilityNotification(
            context = context,
            notificationId = NOTIF_ID_LOW_BATTERY,
            title = u.lowBatNotifTitle,
            body = u.lowBatNotifBody(batteryPercent),
            playRingtone = settings.lowBatteryRingtoneEnabled,
            playCustomMusic = settings.lowBatteryMusicEnabled,
            customSoundUri = settings.lowBatterySoundUri,
            useAlarmStream = false,
            includeBatterySaverAction = settings.lowBatterySaverPromptEnabled,
            strings = u
        )
        if (settings.lowBatteryTtsEnabled) {
            speakUtilityAlert(
                context = context,
                settings = settings,
                text = u.lowBatTts(batteryPercent)
            )
        }
    }

    fun dispatchChargingLevel(
        context: Context,
        settings: NotiTrackSettings,
        batteryPercent: Int
    ) {
        val u = stringsFor(settings.appLanguage).utilities
        postUtilityNotification(
            context = context,
            notificationId = NOTIF_ID_CHARGING_LEVEL,
            title = u.chargingNotifTitle,
            body = u.chargingNotifBody(batteryPercent),
            playRingtone = settings.chargingRingtoneEnabled,
            playCustomMusic = settings.chargingMusicEnabled,
            customSoundUri = settings.chargingSoundUri,
            useAlarmStream = false,
            includeBatterySaverAction = settings.chargingSaverPromptEnabled,
            strings = u
        )
        if (settings.chargingTtsEnabled) {
            speakUtilityAlert(
                context = context,
                settings = settings,
                text = u.chargingTts(batteryPercent)
            )
        }
    }

    fun dispatchFullCharge(
        context: Context,
        settings: NotiTrackSettings,
        batteryPercent: Int,
        extraMinutesWaited: Int
    ) {
        val u = stringsFor(settings.appLanguage).utilities
        postUtilityNotification(
            context = context,
            notificationId = NOTIF_ID_FULL_CHARGE,
            title = u.fullChargeNotifTitle,
            body = u.fullChargeNotifBody(batteryPercent, extraMinutesWaited),
            playRingtone = settings.fullChargeRingtoneEnabled,
            playCustomMusic = settings.fullChargeMusicEnabled,
            customSoundUri = settings.fullChargeSoundUri,
            useAlarmStream = false,
            includeBatterySaverAction = false,
            strings = u
        )
        if (settings.fullChargeTtsEnabled) {
            speakUtilityAlert(
                context = context,
                settings = settings,
                text = u.fullChargeTts(batteryPercent, extraMinutesWaited)
            )
        }
    }

    fun dispatchOverheat(
        context: Context,
        settings: NotiTrackSettings,
        tempCelsius: Float
    ) {
        val u = stringsFor(settings.appLanguage).utilities
        val formattedTemp = String.format(Locale.getDefault(), "%.1f", tempCelsius)
        postUtilityNotification(
            context = context,
            notificationId = NOTIF_ID_OVERHEAT,
            title = u.overheatNotifTitle,
            body = u.overheatNotifBody(formattedTemp),
            playRingtone = true,
            playCustomMusic = settings.overheatSoundUri.isNotBlank(),
            customSoundUri = settings.overheatSoundUri,
            useAlarmStream = settings.overheatUseAlarmSound,
            includeBatterySaverAction = false,
            strings = u
        )
    }

    private fun postUtilityNotification(
        context: Context,
        notificationId: Int,
        title: String,
        body: String,
        playRingtone: Boolean,
        playCustomMusic: Boolean,
        customSoundUri: String,
        useAlarmStream: Boolean,
        includeBatterySaverAction: Boolean,
        strings: UtilitiesStrings
    ) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        ensureChannels(manager, strings)

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPending = PendingIntent.getActivity(
            context,
            notificationId,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val channelId = when {
            useAlarmStream -> CHANNEL_OVERHEAT_ALARM
            playRingtone && !playCustomMusic -> CHANNEL_UTIL_SOUND
            else -> CHANNEL_UTIL_SILENT
        }

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(if (useAlarmStream) NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_STATUS)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(contentPending)

        if (includeBatterySaverAction) {
            val saverIntent = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val saverPending = PendingIntent.getActivity(
                context,
                notificationId + 50,
                saverIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(0, strings.actionOpenBatterySaver, saverPending)
        }

        runCatching { manager.notify(notificationId, builder.build()) }

        if (playCustomMusic || (playRingtone && useAlarmStream)) {
            playAlertTone(
                context = context,
                customUriString = if (playCustomMusic) customSoundUri else "",
                useAlarmStream = useAlarmStream
            )
        }
    }

    private fun playAlertTone(
        context: Context,
        customUriString: String,
        useAlarmStream: Boolean
    ) {
        runCatching {
            val uri = if (customUriString.isNotBlank()) {
                Uri.parse(customUriString)
            } else {
                RingtoneManager.getDefaultUri(
                    if (useAlarmStream) RingtoneManager.TYPE_ALARM else RingtoneManager.TYPE_NOTIFICATION
                )
            }
            val ringtone = RingtoneManager.getRingtone(context, uri) ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                ringtone.audioAttributes = AudioAttributes.Builder()
                    .setUsage(
                        if (useAlarmStream) AudioAttributes.USAGE_ALARM
                        else AudioAttributes.USAGE_NOTIFICATION
                    )
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            }
            ringtone.play()
        }
    }

    private fun speakUtilityAlert(
        context: Context,
        settings: NotiTrackSettings,
        text: String
    ) {
        val app = context.applicationContext as? NotiTrackApplication ?: return
        app.speaker.speakDirectMessage(
            text = text,
            speechRate = settings.ttsSpeechRate,
            language = settings.appLanguage,
            volumeConfig = TtsVolumeConfig(
                overrideVolume = settings.ttsOverrideVolumeEnabled,
                bypassSilentMode = settings.ttsBypassSilentMode,
                volumePercent = settings.ttsCustomVolumePercent,
                autoBoostVolume = false,
                interSpeechDelayMs = settings.ttsDelayBetweenMs
            )
        )
    }

    private fun ensureChannels(manager: NotificationManager, strings: UtilitiesStrings) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val silentCh = NotificationChannel(
            CHANNEL_UTIL_SILENT,
            strings.channelUtilitySilent,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            setSound(null, null)
            enableVibration(true)
        }
        val soundCh = NotificationChannel(
            CHANNEL_UTIL_SOUND,
            strings.channelUtilitySound,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            enableVibration(true)
        }
        val alarmCh = NotificationChannel(
            CHANNEL_OVERHEAT_ALARM,
            strings.channelOverheatAlarm,
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            enableVibration(true)
            val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            setSound(alarmUri, attrs)
        }
        manager.createNotificationChannel(silentCh)
        manager.createNotificationChannel(soundCh)
        manager.createNotificationChannel(alarmCh)
    }
}
