package com.example.engine

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.example.NotiTrackApplication
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.stringsFor
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Full-screen system overlay PIN lock shown above Home, Recents, and Settings during ALARM_RINGING
 * whenever the user has granted "Display over other apps" (SYSTEM_ALERT_WINDOW).
 * Uses lightweight native Android Views attached via Application WindowManager so it never depends
 * on Activity lifecycle or Compose ViewTreeLifecycleOwner.
 */
object AntiTheftOverlayManager {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate + CoroutineExceptionHandler { _, _ -> })

    @Volatile
    private var overlayView: View? = null

    fun hasOverlayPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            runCatching { Settings.canDrawOverlays(context) }.getOrDefault(false)
        } else {
            true
        }
    }

    fun isShowing(): Boolean = overlayView != null

    fun show(
        context: Context,
        reason: AntiTheftTriggerReason?,
        flashEnabled: Boolean,
        vibrateEnabled: Boolean,
        language: AppLanguage
    ) {
        val appContext = context.applicationContext
        if (!hasOverlayPermission(appContext)) return

        scope.launch {
            if (overlayView != null) return@launch
            val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return@launch
            val view = buildOverlayView(
                appContext = appContext,
                reason = reason,
                flashEnabled = flashEnabled,
                vibrateEnabled = vibrateEnabled,
                language = language
            )
            val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            @Suppress("DEPRECATION")
            val flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_FULLSCREEN or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                layoutType,
                flags,
                PixelFormat.OPAQUE
            ).apply {
                gravity = Gravity.CENTER
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }

            runCatching {
                wm.addView(view, params)
                overlayView = view
            }
        }
    }

    fun dismiss(context: Context) {
        val appContext = context.applicationContext
        scope.launch {
            val view = overlayView ?: return@launch
            overlayView = null
            val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            runCatching { wm?.removeViewImmediate(view) }
        }
    }

    private fun buildOverlayView(
        appContext: Context,
        reason: AntiTheftTriggerReason?,
        flashEnabled: Boolean,
        vibrateEnabled: Boolean,
        language: AppLanguage
    ): View {
        val u = stringsFor(language).utilities
        val dp = { value: Int ->
            TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value.toFloat(),
                appContext.resources.displayMetrics
            ).toInt()
        }

        val root = object : FrameLayout(appContext) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_BACK,
                    KeyEvent.KEYCODE_VOLUME_UP,
                    KeyEvent.KEYCODE_VOLUME_DOWN,
                    KeyEvent.KEYCODE_VOLUME_MUTE -> return true
                }
                return super.dispatchKeyEvent(event)
            }
        }.apply {
            isFocusable = true
            isFocusableInTouchMode = true
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.parseColor("#8A0A18"),
                    Color.parseColor("#2B050B"),
                    Color.parseColor("#08090E")
                )
            )
            setPadding(dp(20), dp(48), dp(20), dp(36))
        }

        val scroll = ScrollView(appContext).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }

        val column = LinearLayout(appContext).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleText = when (reason) {
            AntiTheftTriggerReason.CHARGER_UNPLUGGED -> u.alarmTitleCharger
            AntiTheftTriggerReason.DEVICE_MOVED -> u.alarmTitleMotion
            null -> u.alarmTitleDefault
        }

        val badge = TextView(appContext).apply {
            text = "!"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 34f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#44FF1744"))
                setStroke(dp(2), Color.parseColor("#FFFF5252"))
            }
            layoutParams = LinearLayout.LayoutParams(dp(80), dp(80)).apply {
                bottomMargin = dp(16)
            }
        }
        column.addView(badge)

        val titleView = TextView(appContext).apply {
            text = titleText
            setTextColor(Color.parseColor("#FFFF8A80"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(8)
            }
        }
        column.addView(titleView)

        val subtitleView = TextView(appContext).apply {
            text = u.alarmRingingSubtitle
            setTextColor(Color.parseColor("#E6FFFFFF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(14)
            }
        }
        column.addView(subtitleView)

        val pillsRow = LinearLayout(appContext).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(18)
            }
        }
        val activePills = buildList {
            add(u.alarmPillMaxVol)
            if (flashEnabled) add(u.alarmPillFlash)
            if (vibrateEnabled) add(u.alarmPillVibrate)
        }
        activePills.forEach { label ->
            val pill = TextView(appContext).apply {
                text = label
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), dp(6), dp(12), dp(6))
                background = GradientDrawable().apply {
                    cornerRadius = dp(50).toFloat()
                    setColor(Color.parseColor("#2BFFFFFF"))
                    setStroke(dp(1), Color.parseColor("#44FFFFFF"))
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    marginStart = dp(4)
                    marginEnd = dp(4)
                }
            }
            pillsRow.addView(pill)
        }
        column.addView(pillsRow)

        val errorView = TextView(appContext).apply {
            visibility = View.GONE
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14), dp(7), dp(14), dp(7))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor("#D9FF1744"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(14)
            }
        }
        column.addView(errorView)

        val dotsRow = LinearLayout(appContext).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(20)
            }
        }
        val dotViews = List(4) {
            View(appContext).apply {
                background = createDotDrawable(dp, filled = false)
                layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).apply {
                    marginStart = dp(8)
                    marginEnd = dp(8)
                }
            }
        }
        dotViews.forEach { dotsRow.addView(it) }
        column.addView(dotsRow)

        val pinBuffer = StringBuilder()
        var verifying = false

        fun refreshDots() {
            dotViews.forEachIndexed { idx, dot ->
                dot.background = createDotDrawable(dp, filled = idx < pinBuffer.length)
            }
        }

        fun submitPin(entered: String) {
            if (verifying) return
            verifying = true
            scope.launch {
                val app = appContext as? NotiTrackApplication
                val ok = withContext(Dispatchers.IO) {
                    if (app == null) true
                    else {
                        val snap = app.preferences.getSettingsSnapshot()
                        if (!snap.hasPinConfigured) true else app.preferences.verifyPin(entered)
                    }
                }
                if (ok) {
                    AntiTheftRuntimeController.setMotionGuardRequested(false)
                    withContext(Dispatchers.IO + NonCancellable) {
                        if (reason == AntiTheftTriggerReason.DEVICE_MOVED) {
                            app?.preferences?.setMotionGuardEnabled(false)
                        }
                    }
                    AntiTheftRuntimeController.disarmAll(appContext)
                    dismiss(appContext)
                } else {
                    pinBuffer.clear()
                    refreshDots()
                    errorView.text = u.alarmWrongPinError
                    errorView.visibility = View.VISIBLE
                    verifying = false
                }
            }
        }

        val keypadRows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("", "0", "⌫")
        )
        val keypadContainer = LinearLayout(appContext).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        keypadRows.forEach { rowKeys ->
            val row = LinearLayout(appContext).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dp(12)
                }
            }
            rowKeys.forEach { key ->
                val btn = TextView(appContext).apply {
                    text = key
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, if (key == "⌫") 22f else 24f)
                    typeface = Typeface.DEFAULT_BOLD
                    layoutParams = LinearLayout.LayoutParams(dp(68), dp(68)).apply {
                        marginStart = dp(10)
                        marginEnd = dp(10)
                    }
                    if (key.isEmpty()) {
                        visibility = View.INVISIBLE
                    } else {
                        background = GradientDrawable().apply {
                            shape = GradientDrawable.OVAL
                            setColor(if (key == "⌫") Color.TRANSPARENT else Color.parseColor("#26FFFFFF"))
                            if (key != "⌫") setStroke(dp(1), Color.parseColor("#44FFFFFF"))
                        }
                        setOnClickListener {
                            if (verifying) return@setOnClickListener
                            errorView.visibility = View.GONE
                            if (key == "⌫") {
                                if (pinBuffer.isNotEmpty()) {
                                    pinBuffer.deleteCharAt(pinBuffer.length - 1)
                                    refreshDots()
                                }
                            } else if (pinBuffer.length < 4) {
                                pinBuffer.append(key)
                                refreshDots()
                                if (pinBuffer.length == 4) {
                                    submitPin(pinBuffer.toString())
                                }
                            }
                        }
                    }
                }
                row.addView(btn)
            }
            keypadContainer.addView(row)
        }
        column.addView(keypadContainer)

        scroll.addView(column)
        root.addView(scroll)
        return root
    }

    private fun createDotDrawable(dp: (Int) -> Int, filled: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (filled) Color.parseColor("#FFFFD54F") else Color.parseColor("#33FFFFFF"))
            setStroke(dp(1), Color.parseColor("#99FFFFFF"))
        }
    }
}
