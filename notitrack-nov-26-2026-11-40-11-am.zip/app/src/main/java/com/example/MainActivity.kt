package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.FilterAlt
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.AntiTheftOverlayManager
import com.example.engine.BackupPreview
import com.example.engine.BackupSelection
import com.example.engine.BatteryOptimizationHelper
import com.example.engine.BiometricAuthHelper
import com.example.engine.TestNotificationDispatcher
import com.example.engine.TestNotificationScenario
import com.example.ui.components.ActionAuthGuardDialog
import com.example.ui.components.ArtThemeBackdrop
import com.example.ui.components.GlassBottomNavigationBar
import com.example.ui.components.GlassNavItem
import com.example.ui.i18n.AppStrings
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.i18n.stringsFor
import com.example.ui.screens.AppsScreen
import com.example.ui.screens.BackupRestoreConfirmDialog
import com.example.ui.screens.ConfigurePinDialog
import com.example.ui.screens.FiltersScreen
import com.example.ui.screens.InboxScreen
import com.example.ui.screens.NotiTrackLockScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SettingsSubTab
import com.example.ui.screens.UtilitySoundTarget
import com.example.ui.theme.LocalGlassStyle
import com.example.ui.theme.NotiTrackTheme
import com.example.ui.viewmodel.NotiTrackTab
import com.example.ui.viewmodel.NotiTrackViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : FragmentActivity() {

    private val viewModel: NotiTrackViewModel by viewModels {
        val app = application as NotiTrackApplication
        NotiTrackViewModel.Factory(applicationContext, app.repository, app.speaker)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            val appStrings = remember(settings.appLanguage) { stringsFor(settings.appLanguage) }

            LaunchedEffect(settings.flagSecureEnabled) {
                if (settings.flagSecureEnabled) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }

            CompositionLocalProvider(LocalAppStrings provides appStrings) {
                NotiTrackTheme(
                    themeMode = settings.themeMode,
                    artTheme = settings.artTheme
                ) {
                    NotiTrackRoot(
                        activity = this,
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        viewModel.onAppForegrounded()
    }

    override fun onPause() {
        currentFocus?.let { focused ->
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.hideSoftInputFromWindow(focused.windowToken, 0)
            focused.clearFocus()
        }
        super.onPause()
    }

    override fun onStop() {
        viewModel.onAppBackgrounded()
        super.onStop()
    }
}

private data class NavDestination(
    val tab: NotiTrackTab,
    val labelOf: (AppStrings) -> String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val NAV_DESTINATIONS = listOf(
    NavDestination(NotiTrackTab.INBOX, { it.navInbox }, Icons.Filled.Inbox, Icons.Outlined.Inbox),
    NavDestination(NotiTrackTab.APPS, { it.navApps }, Icons.Filled.Apps, Icons.Outlined.Apps),
    NavDestination(NotiTrackTab.FILTERS, { it.navFilters }, Icons.Filled.FilterAlt, Icons.Outlined.FilterAlt),
    NavDestination(NotiTrackTab.SETTINGS, { it.navSettings }, Icons.Filled.Settings, Icons.Outlined.Settings)
)

private data class PendingAuthAction(
    val title: String,
    val subtitle: String,
    val onAuthorized: () -> Unit
)

@Composable
private fun NotiTrackRoot(
    activity: FragmentActivity,
    viewModel: NotiTrackViewModel
) {
    val context = LocalContext.current
    val s = LocalAppStrings.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val allNotifications by viewModel.allNotifications.collectAsStateWithLifecycle()
    val filteredNotifications by viewModel.filteredNotifications.collectAsStateWithLifecycle()
    val appInboxGroups by viewModel.appInboxGroups.collectAsStateWithLifecycle()
    val activeAppGroup by viewModel.activeAppGroup.collectAsStateWithLifecycle()
    val conversationThreads by viewModel.conversationThreads.collectAsStateWithLifecycle()
    val activeThread by viewModel.activeThreadSummary.collectAsStateWithLifecycle()
    val activeThreadMessages by viewModel.activeThreadNotifications.collectAsStateWithLifecycle()
    val appRules by viewModel.appRules.collectAsStateWithLifecycle()
    val filteredAppRules by viewModel.filteredAppRules.collectAsStateWithLifecycle()
    val keywordRules by viewModel.keywordRules.collectAsStateWithLifecycle()
    val ttsFeedbackRules by viewModel.ttsFeedbackRules.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val isListenerEnabled by viewModel.isListenerEnabled.collectAsStateWithLifecycle()
    val isIgnoringBatteryOptimizations by viewModel.isIgnoringBatteryOptimizations.collectAsStateWithLifecycle()
    val isLocked by viewModel.isLocked.collectAsStateWithLifecycle()
    val speakingId by viewModel.speakingNotificationId.collectAsStateWithLifecycle()
    val antiTheftState by viewModel.antiTheftState.collectAsStateWithLifecycle()
    val inboxQuery by viewModel.inboxQuery.collectAsStateWithLifecycle()
    val inboxFilter by viewModel.inboxFilter.collectAsStateWithLifecycle()
    val appsQuery by viewModel.appsQuery.collectAsStateWithLifecycle()
    val appsFilter by viewModel.appsFilter.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val inboxResetTrigger by viewModel.inboxResetTrigger.collectAsStateWithLifecycle()
    val inboxPulseEpoch by viewModel.inboxPulseEpoch.collectAsStateWithLifecycle()
    val activeSettingsSubTab by viewModel.activeSettingsSubTab.collectAsStateWithLifecycle()
    val settingsResetTrigger by viewModel.settingsResetTrigger.collectAsStateWithLifecycle()

    val settingsSubTabListStates = remember {
        SettingsSubTab.entries.associateWith { LazyListState() }
    }
    LaunchedEffect(settingsResetTrigger) {
        if (settingsResetTrigger > 0) {
            settingsSubTabListStates[SettingsSubTab.GENERAL]?.animateScrollToItem(0)
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    val ioScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(currentTab, activeAppGroup, activeThread, isLocked) {
        focusManager.clearFocus(force = true)
        keyboardController?.hide()
    }

    var authError by remember { mutableStateOf<String?>(null) }
    var pendingTestScenario by remember { mutableStateOf<TestNotificationScenario?>(null) }
    var pendingUtilityTestTarget by remember { mutableStateOf<UtilitySoundTarget?>(null) }
    var pendingBackupSelection by remember { mutableStateOf<BackupSelection?>(null) }
    var pendingRestorePreview by remember { mutableStateOf<BackupPreview?>(null) }
    var pendingSoundTarget by remember { mutableStateOf<UtilitySoundTarget?>(null) }
    var pendingAuthAction by remember { mutableStateOf<PendingAuthAction?>(null) }
    var showQuickMotionPinNotice by remember { mutableStateOf(false) }
    var showQuickMotionPinDialog by remember { mutableStateOf(false) }
    var hasPostNotifPermission by remember {
        mutableStateOf(TestNotificationDispatcher.hasPostNotificationPermission(context))
    }
    var hasOverlayPermission by remember {
        mutableStateOf(AntiTheftOverlayManager.hasOverlayPermission(context))
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, context) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasPostNotifPermission = TestNotificationDispatcher.hasPostNotificationPermission(context)
                hasOverlayPermission = AntiTheftOverlayManager.hasOverlayPermission(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(currentTab, activeSettingsSubTab, settings.keepAliveEnabled, settings.hasAnyUtilityMonitorEnabled) {
        hasPostNotifPermission = TestNotificationDispatcher.hasPostNotificationPermission(context)
        hasOverlayPermission = AntiTheftOverlayManager.hasOverlayPermission(context)
    }

    val biometricStatus = remember(isLocked, currentTab) {
        BiometricAuthHelper.checkHardwareStatus(context)
    }

    val ringtonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val target = pendingSoundTarget
        pendingSoundTarget = null
        if (result.resultCode == Activity.RESULT_OK && target != null) {
            val pickedUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            val uriStr = pickedUri?.toString().orEmpty()
            viewModel.updateUtilitiesSettings { current ->
                when (target) {
                    UtilitySoundTarget.LOW_BATTERY -> current.copy(lowBatterySoundUri = uriStr)
                    UtilitySoundTarget.CHARGING -> current.copy(chargingSoundUri = uriStr)
                    UtilitySoundTarget.FULL_CHARGE -> current.copy(fullChargeSoundUri = uriStr)
                    UtilitySoundTarget.OVERHEAT -> current.copy(overheatSoundUri = uriStr)
                }
            }
        }
    }

    fun launchUtilitySoundPicker(target: UtilitySoundTarget, currentUri: String) {
        pendingSoundTarget = target
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            if (currentUri.isNotBlank()) {
                runCatching {
                    putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(currentUri))
                }
            }
        }
        runCatching {
            ringtonePickerLauncher.launch(intent)
        }.onFailure {
            pendingSoundTarget = null
            viewModel.showMessage(s.msgCannotOpenSettings)
        }
    }

    fun runGuardedDelete(action: () -> Unit) {
        if (!settings.isDeleteAuthEffective) {
            action()
            return
        }
        pendingAuthAction = PendingAuthAction(
            title = s.deleteAuthPromptTitle,
            subtitle = s.deleteAuthPromptDesc,
            onAuthorized = action
        )
    }

    fun handleMotionGuardToggle(wantEnable: Boolean) {
        if (wantEnable) {
            if (!settings.hasPinConfigured) {
                showQuickMotionPinNotice = true
            } else {
                viewModel.setMotionGuardEnabled(true)
            }
        } else {
            val isArmed = settings.motionGuardEnabled || antiTheftState.isMotionGuardArmed
            if (isArmed && settings.isAppLockActive) {
                pendingAuthAction = PendingAuthAction(
                    title = s.disarmMotionAuthTitle,
                    subtitle = s.disarmMotionAuthDesc,
                    onAuthorized = { viewModel.setMotionGuardEnabled(false) }
                )
            } else {
                viewModel.setMotionGuardEnabled(false)
            }
        }
    }

    val backupCreateDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        val selection = pendingBackupSelection
        pendingBackupSelection = null
        if (uri != null && selection != null) {
            viewModel.exportBackupJson(selection) { json ->
                ioScope.launch {
                    val saved = withContext(Dispatchers.IO) {
                        runCatching {
                            context.contentResolver.openOutputStream(uri)?.use { out ->
                                out.write(json.toByteArray(Charsets.UTF_8))
                                out.flush()
                            } ?: error("Null output stream")
                            true
                        }.getOrDefault(false)
                    }
                    viewModel.showMessage(if (saved) s.backupSuccessMsg else s.backupFailedMsg)
                }
            }
        }
    }

    val restoreOpenDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            ioScope.launch {
                val rawJson = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use {
                            it.readText()
                        }
                    }.getOrNull()
                }
                if (rawJson.isNullOrBlank()) {
                    viewModel.showMessage(s.restoreInvalidFileMsg)
                } else {
                    viewModel.parseBackupJson(rawJson) { preview ->
                        pendingRestorePreview = preview
                    }
                }
            }
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasPostNotifPermission = granted || TestNotificationDispatcher.hasPostNotificationPermission(context)
        val scenario = pendingTestScenario
        pendingTestScenario = null
        val utilTest = pendingUtilityTestTarget
        pendingUtilityTestTarget = null
        if (hasPostNotifPermission) {
            viewModel.ensureKeepAliveRunning()
            if (scenario != null) {
                TestNotificationDispatcher.dispatchTestNotification(context, scenario, settings.appLanguage)
                viewModel.showMessage(
                    if (isListenerEnabled) s.msgTestSentCaptured else s.msgTestSentNeedAccess
                )
            } else if (utilTest != null) {
                viewModel.testUtilityAlert(utilTest)
            }
        } else {
            viewModel.showMessage(s.msgNeedPostPerm)
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !TestNotificationDispatcher.hasPostNotificationPermission(context)
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            viewModel.ensureKeepAliveRunning()
        }
    }

    fun requestPostNotificationPermission() {
        if (TestNotificationDispatcher.hasPostNotificationPermission(context)) {
            hasPostNotifPermission = true
            viewModel.ensureKeepAliveRunning()
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun triggerUtilityTest(target: UtilitySoundTarget) {
        if (TestNotificationDispatcher.hasPostNotificationPermission(context)) {
            viewModel.testUtilityAlert(target)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pendingUtilityTestTarget = target
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun triggerTestNotification(scenario: TestNotificationScenario) {
        if (TestNotificationDispatcher.hasPostNotificationPermission(context)) {
            TestNotificationDispatcher.dispatchTestNotification(context, scenario, settings.appLanguage)
            viewModel.showMessage(
                if (isListenerEnabled) s.msgTestSentCaptured else s.msgTestSentNeedAccess
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pendingTestScenario = scenario
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun openListenerSettings() {
        runCatching {
            context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }.onFailure {
            viewModel.showMessage(s.msgCannotOpenSettings)
        }
    }

    fun openOverlayPermissionSettings() {
        runCatching {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
            context.startActivity(intent)
        }.onFailure {
            viewModel.showMessage(s.msgCannotOpenSettings)
        }
    }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessage()
        }
    }

    if (isLocked) {
        NotiTrackLockScreen(
            biometricEnabled = settings.biometricEnabled,
            biometricAvailable = biometricStatus.isUsable,
            hasPinConfigured = settings.hasPinConfigured,
            authErrorMessage = authError,
            onRequestBiometric = {
                authError = null
                BiometricAuthHelper.authenticate(
                    activity = activity,
                    title = s.lockPromptTitle,
                    subtitle = s.lockPromptSubtitle,
                    negativeButtonText = s.lockPromptNegative,
                    mismatchMessage = s.biometricMismatchMsg,
                    onSuccess = {
                        authError = null
                        viewModel.unlockApp()
                    },
                    onFailureOrCancel = { err -> authError = err }
                )
            },
            onVerifyPin = { pin, callback ->
                viewModel.verifyPinAndUnlock(pin, callback)
            }
        )
        return
    }

    val unreadCount = remember(allNotifications) {
        allNotifications.count { !it.isRead && !it.isHidden }
    }
    val totalUnreadCount = remember(allNotifications) {
        allNotifications.count { !it.isRead }
    }

    ArtThemeBackdrop(modifier = Modifier.fillMaxSize()) {
        val glass = LocalGlassStyle.current

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isExpanded = maxWidth >= 600.dp

            Scaffold(
                modifier = Modifier.fillMaxSize(),
                containerColor = Color.Transparent,
                contentColor = MaterialTheme.colorScheme.onBackground,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!isExpanded) {
                        val navItems = remember(s, unreadCount) {
                            NAV_DESTINATIONS.map { dest ->
                                GlassNavItem(
                                    key = dest.tab,
                                    label = dest.labelOf(s),
                                    selectedIcon = dest.selectedIcon,
                                    unselectedIcon = dest.unselectedIcon,
                                    badgeCount = if (dest.tab == NotiTrackTab.INBOX) unreadCount else 0,
                                    testTag = "nav_tab_${dest.tab.route}"
                                )
                            }
                        }
                        GlassBottomNavigationBar(
                            items = navItems,
                            selectedKey = currentTab,
                            onSelect = viewModel::selectTab,
                            modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                        )
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (isExpanded) {
                        NavigationRail(
                            containerColor = glass.navBarFill
                        ) {
                            NAV_DESTINATIONS.forEach { dest ->
                                val selected = currentTab == dest.tab
                                val label = dest.labelOf(s)
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { viewModel.selectTab(dest.tab) },
                                    icon = {
                                        NavTabIcon(
                                            dest = dest,
                                            label = label,
                                            selected = selected,
                                            unreadCount = if (dest.tab == NotiTrackTab.INBOX) unreadCount else 0
                                        )
                                    },
                                    label = { Text(label) },
                                    modifier = Modifier.testTag("rail_tab_${dest.tab.route}")
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        val contentModifier = Modifier
                            .fillMaxSize()
                            .widthIn(max = 840.dp)

                        AnimatedContent(
                            targetState = currentTab,
                            transitionSpec = {
                                val forward = targetState.ordinal >= initialState.ordinal
                                (fadeIn(tween(240)) + slideInHorizontally(
                                    animationSpec = tween(260),
                                    initialOffsetX = { if (forward) it / 9 else -it / 9 }
                                )) togetherWith (fadeOut(tween(180)) + slideOutHorizontally(
                                    animationSpec = tween(200),
                                    targetOffsetX = { if (forward) -it / 10 else it / 10 }
                                ))
                            },
                            label = "main_tab_transition"
                        ) { activeTab ->
                            when (activeTab) {
                                NotiTrackTab.INBOX -> InboxScreen(
                                    allNotifications = allNotifications,
                                    notifications = filteredNotifications,
                                    appInboxGroups = appInboxGroups,
                                    activeAppGroup = activeAppGroup,
                                    conversationThreads = conversationThreads,
                                    activeThread = activeThread,
                                    activeThreadMessages = activeThreadMessages,
                                    ttsFeedbackRules = ttsFeedbackRules,
                                    isChatGroupedView = settings.chatTimelineGroupingEnabled,
                                    unreadCount = unreadCount,
                                    inboxResetTrigger = inboxResetTrigger,
                                    inboxPulseEpoch = inboxPulseEpoch,
                                    antiTheftState = antiTheftState,
                                    motionGuardEnabled = settings.motionGuardEnabled,
                                    query = inboxQuery,
                                    activeFilter = inboxFilter,
                                    isListenerEnabled = isListenerEnabled,
                                    isLockConfigured = settings.isAppLockActive,
                                    speakingNotificationId = speakingId,
                                    onQueryChange = viewModel::updateInboxQuery,
                                    onFilterChange = viewModel::selectInboxFilter,
                                    onToggleChatGroupedView = viewModel::toggleChatTimelineGrouping,
                                    onOpenAppGroup = viewModel::openAppGroup,
                                    onOpenThread = viewModel::openConversationThread,
                                    onMarkAllRead = viewModel::markAllRead,
                                    onToggleMotionGuardQuick = {
                                        val isCurrentlyActive = settings.motionGuardEnabled || antiTheftState.isMotionGuardArmed
                                        handleMotionGuardToggle(!isCurrentlyActive)
                                    },
                                    onMarkRead = viewModel::markNotificationRead,
                                    onToggleStar = viewModel::toggleStar,
                                    onToggleHidden = viewModel::toggleHidden,
                                    onDeleteNotification = { id ->
                                        runGuardedDelete { viewModel.deleteNotification(id) }
                                    },
                                    onDeleteNotificationsByIds = { ids ->
                                        runGuardedDelete { viewModel.deleteNotificationsByIds(ids) }
                                    },
                                    onDeleteReadOnly = { ids ->
                                        runGuardedDelete { viewModel.deleteReadNotificationsOnly(ids) }
                                    },
                                    onClearAllNotifications = {
                                        runGuardedDelete { viewModel.clearAllNotifications() }
                                    },
                                    onToggleSpeak = viewModel::toggleSpeakNotification,
                                    onSubmitTtsFeedback = viewModel::submitTtsFeedback,
                                    onOpenAppTarget = viewModel::openNotificationTarget,
                                    onOpenListenerSettings = ::openListenerSettings,
                                    onSendTestNotification = { triggerTestNotification(TestNotificationScenario.BANK_OTP) },
                                    onLockNow = viewModel::lockAppNow,
                                    onShowMessage = viewModel::showMessage,
                                    modifier = contentModifier
                                )

                                NotiTrackTab.APPS -> AppsScreen(
                                    allRulesCount = appRules.size,
                                    capturingCount = appRules.count { it.captureEnabled },
                                    ttsActiveCount = appRules.count { it.readAloudEnabled },
                                    filteredRules = filteredAppRules,
                                    allNotifications = allNotifications,
                                    settings = settings,
                                    query = appsQuery,
                                    activeFilter = appsFilter,
                                    onQueryChange = viewModel::updateAppsQuery,
                                    onFilterChange = viewModel::selectAppsFilter,
                                    onUpdateRule = viewModel::updateAppRule,
                                    onSetCaptureAll = viewModel::setCaptureForAllApps,
                                    onShowMessage = viewModel::showMessage,
                                    modifier = contentModifier
                                )

                                NotiTrackTab.FILTERS -> FiltersScreen(
                                    rules = keywordRules,
                                    appRules = appRules,
                                    onSaveRule = viewModel::saveKeywordRule,
                                    onAddPreset = viewModel::addPresetRule,
                                    onToggleRule = viewModel::toggleKeywordRule,
                                    onDeleteRule = viewModel::deleteKeywordRule,
                                    modifier = contentModifier
                                )

                                NotiTrackTab.SETTINGS -> SettingsScreen(
                                    settings = settings,
                                    antiTheftState = antiTheftState,
                                    biometricStatus = biometricStatus,
                                    isListenerEnabled = isListenerEnabled,
                                    isIgnoringBatteryOptimizations = isIgnoringBatteryOptimizations,
                                    hasPostNotificationPermission = hasPostNotifPermission,
                                    hasOverlayPermission = hasOverlayPermission,
                                    activeSubTab = activeSettingsSubTab,
                                    subTabListStates = settingsSubTabListStates,
                                    onSelectSubTab = viewModel::selectSettingsSubTab,
                                    totalSavedCount = allNotifications.size,
                                    unreadSavedCount = totalUnreadCount,
                                    appRulesCount = appRules.size,
                                    keywordRulesCount = keywordRules.size,
                                    ttsFeedbackRules = ttsFeedbackRules,
                                    onSetAppLanguage = viewModel::setAppLanguage,
                                    onToggleChatTimelineGrouping = viewModel::setChatTimelineGroupingEnabled,
                                    onToggleKeepAlive = { enabled ->
                                        if (enabled && !hasPostNotifPermission) {
                                            requestPostNotificationPermission()
                                        }
                                        viewModel.setKeepAliveEnabled(enabled)
                                    },
                                    onToggleKeepAliveTemp = viewModel::setKeepAliveShowTemp,
                                    onToggleKeepAliveLunar = viewModel::setKeepAliveShowLunar,
                                    onToggleKeepAliveCount = viewModel::setKeepAliveShowCount,
                                    onToggleKeepAliveBattery = viewModel::setKeepAliveShowBattery,
                                    onSelectKeepAliveTheme = viewModel::setKeepAliveTheme,
                                    onSetKeepAliveExpandedDefault = viewModel::setKeepAliveExpandedDefault,
                                    onOpenBatterySettings = {
                                        if (!BatteryOptimizationHelper.openBatteryOptimizationSettings(context)) {
                                            viewModel.showMessage(s.msgCannotOpenSettings)
                                        }
                                    },
                                    onOpenAppDetailsSettings = {
                                        if (!BatteryOptimizationHelper.openAppDetailsSettings(context)) {
                                            viewModel.showMessage(s.msgCannotOpenSettings)
                                        }
                                    },
                                    onRebindListener = viewModel::rebindListenerService,
                                    onToggleBiometric = { wantEnable ->
                                        if (wantEnable && biometricStatus.isUsable) {
                                            BiometricAuthHelper.authenticate(
                                                activity = activity,
                                                title = s.lockBiometricEnableTitle,
                                                subtitle = s.lockBiometricEnableSub,
                                                negativeButtonText = s.cancel,
                                                mismatchMessage = s.biometricMismatchMsg,
                                                onSuccess = { viewModel.setBiometricEnabled(true) },
                                                onFailureOrCancel = { err -> viewModel.showMessage(err) }
                                            )
                                        } else if (!wantEnable) {
                                            if (biometricStatus.isUsable) {
                                                BiometricAuthHelper.authenticate(
                                                    activity = activity,
                                                    title = s.lockBiometricDisableTitle,
                                                    subtitle = s.lockBiometricDisableSub,
                                                    negativeButtonText = s.cancel,
                                                    mismatchMessage = s.biometricMismatchMsg,
                                                    onSuccess = { viewModel.setBiometricEnabled(false) },
                                                    onFailureOrCancel = { err -> viewModel.showMessage(err) }
                                                )
                                            } else {
                                                viewModel.setBiometricEnabled(false)
                                            }
                                        } else {
                                            viewModel.showMessage(
                                                s.biometricStatusMessages[biometricStatus] ?: biometricStatus.messageVi
                                            )
                                        }
                                    },
                                    onSavePin = viewModel::setPin,
                                    onToggleFlagSecure = viewModel::setFlagSecure,
                                    onToggleRequireAuthOnDelete = viewModel::setRequireAuthOnDelete,
                                    onSetAutoLockSeconds = viewModel::setAutoLockSeconds,
                                    onLockNow = viewModel::lockAppNow,
                                    onToggleTtsGlobal = viewModel::setTtsGlobalEnabled,
                                    onSetTtsSpeechRate = viewModel::setTtsSpeechRate,
                                    onToggleTtsIncludeApp = viewModel::setTtsIncludeAppName,
                                    onToggleTtsSmartFilter = viewModel::setTtsSmartFilterGlobal,
                                    onToggleTtsHideBalance = viewModel::setTtsHideBalanceGlobal,
                                    onToggleTtsScreenOffOnly = viewModel::setTtsOnlyWhenScreenOff,
                                    onSetTtsNumericRatioPercent = viewModel::setTtsNumericRatioPercent,
                                    onToggleFeedbackRule = viewModel::toggleTtsFeedbackRule,
                                    onDeleteFeedbackRule = viewModel::deleteTtsFeedbackRule,
                                    onClearAllFeedbackRules = viewModel::clearAllTtsFeedbackRules,
                                    onToggleTtsOverrideVolume = viewModel::setTtsOverrideVolumeEnabled,
                                    onToggleTtsBypassSilent = viewModel::setTtsBypassSilentMode,
                                    onSetTtsCustomVolumePercent = viewModel::setTtsCustomVolumePercent,
                                    onSetTtsDelayBetweenMs = viewModel::setTtsDelayBetweenMs,
                                    onSpeakSample = viewModel::speakSampleVoice,
                                    onToggleCaptureNewApps = viewModel::setCaptureNewAppsByDefault,
                                    onSetRetentionDays = viewModel::setRetentionDays,
                                    onSetThemeMode = viewModel::setThemeMode,
                                    onSetArtTheme = viewModel::setArtTheme,
                                    onUpdateUtilities = viewModel::updateUtilitiesSettings,
                                    onPickUtilitySound = ::launchUtilitySoundPicker,
                                    onTestUtilityAlert = ::triggerUtilityTest,
                                    onRequestPostNotificationPermission = ::requestPostNotificationPermission,
                                    onRequestOverlayPermission = ::openOverlayPermissionSettings,
                                    onRequestToggleMotionGuard = ::handleMotionGuardToggle,
                                    onRequestAuthorizeMotionSettings = { onAuthorized ->
                                        pendingAuthAction = PendingAuthAction(
                                            title = s.utilities.motionAuthTitle,
                                            subtitle = s.utilities.motionAuthDesc,
                                            onAuthorized = onAuthorized
                                        )
                                    },
                                    onOpenListenerSettings = ::openListenerSettings,
                                    onExportNotifications = {
                                        viewModel.generateExportText { exportText ->
                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_SUBJECT, "${s.appName} Log")
                                                putExtra(Intent.EXTRA_TEXT, exportText)
                                            }
                                            context.startActivity(
                                                Intent.createChooser(shareIntent, s.exportAction)
                                            )
                                        }
                                    },
                                    onRequestExportBackupJson = { selection ->
                                        pendingBackupSelection = selection
                                        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                                        backupCreateDocLauncher.launch("NotiTrack_Backup_$stamp.json")
                                    },
                                    onRequestImportBackupJson = {
                                        restoreOpenDocLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                                    },
                                    onSendTestScenario = ::triggerTestNotification,
                                    onDeleteReadOnly = {
                                        runGuardedDelete { viewModel.deleteReadNotificationsOnly(null) }
                                    },
                                    onClearAllNotifications = {
                                        runGuardedDelete { viewModel.clearAllNotifications() }
                                    },
                                    onShowMessage = viewModel::showMessage,
                                    modifier = contentModifier
                                )
                            }
                        }
                    }
                }
            }

            pendingRestorePreview?.let { preview ->
                BackupRestoreConfirmDialog(
                    preview = preview,
                    onDismiss = { pendingRestorePreview = null },
                    onConfirmRestore = { mode ->
                        pendingRestorePreview = null
                        viewModel.restoreBackup(preview.payload, mode)
                    }
                )
            }

            pendingAuthAction?.let { authReq ->
                ActionAuthGuardDialog(
                    title = authReq.title,
                    subtitle = authReq.subtitle,
                    biometricAllowed = settings.biometricEnabled && biometricStatus.isUsable,
                    hasPinConfigured = settings.hasPinConfigured,
                    onRequestBiometric = {
                        BiometricAuthHelper.authenticate(
                            activity = activity,
                            title = authReq.title,
                            subtitle = authReq.subtitle,
                            negativeButtonText = s.cancel,
                            mismatchMessage = s.biometricMismatchMsg,
                            onSuccess = {
                                val callback = authReq.onAuthorized
                                pendingAuthAction = null
                                callback()
                            },
                            onFailureOrCancel = { err -> viewModel.showMessage(err) }
                        )
                    },
                    onVerifyPin = { pin, resultCb ->
                        viewModel.verifyPinOnly(pin) { ok ->
                            resultCb(ok)
                            if (ok) {
                                val callback = authReq.onAuthorized
                                pendingAuthAction = null
                                callback()
                            }
                        }
                    },
                    onDismiss = { pendingAuthAction = null }
                )
            }

            if (showQuickMotionPinNotice) {
                AlertDialog(
                    onDismissRequest = { showQuickMotionPinNotice = false },
                    icon = {
                        Icon(Icons.Filled.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    },
                    title = { Text(s.antiTheftNeedPinTitle, fontWeight = FontWeight.Bold) },
                    text = { Text(s.antiTheftNeedPinDesc, style = MaterialTheme.typography.bodyMedium) },
                    confirmButton = {
                        Button(
                            onClick = {
                                showQuickMotionPinNotice = false
                                showQuickMotionPinDialog = true
                            }
                        ) {
                            Text(s.pinSetupAction)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showQuickMotionPinNotice = false }) {
                            Text(s.cancel)
                        }
                    }
                )
            }

            if (showQuickMotionPinDialog) {
                ConfigurePinDialog(
                    hasExistingPin = settings.hasPinConfigured,
                    onDismiss = { showQuickMotionPinDialog = false },
                    onSave = { newPin ->
                        viewModel.setPin(newPin)
                        showQuickMotionPinDialog = false
                        if (newPin.length == 4) {
                            viewModel.setMotionGuardEnabled(true)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun NavTabIcon(
    dest: NavDestination,
    label: String,
    selected: Boolean,
    unreadCount: Int
) {
    val icon = if (selected) dest.selectedIcon else dest.unselectedIcon
    if (unreadCount > 0) {
        BadgedBox(
            badge = {
                Badge {
                    Text(if (unreadCount > 99) "99+" else unreadCount.toString())
                }
            }
        ) {
            Icon(imageVector = icon, contentDescription = label)
        }
    } else {
        Icon(imageVector = icon, contentDescription = label)
    }
}
