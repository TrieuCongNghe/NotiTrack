package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AppRuleEntity
import com.example.data.model.KeywordAction
import com.example.data.model.KeywordRuleEntity
import com.example.engine.KeywordFilterEngine
import com.example.ui.components.AppIconAvatar
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassSwitch
import com.example.ui.components.KeywordActionBadge
import com.example.ui.components.NotiTrackSearchBar
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.viewmodel.KeywordPreset

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FiltersScreen(
    rules: List<KeywordRuleEntity>,
    appRules: List<AppRuleEntity>,
    onSaveRule: (
        existingId: Long?,
        keywords: String,
        action: KeywordAction,
        targetPackage: String?,
        targetAppName: String?,
        isCaseSensitive: Boolean,
        isRegex: Boolean
    ) -> Unit,
    onAddPreset: (KeywordPreset) -> Unit,
    onToggleRule: (KeywordRuleEntity, Boolean) -> Unit,
    onDeleteRule: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val s = LocalAppStrings.current
    var editingRule by remember { mutableStateOf<KeywordRuleEntity?>(null) }
    var showRuleDialog by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = s.filtersTitle,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = s.filtersSubtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = s.filtersPresetsTitle,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(s.keywordPresets) { preset ->
                    AssistChip(
                        onClick = { onAddPreset(preset) },
                        label = { Text(preset.titleVi, style = MaterialTheme.typography.labelLarge) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Add,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        modifier = Modifier.testTag("preset_chip_${preset.action.name.lowercase()}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 92.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (rules.isEmpty()) {
                    item(key = "empty_filters") {
                        GlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.FilterAlt,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = s.filtersEmptyTitle,
                                    style = MaterialTheme.typography.titleLarge
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = s.filtersEmptyDesc,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(rules, key = { it.id }) { rule ->
                        KeywordRuleCard(
                            rule = rule,
                            onToggle = { enabled -> onToggleRule(rule, enabled) },
                            onEdit = {
                                editingRule = rule
                                showRuleDialog = true
                            },
                            onDelete = { onDeleteRule(rule.id) }
                        )
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = {
                editingRule = null
                showRuleDialog = true
            },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text(s.filtersAddRule) },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("add_keyword_rule_fab")
        )
    }

    if (showRuleDialog) {
        AddEditKeywordRuleDialog(
            initialRule = editingRule,
            appRules = appRules,
            onDismiss = { showRuleDialog = false },
            onSave = { keywords, action, targetPkg, targetAppName, caseSensitive, isRegex ->
                onSaveRule(
                    editingRule?.id,
                    keywords,
                    action,
                    targetPkg,
                    targetAppName,
                    caseSensitive,
                    isRegex
                )
                showRuleDialog = false
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun KeywordRuleCard(
    rule: KeywordRuleEntity,
    onToggle: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val s = LocalAppStrings.current
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("keyword_rule_card_${rule.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                KeywordActionBadge(action = rule.action)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = rule.targetAppName ?: s.filtersScopeAll,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                GlassSwitch(
                    checked = rule.isEnabled,
                    onCheckedChange = onToggle,
                    modifier = Modifier.testTag("keyword_rule_switch_${rule.id}")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            val tokens = if (rule.isRegex) {
                listOf("Regex: ${rule.keywords}")
            } else {
                rule.keywords.split(",", ";", "\n").map { it.trim() }.filter { it.isNotEmpty() }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                tokens.forEach { token ->
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = token,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = s.filtersMatchCount(rule.matchCount),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.testTag("edit_keyword_rule_${rule.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Edit,
                        contentDescription = s.edit,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("delete_keyword_rule_${rule.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = s.delete,
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
private fun AddEditKeywordRuleDialog(
    initialRule: KeywordRuleEntity?,
    appRules: List<AppRuleEntity>,
    onDismiss: () -> Unit,
    onSave: (String, KeywordAction, String?, String?, Boolean, Boolean) -> Unit
) {
    val s = LocalAppStrings.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    var keywords by remember(initialRule) { mutableStateOf(initialRule?.keywords.orEmpty()) }
    var action by remember(initialRule) { mutableStateOf(initialRule?.action ?: KeywordAction.HIGHLIGHT) }
    var targetPackage by remember(initialRule) { mutableStateOf(initialRule?.targetPackage) }
    var targetAppName by remember(initialRule) { mutableStateOf(initialRule?.targetAppName) }
    var isCaseSensitive by remember(initialRule) { mutableStateOf(initialRule?.isCaseSensitive ?: false) }
    var isRegex by remember(initialRule) { mutableStateOf(initialRule?.isRegex ?: false) }
    var appMenuExpanded by remember { mutableStateOf(false) }

    fun clearIme() {
        focusManager.clearFocus(force = true)
        keyboardController?.hide()
    }

    DisposableEffect(Unit) {
        onDispose {
            keyboardController?.hide()
        }
    }

    val regexValid = !isRegex || KeywordFilterEngine.isValidRegex(keywords)
    val canSave = keywords.isNotBlank() && regexValid

    AlertDialog(
        onDismissRequest = {
            clearIme()
            onDismiss()
        },
        title = {
            Text(
                text = if (initialRule == null) s.filtersDialogCreate else s.filtersDialogEdit,
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = keywords,
                    onValueChange = { keywords = it },
                    label = { Text(s.filtersKeywordLabel) },
                    placeholder = { Text(s.filtersKeywordPlaceholder) },
                    isError = isRegex && keywords.isNotBlank() && !regexValid,
                    supportingText = {
                        if (isRegex && keywords.isNotBlank() && !regexValid) {
                            Text(s.filtersRegexInvalid)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_keyword_input")
                )

                Text(
                    text = s.filtersActionPrompt,
                    style = MaterialTheme.typography.labelLarge
                )

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    KeywordAction.entries.forEach { option ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { action = option }
                                .padding(vertical = 4.dp)
                                .testTag("dialog_action_${option.name.lowercase()}"),
                            verticalAlignment = Alignment.Top
                        ) {
                            RadioButton(
                                selected = action == option,
                                onClick = { action = option }
                            )
                            Column(modifier = Modifier.padding(top = 8.dp)) {
                                Text(
                                    text = s.keywordActionLabel[option] ?: option.labelVi,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = s.keywordActionDesc[option] ?: option.descriptionVi,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                OutlinedButton(
                    onClick = {
                        clearIme()
                        appMenuExpanded = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dialog_scope_picker_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Apps,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${s.filtersScopePrefix}: ${targetAppName ?: s.filtersScopeAll}",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { isCaseSensitive = !isCaseSensitive }
                ) {
                    Checkbox(checked = isCaseSensitive, onCheckedChange = { isCaseSensitive = it })
                    Text(s.filtersCaseSensitive, style = MaterialTheme.typography.bodyMedium)
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { isRegex = !isRegex }
                ) {
                    Checkbox(checked = isRegex, onCheckedChange = { isRegex = it })
                    Text(s.filtersUseRegex, style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    clearIme()
                    onSave(keywords, action, targetPackage, targetAppName, isCaseSensitive, isRegex)
                },
                enabled = canSave,
                modifier = Modifier.testTag("dialog_save_keyword_button")
            ) {
                Text(s.save)
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    clearIme()
                    onDismiss()
                }
            ) {
                Text(s.cancel)
            }
        }
    )

    if (appMenuExpanded) {
        AppScopePickerDialog(
            appRules = appRules,
            selectedPackage = targetPackage,
            onDismiss = { appMenuExpanded = false },
            onSelectAll = {
                targetPackage = null
                targetAppName = null
                appMenuExpanded = false
            },
            onSelectApp = { app ->
                targetPackage = app.packageName
                targetAppName = app.appName
                appMenuExpanded = false
            }
        )
    }
}

@Composable
private fun AppScopePickerDialog(
    appRules: List<AppRuleEntity>,
    selectedPackage: String?,
    onDismiss: () -> Unit,
    onSelectAll: () -> Unit,
    onSelectApp: (AppRuleEntity) -> Unit
) {
    val s = LocalAppStrings.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    var searchQuery by remember { mutableStateOf("") }

    fun clearIme() {
        focusManager.clearFocus(force = true)
        keyboardController?.hide()
    }

    DisposableEffect(Unit) {
        onDispose {
            keyboardController?.hide()
        }
    }

    val filteredApps = remember(appRules, searchQuery) {
        val q = searchQuery.trim()
        if (q.isEmpty()) appRules
        else appRules.filter {
            it.appName.contains(q, ignoreCase = true) ||
                it.packageName.contains(q, ignoreCase = true)
        }
    }

    AlertDialog(
        onDismissRequest = {
            clearIme()
            onDismiss()
        },
        title = {
            Text(
                text = s.filtersAppPickerTitle,
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                NotiTrackSearchBar(
                    query = searchQuery,
                    placeholder = s.filtersAppPickerSearchHint,
                    onQueryChange = { searchQuery = it },
                    testTag = "app_scope_picker_search"
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (searchQuery.isBlank()) {
                        item(key = "scope_all_apps") {
                            val isSelected = selectedPackage == null
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        clearIme()
                                        onSelectAll()
                                    }
                                    .padding(horizontal = 8.dp, vertical = 10.dp)
                                    .testTag("app_scope_option_all"),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Apps,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "${s.filtersScopeAll} (${appRules.size})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        }
                    }

                    items(filteredApps, key = { it.packageName }) { app ->
                        val isSelected = selectedPackage == app.packageName
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    clearIme()
                                    onSelectApp(app)
                                }
                                .padding(horizontal = 8.dp, vertical = 8.dp)
                                .testTag("app_scope_option_${app.packageName}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIconAvatar(
                                packageName = app.packageName,
                                appName = app.appName,
                                size = 34.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = app.appName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = app.packageName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (isSelected) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(
                                    imageVector = Icons.Filled.Check,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    clearIme()
                    onDismiss()
                }
            ) {
                Text(s.close)
            }
        }
    )
}
