package com.example.ui.theme

import androidx.annotation.DrawableRes
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R

enum class AppArtTheme(
    val titleVi: String,
    val titleEn: String,
    val subtitleVi: String,
    val subtitleEn: String,
    @DrawableRes val artDrawableRes: Int,
    val previewPrimaryHex: Long,
    val previewAccentHex: Long,
    val previewBgHex: Long,
    val cardCornerDp: Int,
    val pillCornerDp: Int
) {
    JADE(
        titleVi = "Ngọc Bích",
        titleEn = "Jade Vault",
        subtitleVi = "Vân ngọc sâu & ánh vàng kim",
        subtitleEn = "Deep jade silk & champagne gold",
        artDrawableRes = R.drawable.img_theme_jade,
        previewPrimaryHex = 0xFF3FE6BC,
        previewAccentHex = 0xFFF6B94D,
        previewBgHex = 0xFF07231C,
        cardCornerDp = 18,
        pillCornerDp = 16
    ),
    AURORA(
        titleVi = "Cực Quang",
        titleEn = "Aurora Night",
        subtitleVi = "Đêm phương Bắc & dải cực quang",
        subtitleEn = "Midnight cosmos & emerald aurora",
        artDrawableRes = R.drawable.img_theme_aurora,
        previewPrimaryHex = 0xFF22D3EE,
        previewAccentHex = 0xFFC084FC,
        previewBgHex = 0xFF0A102E,
        cardCornerDp = 20,
        pillCornerDp = 20
    ),
    SAKURA(
        titleVi = "Anh Đào",
        titleEn = "Sakura Blossom",
        subtitleVi = "Cánh hoa dịu dàng & ánh hồng sương",
        subtitleEn = "Blush sakura petals & soft twilight",
        artDrawableRes = R.drawable.img_theme_sakura,
        previewPrimaryHex = 0xFFF472B6,
        previewAccentHex = 0xFFFDA4AF,
        previewBgHex = 0xFF3B1534,
        cardCornerDp = 24,
        pillCornerDp = 24
    ),
    CYBERPUNK(
        titleVi = "Cyberpunk",
        titleEn = "Cyberpunk Neon",
        subtitleVi = "Ánh sáng Cyan & Magenta tương lai",
        subtitleEn = "Electric cyan & neon magenta",
        artDrawableRes = R.drawable.img_theme_cyberpunk,
        previewPrimaryHex = 0xFF00F0FF,
        previewAccentHex = 0xFFFF2A85,
        previewBgHex = 0xFF100826,
        cardCornerDp = 12,
        pillCornerDp = 10
    ),
    SUNSET(
        titleVi = "Hoàng Hôn",
        titleEn = "Ocean Sunset",
        subtitleVi = "Biển chiều san hô & ánh vàng ấm",
        subtitleEn = "Coral horizon & glassy ocean glow",
        artDrawableRes = R.drawable.img_theme_sunset,
        previewPrimaryHex = 0xFFFF9F68,
        previewAccentHex = 0xFFFDE68A,
        previewBgHex = 0xFF28163A,
        cardCornerDp = 20,
        pillCornerDp = 18
    ),
    CRYSTAL(
        titleVi = "Pha Lê",
        titleEn = "Crystal Frost",
        subtitleVi = "Pha lê băng trong suốt & ánh bạc",
        subtitleEn = "Glacial ice refraction & pearl silver",
        artDrawableRes = R.drawable.img_theme_crystal,
        previewPrimaryHex = 0xFF38BDF8,
        previewAccentHex = 0xFFBAE6FD,
        previewBgHex = 0xFF0F2740,
        cardCornerDp = 16,
        pillCornerDp = 14
    );

    companion object {
        fun fromName(raw: String?): AppArtTheme {
            if (raw.isNullOrBlank()) return JADE
            return entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: JADE
        }
    }
}

@Immutable
data class GlassStyleSpec(
    val artTheme: AppArtTheme,
    val isDark: Boolean,
    val backdropScrimTop: Color,
    val backdropScrimMid: Color,
    val backdropScrimBottom: Color,
    val cardFill: Color,
    val cardElevatedFill: Color,
    val navBarFill: Color,
    val specularTopBorder: Color,
    val cardBorder: Color,
    val pillActiveStart: Color,
    val pillActiveEnd: Color,
    val switchActiveStart: Color,
    val switchActiveEnd: Color,
    val switchInactiveTrack: Color,
    val unreadCardFill: Color,
    val unreadCardBorder: Color,
    val unreadPulseGlow: Color,
    val readCardFill: Color,
    val pinnedCardFill: Color,
    val pinnedCardBorder: Color,
    val highlightedCardFill: Color,
    val highlightedCardBorder: Color,
    val hiddenCardFill: Color,
    val hiddenCardBorder: Color,
    val cardCornerRadius: Dp,
    val pillCornerRadius: Dp
) {
    val cardShape get() = RoundedCornerShape(cardCornerRadius)
    val pillShape get() = RoundedCornerShape(pillCornerRadius)
}

fun buildColorSchemeFor(artTheme: AppArtTheme, dark: Boolean): ColorScheme = when (artTheme) {
    AppArtTheme.JADE -> if (dark) {
        darkColorScheme(
            primary = Color(0xFF4FD8B8),
            onPrimary = Color(0xFF00382C),
            primaryContainer = Color(0xFF0D4E3F),
            onPrimaryContainer = Color(0xFFC8F9EC),
            secondary = Color(0xFFF6B94D),
            onSecondary = Color(0xFF412600),
            secondaryContainer = Color(0xFF5D3A06),
            onSecondaryContainer = Color(0xFFFFE2AE),
            tertiary = Color(0xFF7DD3FC),
            onTertiary = Color(0xFF00334E),
            tertiaryContainer = Color(0xFF124663),
            onTertiaryContainer = Color(0xFFD5F0FF),
            error = Color(0xFFFFB4AB),
            onError = Color(0xFF690005),
            errorContainer = Color(0xFF8C1D18),
            onErrorContainer = Color(0xFFFFDAD6),
            background = Color(0xFF061612),
            onBackground = Color(0xFFECF7F3),
            surface = Color(0xFF0A201A),
            onSurface = Color(0xFFECF7F3),
            surfaceVariant = Color(0xFF143028),
            onSurfaceVariant = Color(0xFFAAC6BC),
            surfaceContainerLowest = Color(0xFF0A1D18),
            surfaceContainerLow = Color(0xFF0E251F),
            surfaceContainer = Color(0xFF132D26),
            surfaceContainerHigh = Color(0xFF1B3A31),
            outline = Color(0xFF5D8075),
            outlineVariant = Color(0xFF274A40)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF0B7A62),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFC5F4E6),
            onPrimaryContainer = Color(0xFF03362B),
            secondary = Color(0xFFB46909),
            onSecondary = Color.White,
            secondaryContainer = Color(0xFFFFE4BE),
            onSecondaryContainer = Color(0xFF3E2100),
            tertiary = Color(0xFF17648A),
            onTertiary = Color.White,
            tertiaryContainer = Color(0xFFCFEAFF),
            onTertiaryContainer = Color(0xFF00253A),
            error = Color(0xFFC43B3B),
            onError = Color.White,
            errorContainer = Color(0xFFFFDAD6),
            onErrorContainer = Color(0xFF410002),
            background = Color(0xFFEAF5F1),
            onBackground = Color(0xFF0E1D19),
            surface = Color(0xFFF3FAF7),
            onSurface = Color(0xFF0E1D19),
            surfaceVariant = Color(0xFFDDECE6),
            onSurfaceVariant = Color(0xFF3E554D),
            surfaceContainerLowest = Color(0xFFFFFFFF),
            surfaceContainerLow = Color(0xFFEFF8F4),
            surfaceContainer = Color(0xFFE4F1EC),
            surfaceContainerHigh = Color(0xFFD8E9E2),
            outline = Color(0xFF6B837B),
            outlineVariant = Color(0xFFC5DCD4)
        )
    }

    AppArtTheme.AURORA -> if (dark) {
        darkColorScheme(
            primary = Color(0xFF38E2D4),
            onPrimary = Color(0xFF003734),
            primaryContainer = Color(0xFF0F4C5C),
            onPrimaryContainer = Color(0xFFCCFBF7),
            secondary = Color(0xFFC084FC),
            onSecondary = Color(0xFF340C59),
            secondaryContainer = Color(0xFF4C1D7A),
            onSecondaryContainer = Color(0xFFF3E4FF),
            tertiary = Color(0xFF60A5FA),
            onTertiary = Color(0xFF042B5E),
            tertiaryContainer = Color(0xFF173D73),
            onTertiaryContainer = Color(0xFFDCEBFF),
            error = Color(0xFFFFB4AB),
            onError = Color(0xFF690005),
            errorContainer = Color(0xFF8C1D18),
            onErrorContainer = Color(0xFFFFDAD6),
            background = Color(0xFF070B1E),
            onBackground = Color(0xFFEBF0FF),
            surface = Color(0xFF0D1430),
            onSurface = Color(0xFFEBF0FF),
            surfaceVariant = Color(0xFF17224A),
            onSurfaceVariant = Color(0xFFA8B5DB),
            surfaceContainerLowest = Color(0xFF0B1128),
            surfaceContainerLow = Color(0xFF111938),
            surfaceContainer = Color(0xFF162148),
            surfaceContainerHigh = Color(0xFF1E2C5C),
            outline = Color(0xFF5D6E9E),
            outlineVariant = Color(0xFF2A396B)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF0C7787),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFC6F3F8),
            onPrimaryContainer = Color(0xFF03313B),
            secondary = Color(0xFF7E3AF2),
            onSecondary = Color.White,
            secondaryContainer = Color(0xFFEDE0FF),
            onSecondaryContainer = Color(0xFF2D0A63),
            tertiary = Color(0xFF2563EB),
            onTertiary = Color.White,
            tertiaryContainer = Color(0xFFDCE7FF),
            onTertiaryContainer = Color(0xFF082466),
            error = Color(0xFFC43B3B),
            onError = Color.White,
            errorContainer = Color(0xFFFFDAD6),
            onErrorContainer = Color(0xFF410002),
            background = Color(0xFFEDF2FC),
            onBackground = Color(0xFF10172C),
            surface = Color(0xFFF5F8FF),
            onSurface = Color(0xFF10172C),
            surfaceVariant = Color(0xFFDFE7FA),
            onSurfaceVariant = Color(0xFF455275),
            surfaceContainerLowest = Color(0xFFFFFFFF),
            surfaceContainerLow = Color(0xFFF0F4FE),
            surfaceContainer = Color(0xFFE5ECFA),
            surfaceContainerHigh = Color(0xFFD8E3F7),
            outline = Color(0xFF6B7AA0),
            outlineVariant = Color(0xFFC6D2EE)
        )
    }

    AppArtTheme.SAKURA -> if (dark) {
        darkColorScheme(
            primary = Color(0xFFFF8BC2),
            onPrimary = Color(0xFF4D0B2D),
            primaryContainer = Color(0xFF6E2049),
            onPrimaryContainer = Color(0xFFFFD8EA),
            secondary = Color(0xFFFBBF24),
            onSecondary = Color(0xFF422800),
            secondaryContainer = Color(0xFF5F3A08),
            onSecondaryContainer = Color(0xFFFFE5A6),
            tertiary = Color(0xFFD8B4FE),
            onTertiary = Color(0xFF39125E),
            tertiaryContainer = Color(0xFF51247A),
            onTertiaryContainer = Color(0xFFF3E4FF),
            error = Color(0xFFFFB4AB),
            onError = Color(0xFF690005),
            errorContainer = Color(0xFF8C1D18),
            onErrorContainer = Color(0xFFFFDAD6),
            background = Color(0xFF1F0C1C),
            onBackground = Color(0xFFFDF0F6),
            surface = Color(0xFF2B1227),
            onSurface = Color(0xFFFDF0F6),
            surfaceVariant = Color(0xFF421E3B),
            onSurfaceVariant = Color(0xFFD7AFC5),
            surfaceContainerLowest = Color(0xFF251021),
            surfaceContainerLow = Color(0xFF31162C),
            surfaceContainer = Color(0xFF3C1C36),
            surfaceContainerHigh = Color(0xFF4C2544),
            outline = Color(0xFF8C627A),
            outlineVariant = Color(0xFF5A314C)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFFC22D74),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFFFD8EA),
            onPrimaryContainer = Color(0xFF490628),
            secondary = Color(0xFFB86314),
            onSecondary = Color.White,
            secondaryContainer = Color(0xFFFFE2C6),
            onSecondaryContainer = Color(0xFF3F1D00),
            tertiary = Color(0xFF7B3FA0),
            onTertiary = Color.White,
            tertiaryContainer = Color(0xFFF2DFFF),
            onTertiaryContainer = Color(0xFF310A4C),
            error = Color(0xFFC43B3B),
            onError = Color.White,
            errorContainer = Color(0xFFFFDAD6),
            onErrorContainer = Color(0xFF410002),
            background = Color(0xFFFDF1F6),
            onBackground = Color(0xFF26121F),
            surface = Color(0xFFFFF7FA),
            onSurface = Color(0xFF26121F),
            surfaceVariant = Color(0xFFF6E2EC),
            onSurfaceVariant = Color(0xFF6A485B),
            surfaceContainerLowest = Color(0xFFFFFFFF),
            surfaceContainerLow = Color(0xFFFDF2F7),
            surfaceContainer = Color(0xFFF7E7EF),
            surfaceContainerHigh = Color(0xFFEFD9E4),
            outline = Color(0xFF957084),
            outlineVariant = Color(0xFFE5C8D8)
        )
    }

    AppArtTheme.CYBERPUNK -> if (dark) {
        darkColorScheme(
            primary = Color(0xFF00F0FF),
            onPrimary = Color(0xFF003238),
            primaryContainer = Color(0xFF064857),
            onPrimaryContainer = Color(0xFFC5FAFF),
            secondary = Color(0xFFFF4D9E),
            onSecondary = Color(0xFF4E0024),
            secondaryContainer = Color(0xFF730E40),
            onSecondaryContainer = Color(0xFFFFD7E8),
            tertiary = Color(0xFFA855F7),
            onTertiary = Color(0xFF2F005A),
            tertiaryContainer = Color(0xFF4B147C),
            onTertiaryContainer = Color(0xFFF1DDFF),
            error = Color(0xFFFF6B81),
            onError = Color(0xFF4F0010),
            errorContainer = Color(0xFF7F1227),
            onErrorContainer = Color(0xFFFFD9DF),
            background = Color(0xFF080617),
            onBackground = Color(0xFFECEBFF),
            surface = Color(0xFF110C29),
            onSurface = Color(0xFFECEBFF),
            surfaceVariant = Color(0xFF1D1542),
            onSurfaceVariant = Color(0xFFB3AAD8),
            surfaceContainerLowest = Color(0xFF0D0921),
            surfaceContainerLow = Color(0xFF140F31),
            surfaceContainer = Color(0xFF1B1540),
            surfaceContainerHigh = Color(0xFF251E54),
            outline = Color(0xFF6C639E),
            outlineVariant = Color(0xFF342A69)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF007B8F),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFC4F5FD),
            onPrimaryContainer = Color(0xFF00313A),
            secondary = Color(0xFFD11B71),
            onSecondary = Color.White,
            secondaryContainer = Color(0xFFFFD8E8),
            onSecondaryContainer = Color(0xFF4B0023),
            tertiary = Color(0xFF7C3AED),
            onTertiary = Color.White,
            tertiaryContainer = Color(0xFFECE0FF),
            onTertiaryContainer = Color(0xFF2A0666),
            error = Color(0xFFC82848),
            onError = Color.White,
            errorContainer = Color(0xFFFFD9DF),
            onErrorContainer = Color(0xFF460010),
            background = Color(0xFFF0EFFC),
            onBackground = Color(0xFF14112B),
            surface = Color(0xFFF7F6FF),
            onSurface = Color(0xFF14112B),
            surfaceVariant = Color(0xFFE4E1FA),
            onSurfaceVariant = Color(0xFF4E4973),
            surfaceContainerLowest = Color(0xFFFFFFFF),
            surfaceContainerLow = Color(0xFFF3F1FE),
            surfaceContainer = Color(0xFFE9E6FA),
            surfaceContainerHigh = Color(0xFFDDD8F6),
            outline = Color(0xFF75709C),
            outlineVariant = Color(0xFFCCC6EC)
        )
    }

    AppArtTheme.SUNSET -> if (dark) {
        darkColorScheme(
            primary = Color(0xFFFFA36C),
            onPrimary = Color(0xFF4A1B00),
            primaryContainer = Color(0xFF6E2D0F),
            onPrimaryContainer = Color(0xFFFFE0CC),
            secondary = Color(0xFFFDE047),
            onSecondary = Color(0xFF3D3100),
            secondaryContainer = Color(0xFF5B4A04),
            onSecondaryContainer = Color(0xFFFFF3B0),
            tertiary = Color(0xFFF472B6),
            onTertiary = Color(0xFF4A0D31),
            tertiaryContainer = Color(0xFF6C1F4A),
            onTertiaryContainer = Color(0xFFFFD8EB),
            error = Color(0xFFFFB4AB),
            onError = Color(0xFF690005),
            errorContainer = Color(0xFF8C1D18),
            onErrorContainer = Color(0xFFFFDAD6),
            background = Color(0xFF130E24),
            onBackground = Color(0xFFFDF2EC),
            surface = Color(0xFF1E1636),
            onSurface = Color(0xFFFDF2EC),
            surfaceVariant = Color(0xFF30224E),
            onSurfaceVariant = Color(0xFFCBBBD8),
            surfaceContainerLowest = Color(0xFF18112D),
            surfaceContainerLow = Color(0xFF22193C),
            surfaceContainer = Color(0xFF2B204B),
            surfaceContainerHigh = Color(0xFF37295E),
            outline = Color(0xFF7F6B99),
            outlineVariant = Color(0xFF46356A)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFFC94B24),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFFFDDD1),
            onPrimaryContainer = Color(0xFF471100),
            secondary = Color(0xFFA86805),
            onSecondary = Color.White,
            secondaryContainer = Color(0xFFFFE7B8),
            onSecondaryContainer = Color(0xFF3B2100),
            tertiary = Color(0xFF9F2A65),
            onTertiary = Color.White,
            tertiaryContainer = Color(0xFFFFD8E8),
            onTertiaryContainer = Color(0xFF420624),
            error = Color(0xFFC43B3B),
            onError = Color.White,
            errorContainer = Color(0xFFFFDAD6),
            onErrorContainer = Color(0xFF410002),
            background = Color(0xFFFDF3EE),
            onBackground = Color(0xFF23161F),
            surface = Color(0xFFFFF8F5),
            onSurface = Color(0xFF23161F),
            surfaceVariant = Color(0xFFF5E3DC),
            onSurfaceVariant = Color(0xFF634D56),
            surfaceContainerLowest = Color(0xFFFFFFFF),
            surfaceContainerLow = Color(0xFFFDF3EE),
            surfaceContainer = Color(0xFFF5E6DF),
            surfaceContainerHigh = Color(0xFFECD8CF),
            outline = Color(0xFF8E747E),
            outlineVariant = Color(0xFFE0C8C0)
        )
    }

    AppArtTheme.CRYSTAL -> if (dark) {
        darkColorScheme(
            primary = Color(0xFF7DD3FC),
            onPrimary = Color(0xFF00324D),
            primaryContainer = Color(0xFF0E4B70),
            onPrimaryContainer = Color(0xFFD9F3FF),
            secondary = Color(0xFFE2E8F0),
            onSecondary = Color(0xFF1E293B),
            secondaryContainer = Color(0xFF334155),
            onSecondaryContainer = Color(0xFFF1F5F9),
            tertiary = Color(0xFF5EEAD4),
            onTertiary = Color(0xFF003830),
            tertiaryContainer = Color(0xFF0F4E46),
            onTertiaryContainer = Color(0xFFCCFBF1),
            error = Color(0xFFFFB4AB),
            onError = Color(0xFF690005),
            errorContainer = Color(0xFF8C1D18),
            onErrorContainer = Color(0xFFFFDAD6),
            background = Color(0xFF091422),
            onBackground = Color(0xFFEDF6FF),
            surface = Color(0xFF102033),
            onSurface = Color(0xFFEDF6FF),
            surfaceVariant = Color(0xFF1B314A),
            onSurfaceVariant = Color(0xFFADC4DB),
            surfaceContainerLowest = Color(0xFF0C1A2B),
            surfaceContainerLow = Color(0xFF12243A),
            surfaceContainer = Color(0xFF182F4B),
            surfaceContainerHigh = Color(0xFF213D5F),
            outline = Color(0xFF64809E),
            outlineVariant = Color(0xFF2B486A)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF026AA7),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFD0EEFF),
            onPrimaryContainer = Color(0xFF002741),
            secondary = Color(0xFF475569),
            onSecondary = Color.White,
            secondaryContainer = Color(0xFFE2E8F0),
            onSecondaryContainer = Color(0xFF0F172A),
            tertiary = Color(0xFF0D7C72),
            onTertiary = Color.White,
            tertiaryContainer = Color(0xFFC5F5EE),
            onTertiaryContainer = Color(0xFF02342F),
            error = Color(0xFFC43B3B),
            onError = Color.White,
            errorContainer = Color(0xFFFFDAD6),
            onErrorContainer = Color(0xFF410002),
            background = Color(0xFFEDF6FC),
            onBackground = Color(0xFF0D1D2C),
            surface = Color(0xFFF6FBFF),
            onSurface = Color(0xFF0D1D2C),
            surfaceVariant = Color(0xFFDFEDF7),
            onSurfaceVariant = Color(0xFF415B72),
            surfaceContainerLowest = Color(0xFFFFFFFF),
            surfaceContainerLow = Color(0xFFF0F8FE),
            surfaceContainer = Color(0xFFE3F1FA),
            surfaceContainerHigh = Color(0xFFD4E7F5),
            outline = Color(0xFF68839B),
            outlineVariant = Color(0xFFC2D9EA)
        )
    }
}

fun buildGlassStyleFor(artTheme: AppArtTheme, scheme: ColorScheme, dark: Boolean): GlassStyleSpec {
    val primary = scheme.primary
    val secondary = scheme.secondary
    return if (dark) {
        GlassStyleSpec(
            artTheme = artTheme,
            isDark = true,
            backdropScrimTop = Color(artTheme.previewBgHex).copy(alpha = 0.50f),
            backdropScrimMid = Color(artTheme.previewBgHex).copy(alpha = 0.62f),
            backdropScrimBottom = Color(artTheme.previewBgHex).copy(alpha = 0.78f),
            cardFill = scheme.surfaceContainerLow.copy(alpha = 0.76f),
            cardElevatedFill = scheme.surfaceContainer.copy(alpha = 0.84f),
            navBarFill = scheme.surfaceContainerLowest.copy(alpha = 0.86f),
            specularTopBorder = Color.White.copy(alpha = 0.24f),
            cardBorder = primary.copy(alpha = 0.22f),
            pillActiveStart = primary.copy(alpha = 0.92f),
            pillActiveEnd = secondary.copy(alpha = 0.82f),
            switchActiveStart = primary,
            switchActiveEnd = secondary,
            switchInactiveTrack = Color.White.copy(alpha = 0.16f),
            unreadCardFill = scheme.primaryContainer.copy(alpha = 0.72f),
            unreadCardBorder = primary.copy(alpha = 0.88f),
            unreadPulseGlow = Color.White.copy(alpha = 0.78f),
            readCardFill = scheme.surfaceContainerLowest.copy(alpha = 0.56f),
            pinnedCardFill = Color(0xFF4A3206).copy(alpha = 0.78f),
            pinnedCardBorder = Color(0xFFFFC13B).copy(alpha = 0.85f),
            highlightedCardFill = scheme.secondaryContainer.copy(alpha = 0.78f),
            highlightedCardBorder = secondary.copy(alpha = 0.88f),
            hiddenCardFill = Color(0xFF23163D).copy(alpha = 0.82f),
            hiddenCardBorder = Color(0xFFA78BFA).copy(alpha = 0.78f),
            cardCornerRadius = artTheme.cardCornerDp.dp,
            pillCornerRadius = artTheme.pillCornerDp.dp
        )
    } else {
        GlassStyleSpec(
            artTheme = artTheme,
            isDark = false,
            backdropScrimTop = scheme.background.copy(alpha = 0.74f),
            backdropScrimMid = scheme.background.copy(alpha = 0.80f),
            backdropScrimBottom = scheme.background.copy(alpha = 0.88f),
            cardFill = Color.White.copy(alpha = 0.78f),
            cardElevatedFill = Color.White.copy(alpha = 0.88f),
            navBarFill = Color.White.copy(alpha = 0.86f),
            specularTopBorder = Color.White.copy(alpha = 0.92f),
            cardBorder = primary.copy(alpha = 0.22f),
            pillActiveStart = primary,
            pillActiveEnd = secondary.copy(alpha = 0.88f),
            switchActiveStart = primary,
            switchActiveEnd = secondary,
            switchInactiveTrack = scheme.outlineVariant.copy(alpha = 0.75f),
            unreadCardFill = scheme.primaryContainer.copy(alpha = 0.84f),
            unreadCardBorder = primary.copy(alpha = 0.82f),
            unreadPulseGlow = primary,
            readCardFill = Color.White.copy(alpha = 0.66f),
            pinnedCardFill = Color(0xFFFFEFC7).copy(alpha = 0.92f),
            pinnedCardBorder = Color(0xFFD97706).copy(alpha = 0.82f),
            highlightedCardFill = scheme.secondaryContainer.copy(alpha = 0.90f),
            highlightedCardBorder = secondary.copy(alpha = 0.82f),
            hiddenCardFill = Color(0xFFEDE6FA).copy(alpha = 0.90f),
            hiddenCardBorder = Color(0xFF7C3AED).copy(alpha = 0.72f),
            cardCornerRadius = artTheme.cardCornerDp.dp,
            pillCornerRadius = artTheme.pillCornerDp.dp
        )
    }
}

val LocalGlassStyle = staticCompositionLocalOf<GlassStyleSpec> {
    val scheme = buildColorSchemeFor(AppArtTheme.JADE, dark = true)
    buildGlassStyleFor(AppArtTheme.JADE, scheme, dark = true)
}
