package com.example.ui.screens

import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DeviceThermostat
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.prefs.KeepAliveNotifTheme
import com.example.data.prefs.NotiTrackSettings
import com.example.engine.VietnameseLunarCalendar
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassSwitch
import com.example.ui.i18n.LocalAppStrings
import kotlin.math.roundToInt

@Composable
fun SettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String,
    enabled: Boolean = true,
    leadingIcon: ImageVector? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leadingIcon != null) {
            Icon(
                imageVector = leadingIcon,
                contentDescription = null,
                tint = if (enabled) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f),
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = if (enabled) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.48f)
            )
            if (subtitle.isNotBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(modifier = Modifier.width(10.dp))
        GlassSwitch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsKeepAliveCard(
    settings: NotiTrackSettings,
    unreadCount: Int,
    isIgnoringBatteryOptimizations: Boolean,
    onToggleKeepAlive: (Boolean) -> Unit,
    onToggleShowTemp: (Boolean) -> Unit,
    onToggleShowLunar: (Boolean) -> Unit,
    onToggleShowCount: (Boolean) -> Unit,
    onToggleShowBattery: (Boolean) -> Unit,
    onSelectTheme: (KeepAliveNotifTheme) -> Unit,
    onSetExpandedDefault: (Boolean) -> Unit,
    onOpenBatterySettings: () -> Unit,
    onOpenAppDetailsSettings: () -> Unit,
    onRebindListener: () -> Unit
) {
    val s = LocalAppStrings.current
    val u = s.utilities
    val context = LocalContext.current

    val liveTelemetry = remember {
        val batteryIntent = runCatching {
            context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        }.getOrNull()
        val rawTemp = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 320) ?: 320
        val tempC = (rawTemp / 10f).coerceIn(0f, 99f).roundToInt()
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, 80) ?: 80
        val scale = (batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).coerceAtLeast(1)
        val pct = ((level * 100f) / scale).roundToInt().coerceIn(0, 100)
        val lunar = VietnameseLunarCalendar.today().formatDdMmYyyy()
        Triple(tempC, pct, lunar)
    }

    SettingsCard(title = s.sectionPersistence) {
        SettingSwitchRow(
            title = s.keepAliveTitle,
            subtitle = s.keepAliveDesc,
            checked = settings.keepAliveEnabled,
            onCheckedChange = onToggleKeepAlive,
            testTag = "keep_alive_switch",
            leadingIcon = Icons.Filled.Bolt
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Live preview of the styled persistent status bar notification
        val shortLunar = remember { VietnameseLunarCalendar.today().formatShort() }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(settings.keepAliveTheme.startColorHex),
                            Color(settings.keepAliveTheme.endColorHex)
                        )
                    )
                )
                .padding(horizontal = 12.dp, vertical = if (settings.keepAliveExpandedDefault) 10.dp else 9.dp)
                .testTag("keep_alive_live_preview")
        ) {
            val anyItemVisible = settings.keepAliveShowTemp || settings.keepAliveShowLunar ||
                settings.keepAliveShowCount || settings.keepAliveShowBattery
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                if (settings.keepAliveExpandedDefault) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_notitrack_art),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(20.dp)
                                .clip(RoundedCornerShape(6.dp))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = s.appName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.weight(1f)
                        )
                        if (settings.chargeGuardEnabled) {
                            Icon(
                                imageVector = Icons.Filled.Power,
                                contentDescription = null,
                                tint = Color(0xFFFFD166),
                                modifier = Modifier
                                    .padding(end = 5.dp)
                                    .size(15.dp)
                            )
                        }
                        if (settings.motionGuardEnabled) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = null,
                                tint = Color(0xFFFF758F),
                                modifier = Modifier
                                    .padding(end = 5.dp)
                                    .size(15.dp)
                            )
                        }
                        Surface(
                            color = Color.White.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = s.keepAliveActiveBadge,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFD1FAE5),
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = Color.White.copy(alpha = 0.22f),
                            shape = CircleShape,
                            border = BorderStroke(0.75.dp, Color.White.copy(alpha = 0.3f))
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ExpandLess,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier
                                    .size(20.dp)
                                    .padding(2.dp)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (anyItemVisible) {
                        FlowRow(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            if (settings.keepAliveShowTemp) {
                                PreviewNotifPill(
                                    icon = Icons.Filled.DeviceThermostat,
                                    text = "${liveTelemetry.first}°C"
                                )
                            }
                            if (settings.keepAliveShowLunar) {
                                PreviewNotifPill(
                                    icon = Icons.Filled.CalendarMonth,
                                    text = if (settings.keepAliveExpandedDefault) shortLunar else shortLunar
                                )
                            }
                            if (settings.keepAliveShowCount) {
                                PreviewNotifPill(
                                    icon = Icons.Filled.Notifications,
                                    text = "$unreadCount"
                                )
                            }
                            if (settings.keepAliveShowBattery) {
                                PreviewNotifPill(
                                    icon = Icons.Filled.BatteryChargingFull,
                                    text = "${liveTelemetry.second}%"
                                )
                            }
                        }
                    } else {
                        Text(
                            text = s.keepAliveNotifText,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (!settings.keepAliveExpandedDefault) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = Color.White.copy(alpha = 0.22f),
                            shape = CircleShape,
                            border = BorderStroke(0.75.dp, Color.White.copy(alpha = 0.3f))
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ExpandMore,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier
                                    .size(22.dp)
                                    .padding(3.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = s.keepAliveCustomizeTitle,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SettingSwitchRow(
            title = s.keepAliveShowTempTitle,
            subtitle = "",
            checked = settings.keepAliveShowTemp,
            enabled = settings.keepAliveEnabled,
            onCheckedChange = onToggleShowTemp,
            testTag = "keep_alive_temp_switch",
            leadingIcon = Icons.Filled.DeviceThermostat
        )
        SettingSwitchRow(
            title = s.keepAliveShowLunarTitle,
            subtitle = "",
            checked = settings.keepAliveShowLunar,
            enabled = settings.keepAliveEnabled,
            onCheckedChange = onToggleShowLunar,
            testTag = "keep_alive_lunar_switch",
            leadingIcon = Icons.Filled.CalendarMonth
        )
        SettingSwitchRow(
            title = s.keepAliveShowCountTitle,
            subtitle = "",
            checked = settings.keepAliveShowCount,
            enabled = settings.keepAliveEnabled,
            onCheckedChange = onToggleShowCount,
            testTag = "keep_alive_count_switch",
            leadingIcon = Icons.Filled.Notifications
        )
        SettingSwitchRow(
            title = s.keepAliveShowBatteryTitle,
            subtitle = "",
            checked = settings.keepAliveShowBattery,
            enabled = settings.keepAliveEnabled,
            onCheckedChange = onToggleShowBattery,
            testTag = "keep_alive_battery_switch",
            leadingIcon = Icons.Filled.BatteryChargingFull
        )

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = u.keepAliveStyleTitle,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = !settings.keepAliveExpandedDefault,
                enabled = settings.keepAliveEnabled,
                onClick = { onSetExpandedDefault(false) },
                label = {
                    Text(
                        text = u.keepAliveStyleCompact,
                        style = MaterialTheme.typography.labelSmall
                    )
                },
                modifier = Modifier.testTag("keep_alive_style_compact")
            )
            FilterChip(
                selected = settings.keepAliveExpandedDefault,
                enabled = settings.keepAliveEnabled,
                onClick = { onSetExpandedDefault(true) },
                label = {
                    Text(
                        text = u.keepAliveStyleFull,
                        style = MaterialTheme.typography.labelSmall
                    )
                },
                modifier = Modifier.testTag("keep_alive_style_full")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = s.keepAliveThemeTitle,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            KeepAliveNotifTheme.entries.forEach { theme ->
                FilterChip(
                    selected = settings.keepAliveTheme == theme,
                    enabled = settings.keepAliveEnabled,
                    onClick = { onSelectTheme(theme) },
                    leadingIcon = {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(Color(theme.endColorHex))
                                .border(1.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                        )
                    },
                    label = {
                        Text(
                            text = s.keepAliveThemeLabels[theme] ?: theme.labelVi,
                            style = MaterialTheme.typography.labelSmall
                        )
                    },
                    modifier = Modifier.testTag("keep_alive_theme_${theme.name.lowercase()}")
                )
            }
        }

        HorizontalDivider(
            color = MaterialTheme.colorScheme.outlineVariant,
            modifier = Modifier.padding(vertical = 12.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.BatteryChargingFull,
                contentDescription = null,
                tint = if (isIgnoringBatteryOptimizations) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = s.batteryTitle,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (isIgnoringBatteryOptimizations) s.batteryUnrestricted else s.batteryRestricted,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isIgnoringBatteryOptimizations) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onOpenBatterySettings,
                modifier = Modifier.testTag("battery_optimization_button")
            ) {
                Text(s.batteryAction)
            }
            OutlinedButton(
                onClick = onOpenAppDetailsSettings,
                modifier = Modifier.testTag("app_info_settings_button")
            ) {
                Text(s.appInfoAction)
            }
            OutlinedButton(
                onClick = onRebindListener,
                modifier = Modifier.testTag("rebind_listener_button")
            ) {
                Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(s.rebindServiceAction)
            }
        }
    }
}

@Composable
private fun PreviewNotifPill(
    icon: ImageVector,
    text: String
) {
    Surface(
        color = Color.White.copy(alpha = 0.16f),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun ConfigurePinDialog(
    hasExistingPin: Boolean,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    val s = LocalAppStrings.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    val mismatch = confirmPin.isNotEmpty() && pin != confirmPin
    val valid = pin.length == 4 && pin.all { it.isDigit() } && pin == confirmPin

    fun clearIme() {
        focusManager.clearFocus(force = true)
        keyboardController?.hide()
    }

    DisposableEffect(Unit) {
        onDispose {
            keyboardController?.hide()
        }
    }

    AlertDialog(
        onDismissRequest = {
            clearIme()
            onDismiss()
        },
        title = { Text(if (hasExistingPin) s.pinDialogChangeTitle else s.pinDialogSetTitle) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) pin = it },
                    label = { Text(s.pinInputLabel) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.NumberPassword,
                        imeAction = ImeAction.Next
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("pin_input_field")
                )
                OutlinedTextField(
                    value = confirmPin,
                    onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) confirmPin = it },
                    label = { Text(s.pinConfirmLabel) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.NumberPassword,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            if (valid) {
                                clearIme()
                                onSave(pin)
                            }
                        }
                    ),
                    isError = mismatch,
                    supportingText = { if (mismatch) Text(s.pinMismatchError) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("pin_confirm_field")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    clearIme()
                    onSave(pin)
                },
                enabled = valid,
                modifier = Modifier.testTag("save_pin_button")
            ) {
                Text(s.save)
            }
        },
        dismissButton = {
            Row {
                if (hasExistingPin) {
                    TextButton(
                        onClick = {
                            clearIme()
                            onSave("")
                        }
                    ) {
                        Text(s.pinRemoveAction, color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(
                    onClick = {
                        clearIme()
                        onDismiss()
                    }
                ) {
                    Text(s.cancel)
                }
            }
        }
    )
}
