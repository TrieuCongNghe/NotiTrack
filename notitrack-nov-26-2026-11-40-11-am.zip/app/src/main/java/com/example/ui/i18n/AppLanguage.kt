package com.example.ui.i18n

import java.util.Locale

enum class AppLanguage(
    val code: String,
    val nativeLabel: String,
    val englishName: String,
    val bcp47Tag: String
) {
    SYSTEM("system", "Tự động theo máy", "System Default", ""),
    VIETNAMESE("vi", "Tiếng Việt", "Vietnamese", "vi-VN"),
    ENGLISH("en", "English", "English", "en-US"),
    CHINESE("zh", "中文 简体", "Chinese Simplified", "zh-CN"),
    CHINESE_TRADITIONAL("zh-TW", "中文 繁體", "Chinese Traditional", "zh-TW"),
    JAPANESE("ja", "日本語", "Japanese", "ja-JP"),
    KOREAN("ko", "한국어", "Korean", "ko-KR"),
    SPANISH("es", "Español", "Spanish", "es-ES"),
    FRENCH("fr", "Français", "French", "fr-FR"),
    GERMAN("de", "Deutsch", "German", "de-DE"),
    PORTUGUESE("pt", "Português", "Portuguese", "pt-BR"),
    RUSSIAN("ru", "Русский", "Russian", "ru-RU"),
    ITALIAN("it", "Italiano", "Italian", "it-IT"),
    THAI("th", "ไทย", "Thai", "th-TH"),
    INDONESIAN("id", "Bahasa Indonesia", "Indonesian", "id-ID"),
    MALAY("ms", "Bahasa Melayu", "Malay", "ms-MY"),
    HINDI("hi", "हिन्दी", "Hindi", "hi-IN"),
    ARABIC("ar", "العربية", "Arabic", "ar-SA"),
    TURKISH("tr", "Türkçe", "Turkish", "tr-TR"),
    POLISH("pl", "Polski", "Polish", "pl-PL"),
    DUTCH("nl", "Nederlands", "Dutch", "nl-NL");

    fun resolved(): AppLanguage {
        if (this != SYSTEM) return this
        val locale = Locale.getDefault()
        val lang = locale.language.lowercase(Locale.ROOT)
        val country = locale.country.uppercase(Locale.ROOT)
        return when (lang) {
            "vi" -> VIETNAMESE
            "en" -> ENGLISH
            "zh" -> if (country in setOf("TW", "HK", "MO")) CHINESE_TRADITIONAL else CHINESE
            "ja" -> JAPANESE
            "ko" -> KOREAN
            "es" -> SPANISH
            "fr" -> FRENCH
            "de" -> GERMAN
            "pt" -> PORTUGUESE
            "ru" -> RUSSIAN
            "it" -> ITALIAN
            "th" -> THAI
            "in", "id" -> INDONESIAN
            "ms" -> MALAY
            "hi" -> HINDI
            "ar" -> ARABIC
            "tr" -> TURKISH
            "pl" -> POLISH
            "nl" -> DUTCH
            else -> ENGLISH
        }
    }

    fun toLocale(): Locale {
        val target = resolved()
        return if (target.bcp47Tag.isNotEmpty()) Locale.forLanguageTag(target.bcp47Tag)
        else Locale.getDefault()
    }

    companion object {
        fun fromCode(code: String?): AppLanguage =
            entries.firstOrNull { it.code == code } ?: VIETNAMESE
    }
}
