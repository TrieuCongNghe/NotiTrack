package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhonelinkLock
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.TtsFeedbackRuleEntity
import com.example.data.prefs.KeepAliveNotifTheme
import com.example.data.prefs.NotiTrackSettings
import com.example.engine.AntiTheftRuntimeState
import com.example.engine.BackupSelection
import com.example.engine.BiometricHardwareStatus
import com.example.engine.SmartTtsTemplateEngine
import com.example.engine.TestNotificationScenario
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassSlidingPillTabBar
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.AppStrings
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.AppArtTheme
import com.example.ui.theme.LocalGlassStyle
import com.example.ui.theme.NotiTrackMintGlow
import com.example.ui.theme.NotiTrackObsidianDeep
import com.example.ui.theme.NotiTrackObsidianMid
import com.example.ui.theme.ThemeMode
import kotlin.math.roundToInt

enum class SettingsSubTab(
    val icon: ImageVector,
    val labelOf: (AppStrings) -> String
) {
    GENERAL(Icons.Filled.Tune, { it.settingsTabGeneral }),
    TTS(Icons.Filled.RecordVoiceOver, { it.settingsTabTts }),
    UTILITIES(Icons.Filled.Build, { it.settingsTabUtilities }),
    NOTIFICATION(Icons.Filled.NotificationsActive, { it.settingsTabNotif }),
    SECURITY(Icons.Filled.Security, { it.settingsTabSecurity })
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: NotiTrackSettings,
    antiTheftState: AntiTheftRuntimeState,
    biometricStatus: BiometricHardwareStatus,
    isListenerEnabled: Boolean,
    isIgnoringBatteryOptimizations: Boolean,
    hasPostNotificationPermission: Boolean,
    hasOverlayPermission: Boolean,
    activeSubTab: SettingsSubTab,
    subTabListStates: Map<SettingsSubTab, LazyListState>,
    onSelectSubTab: (SettingsSubTab) -> Unit,
    totalSavedCount: Int,
    unreadSavedCount: Int,
    appRulesCount: Int,
    keywordRulesCount: Int,
    ttsFeedbackRules: List<TtsFeedbackRuleEntity>,
    onSetAppLanguage: (AppLanguage) -> Unit,
    onToggleChatTimelineGrouping: (Boolean) -> Unit,
    onToggleKeepAlive: (Boolean) -> Unit,
    onToggleKeepAliveTemp: (Boolean) -> Unit,
    onToggleKeepAliveLunar: (Boolean) -> Unit,
    onToggleKeepAliveCount: (Boolean) -> Unit,
    onToggleKeepAliveBattery: (Boolean) -> Unit,
    onSelectKeepAliveTheme: (KeepAliveNotifTheme) -> Unit,
    onSetKeepAliveExpandedDefault: (Boolean) -> Unit,
    onOpenBatterySettings: () -> Unit,
    onOpenAppDetailsSettings: () -> Unit,
    onRebindListener: () -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onSavePin: (String) -> Unit,
    onToggleFlagSecure: (Boolean) -> Unit,
    onToggleRequireAuthOnDelete: (Boolean) -> Unit,
    onSetAutoLockSeconds: (Int) -> Unit,
    onLockNow: () -> Unit,
    onToggleTtsGlobal: (Boolean) -> Unit,
    onSetTtsSpeechRate: (Float) -> Unit,
    onToggleTtsIncludeApp: (Boolean) -> Unit,
    onToggleTtsSmartFilter: (Boolean) -> Unit,
    onToggleTtsHideBalance: (Boolean) -> Unit,
    onToggleTtsScreenOffOnly: (Boolean) -> Unit,
    onSetTtsNumericRatioPercent: (Int) -> Unit,
    onToggleFeedbackRule: (TtsFeedbackRuleEntity) -> Unit,
    onDeleteFeedbackRule: (Long) -> Unit,
    onClearAllFeedbackRules: () -> Unit,
    onToggleTtsOverrideVolume: (Boolean) -> Unit,
    onToggleTtsBypassSilent: (Boolean) -> Unit,
    onSetTtsCustomVolumePercent: (Int) -> Unit,
    onSetTtsDelayBetweenMs: (Int) -> Unit,
    onSpeakSample: () -> Unit,
    onToggleCaptureNewApps: (Boolean) -> Unit,
    onSetRetentionDays: (Int) -> Unit,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSetArtTheme: (AppArtTheme) -> Unit,
    onUpdateUtilities: ((NotiTrackSettings) -> NotiTrackSettings) -> Unit,
    onPickUtilitySound: (UtilitySoundTarget, String) -> Unit,
    onTestUtilityAlert: (UtilitySoundTarget) -> Unit,
    onRequestPostNotificationPermission: () -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onRequestToggleMotionGuard: (Boolean) -> Unit,
    onRequestAuthorizeMotionSettings: (onAuthorized: () -> Unit) -> Unit,
    onOpenListenerSettings: () -> Unit,
    onExportNotifications: () -> Unit,
    onRequestExportBackupJson: (BackupSelection) -> Unit,
    onRequestImportBackupJson: () -> Unit,
    onSendTestScenario: (TestNotificationScenario) -> Unit,
    onDeleteReadOnly: () -> Unit,
    onClearAllNotifications: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val s = LocalAppStrings.current
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }
    var pendingPinAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var showNeedPinNotice by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var showTestPicker by remember { mutableStateOf(false) }
    var showSupportAboutDialog by remember { mutableStateOf(false) }
    var showDonateQrDialog by remember { mutableStateOf(false) }
    var showFeedbackManager by remember { mutableStateOf(false) }
    var showBackupOptionsDialog by remember { mutableStateOf(false) }
    val bioStatusText = s.biometricStatusMessages[biometricStatus] ?: biometricStatus.messageVi

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = s.settingsTitle,
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Animated Sliding Glass Pill Sub-Tab Selector Bar
        GlassSlidingPillTabBar(
            items = SettingsSubTab.entries,
            selectedItem = activeSubTab,
            onSelect = onSelectSubTab,
            labelOf = { it.labelOf(s) },
            iconOf = { it.icon },
            tagOf = { "settings_subtab_${it.name.lowercase()}" }
        )

        Spacer(modifier = Modifier.height(10.dp))

        AnimatedContent(
            targetState = activeSubTab,
            modifier = Modifier.weight(1f),
            transitionSpec = {
                val forward = targetState.ordinal >= initialState.ordinal
                (fadeIn(tween(240)) + slideInHorizontally(
                    animationSpec = tween(260),
                    initialOffsetX = { if (forward) it / 8 else -it / 8 }
                )) togetherWith (fadeOut(tween(180)) + slideOutHorizontally(
                    animationSpec = tween(200),
                    targetOffsetX = { if (forward) -it / 10 else it / 10 }
                ))
            },
            label = "settings_subtab_transition"
        ) { currentSubTab ->
            val tabListState = subTabListStates[currentSubTab] ?: rememberLazyListState()
            LazyColumn(
                state = tabListState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 4.dp, bottom = 36.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (currentSubTab) {
                SettingsSubTab.GENERAL -> {
                    item(key = "hero_status") {
                        SettingsHeroCard(
                            settings = settings,
                            bioStatusText = bioStatusText,
                            totalSavedCount = totalSavedCount,
                            onLockNow = onLockNow
                        )
                    }

                    item(key = "support_card") {
                        SettingsSupportCard(
                            onOpenSupport = { showSupportAboutDialog = true }
                        )
                    }

                    item(key = "display_grouping") {
                        SettingsCard(title = s.sectionDisplayGrouping) {
                            SettingSwitchRow(
                                title = s.chatGroupingTitle,
                                subtitle = s.chatGroupingDesc,
                                checked = settings.chatTimelineGroupingEnabled,
                                onCheckedChange = onToggleChatTimelineGrouping,
                                testTag = "chat_grouping_switch",
                                leadingIcon = Icons.Filled.Forum
                            )
                        }
                    }

                    item(key = "language_theme") {
                        SettingsCard(title = s.sectionLanguageAndTheme) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.65f),
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { showLanguageDialog = true }
                                    .testTag("language_picker_button")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Language,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = s.languageTitle,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = settings.appLanguage.nativeLabel,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant,
                                modifier = Modifier.padding(vertical = 12.dp)
                            )

                            Text(
                                text = s.themeTitle,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                ThemeMode.entries.forEach { mode ->
                                    FilterChip(
                                        selected = settings.themeMode == mode,
                                        onClick = { onSetThemeMode(mode) },
                                        label = {
                                            Text(
                                                text = s.themeLabels[mode] ?: mode.labelVi,
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    )
                                }
                            }

                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant,
                                modifier = Modifier.padding(vertical = 12.dp)
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Palette,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = s.artThemeSectionTitle,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = s.artThemeSectionDesc,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            ArtThemeGalleryGrid(
                                selectedTheme = settings.artTheme,
                                onSelectTheme = onSetArtTheme
                            )
                        }
                    }
                }

                SettingsSubTab.TTS -> {
                    item(key = "tts_main") {
                        SettingsCard(title = s.sectionTts) {
                            SettingSwitchRow(
                                title = s.ttsGlobalTitle,
                                subtitle = s.ttsGlobalDesc,
                                checked = settings.ttsGlobalEnabled,
                                onCheckedChange = onToggleTtsGlobal,
                                testTag = "tts_global_switch",
                                leadingIcon = Icons.Filled.RecordVoiceOver
                            )

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                            SettingSwitchRow(
                                title = s.ttsIncludeAppTitle,
                                subtitle = s.ttsIncludeAppDesc,
                                checked = settings.ttsIncludeAppName,
                                onCheckedChange = onToggleTtsIncludeApp,
                                testTag = "tts_include_app_switch"
                            )

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                            SettingSwitchRow(
                                title = s.ttsSmartFilterTitle,
                                subtitle = s.ttsSmartFilterDesc,
                                checked = settings.ttsSmartFilterGlobal,
                                onCheckedChange = onToggleTtsSmartFilter,
                                testTag = "tts_smart_filter_switch",
                                leadingIcon = Icons.Filled.AutoFixHigh
                            )

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                            SettingSwitchRow(
                                title = s.ttsHideBalanceTitle,
                                subtitle = s.ttsHideBalanceDesc,
                                checked = settings.ttsHideBalanceGlobal,
                                onCheckedChange = onToggleTtsHideBalance,
                                testTag = "tts_hide_balance_switch",
                                leadingIcon = Icons.Filled.MoneyOff
                            )

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                            SettingSwitchRow(
                                title = s.ttsScreenOffOnlyTitle,
                                subtitle = s.ttsScreenOffOnlyDesc,
                                checked = settings.ttsOnlyWhenScreenOff,
                                onCheckedChange = onToggleTtsScreenOffOnly,
                                testTag = "tts_screen_off_only_switch",
                                leadingIcon = Icons.Filled.PhonelinkLock
                            )

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                Text(
                                    text = s.ttsNumericRatioTitle(settings.ttsNumericRatioPercent),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = s.ttsNumericRatioDesc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Slider(
                                    value = settings.ttsNumericRatioPercent.toFloat(),
                                    onValueChange = { raw ->
                                        val snapped = ((raw / 5f).roundToInt() * 5).coerceIn(
                                            SmartTtsTemplateEngine.MIN_NUMERIC_RATIO_PERCENT,
                                            SmartTtsTemplateEngine.MAX_NUMERIC_RATIO_PERCENT
                                        )
                                        onSetTtsNumericRatioPercent(snapped)
                                    },
                                    valueRange = SmartTtsTemplateEngine.MIN_NUMERIC_RATIO_PERCENT.toFloat()..SmartTtsTemplateEngine.MAX_NUMERIC_RATIO_PERCENT.toFloat(),
                                    steps = 9,
                                    modifier = Modifier.testTag("tts_numeric_ratio_slider")
                                )
                            }

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showFeedbackManager = true }
                                    .padding(vertical = 12.dp)
                                    .testTag("tts_feedback_manager_row"),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Psychology,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = s.feedbackManagerTitle,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = s.feedbackManagerDesc(ttsFeedbackRules.size),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    item(key = "tts_volume") {
                        SettingsCard(title = s.ttsVolumeSectionTitle) {
                            SettingSwitchRow(
                                title = s.ttsOverrideVolumeTitle,
                                subtitle = s.ttsOverrideVolumeDesc,
                                checked = settings.ttsOverrideVolumeEnabled,
                                onCheckedChange = onToggleTtsOverrideVolume,
                                testTag = "tts_override_volume_switch",
                                leadingIcon = Icons.Filled.VolumeUp
                            )

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                            SettingSwitchRow(
                                title = s.ttsBypassSilentTitle,
                                subtitle = s.ttsBypassSilentDesc,
                                checked = settings.ttsBypassSilentMode,
                                onCheckedChange = onToggleTtsBypassSilent,
                                testTag = "tts_bypass_silent_switch",
                                leadingIcon = Icons.Filled.NotificationsOff
                            )

                            AnimatedVisibility(
                                visible = settings.ttsOverrideVolumeEnabled || settings.ttsBypassSilentMode
                            ) {
                                Column(modifier = Modifier.padding(top = 10.dp)) {
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = s.ttsVolumeLevelTitle(settings.ttsCustomVolumePercent),
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Slider(
                                        value = settings.ttsCustomVolumePercent.toFloat(),
                                        onValueChange = { onSetTtsCustomVolumePercent(it.roundToInt()) },
                                        valueRange = 10f..100f,
                                        steps = 8,
                                        modifier = Modifier.testTag("tts_volume_slider")
                                    )
                                }
                            }

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                Text(
                                    text = s.ttsDelayTitle(settings.ttsDelayBetweenMs),
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = s.ttsDelayDesc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Slider(
                                    value = settings.ttsDelayBetweenMs.toFloat(),
                                    onValueChange = { raw ->
                                        val snapped = ((raw / 500f).roundToInt() * 500).coerceIn(500, 5000)
                                        onSetTtsDelayBetweenMs(snapped)
                                    },
                                    valueRange = 500f..5000f,
                                    steps = 8,
                                    modifier = Modifier.testTag("tts_delay_slider")
                                )
                            }

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = s.ttsSpeedTitle(settings.ttsSpeechRate),
                                        style = MaterialTheme.typography.titleSmall,
                                        modifier = Modifier.weight(1f)
                                    )
                                    TextButton(
                                        onClick = onSpeakSample,
                                        modifier = Modifier.testTag("tts_test_sample_button")
                                    ) {
                                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(s.ttsPreviewAction)
                                    }
                                }
                                Slider(
                                    value = settings.ttsSpeechRate,
                                    onValueChange = onSetTtsSpeechRate,
                                    valueRange = 0.7f..1.7f,
                                    steps = 9,
                                    modifier = Modifier.testTag("tts_rate_slider")
                                )
                            }
                        }
                    }
                }

                SettingsSubTab.UTILITIES -> {
                    item(key = "utilities_all") {
                        SettingsUtilitiesContent(
                            settings = settings,
                            antiTheftState = antiTheftState,
                            hasPostNotificationPermission = hasPostNotificationPermission,
                            hasOverlayPermission = hasOverlayPermission,
                            onRequestPostNotificationPermission = onRequestPostNotificationPermission,
                            onRequestOverlayPermission = onRequestOverlayPermission,
                            onUpdateUtilities = onUpdateUtilities,
                            onPickUtilitySound = onPickUtilitySound,
                            onTestUtilityAlert = onTestUtilityAlert,
                            onRequestToggleChargeGuard = { wantEnable ->
                                if (wantEnable && !settings.hasPinConfigured) {
                                    pendingPinAction = {
                                        onUpdateUtilities { it.copy(chargeGuardEnabled = true) }
                                    }
                                    showNeedPinNotice = true
                                } else {
                                    onUpdateUtilities { it.copy(chargeGuardEnabled = wantEnable) }
                                }
                            },
                            onRequestToggleMotionGuard = { wantEnable ->
                                if (wantEnable && !settings.hasPinConfigured) {
                                    pendingPinAction = {
                                        onRequestToggleMotionGuard(true)
                                    }
                                    showNeedPinNotice = true
                                } else {
                                    onRequestToggleMotionGuard(wantEnable)
                                }
                            },
                            onRequestAuthorizeMotionSettings = { onUnlocked ->
                                if (!settings.isAppLockActive) {
                                    pendingPinAction = onUnlocked
                                    showNeedPinNotice = true
                                } else {
                                    onRequestAuthorizeMotionSettings(onUnlocked)
                                }
                            }
                        )
                    }
                }

                SettingsSubTab.NOTIFICATION -> {
                    item(key = "keep_alive") {
                        SettingsKeepAliveCard(
                            settings = settings,
                            unreadCount = unreadSavedCount,
                            isIgnoringBatteryOptimizations = isIgnoringBatteryOptimizations,
                            onToggleKeepAlive = onToggleKeepAlive,
                            onToggleShowTemp = onToggleKeepAliveTemp,
                            onToggleShowLunar = onToggleKeepAliveLunar,
                            onToggleShowCount = onToggleKeepAliveCount,
                            onToggleShowBattery = onToggleKeepAliveBattery,
                            onSelectTheme = onSelectKeepAliveTheme,
                            onSetExpandedDefault = onSetKeepAliveExpandedDefault,
                            onOpenBatterySettings = onOpenBatterySettings,
                            onOpenAppDetailsSettings = onOpenAppDetailsSettings,
                            onRebindListener = onRebindListener
                        )
                    }

                    item(key = "listener_test") {
                        SettingsCard(title = s.sectionListenerTest) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = s.listenerPermTitle, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        text = if (isListenerEnabled) s.listenerPermActiveDesc else s.listenerPermInactiveDesc,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isListenerEnabled) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.error
                                    )
                                }
                                OutlinedButton(
                                    onClick = onOpenListenerSettings,
                                    modifier = Modifier.testTag("settings_open_listener_button")
                                ) {
                                    Icon(Icons.Filled.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(s.openSettings)
                                }
                            }

                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )

                            SettingSwitchRow(
                                title = s.captureNewAppsTitle,
                                subtitle = s.captureNewAppsDesc,
                                checked = settings.captureNewAppsByDefault,
                                onCheckedChange = onToggleCaptureNewApps,
                                testTag = "capture_new_apps_switch"
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = { showTestPicker = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("settings_send_test_button")
                            ) {
                                Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(s.sendTest)
                            }
                        }
                    }
                }

                SettingsSubTab.SECURITY -> {
                    item(key = "biometric_privacy") {
                        SettingsCard(title = s.sectionBiometricPrivacy) {
                            SettingSwitchRow(
                                title = s.biometricTitle,
                                subtitle = if (biometricStatus.isUsable) s.biometricDesc else bioStatusText,
                                checked = settings.biometricEnabled,
                                enabled = biometricStatus.isUsable || settings.biometricEnabled,
                                onCheckedChange = onToggleBiometric,
                                testTag = "biometric_lock_switch",
                                leadingIcon = Icons.Filled.Fingerprint
                            )

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showPinDialog = true }
                                    .padding(vertical = 12.dp)
                                    .testTag("configure_pin_row"),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Pin,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = s.pinTitle, style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        text = if (settings.hasPinConfigured) s.pinConfiguredDesc else s.pinUnconfiguredDesc,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = if (settings.hasPinConfigured) s.pinChangeAction else s.pinSetupAction,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                            SettingSwitchRow(
                                title = s.flagSecureTitle,
                                subtitle = s.flagSecureDesc,
                                checked = settings.flagSecureEnabled,
                                onCheckedChange = onToggleFlagSecure,
                                testTag = "flag_secure_switch",
                                leadingIcon = Icons.Filled.Security
                            )

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                            SettingSwitchRow(
                                title = s.requireAuthOnDeleteTitle,
                                subtitle = if (settings.isAppLockActive) s.requireAuthOnDeleteDesc
                                else s.requireAuthOnDeleteNeedLock,
                                checked = settings.requireAuthOnDelete && settings.isAppLockActive,
                                enabled = settings.isAppLockActive,
                                onCheckedChange = onToggleRequireAuthOnDelete,
                                testTag = "require_auth_delete_switch",
                                leadingIcon = Icons.Filled.Shield
                            )

                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                Text(text = s.autoLockTitle, style = MaterialTheme.typography.titleSmall)
                                Spacer(modifier = Modifier.height(8.dp))
                                val lockOptions = listOf(
                                    0 to s.autoLockImmediate,
                                    30 to s.autoLock30s,
                                    60 to s.autoLock1m,
                                    300 to s.autoLock5m
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    lockOptions.forEach { (sec, label) ->
                                        FilterChip(
                                            selected = settings.autoLockSeconds == sec,
                                            onClick = { onSetAutoLockSeconds(sec) },
                                            label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item(key = "data_storage") {
                        SettingsCard(title = s.sectionData) {
                            Text(text = s.retentionTitle, style = MaterialTheme.typography.titleSmall)
                            Spacer(modifier = Modifier.height(8.dp))
                            val retentionOptions = listOf(
                                7 to s.retention7d,
                                30 to s.retention30d,
                                90 to s.retention90d,
                                0 to s.retentionNever
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                retentionOptions.forEach { (days, label) ->
                                    FilterChip(
                                        selected = settings.retentionDays == days,
                                        onClick = { onSetRetentionDays(days) },
                                        label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }

                            HorizontalDivider(
                                color = MaterialTheme.colorScheme.outlineVariant,
                                modifier = Modifier.padding(vertical = 12.dp)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { showBackupOptionsDialog = true },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("backup_json_button")
                                ) {
                                    Icon(Icons.Filled.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(s.backupJsonAction, maxLines = 1)
                                }
                                OutlinedButton(
                                    onClick = onRequestImportBackupJson,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("restore_json_button")
                                ) {
                                    Icon(Icons.Filled.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(s.restoreJsonAction, maxLines = 1)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedButton(
                                    onClick = onExportNotifications,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("export_notifications_button")
                                ) {
                                    Icon(Icons.Filled.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(s.exportAction)
                                }
                                OutlinedButton(
                                    onClick = { showClearConfirm = true },
                                    enabled = totalSavedCount > 0,
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("clear_all_notifications_button")
                                ) {
                                    Icon(Icons.Filled.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(s.clearAllAction)
                                }
                            }
                        }
                    }
                }
            }
        }
        }
    }

    if (showSupportAboutDialog) {
        SupportAboutDialog(
            onDismiss = { showSupportAboutDialog = false },
            onOpenBankQr = {
                showSupportAboutDialog = false
                showDonateQrDialog = true
            },
            onShowMessage = onShowMessage
        )
    }

    if (showDonateQrDialog) {
        DonateQrDialog(
            onDismiss = { showDonateQrDialog = false },
            onShowMessage = onShowMessage
        )
    }

    if (showNeedPinNotice) {
        AlertDialog(
            onDismissRequest = {
                showNeedPinNotice = false
                pendingPinAction = null
            },
            icon = {
                Icon(Icons.Filled.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            },
            title = { Text(s.antiTheftNeedPinTitle, fontWeight = FontWeight.Bold) },
            text = { Text(s.antiTheftNeedPinDesc, style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                Button(
                    onClick = {
                        showNeedPinNotice = false
                        showPinDialog = true
                    },
                    modifier = Modifier.testTag("antitheft_setup_pin_now_button")
                ) {
                    Text(s.pinSetupAction)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showNeedPinNotice = false
                        pendingPinAction = null
                    }
                ) {
                    Text(s.cancel)
                }
            }
        )
    }

    if (showPinDialog) {
        ConfigurePinDialog(
            hasExistingPin = settings.hasPinConfigured,
            onDismiss = {
                showPinDialog = false
                pendingPinAction = null
            },
            onSave = { newPin ->
                onSavePin(newPin)
                showPinDialog = false
                if (newPin.length == 4) {
                    pendingPinAction?.invoke()
                }
                pendingPinAction = null
            }
        )
    }

    if (showTestPicker) {
        AlertDialog(
            onDismissRequest = { showTestPicker = false },
            title = { Text(s.testDialogTitle) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = s.testDialogDesc,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TestNotificationScenario.entries.forEach { scenario ->
                        val copy = s.testScenarios[scenario] ?: return@forEach
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.small)
                                .clickable {
                                    onSendTestScenario(scenario)
                                    showTestPicker = false
                                }
                                .testTag("test_scenario_${scenario.name.lowercase()}"),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            shape = MaterialTheme.shapes.small
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(copy.label, style = MaterialTheme.typography.titleSmall)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = copy.content,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTestPicker = false }) {
                    Text(s.cancel)
                }
            }
        )
    }

    if (showClearConfirm) {
        BulkDeleteConfirmDialog(
            totalCount = totalSavedCount,
            unreadCount = unreadSavedCount,
            onDismiss = { showClearConfirm = false },
            onDeleteOnlyRead = {
                onDeleteReadOnly()
                showClearConfirm = false
            },
            onDeleteAll = {
                onClearAllNotifications()
                showClearConfirm = false
            }
        )
    }

    if (showFeedbackManager) {
        TtsFeedbackManagerDialog(
            rules = ttsFeedbackRules,
            onDismiss = { showFeedbackManager = false },
            onToggleRule = onToggleFeedbackRule,
            onDeleteRule = onDeleteFeedbackRule,
            onClearAll = {
                onClearAllFeedbackRules()
                showFeedbackManager = false
            }
        )
    }

    if (showBackupOptionsDialog) {
        BackupExportOptionsDialog(
            notificationsCount = totalSavedCount,
            appRulesCount = appRulesCount,
            keywordRulesCount = keywordRulesCount,
            feedbackRulesCount = ttsFeedbackRules.size,
            onDismiss = { showBackupOptionsDialog = false },
            onConfirmExport = { selection ->
                showBackupOptionsDialog = false
                onRequestExportBackupJson(selection)
            }
        )
    }

    if (showLanguageDialog) {
        LanguagePickerDialog(
            selectedLanguage = settings.appLanguage,
            onSelect = { lang ->
                onSetAppLanguage(lang)
                showLanguageDialog = false
            },
            onDismiss = { showLanguageDialog = false }
        )
    }
}

@Composable
private fun LanguagePickerDialog(
    selectedLanguage: AppLanguage,
    onSelect: (AppLanguage) -> Unit,
    onDismiss: () -> Unit
) {
    val s = LocalAppStrings.current
    val u = s.utilities
    var query by remember { mutableStateOf("") }
    val filtered = remember(query) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) AppLanguage.entries
        else AppLanguage.entries.filter {
            it.nativeLabel.contains(trimmed, ignoreCase = true) ||
                it.englishName.contains(trimmed, ignoreCase = true) ||
                it.code.contains(trimmed, ignoreCase = true)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = u.languagePickerTitle,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text(u.languageSearchHint) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("language_search_input")
                )
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(filtered, key = { it.code }) { lang ->
                        val isSelected = lang == selectedLanguage
                        Surface(
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                            else Color.Transparent,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onSelect(lang) }
                                .testTag("lang_option_${lang.code}")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = lang.nativeLabel,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer
                                        else MaterialTheme.colorScheme.onSurface
                                    )
                                    if (lang != AppLanguage.SYSTEM && !lang.nativeLabel.equals(lang.englishName, ignoreCase = true)) {
                                        Text(
                                            text = lang.englishName,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(s.close)
            }
        }
    )
}

@Composable
private fun SettingsHeroCard(
    settings: NotiTrackSettings,
    bioStatusText: String,
    totalSavedCount: Int,
    onLockNow: () -> Unit
) {
    val s = LocalAppStrings.current
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.large)
            .background(
                Brush.horizontalGradient(
                    colors = listOf(NotiTrackObsidianDeep, NotiTrackObsidianMid)
                )
            )
            .padding(18.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_vault_shield_1795064151326),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (settings.isAppLockActive) s.heroProtected else s.heroUnprotected,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = bioStatusText,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.78f)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        color = NotiTrackMintGlow.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = s.heroLocalCount(totalSavedCount),
                            style = MaterialTheme.typography.labelSmall,
                            color = NotiTrackMintGlow,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    if (settings.isAppLockActive) {
                        Surface(
                            color = Color.White.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(onClick = onLockNow)
                                .testTag("hero_lock_now_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Lock,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = s.heroLockNow,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ArtThemeGalleryGrid(
    selectedTheme: AppArtTheme,
    onSelectTheme: (AppArtTheme) -> Unit
) {
    val u = LocalAppStrings.current.utilities
    val rows = remember { AppArtTheme.entries.chunked(2) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        rows.forEach { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                pair.forEach { theme ->
                    val isSelected = theme == selectedTheme
                    val title = u.artThemeTitles[theme] ?: theme.titleEn
                    val subtitle = u.artThemeSubtitles[theme] ?: theme.subtitleEn
                    val cardScale by animateFloatAsState(
                        targetValue = if (isSelected) 1.02f else 0.99f,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                        label = "theme_card_scale"
                    )
                    val cardShape = RoundedCornerShape(theme.cardCornerDp.dp)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(124.dp)
                            .scale(cardScale)
                            .clip(cardShape)
                            .border(
                                width = if (isSelected) 2.2.dp else 1.dp,
                                color = if (isSelected) Color(theme.previewPrimaryHex)
                                else Color.White.copy(alpha = 0.25f),
                                shape = cardShape
                            )
                            .clickable { onSelectTheme(theme) }
                            .testTag("art_theme_card_${theme.name.lowercase()}")
                    ) {
                        Image(
                            painter = painterResource(id = theme.artDrawableRes),
                            contentDescription = title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Black.copy(alpha = 0.08f),
                                            Color.Black.copy(alpha = 0.48f),
                                            Color.Black.copy(alpha = 0.84f)
                                        )
                                    )
                                )
                        )
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = Color(theme.previewPrimaryHex),
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                                    .size(20.dp)
                            )
                        }
                        Row(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(Color(theme.previewPrimaryHex))
                                    .border(1.dp, Color.White.copy(alpha = 0.7f), CircleShape)
                            )
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(Color(theme.previewAccentHex))
                                    .border(1.dp, Color.White.copy(alpha = 0.7f), CircleShape)
                            )
                        }
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(10.dp)
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.82f),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSupportCard(onOpenSupport: () -> Unit) {
    val s = LocalAppStrings.current
    val glass = LocalGlassStyle.current
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = if (glass.isDark) 0.45f else 0.75f),
        borderColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Favorite,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = s.supportCardTitle,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = s.supportCardSubtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.85f)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Button(
                onClick = onOpenSupport,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary,
                    contentColor = MaterialTheme.colorScheme.onSecondary
                ),
                modifier = Modifier.testTag("settings_support_button")
            ) {
                Text(s.supportButtonLabel)
            }
        }
    }
}
