package com.example.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

enum class ThemeMode(val labelVi: String) {
    SYSTEM("Theo hệ thống"),
    LIGHT("Giao diện sáng"),
    DARK("Giao diện tối")
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun NotiTrackTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    artTheme: AppArtTheme = AppArtTheme.JADE,
    content: @Composable () -> Unit
) {
    val useDarkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val colorScheme = remember(artTheme, useDarkTheme) {
        buildColorSchemeFor(artTheme, useDarkTheme)
    }
    val glassStyle = remember(artTheme, colorScheme, useDarkTheme) {
        buildGlassStyleFor(artTheme, colorScheme, useDarkTheme)
    }
    val shapes = remember(artTheme) {
        val base = artTheme.cardCornerDp
        Shapes(
            extraSmall = RoundedCornerShape((base / 2).coerceAtLeast(6).dp),
            small = RoundedCornerShape((base - 4).coerceAtLeast(8).dp),
            medium = RoundedCornerShape(base.dp),
            large = RoundedCornerShape((base + 4).dp),
            extraLarge = RoundedCornerShape((base + 10).dp)
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = view.context.findActivity()?.window ?: return@SideEffect
            val insetsController = WindowCompat.getInsetsController(window, view)
            insetsController.isAppearanceLightStatusBars = !useDarkTheme
            insetsController.isAppearanceLightNavigationBars = !useDarkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = NotiTrackTypography,
        shapes = shapes
    ) {
        CompositionLocalProvider(
            LocalGlassStyle provides glassStyle,
            LocalContentColor provides colorScheme.onBackground,
            content = content
        )
    }
}
