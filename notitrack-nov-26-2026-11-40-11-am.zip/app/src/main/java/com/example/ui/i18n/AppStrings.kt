package com.example.ui.i18n

import androidx.compose.runtime.staticCompositionLocalOf
import com.example.data.model.KeywordAction
import com.example.data.prefs.KeepAliveNotifTheme
import com.example.engine.BiometricHardwareStatus
import com.example.engine.TestNotificationScenario
import com.example.ui.theme.AppArtTheme
import com.example.ui.theme.ThemeMode
import com.example.ui.viewmodel.AppsFilter
import com.example.ui.viewmodel.InboxFilter
import com.example.ui.viewmodel.KeywordPreset

data class TestScenarioCopy(
    val label: String,
    val title: String,
    val content: String,
    val subText: String
)

data class AppStrings(
    // Nav
    val navInbox: String,
    val navApps: String,
    val navFilters: String,
    val navSettings: String,
    // Common
    val save: String,
    val cancel: String,
    val delete: String,
    val copy: String,
    val share: String,
    val speak: String,
    val stopSpeak: String,
    val openSettings: String,
    val grantAccess: String,
    val sendTest: String,
    val clearSearch: String,
    val back: String,
    val edit: String,
    val close: String,
    val today: String,
    val yesterday: String,
    // Listener Banner
    val listenerBannerTitle: String,
    val listenerBannerDesc: String,
    val listenerActive: String,
    val listenerInactive: String,
    // Inbox & Chat Timeline & Multi-select Delete
    val inboxSearchHint: String,
    val inboxTimeline: String,
    val inboxGrouped: String,
    val inboxMarkAllRead: String,
    val inboxLockNow: String,
    val inboxSavedCount: (Int) -> String,
    val inboxEmptyTitle: String,
    val inboxEmptyDesc: String,
    val inboxCopied: String,
    val inboxCopiedOtp: (String) -> String,
    val inboxMatchedKeywords: (String) -> String,
    val inboxShowAgain: String,
    val inboxHidePrivate: String,
    val inboxShareTitle: String,
    val inboxPinStar: String,
    val inboxFilterLabels: Map<InboxFilter, String>,
    val timeJustNow: String,
    val timeMinutesAgo: (Long) -> String,
    val inboxSelectMode: String,
    val inboxSelectedCount: (Int) -> String,
    val inboxSelectAll: String,
    val inboxDeselectAll: String,
    val inboxDeleteSelected: String,
    val inboxDeleteAll: String,
    val inboxUnreadWarnTitle: String,
    val inboxUnreadWarnBody: (total: Int, unread: Int) -> String,
    val inboxDeleteConfirmTitle: String,
    val inboxDeleteConfirmBody: (total: Int) -> String,
    val inboxDeleteOnlyRead: (readCount: Int) -> String,
    val inboxDeleteForceAll: String,
    val inboxChatGroupingHint: String,
    // Apps
    val appsTitle: String,
    val appsSubtitle: String,
    val appsSearchHint: String,
    val appsEnableAll: String,
    val appsDisableAll: String,
    val appsCountSummary: (Int, Int) -> String,
    val appsTtsSummary: (Int) -> String,
    val appsTtsGlobalOffNotice: String,
    val appsChipTts: String,
    val appsChipAutoDismiss: String,
    val appsChipSmartTts: String,
    val appsChipHideBalance: String,
    val appsFilterLabels: Map<AppsFilter, String>,
    // Filters
    val filtersTitle: String,
    val filtersSubtitle: String,
    val filtersPresetsTitle: String,
    val filtersAddRule: String,
    val filtersEmptyTitle: String,
    val filtersEmptyDesc: String,
    val filtersDialogCreate: String,
    val filtersDialogEdit: String,
    val filtersKeywordLabel: String,
    val filtersKeywordPlaceholder: String,
    val filtersRegexInvalid: String,
    val filtersActionPrompt: String,
    val filtersScopePrefix: String,
    val filtersScopeAll: String,
    val filtersCaseSensitive: String,
    val filtersUseRegex: String,
    val filtersMatchCount: (Int) -> String,
    val keywordActionLabel: Map<KeywordAction, String>,
    val keywordActionShort: Map<KeywordAction, String>,
    val keywordActionDesc: Map<KeywordAction, String>,
    val keywordPresets: List<KeywordPreset>,
    // Settings
    val settingsTitle: String,
    val heroProtected: String,
    val heroUnprotected: String,
    val heroLocalCount: (Int) -> String,
    val heroLockNow: String,
    // Support / Donate
    val supportCardTitle: String,
    val supportCardSubtitle: String,
    val supportButtonLabel: String,
    val supportDialogTitle: String,
    val supportAppIntro: String,
    val supportAuthorLabel: String,
    val supportFacebookLabel: String,
    val supportBuyCoffeeAction: String,
    val supportDonateBankAction: String,
    val donateQrDialogTitle: String,
    val donateQrDialogSubtitle: String,
    val donateBankLabel: String,
    val donateAccountNoLabel: String,
    val donateAccountHolderLabel: String,
    val donateSaveQrAction: String,
    val donateCopyStkAction: String,
    val msgQrSaved: String,
    val msgQrSaveFailed: String,
    val msgStkCopied: String,
    // Display & Chat Grouping
    val sectionDisplayGrouping: String,
    val chatGroupingTitle: String,
    val chatGroupingDesc: String,
    val sectionLanguageAndTheme: String,
    val languageTitle: String,
    val themeTitle: String,
    val themeLabels: Map<ThemeMode, String>,
    // Keep-Alive Notification Customization
    val sectionPersistence: String,
    val keepAliveTitle: String,
    val keepAliveDesc: String,
    val keepAliveCustomizeTitle: String,
    val keepAliveShowTempTitle: String,
    val keepAliveShowLunarTitle: String,
    val keepAliveShowCountTitle: String,
    val keepAliveShowBatteryTitle: String,
    val keepAliveThemeTitle: String,
    val keepAliveThemeLabels: Map<KeepAliveNotifTheme, String>,
    val keepAliveActiveBadge: String,
    val keepAliveLunarShort: String,
    val keepAliveCountShort: String,
    val keepAliveBatteryShort: String,
    val batteryTitle: String,
    val batteryUnrestricted: String,
    val batteryRestricted: String,
    val batteryAction: String,
    val appInfoAction: String,
    val rebindServiceAction: String,
    val sectionBiometricPrivacy: String,
    val biometricTitle: String,
    val biometricDesc: String,
    val pinTitle: String,
    val pinConfiguredDesc: String,
    val pinUnconfiguredDesc: String,
    val pinChangeAction: String,
    val pinSetupAction: String,
    val flagSecureTitle: String,
    val flagSecureDesc: String,
    val autoLockTitle: String,
    val autoLockImmediate: String,
    val autoLock30s: String,
    val autoLock1m: String,
    val autoLock5m: String,
    // TTS & Smart Reader
    val sectionTts: String,
    val ttsGlobalTitle: String,
    val ttsGlobalDesc: String,
    val ttsIncludeAppTitle: String,
    val ttsIncludeAppDesc: String,
    val ttsSmartFilterTitle: String,
    val ttsSmartFilterDesc: String,
    val ttsHideBalanceTitle: String,
    val ttsHideBalanceDesc: String,
    val ttsSpeedTitle: (Float) -> String,
    val ttsPreviewAction: String,
    val ttsSpokenPrefix: (String) -> String,
    val ttsSampleSentence: String,
    val sectionListenerTest: String,
    val listenerPermTitle: String,
    val listenerPermActiveDesc: String,
    val listenerPermInactiveDesc: String,
    val captureNewAppsTitle: String,
    val captureNewAppsDesc: String,
    val sectionData: String,
    val retentionTitle: String,
    val retention7d: String,
    val retention30d: String,
    val retention90d: String,
    val retentionNever: String,
    val exportAction: String,
    val clearAllAction: String,
    val clearAllDialogTitle: String,
    val clearAllDialogDesc: (Int) -> String,
    // Test Picker Dialog
    val testDialogTitle: String,
    val testDialogDesc: String,
    val testChannelName: String,
    val testChannelDesc: String,
    val testScenarios: Map<TestNotificationScenario, TestScenarioCopy>,
    val androidRedactedNotice: String,
    // PIN Dialog
    val pinDialogChangeTitle: String,
    val pinDialogSetTitle: String,
    val pinInputLabel: String,
    val pinConfirmLabel: String,
    val pinMismatchError: String,
    val pinRemoveAction: String,
    // Lock Screen
    val lockScreenTitle: String,
    val lockScreenSubtitle: String,
    val lockBiometricButton: String,
    val lockPinButton: String,
    val lockHidePinButton: String,
    val lockPromptTitle: String,
    val lockPromptSubtitle: String,
    val lockPromptNegative: String,
    val lockPinIncorrect: String,
    val lockBiometricEnableTitle: String,
    val lockBiometricEnableSub: String,
    val lockBiometricDisableTitle: String,
    val lockBiometricDisableSub: String,
    val biometricStatusMessages: Map<BiometricHardwareStatus, String>,
    val biometricMismatchMsg: String,
    // Keep-Alive Notification
    val keepAliveChannelName: String,
    val keepAliveNotifTitle: String,
    val keepAliveNotifText: String,
    val feedback: FeedbackStrings,
    val extra: ExtraAppStrings = ExtraAppStrings(),
    val utilities: UtilitiesStrings = UtilitiesStrings()
) {
    val appName: String = "NotiTrack"

    val msgNeedLockFirst: String get() = feedback.msgNeedLockFirst
    val msgMarkedAllRead: String get() = feedback.msgMarkedAllRead
    val msgMovedToHidden: String get() = feedback.msgMovedToHidden
    val msgRestoredToMain: String get() = feedback.msgRestoredToMain
    val msgDeletedOne: String get() = feedback.msgDeletedOne
    val msgDeletedMany: (Int) -> String get() = feedback.msgDeletedMany
    val msgDeletedApp: (String) -> String get() = feedback.msgDeletedApp
    val msgEnabledAllApps: String get() = feedback.msgEnabledAllApps
    val msgDisabledAllApps: String get() = feedback.msgDisabledAllApps
    val msgRuleUpdated: String get() = feedback.msgRuleUpdated
    val msgRuleAdded: String get() = feedback.msgRuleAdded
    val msgPresetAdded: (String) -> String get() = feedback.msgPresetAdded
    val msgRuleDeleted: String get() = feedback.msgRuleDeleted
    val msgBiometricOn: String get() = feedback.msgBiometricOn
    val msgBiometricOff: String get() = feedback.msgBiometricOff
    val msgPinCleared: String get() = feedback.msgPinCleared
    val msgPinSaved: String get() = feedback.msgPinSaved
    val msgRetentionNever: String get() = feedback.msgRetentionNever
    val msgRetentionDays: (Int) -> String get() = feedback.msgRetentionDays
    val msgClearedAll: String get() = feedback.msgClearedAll
    val msgTestSentCaptured: String get() = feedback.msgTestSentCaptured
    val msgTestSentNeedAccess: String get() = feedback.msgTestSentNeedAccess
    val msgNeedPostPerm: String get() = feedback.msgNeedPostPerm
    val msgCannotOpenSettings: String get() = feedback.msgCannotOpenSettings
    val msgServiceRebound: String get() = feedback.msgServiceRebound
    val msgKeepAliveOn: String get() = feedback.msgKeepAliveOn
    val msgKeepAliveOff: String get() = feedback.msgKeepAliveOff
    val exportEmpty: String get() = feedback.exportEmpty
    val exportHeader: (Int) -> String get() = feedback.exportHeader
    val exportTimeLabel: String get() = feedback.exportTimeLabel

    val settingsTabGeneral: String get() = extra.settingsTabGeneral
    val settingsTabTts: String get() = extra.settingsTabTts
    val settingsTabUtilities: String get() = extra.settingsTabUtilities
    val settingsTabNotif: String get() = extra.settingsTabNotif
    val settingsTabSecurity: String get() = extra.settingsTabSecurity
    val ttsVolumeSectionTitle: String get() = extra.ttsVolumeSectionTitle
    val ttsOverrideVolumeTitle: String get() = extra.ttsOverrideVolumeTitle
    val ttsOverrideVolumeDesc: String get() = extra.ttsOverrideVolumeDesc
    val ttsBypassSilentTitle: String get() = extra.ttsBypassSilentTitle
    val ttsBypassSilentDesc: String get() = extra.ttsBypassSilentDesc
    val ttsVolumeLevelTitle: (Int) -> String get() = extra.ttsVolumeLevelTitle
    val msgTtsAllOn: String get() = extra.msgTtsAllOn
    val msgTtsAllOff: String get() = extra.msgTtsAllOff
    val msgSmartTtsAllOn: String get() = extra.msgSmartTtsAllOn
    val msgSmartTtsAllOff: String get() = extra.msgSmartTtsAllOff
    val msgHideBalanceAllOn: String get() = extra.msgHideBalanceAllOn
    val msgHideBalanceAllOff: String get() = extra.msgHideBalanceAllOff
    val advTtsTitle: String get() = extra.advTtsTitle
    val advTtsFilterModeLabel: String get() = extra.advTtsFilterModeLabel
    val advTtsFilterNumeric: String get() = extra.advTtsFilterNumeric
    val advTtsFilterNumericDesc: String get() = extra.advTtsFilterNumericDesc
    val advTtsFilterAll: String get() = extra.advTtsFilterAll
    val advTtsFilterAllDesc: String get() = extra.advTtsFilterAllDesc
    val advTtsSampleSection: String get() = extra.advTtsSampleSection
    val advTtsSampleEmptyNotice: String get() = extra.advTtsSampleEmptyNotice
    val advTtsSamplePickHint: String get() = extra.advTtsSamplePickHint
    val advTtsSampleTapHint: String get() = extra.advTtsSampleTapHint
    val advTtsSampleClearTemplate: String get() = extra.advTtsSampleClearTemplate
    val advTtsSamplePreviewLabel: String get() = extra.advTtsSamplePreviewLabel
    val advTtsNumberModeLabel: String get() = extra.advTtsNumberModeLabel
    val advTtsNumberAuto: String get() = extra.advTtsNumberAuto
    val advTtsNumberExact: String get() = extra.advTtsNumberExact
    val advTtsNumberNatural: String get() = extra.advTtsNumberNatural
    val advTtsAutoBoostTitle: String get() = extra.advTtsAutoBoostTitle
    val advTtsAutoBoostDesc: String get() = extra.advTtsAutoBoostDesc
    val advTtsCustomBadge: String get() = extra.advTtsCustomBadge
    val advTtsGearDesc: String get() = extra.advTtsGearDesc
    val msgAdvTtsSaved: String get() = extra.msgAdvTtsSaved
    val filtersAppPickerTitle: String get() = extra.filtersAppPickerTitle
    val filtersAppPickerSearchHint: String get() = extra.filtersAppPickerSearchHint
    val inboxThreadsSummary: (Int, Int) -> String get() = extra.inboxThreadsSummary
    val inboxConversationsTitle: String get() = extra.inboxConversationsTitle
    val ttsDelayTitle: (Int) -> String get() = extra.ttsDelayTitle
    val ttsDelayDesc: String get() = extra.ttsDelayDesc
    val inboxFabMarkAllRead: String get() = extra.inboxFabMarkAllRead
    val msgAllAlreadyRead: String get() = extra.msgAllAlreadyRead
    // New 5-feature upgrade strings
    val ttsScreenOffOnlyTitle: String get() = extra.ttsScreenOffOnlyTitle
    val ttsScreenOffOnlyDesc: String get() = extra.ttsScreenOffOnlyDesc
    val ttsNumericRatioTitle: (Int) -> String get() = extra.ttsNumericRatioTitle
    val ttsNumericRatioDesc: String get() = extra.ttsNumericRatioDesc
    val advTtsRatioUseGlobal: (Int) -> String get() = extra.advTtsRatioUseGlobal
    val advTtsRatioCustom: (Int) -> String get() = extra.advTtsRatioCustom
    val advTtsSampleNumericPass: (Int, Int) -> String get() = extra.advTtsSampleNumericPass
    val advTtsSampleNumericSkip: (Int, Int) -> String get() = extra.advTtsSampleNumericSkip
    val feedbackSectionTitle: String get() = extra.feedbackSectionTitle
    val feedbackShouldSpeakBtn: String get() = extra.feedbackShouldSpeakBtn
    val feedbackDoNotSpeakBtn: String get() = extra.feedbackDoNotSpeakBtn
    val feedbackBadgeSpeak: String get() = extra.feedbackBadgeSpeak
    val feedbackBadgeMute: String get() = extra.feedbackBadgeMute
    val feedbackNumericDensityLabel: (Int) -> String get() = extra.feedbackNumericDensityLabel
    val feedbackSavedSpeakMsg: (String) -> String get() = extra.feedbackSavedSpeakMsg
    val feedbackSavedMuteMsg: (String) -> String get() = extra.feedbackSavedMuteMsg
    val feedbackRemovedMsg: String get() = extra.feedbackRemovedMsg
    val feedbackManagerTitle: String get() = extra.feedbackManagerTitle
    val feedbackManagerDesc: (Int) -> String get() = extra.feedbackManagerDesc
    val feedbackManagerEmpty: String get() = extra.feedbackManagerEmpty
    val feedbackClearAll: String get() = extra.feedbackClearAll
    val feedbackClearedAllMsg: String get() = extra.feedbackClearedAllMsg
    val feedbackMatchCount: (Int) -> String get() = extra.feedbackMatchCount
    val backupJsonAction: String get() = extra.backupJsonAction
    val restoreJsonAction: String get() = extra.restoreJsonAction
    val backupDialogTitle: String get() = extra.backupDialogTitle
    val backupDialogDesc: String get() = extra.backupDialogDesc
    val backupOptNotifications: (Int) -> String get() = extra.backupOptNotifications
    val backupOptAppRules: (Int) -> String get() = extra.backupOptAppRules
    val backupOptKeywordRules: (Int) -> String get() = extra.backupOptKeywordRules
    val backupOptFeedbackRules: (Int) -> String get() = extra.backupOptFeedbackRules
    val backupOptSettings: String get() = extra.backupOptSettings
    val backupChooseLocation: String get() = extra.backupChooseLocation
    val backupSuccessMsg: String get() = extra.backupSuccessMsg
    val backupFailedMsg: String get() = extra.backupFailedMsg
    val restoreDialogTitle: String get() = extra.restoreDialogTitle
    val restorePreviewDate: (String) -> String get() = extra.restorePreviewDate
    val restoreModeMergeTitle: String get() = extra.restoreModeMergeTitle
    val restoreModeMergeDesc: String get() = extra.restoreModeMergeDesc
    val restoreModeReplaceTitle: String get() = extra.restoreModeReplaceTitle
    val restoreModeReplaceDesc: String get() = extra.restoreModeReplaceDesc
    val restoreConfirmAction: String get() = extra.restoreConfirmAction
    val restoreSuccessMsg: (Int, Int, Int, Int) -> String get() = extra.restoreSuccessMsg
    val restoreInvalidFileMsg: String get() = extra.restoreInvalidFileMsg
    val launchDeepLinkDesc: (String) -> String get() = extra.launchDeepLinkDesc
    val launchFallbackMsg: (String) -> String get() = extra.launchFallbackMsg
    val launchFailedMsg: (String) -> String get() = extra.launchFailedMsg
    // Art Themes, Delete Auth & Utilities
    val artThemeSectionTitle: String get() = extra.artThemeSectionTitle
    val artThemeSectionDesc: String get() = extra.artThemeSectionDesc
    val requireAuthOnDeleteTitle: String get() = extra.requireAuthOnDeleteTitle
    val requireAuthOnDeleteDesc: String get() = extra.requireAuthOnDeleteDesc
    val requireAuthOnDeleteNeedLock: String get() = extra.requireAuthOnDeleteNeedLock
    val deleteAuthPromptTitle: String get() = extra.deleteAuthPromptTitle
    val deleteAuthPromptDesc: String get() = extra.deleteAuthPromptDesc
    val disarmMotionAuthTitle: String get() = extra.disarmMotionAuthTitle
    val disarmMotionAuthDesc: String get() = extra.disarmMotionAuthDesc
    val antiTheftNeedPinTitle: String get() = extra.antiTheftNeedPinTitle
    val antiTheftNeedPinDesc: String get() = extra.antiTheftNeedPinDesc
    val motionGuardArmedMsg: (Int) -> String get() = extra.motionGuardArmedMsg
    val motionGuardDisarmedMsg: String get() = extra.motionGuardDisarmedMsg
    val inboxShieldFabArm: String get() = extra.inboxShieldFabArm
    val inboxShieldFabArmed: String get() = extra.inboxShieldFabArmed
    val inboxBadgePinned: String get() = extra.inboxBadgePinned
    val inboxBadgePriority: String get() = extra.inboxBadgePriority
    val inboxBadgeHidden: String get() = extra.inboxBadgeHidden
    val inboxBadgeUnread: String get() = extra.inboxBadgeUnread
}

data class FeedbackStrings(
    val msgNeedLockFirst: String,
    val msgMarkedAllRead: String,
    val msgMovedToHidden: String,
    val msgRestoredToMain: String,
    val msgDeletedOne: String,
    val msgDeletedMany: (Int) -> String,
    val msgDeletedApp: (String) -> String,
    val msgEnabledAllApps: String,
    val msgDisabledAllApps: String,
    val msgRuleUpdated: String,
    val msgRuleAdded: String,
    val msgPresetAdded: (String) -> String,
    val msgRuleDeleted: String,
    val msgBiometricOn: String,
    val msgBiometricOff: String,
    val msgPinCleared: String,
    val msgPinSaved: String,
    val msgRetentionNever: String,
    val msgRetentionDays: (Int) -> String,
    val msgClearedAll: String,
    val msgTestSentCaptured: String,
    val msgTestSentNeedAccess: String,
    val msgNeedPostPerm: String,
    val msgCannotOpenSettings: String,
    val msgServiceRebound: String,
    val msgKeepAliveOn: String,
    val msgKeepAliveOff: String,
    val exportEmpty: String,
    val exportHeader: (Int) -> String,
    val exportTimeLabel: String
)

data class ExtraAppStrings(
    val settingsTabGeneral: String = "General",
    val settingsTabTts: String = "Speech",
    val settingsTabUtilities: String = "Utilities",
    val settingsTabNotif: String = "Alerts",
    val settingsTabSecurity: String = "Security",
    val ttsVolumeSectionTitle: String = "Read-Aloud Volume",
    val ttsOverrideVolumeTitle: String = "Independent read-aloud volume",
    val ttsOverrideVolumeDesc: String = "Speak at your chosen level regardless of current media volume, then restore automatically",
    val ttsBypassSilentTitle: String = "Bypass Silent / Vibrate mode",
    val ttsBypassSilentDesc: String = "Route speech through Alarm audio channel so important alerts are heard even when muted",
    val ttsVolumeLevelTitle: (Int) -> String = { "Read-aloud volume: $it%" },
    val msgTtsAllOn: String = "Enabled read-aloud for all apps",
    val msgTtsAllOff: String = "Disabled read-aloud for all apps. You can still turn on individual apps anytime.",
    val msgSmartTtsAllOn: String = "Enabled smart concise readout for all apps",
    val msgSmartTtsAllOff: String = "Disabled smart concise readout for all apps",
    val msgHideBalanceAllOn: String = "Enabled hide balance for all apps",
    val msgHideBalanceAllOff: String = "Disabled hide balance for all apps",
    val advTtsTitle: String = "Advanced Read-Aloud Filter",
    val advTtsFilterModeLabel: String = "Which notifications to read aloud:",
    val advTtsFilterNumeric: String = "Numeric & balance alerts only",
    val advTtsFilterNumericDesc: String = "Only speak notifications containing transfers, balances, or codes while skipping promos",
    val advTtsFilterAll: String = "Read all notifications",
    val advTtsFilterAllDesc: String = "Speak every notification from this app, including promos and general updates",
    val advTtsSampleSection: String = "Highlight parts to read from a saved sample",
    val advTtsSampleEmptyNotice: String = "This app has no saved notifications yet. Receive at least one notification first to highlight which parts to read aloud.",
    val advTtsSamplePickHint: String = "Choose a saved notification sample:",
    val advTtsSampleTapHint: String = "Tap words below to highlight what NotiTrack should read aloud:",
    val advTtsSampleClearTemplate: String = "Clear highlight",
    val advTtsSamplePreviewLabel: String = "Spoken preview:",
    val advTtsNumberModeLabel: String = "Number reading style:",
    val advTtsNumberAuto: String = "Smart by context",
    val advTtsNumberExact: String = "Digit by digit",
    val advTtsNumberNatural: String = "Natural words",
    val advTtsAutoBoostTitle: String = "Auto-boost volume for this app",
    val advTtsAutoBoostDesc: String = "Automatically raise speech volume when this app posts an alert",
    val advTtsCustomBadge: String = "Custom",
    val advTtsGearDesc: String = "Advanced read-aloud filter",
    val msgAdvTtsSaved: String = "Saved advanced read-aloud settings",
    val filtersAppPickerTitle: String = "Select Application Scope",
    val filtersAppPickerSearchHint: String = "Search all installed apps…",
    val inboxThreadsSummary: (threads: Int, total: Int) -> String = { threads, total -> "$threads groups • $total alerts" },
    val inboxConversationsTitle: String = "Grouped Conversations",
    val ttsDelayTitle: (Int) -> String = { ms -> "Pause between announcements: ${String.format("%.1f", ms / 1000f)}s" },
    val ttsDelayDesc: String = "Keeps volume ready and adds a clean pause between back-to-back notifications so nothing is missed",
    val inboxFabMarkAllRead: String = "Mark all read",
    val msgAllAlreadyRead: String = "All notifications are already read",
    val ttsScreenOffOnlyTitle: String = "Read aloud only when screen is off",
    val ttsScreenOffOnlyDesc: String = "Still speaks on the Lock Screen; stays quiet while the device is unlocked and in use",
    val ttsNumericRatioTitle: (Int) -> String = { "Anti-ad numeric threshold: $it%" },
    val ttsNumericRatioDesc: String = "When Smart Filter is on, notifications must contain at least this share of numbers or amounts to be read aloud",
    val advTtsRatioUseGlobal: (Int) -> String = { "Use global default: $it%" },
    val advTtsRatioCustom: (Int) -> String = { "Custom threshold: $it%" },
    val advTtsSampleNumericPass: (Int, Int) -> String = { actual, min -> "Numeric density: $actual% • Will speak" },
    val advTtsSampleNumericSkip: (Int, Int) -> String = { actual, min -> "Numeric density: $actual% • Skipped" },
    val feedbackSectionTitle: String = "Teach NotiTrack for similar notifications:",
    val feedbackShouldSpeakBtn: String = "Should speak",
    val feedbackDoNotSpeakBtn: String = "Don't speak",
    val feedbackBadgeSpeak: String = "Learned: Speak",
    val feedbackBadgeMute: String = "Learned: Mute",
    val feedbackNumericDensityLabel: (Int) -> String = { "Numeric density: $it%" },
    val feedbackSavedSpeakMsg: (String) -> String = { "Learned: Similar alerts from $it will be read aloud" },
    val feedbackSavedMuteMsg: (String) -> String = { "Learned: Similar alerts from $it will stay silent" },
    val feedbackRemovedMsg: String = "Removed learned feedback rule for this pattern",
    val feedbackManagerTitle: String = "Learned read-aloud feedback",
    val feedbackManagerDesc: (Int) -> String = { if (it == 0) "No learned patterns yet" else "$it learned patterns active" },
    val feedbackManagerEmpty: String = "Open any notification and tap \"Should speak\" or \"Don't speak\" to teach NotiTrack your preferences.",
    val feedbackClearAll: String = "Clear all",
    val feedbackClearedAllMsg: String = "Cleared all learned feedback rules",
    val feedbackMatchCount: (Int) -> String = { "Applied $it times" },
    val backupJsonAction: String = "Backup",
    val restoreJsonAction: String = "Restore",
    val backupDialogTitle: String = "Select Data to Backup",
    val backupDialogDesc: String = "Choose which sections to include in your backup file:",
    val backupOptNotifications: (Int) -> String = { "Saved notifications • $it" },
    val backupOptAppRules: (Int) -> String = { "App rules • $it" },
    val backupOptKeywordRules: (Int) -> String = { "Keyword filters • $it" },
    val backupOptFeedbackRules: (Int) -> String = { "Learned speech rules • $it" },
    val backupOptSettings: String = "App settings & preferences",
    val backupChooseLocation: String = "Choose save location",
    val backupSuccessMsg: String = "Backup exported successfully",
    val backupFailedMsg: String = "Failed to export backup file",
    val restoreDialogTitle: String = "Restore Backup Data",
    val restorePreviewDate: (String) -> String = { "Exported on $it" },
    val restoreModeMergeTitle: String = "Merge and skip duplicates",
    val restoreModeMergeDesc: String = "Keep existing data on this device and add only missing records from the backup",
    val restoreModeReplaceTitle: String = "Replace completely",
    val restoreModeReplaceDesc: String = "Overwrite existing items in the included sections with data from the backup file",
    val restoreConfirmAction: String = "Restore now",
    val restoreSuccessMsg: (Int, Int, Int, Int) -> String = { n, a, k, f ->
        "Restored: $n alerts, $a apps, $k filters, $f learned rules"
    },
    val restoreInvalidFileMsg: String = "Invalid or unsupported NotiTrack backup file",
    val launchDeepLinkDesc: (String) -> String = { "Open notification directly in $it" },
    val launchFallbackMsg: (String) -> String = { "Original notification link expired — opening $it" },
    val launchFailedMsg: (String) -> String = { "Unable to open $it" },
    val artThemeSectionTitle: String = "Glass Art Themes",
    val artThemeSectionDesc: String = "Choose a visual theme to harmonize artwork, frosted glass panels, switches, and navigation tabs",
    val requireAuthOnDeleteTitle: String = "Require PIN or Fingerprint to delete",
    val requireAuthOnDeleteDesc: String = "Verify your PIN or fingerprint before deleting any notification or clearing history",
    val requireAuthOnDeleteNeedLock: String = "Enable Fingerprint lock or set a 4-digit PIN above to activate delete protection",
    val deleteAuthPromptTitle: String = "Verify to Delete Notifications",
    val deleteAuthPromptDesc: String = "Enter your 4-digit PIN or verify fingerprint before deleting notifications",
    val disarmMotionAuthTitle: String = "Disarm Active Anti-Theft",
    val disarmMotionAuthDesc: String = "Verify PIN or fingerprint to turn off Active Anti-Theft",
    val antiTheftNeedPinTitle: String = "4-Digit PIN Required",
    val antiTheftNeedPinDesc: String = "Anti-Theft protection requires a 4-digit PIN to stop the alarm. Set your PIN now to continue.",
    val motionGuardArmedMsg: (Int) -> String = { sec ->
        if (sec > 0) "Active Anti-Theft will arm in ${sec}s — set your phone down"
        else "Active Anti-Theft is now guarding your device"
    },
    val motionGuardDisarmedMsg: String = "Active Anti-Theft turned off",
    val inboxShieldFabArm: String = "Anti-Theft",
    val inboxShieldFabArmed: String = "Guarding",
    val inboxBadgePinned: String = "Pinned",
    val inboxBadgePriority: String = "Priority",
    val inboxBadgeHidden: String = "Private",
    val inboxBadgeUnread: String = "NEW"
)

data class UtilitiesStrings(
    val telemetryBatteryStatus: (pct: Int, charging: Boolean) -> String = { pct, charging ->
        if (charging) "Battery $pct% • Charging" else "Battery $pct% • On battery"
    },
    val notifPermMissingBanner: String = "Notification permission is off — status bar and utility alerts cannot be shown.",
    val grantPermissionAction: String = "Allow",
    val overlaySectionTitle: String = "Enhanced Alarm Lock Screen",
    val overlayGrantedDesc: String = "Overlay protection is active. The alarm stays locked on screen even if someone presses Home or switches apps.",
    val overlayMissingDesc: String = "Allow displaying over other apps so the alarm screen stays locked in front and cannot be dismissed easily.",
    val overlayGrantAction: String = "Enable Overlay",
    val overlayActiveBadge: String = "ACTIVE",
    val testAlertAction: String = "Test alert",
    val testAlertSentMsg: String = "Test alert sent",
    val ringtoneToggleTitle: String = "Notification ringtone",
    val customSoundToggleTitle: String = "Custom alert sound",
    val ttsToggleTitle: String = "Voice announcement",
    val batterySaverToggleTitle: String = "Quick Battery Saver prompt",
    val batterySaverToggleDesc: String = "Adds a quick button on the alert to open system Battery Saver",
    val defaultSoundLabel: String = "System default sound",
    val selectedSoundLabel: String = "Selected sound",
    val pickSoundAction: String = "Choose sound",
    val lowBatTitle: String = "Low Battery Alert",
    val lowBatDesc: String = "Reminds you when battery drops low so you can charge or save power.",
    val lowBatThresholdLabel: (Int) -> String = { "Alert at: $it%" },
    val lowBatNotifTitle: String = "Battery is low",
    val lowBatNotifBody: (Int) -> String = { "Your battery is down to $it%. Prepare to charge or turn on Battery Saver." },
    val lowBatTts: (Int) -> String = { "Battery is low, $it percent remaining." },
    val chargingTitle: String = "Charging Reminder",
    val chargingDesc: String = "Sends an urgent reminder when battery gets very low so you plug in on time.",
    val chargingThresholdLabel: (Int) -> String = { "Remind at: $it%" },
    val chargingNotifTitle: String = "Time to plug in",
    val chargingNotifBody: (Int) -> String = { "Only $it% battery remaining. Plug in your charger now to avoid shutting down." },
    val chargingTts: (Int) -> String = { "Battery is down to $it percent. Please plug in your charger now." },
    val fullChargeTitle: String = "Full Charge Alert",
    val fullChargeDesc: String = "Notifies you when charging finishes, with an optional extra top-off timer at 100%.",
    val fullChargeThresholdLabel: (Int) -> String = { "Notify at: $it%" },
    val fullChargeExtraZeroLabel: String = "Notify right when battery reaches 100%",
    val fullChargeExtraMinsLabel: (Int) -> String = { "Charge $it extra minutes after reaching 100%" },
    val fullChargeNotifTitle: String = "Battery fully charged",
    val fullChargeNotifBody: (pct: Int, extraMins: Int) -> String = { pct, extra ->
        if (extra > 0) "Battery reached $pct% and topped off for $extra extra minutes. Ready to unplug."
        else "Battery reached $pct%. You can unplug now to protect battery health."
    },
    val fullChargeTts: (pct: Int, extraMins: Int) -> String = { pct, extra ->
        if (extra > 0) "Battery is fully topped off at $pct percent. You can unplug now."
        else "Battery is fully charged at $pct percent. Please unplug."
    },
    val overheatTitle: String = "Overheat Alert",
    val overheatDesc: String = "Monitors device temperature and alerts you when your phone runs too hot.",
    val overheatThresholdLabel: (Int) -> String = { "Alert from: $it°C" },
    val overheatStyleLabel: String = "Alert style",
    val overheatStyleNotif: String = "Standard alert",
    val overheatStyleAlarm: String = "Loud ringtone",
    val overheatCooldownLabel: (Int) -> String = { "Repeat every: ${it}s" },
    val overheatNotifTitle: String = "Device is running hot",
    val overheatNotifBody: (String) -> String = { "Device temperature reached ${it}°C. Pause heavy tasks or unplug to cool down." },
    val chargeGuardTitle: String = "Charging Anti-Theft",
    val chargeGuardDesc: String = "Guards your phone while charging and sounds an alarm if unplugged unexpectedly.",
    val chargeGuardArmedBadge: String = "GUARDING",
    val chargeGuardStandbyBadge: String = "STANDBY",
    val chargeGuardMinBatAny: String = "Activate immediately whenever plugged in",
    val chargeGuardMinBatAt: (Int) -> String = { "Activate on plug-in when battery is $it% or lower" },
    val chargeGuardDelayLabel: (Int) -> String = { "Delay after unplug: ${it}s" },
    val confirmDialogTitle: String = "Owner confirmation before alarm",
    val confirmDialogDesc: String = "Allows entering your 4-digit PIN or fingerprint to cancel before the siren rings.",
    val confirmWindowLabel: (Int) -> String = { "Confirmation time: ${it}s" },
    val flashStrobeTitle: String = "Flash camera light during alarm",
    val strongVibrateTitle: String = "Strong continuous vibration",
    val antiTheftProtectionNotice: String = "Once triggered, alarm volume locks at maximum and the alert stays locked on screen. Only your 4-digit Security PIN stops the alarm.",
    val motionGuardTitle: String = "Active Anti-Theft",
    val motionGuardDesc: String = "Detects if your phone is picked up or moved. Also toggleable from the Inbox.",
    val motionGuardArmingBadge: (Int) -> String = { "ARMING ${it}s" },
    val motionGuardArmedBadge: String = "GUARDING",
    val motionCustomizeOpenAction: String = "Customize settings",
    val motionCustomizeCloseAction: String = "Collapse and lock settings",
    val motionAuthTitle: String = "Verify Anti-Theft Settings",
    val motionAuthDesc: String = "Enter your 4-digit PIN or fingerprint to customize Active Anti-Theft.",
    val motionSensitivityLabel: String = "Movement sensitivity",
    val motionSensLow: String = "Low",
    val motionSensMedium: String = "Medium",
    val motionSensHigh: String = "High",
    val motionArmDelayLabel: (Int) -> String = { "Settle delay before arming: ${it}s" },
    val alarmTitleCharger: String = "CHARGER UNPLUGGED!",
    val alarmTitleMotion: String = "DEVICE MOVED!",
    val alarmTitleDefault: String = "ANTI-THEFT ALARM",
    val alarmRingingSubtitle: String = "Alarm volume is locked at maximum.\nEnter your 4-digit PIN to stop the alarm.",
    val alarmConfirmSubtitle: (Int) -> String = { "Confirm you are the owner within ${it}s using your 4-digit PIN or fingerprint." },
    val alarmPillMaxVol: String = "Max volume",
    val alarmPillFlash: String = "Flash",
    val alarmPillVibrate: String = "Vibrate",
    val alarmDisarmFingerprintBtn: String = "Disarm with Fingerprint",
    val alarmStopBtn: String = "Stop Alarm",
    val alarmWrongPinError: String = "Incorrect 4-digit PIN",
    val alarmBiometricTitle: String = "Verify Device Owner",
    val alarmBiometricSub: String = "Scan fingerprint to disarm anti-theft",
    val alarmBiometricNeg: String = "Use PIN",
    val alarmNotifChannelName: String = "Anti-Theft Alarm",
    val alarmNotifTitleRinging: String = "Anti-theft alarm active",
    val alarmNotifBodyRinging: String = "Enter your 4-digit PIN to stop the alarm.",
    val alarmNotifTitleConfirm: String = "Verify device owner",
    val alarmNotifBodyConfirm: String = "Enter PIN or fingerprint before the siren sounds.",
    val actionOpenBatterySaver: String = "Open Battery Saver",
    val channelUtilitySilent: String = "Battery & Device Alerts",
    val channelUtilitySound: String = "Battery Sound Alerts",
    val channelOverheatAlarm: String = "Overheat Emergency Alerts",
    val keepAliveStyleTitle: String = "Status notification layout",
    val keepAliveStyleCompact: String = "Compact with expand arrow",
    val keepAliveStyleFull: String = "Always expanded",
    val languagePickerTitle: String = "Display Language",
    val languageSearchHint: String = "Search language…",
    val artThemeTitles: Map<AppArtTheme, String> = mapOf(
        AppArtTheme.JADE to "Jade Vault",
        AppArtTheme.AURORA to "Aurora Night",
        AppArtTheme.SAKURA to "Sakura Blossom",
        AppArtTheme.CYBERPUNK to "Cyberpunk Neon",
        AppArtTheme.SUNSET to "Ocean Sunset",
        AppArtTheme.CRYSTAL to "Crystal Frost"
    ),
    val artThemeSubtitles: Map<AppArtTheme, String> = mapOf(
        AppArtTheme.JADE to "Deep jade silk & champagne gold",
        AppArtTheme.AURORA to "Midnight cosmos & emerald aurora",
        AppArtTheme.SAKURA to "Blush sakura petals & soft twilight",
        AppArtTheme.CYBERPUNK to "Electric cyan & neon magenta",
        AppArtTheme.SUNSET to "Coral horizon & glassy ocean glow",
        AppArtTheme.CRYSTAL to "Glacial ice refraction & pearl silver"
    )
)

val LocalAppStrings = staticCompositionLocalOf<AppStrings> { vietnameseStrings() }

fun stringsFor(language: AppLanguage): AppStrings = when (language.resolved()) {
    AppLanguage.VIETNAMESE -> vietnameseStrings()
    AppLanguage.ENGLISH -> englishStrings()
    AppLanguage.CHINESE -> chineseStrings()
    AppLanguage.CHINESE_TRADITIONAL -> chineseTraditionalStrings()
    AppLanguage.JAPANESE -> japaneseStrings()
    AppLanguage.KOREAN -> koreanStrings()
    AppLanguage.SPANISH -> spanishStrings()
    AppLanguage.FRENCH -> frenchStrings()
    AppLanguage.GERMAN -> germanStrings()
    AppLanguage.PORTUGUESE -> portugueseStrings()
    AppLanguage.RUSSIAN -> russianStrings()
    AppLanguage.ITALIAN -> italianStrings()
    AppLanguage.THAI -> thaiStrings()
    AppLanguage.INDONESIAN -> indonesianStrings()
    AppLanguage.MALAY -> malayStrings()
    AppLanguage.HINDI -> hindiStrings()
    AppLanguage.ARABIC -> arabicStrings()
    AppLanguage.TURKISH -> turkishStrings()
    AppLanguage.POLISH -> polishStrings()
    AppLanguage.DUTCH -> dutchStrings()
    AppLanguage.SYSTEM -> englishStrings()
}
