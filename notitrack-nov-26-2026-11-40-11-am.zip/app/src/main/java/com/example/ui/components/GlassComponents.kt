package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.LocalGlassStyle

/**
 * Full-screen artistic wallpaper backdrop with smooth theme crossfade and adaptive scrim
 * ensuring crisp typography contrast across all 6 Art Glassmorphism themes.
 */
@Composable
fun ArtThemeBackdrop(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val glass = LocalGlassStyle.current
    Box(modifier = modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = glass.artTheme,
            transitionSpec = { fadeIn(tween(420)) togetherWith fadeOut(tween(420)) },
            label = "art_theme_backdrop"
        ) { theme ->
            Image(
                painter = painterResource(id = theme.artDrawableRes),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            glass.backdropScrimTop,
                            glass.backdropScrimMid,
                            glass.backdropScrimBottom
                        )
                    )
                )
        )
        content()
    }
}

/**
 * Translucent frosted glass container with top specular highlight gradient border.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = LocalGlassStyle.current.cardShape,
    containerColor: Color = LocalGlassStyle.current.cardFill,
    contentColor: Color = MaterialTheme.colorScheme.onSurface,
    borderColor: Color = LocalGlassStyle.current.cardBorder,
    borderWidth: Dp = 1.dp,
    content: @Composable () -> Unit
) {
    val glass = LocalGlassStyle.current
    val borderBrush = Brush.verticalGradient(
        colors = listOf(
            glass.specularTopBorder,
            borderColor,
            borderColor.copy(alpha = (borderColor.alpha * 0.55f).coerceIn(0f, 1f))
        )
    )
    Surface(
        modifier = modifier,
        shape = shape,
        color = containerColor,
        contentColor = contentColor,
        border = BorderStroke(borderWidth, borderBrush),
        content = content
    )
}

/**
 * Theme-adaptive Glassmorphism Switch with bouncy spring thumb and luminous active track.
 */
@Composable
fun GlassSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val glass = LocalGlassStyle.current
    val thumbOffset by animateDpAsState(
        targetValue = if (checked) 22.dp else 2.dp,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "glass_switch_thumb"
    )
    val thumbScale by animateFloatAsState(
        targetValue = if (checked) 1.04f else 0.92f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "glass_switch_scale"
    )
    val alphaFactor = if (enabled) 1f else 0.42f
    val trackShape = RoundedCornerShape(50)

    Box(
        modifier = modifier
            .size(width = 50.dp, height = 30.dp)
            .clip(trackShape)
            .background(
                brush = if (checked) {
                    Brush.horizontalGradient(
                        listOf(
                            glass.switchActiveStart.copy(alpha = alphaFactor),
                            glass.switchActiveEnd.copy(alpha = alphaFactor)
                        )
                    )
                } else {
                    Brush.horizontalGradient(
                        listOf(
                            glass.switchInactiveTrack.copy(alpha = alphaFactor),
                            glass.switchInactiveTrack.copy(alpha = alphaFactor)
                        )
                    )
                }
            )
            .border(
                width = 1.dp,
                color = if (checked) glass.specularTopBorder.copy(alpha = 0.65f * alphaFactor)
                else glass.cardBorder.copy(alpha = 0.5f * alphaFactor),
                shape = trackShape
            )
            .clickable(enabled = enabled) { onCheckedChange(!checked) }
            .padding(2.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .offset(x = thumbOffset)
                .size(22.dp)
                .scale(thumbScale)
                .shadow(elevation = if (checked) 4.dp else 1.dp, shape = CircleShape)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = if (enabled) 0.96f else 0.7f))
        )
    }
}

/**
 * Animated sliding glass pill segmented tab bar for Settings sub-tabs.
 */
@Composable
fun <T> GlassSlidingPillTabBar(
    items: List<T>,
    selectedItem: T,
    onSelect: (T) -> Unit,
    labelOf: (T) -> String,
    iconOf: (T) -> ImageVector,
    tagOf: (T) -> String,
    modifier: Modifier = Modifier
) {
    val glass = LocalGlassStyle.current
    val selectedIndex = items.indexOf(selectedItem).coerceAtLeast(0)
    val count = items.size.coerceAtLeast(1)

    val compactStacked = count >= 5
    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .height(if (compactStacked) 58.dp else 50.dp),
        shape = glass.pillShape,
        containerColor = glass.cardFill,
        borderColor = glass.cardBorder
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp)
        ) {
            val segmentWidth = maxWidth / count
            val indicatorOffset by animateDpAsState(
                targetValue = segmentWidth * selectedIndex,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMediumLow
                ),
                label = "sliding_subtab_pill"
            )

            Box(
                modifier = Modifier
                    .offset(x = indicatorOffset)
                    .width(segmentWidth)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape((glass.pillCornerRadius - 3.dp).coerceAtLeast(6.dp)))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(glass.pillActiveStart, glass.pillActiveEnd)
                        )
                    )
                    .border(
                        width = 1.dp,
                        color = glass.specularTopBorder,
                        shape = RoundedCornerShape((glass.pillCornerRadius - 3.dp).coerceAtLeast(6.dp))
                    )
            )

            Row(modifier = Modifier.fillMaxSize()) {
                items.forEach { item ->
                    val selected = item == selectedItem
                    val contentColor by animateColorAsState(
                        targetValue = if (selected) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        animationSpec = tween(220),
                        label = "subtab_color"
                    )
                    val interaction = remember { MutableInteractionSource() }
                    val pressed by interaction.collectIsPressedAsState()
                    val pressScale by animateFloatAsState(
                        targetValue = if (pressed) 0.93f else 1f,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                        label = "subtab_scale"
                    )

                    val tabModifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .scale(pressScale)
                        .clip(RoundedCornerShape((glass.pillCornerRadius - 3.dp).coerceAtLeast(6.dp)))
                        .clickable(
                            interactionSource = interaction,
                            indication = null,
                            onClick = { onSelect(item) }
                        )
                        .padding(horizontal = 2.dp)
                        .testTag(tagOf(item))

                    if (compactStacked) {
                        Column(
                            modifier = tabModifier,
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = iconOf(item),
                                contentDescription = null,
                                tint = contentColor,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = labelOf(item),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = contentColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    } else {
                        Row(
                            modifier = tabModifier,
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = iconOf(item),
                                contentDescription = null,
                                tint = contentColor,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = labelOf(item),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = contentColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

data class GlassNavItem<T>(
    val key: T,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val badgeCount: Int = 0,
    val testTag: String
)

/**
 * Floating frosted-glass bottom navigation bar with spring-sliding active pill.
 */
@Composable
fun <T> GlassBottomNavigationBar(
    items: List<GlassNavItem<T>>,
    selectedKey: T,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    val glass = LocalGlassStyle.current
    val selectedIndex = items.indexOfFirst { it.key == selectedKey }.coerceAtLeast(0)
    val count = items.size.coerceAtLeast(1)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp),
            shape = RoundedCornerShape((glass.pillCornerRadius + 6.dp).coerceAtMost(28.dp)),
            containerColor = glass.navBarFill,
            borderColor = glass.cardBorder,
            borderWidth = 1.dp
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 6.dp, vertical = 6.dp)
            ) {
                val segmentWidth = maxWidth / count
                val indicatorOffset by animateDpAsState(
                    targetValue = segmentWidth * selectedIndex,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioLowBouncy,
                        stiffness = Spring.StiffnessMediumLow
                    ),
                    label = "glass_nav_pill"
                )

                Box(
                    modifier = Modifier
                        .offset(x = indicatorOffset)
                        .width(segmentWidth)
                        .fillMaxHeight()
                        .clip(glass.pillShape)
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    glass.pillActiveStart.copy(alpha = 0.28f),
                                    glass.pillActiveEnd.copy(alpha = 0.22f)
                                )
                            )
                        )
                        .border(
                            width = 1.dp,
                            color = glass.pillActiveStart.copy(alpha = 0.52f),
                            shape = glass.pillShape
                        )
                )

                Row(modifier = Modifier.fillMaxSize()) {
                    items.forEach { item ->
                        val selected = item.key == selectedKey
                        val tint by animateColorAsState(
                            targetValue = if (selected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            animationSpec = tween(220),
                            label = "nav_item_tint"
                        )
                        val iconScale by animateFloatAsState(
                            targetValue = if (selected) 1.12f else 1.0f,
                            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                            label = "nav_icon_scale"
                        )
                        val interaction = remember { MutableInteractionSource() }
                        val pressed by interaction.collectIsPressedAsState()
                        val pressScale by animateFloatAsState(
                            targetValue = if (pressed) 0.92f else 1f,
                            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                            label = "nav_press_scale"
                        )

                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .scale(pressScale)
                                .clip(glass.pillShape)
                                .clickable(
                                    interactionSource = interaction,
                                    indication = null,
                                    onClick = { onSelect(item.key) }
                                )
                                .testTag(item.testTag),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            val iconVec = if (selected) item.selectedIcon else item.unselectedIcon
                            if (item.badgeCount > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge {
                                            Text(if (item.badgeCount > 99) "99+" else item.badgeCount.toString())
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = iconVec,
                                        contentDescription = item.label,
                                        tint = tint,
                                        modifier = Modifier
                                            .size(22.dp)
                                            .scale(iconScale)
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = iconVec,
                                    contentDescription = item.label,
                                    tint = tint,
                                    modifier = Modifier
                                        .size(22.dp)
                                        .scale(iconScale)
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = item.label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = tint,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Reusable PIN / Biometric authorization dialog guarding sensitive actions
 * (deleting notifications when "Yêu cầu PIN/Vân tay khi xoá thông báo" is ON,
 * or disarming Active Motion Anti-Theft).
 */
@Composable
fun ActionAuthGuardDialog(
    title: String,
    subtitle: String,
    biometricAllowed: Boolean,
    hasPinConfigured: Boolean,
    onRequestBiometric: () -> Unit,
    onVerifyPin: (String, (Boolean) -> Unit) -> Unit,
    onDismiss: () -> Unit
) {
    val s = LocalAppStrings.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }

    fun clearIme() {
        focusManager.clearFocus(force = true)
        keyboardController?.hide()
    }

    fun submitPin() {
        if (pinInput.length != 4) return
        clearIme()
        onVerifyPin(pinInput) { ok ->
            if (!ok) {
                pinError = s.lockPinIncorrect
                pinInput = ""
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            keyboardController?.hide()
        }
    }

    AlertDialog(
        onDismissRequest = {
            clearIme()
            onDismiss()
        },
        icon = {
            Icon(
                imageVector = Icons.Filled.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        },
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (biometricAllowed) {
                    OutlinedButton(
                        onClick = {
                            clearIme()
                            onRequestBiometric()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_guard_biometric_button")
                    ) {
                        Icon(Icons.Filled.Fingerprint, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(s.lockBiometricButton)
                    }
                }
                if (hasPinConfigured) {
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { raw ->
                            if (raw.length <= 4 && raw.all(Char::isDigit)) {
                                pinInput = raw
                                pinError = null
                            }
                        },
                        label = { Text(s.pinInputLabel) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.NumberPassword,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(onDone = { submitPin() }),
                        isError = pinError != null,
                        supportingText = { pinError?.let { Text(it) } },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_guard_pin_input")
                    )
                }
            }
        },
        confirmButton = {
            if (hasPinConfigured) {
                Button(
                    enabled = pinInput.length == 4,
                    onClick = { submitPin() },
                    modifier = Modifier.testTag("auth_guard_confirm_pin_button")
                ) {
                    Text(s.save)
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    clearIme()
                    onDismiss()
                }
            ) {
                Text(s.cancel)
            }
        }
    )
}
