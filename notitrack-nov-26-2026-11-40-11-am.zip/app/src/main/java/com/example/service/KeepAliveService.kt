package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.view.View
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.NotiTrackApplication
import com.example.R
import com.example.data.prefs.KeepAliveNotifTheme
import com.example.data.prefs.NotiTrackSettings
import com.example.engine.AntiTheftPhase
import com.example.engine.AntiTheftRuntimeController
import com.example.engine.AntiTheftTriggerReason
import com.example.engine.BatteryOptimizationHelper
import com.example.engine.DeviceGuardEngine
import com.example.engine.DeviceGuardEvent
import com.example.engine.GuardTelemetrySnapshot
import com.example.engine.MotionSensitivity
import com.example.engine.SustainedMotionFilter
import com.example.engine.UtilityAlertDispatcher
import com.example.engine.VietnameseLunarCalendar
import com.example.ui.i18n.stringsFor
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class KeepAliveService : Service(), SensorEventListener {

    private val exceptionHandler = CoroutineExceptionHandler { _, _ -> }
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO + exceptionHandler)

    private data class DeviceTelemetry(
        val tempCelsius: Float = 32f,
        val batteryPercent: Int = 100,
        val isCharging: Boolean = false,
        val dayTick: Long = System.currentTimeMillis() / 60_000L
    )

    private val telemetryFlow = MutableStateFlow(DeviceTelemetry())
    private val guardEngine = DeviceGuardEngine()
    private val sustainedMotionFilter = SustainedMotionFilter()

    private var receiverRegistered = false
    private var foregroundStarted = false
    @Volatile
    private var latestSettings: NotiTrackSettings = NotiTrackSettings()
    @Volatile
    private var latestUnreadCount: Int = 0

    // Active Motion Anti-Theft sensor tracking
    private var sensorManager: SensorManager? = null
    @Volatile
    private var motionSensorRegistered = false
    private var usingRawAccelerometer = false
    private val gravity = FloatArray(3)
    private var gravityInitialized = false
    private var motionArmJob: Job? = null
    @Volatile
    private var motionSensorArmed = false
    private var lastMotionTriggerMs = 0L

    private val systemStatusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_BATTERY_CHANGED -> updateTelemetryFromIntent(intent)
                Intent.ACTION_DATE_CHANGED,
                Intent.ACTION_TIME_CHANGED,
                Intent.ACTION_TIMEZONE_CHANGED -> {
                    telemetryFlow.value = telemetryFlow.value.copy(
                        dayTick = System.currentTimeMillis()
                    )
                }
                Intent.ACTION_SCREEN_ON,
                Intent.ACTION_USER_PRESENT -> {
                    serviceScope.launch {
                        verifyListenerConnection()
                    }
                }
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        AntiTheftRuntimeController.onForceStopMotionSensor = { stopMotionSensor() }

        // Prevent ghost motion triggers from stale persisted flags after process restart or crash
        if (!AntiTheftRuntimeController.motionGuardArmedRequested) {
            serviceScope.launch {
                val app = application as? NotiTrackApplication ?: return@launch
                val snap = runCatching { app.preferences.getSettingsSnapshot() }.getOrNull()
                if (snap?.motionGuardEnabled == true && !AntiTheftRuntimeController.motionGuardArmedRequested) {
                    app.preferences.setMotionGuardEnabled(false)
                }
            }
        }

        registerTelemetryReceiver()
        readStickyBatteryTelemetry(evaluateRules = false)
        promoteInitialForeground()
        startLiveNotificationObserver()
        startListenerWatchdog()
        startUtilityTimerTicker()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopMotionSensor()
                foregroundStarted = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REPOST -> {
                promoteInitialForeground()
                serviceScope.launch {
                    val app = application as? NotiTrackApplication ?: return@launch
                    val settings = app.preferences.getSettingsSnapshot()
                    if (!settings.keepAliveEnabled && !settings.hasAnyUtilityMonitorEnabled) return@launch
                    val unread = runCatching { app.repository.getUnreadCountSnapshot() }
                        .getOrDefault(latestUnreadCount)
                    latestSettings = settings
                    latestUnreadCount = unread
                    delay(250L)
                    val notification = buildStatusNotification(
                        settings = settings,
                        telemetry = telemetryFlow.value,
                        unreadCount = unread,
                        chargeGuardArmed = settings.chargeGuardEnabled && guardEngine.isChargeGuardArmed,
                        motionGuardArmed = motionSensorArmed && AntiTheftRuntimeController.motionGuardArmedRequested
                    )
                    postForegroundNotification(notification)
                }
                return START_STICKY
            }
        }

        readStickyBatteryTelemetry(evaluateRules = false)
        promoteInitialForeground()
        telemetryFlow.value = telemetryFlow.value.copy(dayTick = System.currentTimeMillis())
        serviceScope.launch {
            verifyListenerConnection()
        }
        return START_STICKY
    }

    private fun registerTelemetryReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        runCatching {
            ContextCompat.registerReceiver(
                this,
                systemStatusReceiver,
                filter,
                ContextCompat.RECEIVER_NOT_EXPORTED
            )
            receiverRegistered = true
        }
    }

    private fun readStickyBatteryTelemetry(evaluateRules: Boolean): DeviceTelemetry {
        val sticky = runCatching {
            registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        }.getOrNull()
        return if (sticky != null) {
            updateTelemetryFromIntent(sticky, evaluateRules = evaluateRules)
        } else {
            telemetryFlow.value
        }
    }

    private fun updateTelemetryFromIntent(intent: Intent, evaluateRules: Boolean = true): DeviceTelemetry {
        val rawTemp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 320)
        val tempC = (rawTemp / 10f).coerceIn(0f, 99f)
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val pct = if (level >= 0) ((level * 100f) / scale).roundToInt().coerceIn(0, 100) else 100
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val charging = plugged != 0 ||
            status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val prev = telemetryFlow.value
        val next = prev.copy(
            tempCelsius = tempC,
            batteryPercent = pct,
            isCharging = charging
        )
        if (prev.tempCelsius != tempC || prev.batteryPercent != pct || prev.isCharging != charging) {
            telemetryFlow.value = next
        }
        if (evaluateRules) {
            evaluateGuardRules(next, latestSettings)
        }
        return next
    }

    private fun evaluateGuardRules(telemetry: DeviceTelemetry, settings: NotiTrackSettings) {
        val events = guardEngine.evaluateTelemetry(
            snapshot = GuardTelemetrySnapshot(
                batteryPercent = telemetry.batteryPercent,
                isCharging = telemetry.isCharging,
                tempCelsius = telemetry.tempCelsius,
                nowMs = System.currentTimeMillis()
            ),
            config = settings.toDeviceGuardConfig()
        )
        AntiTheftRuntimeController.updateArmedIndicators(
            chargeGuardArmed = guardEngine.isChargeGuardArmed,
            motionGuardArmed = motionSensorArmed && AntiTheftRuntimeController.motionGuardArmedRequested
        )
        events.forEach { event -> handleGuardEvent(event, settings) }
    }

    private fun handleGuardEvent(event: DeviceGuardEvent, settings: NotiTrackSettings) {
        when (event) {
            is DeviceGuardEvent.LowBatteryAlert -> {
                UtilityAlertDispatcher.dispatchLowBattery(this, settings, event.batteryPercent)
            }
            is DeviceGuardEvent.ChargingLevelAlert -> {
                UtilityAlertDispatcher.dispatchChargingLevel(this, settings, event.batteryPercent)
            }
            is DeviceGuardEvent.FullChargeAlert -> {
                UtilityAlertDispatcher.dispatchFullCharge(
                    context = this,
                    settings = settings,
                    batteryPercent = event.batteryPercent,
                    extraMinutesWaited = event.extraMinutesWaited
                )
            }
            is DeviceGuardEvent.OverheatAlert -> {
                UtilityAlertDispatcher.dispatchOverheat(this, settings, event.tempCelsius)
            }
            is DeviceGuardEvent.ChargerGuardUnplugged -> {
                AntiTheftRuntimeController.triggerGuardBreach(
                    context = this,
                    reason = AntiTheftTriggerReason.CHARGER_UNPLUGGED,
                    delaySeconds = event.delaySeconds,
                    confirmDialogEnabled = event.confirmDialogEnabled,
                    confirmSeconds = event.confirmSeconds,
                    flashEnabled = settings.chargeGuardFlashEnabled,
                    vibrateEnabled = settings.chargeGuardVibrateEnabled
                )
            }
            DeviceGuardEvent.ChargerReconnected -> {
                AntiTheftRuntimeController.onChargerReconnectedDuringGrace()
            }
        }
    }

    private fun startUtilityTimerTicker() {
        serviceScope.launch {
            while (isActive) {
                delay(30_000L)
                val settings = latestSettings
                val telemetry = readStickyBatteryTelemetry(evaluateRules = true)
                val fullAlert = guardEngine.checkFullChargeTimerTick(
                    isCharging = telemetry.isCharging,
                    batteryPercent = telemetry.batteryPercent,
                    nowMs = System.currentTimeMillis(),
                    config = settings.toDeviceGuardConfig()
                )
                if (fullAlert != null) {
                    handleGuardEvent(fullAlert, settings)
                }
            }
        }
    }

    private fun syncMotionGuardSensor(settings: NotiTrackSettings) {
        if (!settings.motionGuardEnabled || !AntiTheftRuntimeController.motionGuardArmedRequested) {
            stopMotionSensor()
            return
        }
        if (motionSensorRegistered || motionArmJob?.isActive == true) return

        val delaySec = settings.motionGuardArmDelaySeconds.coerceIn(0, 30)
        motionArmJob?.cancel()
        motionArmJob = serviceScope.launch {
            var remaining = delaySec
            while (remaining > 0 && isActive && latestSettings.motionGuardEnabled &&
                AntiTheftRuntimeController.motionGuardArmedRequested
            ) {
                AntiTheftRuntimeController.updateArmedIndicators(
                    chargeGuardArmed = guardEngine.isChargeGuardArmed,
                    motionGuardArmed = false,
                    motionArmingCountdownSec = remaining
                )
                delay(1_000L)
                remaining--
            }
            if (isActive && latestSettings.motionGuardEnabled &&
                AntiTheftRuntimeController.motionGuardArmedRequested
            ) {
                startMotionSensorInternal()
            } else {
                stopMotionSensor()
            }
        }
    }

    private fun startMotionSensorInternal() {
        if (!AntiTheftRuntimeController.motionGuardArmedRequested || !latestSettings.motionGuardEnabled) {
            stopMotionSensor()
            return
        }
        val mgr = sensorManager ?: return
        val linear = mgr.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        val chosen = linear ?: mgr.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        usingRawAccelerometer = linear == null
        gravityInitialized = false
        sustainedMotionFilter.reset(System.currentTimeMillis())
        val registered = runCatching {
            mgr.registerListener(this, chosen, SensorManager.SENSOR_DELAY_UI)
        }.getOrDefault(false)
        motionSensorRegistered = registered
        motionSensorArmed = registered
        AntiTheftRuntimeController.updateArmedIndicators(
            chargeGuardArmed = guardEngine.isChargeGuardArmed,
            motionGuardArmed = motionSensorArmed,
            motionArmingCountdownSec = 0
        )
    }

    private fun stopMotionSensor() {
        motionArmJob?.cancel()
        motionArmJob = null
        motionSensorArmed = false
        if (motionSensorRegistered) {
            runCatching { sensorManager?.unregisterListener(this) }
            motionSensorRegistered = false
        }
        gravityInitialized = false
        sustainedMotionFilter.reset(System.currentTimeMillis())
        AntiTheftRuntimeController.updateArmedIndicators(
            chargeGuardArmed = guardEngine.isChargeGuardArmed,
            motionGuardArmed = false,
            motionArmingCountdownSec = 0
        )
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        val settings = latestSettings
        if (!motionSensorArmed ||
            !AntiTheftRuntimeController.motionGuardArmedRequested ||
            !settings.motionGuardEnabled ||
            AntiTheftRuntimeController.isInMotionDisarmCooldown()
        ) {
            stopMotionSensor()
            return
        }
        val currentPhase = AntiTheftRuntimeController.state.value.phase
        if (currentPhase == AntiTheftPhase.ALARM_RINGING || currentPhase == AntiTheftPhase.AWAITING_CONFIRM) {
            return
        }

        val ax: Float
        val ay: Float
        val az: Float
        if (usingRawAccelerometer) {
            val alpha = 0.8f
            if (!gravityInitialized) {
                gravity[0] = event.values[0]
                gravity[1] = event.values[1]
                gravity[2] = event.values[2]
                gravityInitialized = true
                return
            }
            gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0]
            gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1]
            gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2]
            ax = event.values[0] - gravity[0]
            ay = event.values[1] - gravity[1]
            az = event.values[2] - gravity[2]
        } else {
            ax = event.values[0]
            ay = event.values[1]
            az = event.values[2]
        }

        val sensitivity = MotionSensitivity.fromLevel(settings.motionGuardSensitivity)
        val now = System.currentTimeMillis()
        if (sustainedMotionFilter.onReading(ax, ay, az, sensitivity, now)) {
            if (now - lastMotionTriggerMs < 2_500L) return
            lastMotionTriggerMs = now
            AntiTheftRuntimeController.triggerGuardBreach(
                context = this,
                reason = AntiTheftTriggerReason.DEVICE_MOVED,
                delaySeconds = 0,
                confirmDialogEnabled = settings.motionGuardConfirmDialogEnabled,
                confirmSeconds = settings.motionGuardConfirmSeconds,
                flashEnabled = settings.motionGuardFlashEnabled,
                vibrateEnabled = settings.motionGuardVibrateEnabled
            )
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun promoteInitialForeground() {
        val settings = latestSettings
        val unread = latestUnreadCount
        val notification = buildStatusNotification(
            settings = settings,
            telemetry = telemetryFlow.value,
            unreadCount = unread,
            chargeGuardArmed = settings.chargeGuardEnabled && guardEngine.isChargeGuardArmed,
            motionGuardArmed = motionSensorArmed && AntiTheftRuntimeController.motionGuardArmedRequested
        )
        postForegroundNotification(notification)
    }

    private fun postForegroundNotification(notification: Notification) {
        val started = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        }.getOrElse {
            runCatching {
                startForeground(NOTIFICATION_ID, notification)
                true
            }.getOrDefault(false)
        }
        if (started) {
            foregroundStarted = true
        }
        runCatching {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(NOTIFICATION_ID, notification)
        }
    }

    private fun startLiveNotificationObserver() {
        val app = application as? NotiTrackApplication ?: return
        serviceScope.launch {
            combine(
                app.preferences.settingsFlow,
                app.repository.unreadNotificationCount,
                telemetryFlow,
                AntiTheftRuntimeController.state
            ) { settings, unreadCount, telemetry, antiTheftState ->
                QuadState(settings, unreadCount, telemetry, antiTheftState.isChargeGuardArmed, antiTheftState.isMotionGuardArmed)
            }.collect { (settings, unreadCount, telemetry, chargeArmed, motionArmed) ->
                latestSettings = settings
                latestUnreadCount = unreadCount
                val freshTelemetry = readStickyBatteryTelemetry(evaluateRules = false)
                evaluateGuardRules(freshTelemetry, settings)
                syncMotionGuardSensor(settings)

                if (!settings.keepAliveEnabled && !settings.hasAnyUtilityMonitorEnabled) return@collect
                val showChargeIcon = settings.chargeGuardEnabled && (chargeArmed || guardEngine.isChargeGuardArmed)
                val showMotionIcon = AntiTheftRuntimeController.motionGuardArmedRequested && (settings.motionGuardEnabled || motionArmed)
                val notification = buildStatusNotification(
                    settings = settings,
                    telemetry = freshTelemetry,
                    unreadCount = unreadCount,
                    chargeGuardArmed = showChargeIcon,
                    motionGuardArmed = showMotionIcon
                )
                if (!foregroundStarted) {
                    postForegroundNotification(notification)
                } else {
                    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    runCatching {
                        manager.notify(NOTIFICATION_ID, notification)
                    }
                }
            }
        }
    }

    private data class QuadState(
        val settings: NotiTrackSettings,
        val unreadCount: Int,
        val telemetry: DeviceTelemetry,
        val chargeArmed: Boolean,
        val motionArmed: Boolean
    )

    private fun startListenerWatchdog() {
        serviceScope.launch {
            delay(5_000L)
            while (isActive) {
                verifyListenerConnection()
                delay(60_000L)
            }
        }
    }

    private suspend fun verifyListenerConnection() {
        val app = application as? NotiTrackApplication ?: return
        if (!app.repository.isNotificationListenerEnabled()) return
        if (NotiTrackListenerService.isConnected) return

        BatteryOptimizationHelper.requestListenerRebind(this)
        delay(4_000L)
        if (!NotiTrackListenerService.isConnected && app.repository.isNotificationListenerEnabled()) {
            BatteryOptimizationHelper.forceRebindListener(this, respectCooldown = true)
        }
    }

    private fun buildStatusNotification(
        settings: NotiTrackSettings,
        telemetry: DeviceTelemetry,
        unreadCount: Int,
        chargeGuardArmed: Boolean,
        motionGuardArmed: Boolean
    ): Notification {
        val strings = stringsFor(settings.appLanguage)
        ensureChannel(strings.keepAliveChannelName)

        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val dismissIntent = Intent(this, KeepAliveDismissReceiver::class.java).apply {
            action = ACTION_REPOST_KEEP_ALIVE_BROADCAST
        }
        val deletePendingIntent = PendingIntent.getBroadcast(
            this,
            4092,
            dismissIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleExpandIntent = Intent(this, KeepAliveDismissReceiver::class.java).apply {
            action = ACTION_TOGGLE_EXPAND_BROADCAST
        }
        val toggleExpandPendingIntent = PendingIntent.getBroadcast(
            this,
            4093,
            toggleExpandIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val tempText = "${telemetry.tempCelsius.roundToInt()}°C"
        val lunarDate = VietnameseLunarCalendar.today()
        val lunarFullText = lunarDate.formatDdMmYyyy()
        val lunarShortText = lunarDate.formatShort()
        val countShortText = "$unreadCount"
        val countFullText = "$unreadCount ${strings.keepAliveCountShort}"
        val bolt = if (telemetry.isCharging) "⚡" else ""
        val batteryShortText = "$bolt${telemetry.batteryPercent}%"
        val batteryFullText = "${strings.keepAliveBatteryShort} $bolt${telemetry.batteryPercent}%"

        val summaryParts = buildList {
            if (settings.keepAliveShowTemp) add(tempText)
            if (settings.keepAliveShowLunar) add("$lunarFullText ${strings.keepAliveLunarShort}")
            if (settings.keepAliveShowCount) add(countFullText)
            if (settings.keepAliveShowBattery) add(batteryFullText)
        }
        val fallbackSummary = if (summaryParts.isNotEmpty()) {
            summaryParts.joinToString(" • ")
        } else {
            strings.keepAliveNotifText
        }

        val bgRes = when (settings.keepAliveTheme) {
            KeepAliveNotifTheme.JADE -> R.drawable.bg_keep_alive_jade
            KeepAliveNotifTheme.OCEAN -> R.drawable.bg_keep_alive_ocean
            KeepAliveNotifTheme.OBSIDIAN -> R.drawable.bg_keep_alive_obsidian
            KeepAliveNotifTheme.AMBER -> R.drawable.bg_keep_alive_amber
            KeepAliveNotifTheme.CRIMSON -> R.drawable.bg_keep_alive_crimson
        }

        val anyVisible = settings.keepAliveShowTemp || settings.keepAliveShowLunar ||
            settings.keepAliveShowCount || settings.keepAliveShowBattery

        // 1) Compact single-row bar (<=38dp) with built-in expand chevron button
        val compactViews = RemoteViews(packageName, R.layout.notification_keep_alive_compact).apply {
            setInt(R.id.keep_alive_root, "setBackgroundResource", bgRes)

            setViewVisibility(R.id.pill_temp, if (settings.keepAliveShowTemp) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_temp, tempText)

            setViewVisibility(R.id.pill_lunar, if (settings.keepAliveShowLunar) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_lunar, lunarShortText)

            setViewVisibility(R.id.pill_count, if (settings.keepAliveShowCount) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_count, countShortText)

            setViewVisibility(R.id.pill_battery, if (settings.keepAliveShowBattery) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_battery, batteryShortText)

            setViewVisibility(R.id.icon_charge_guard, if (chargeGuardArmed) View.VISIBLE else View.GONE)
            setViewVisibility(R.id.icon_motion_guard, if (motionGuardArmed) View.VISIBLE else View.GONE)

            setViewVisibility(R.id.keep_alive_pills_row, if (anyVisible || chargeGuardArmed || motionGuardArmed) View.VISIBLE else View.GONE)
            setViewVisibility(R.id.keep_alive_fallback_line, if (anyVisible || chargeGuardArmed || motionGuardArmed) View.GONE else View.VISIBLE)
            setTextViewText(R.id.keep_alive_fallback_line, strings.keepAliveNotifText)
            setOnClickPendingIntent(R.id.btn_toggle_expand, toggleExpandPendingIntent)
        }

        // 2) Full-info 2-row card strictly <=46dp so it NEVER clips on Android 12+ 48dp limits,
        //    MIUI Android style, MIUI Classic style, or Android 8-11.
        val fullCompactViews = RemoteViews(packageName, R.layout.notification_keep_alive_full_compact).apply {
            setInt(R.id.keep_alive_root, "setBackgroundResource", bgRes)
            setTextViewText(R.id.keep_alive_title, strings.appName)
            setTextViewText(R.id.keep_alive_badge, strings.keepAliveActiveBadge)
            setViewVisibility(R.id.icon_charge_guard, if (chargeGuardArmed) View.VISIBLE else View.GONE)
            setViewVisibility(R.id.icon_motion_guard, if (motionGuardArmed) View.VISIBLE else View.GONE)

            setViewVisibility(R.id.pill_temp, if (settings.keepAliveShowTemp) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_temp, tempText)

            setViewVisibility(R.id.pill_lunar, if (settings.keepAliveShowLunar) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_lunar, lunarShortText)

            setViewVisibility(R.id.pill_count, if (settings.keepAliveShowCount) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_count, countShortText)

            setViewVisibility(R.id.pill_battery, if (settings.keepAliveShowBattery) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_battery, batteryShortText)

            setViewVisibility(R.id.keep_alive_pills_row, if (anyVisible) View.VISIBLE else View.GONE)
            setViewVisibility(R.id.keep_alive_fallback_line, if (anyVisible) View.GONE else View.VISIBLE)
            setTextViewText(R.id.keep_alive_fallback_line, strings.keepAliveNotifText)
            setOnClickPendingIntent(R.id.btn_toggle_expand, toggleExpandPendingIntent)
        }

        // 3) Spacious BigContentView card (~100dp, well below Android's 252dp big-view cap)
        val expandedViews = RemoteViews(packageName, R.layout.notification_keep_alive).apply {
            setInt(R.id.keep_alive_root, "setBackgroundResource", bgRes)
            setTextViewText(R.id.keep_alive_title, strings.appName)
            setTextViewText(R.id.keep_alive_badge, strings.keepAliveActiveBadge)
            setViewVisibility(R.id.icon_charge_guard, if (chargeGuardArmed) View.VISIBLE else View.GONE)
            setViewVisibility(R.id.icon_motion_guard, if (motionGuardArmed) View.VISIBLE else View.GONE)

            val showRow1 = settings.keepAliveShowTemp || settings.keepAliveShowLunar
            val showRow2 = settings.keepAliveShowCount || settings.keepAliveShowBattery

            setViewVisibility(R.id.keep_alive_row_1, if (showRow1) View.VISIBLE else View.GONE)
            setViewVisibility(R.id.pill_temp, if (settings.keepAliveShowTemp) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_temp, tempText)

            setViewVisibility(R.id.pill_lunar, if (settings.keepAliveShowLunar) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_lunar, "$lunarFullText ${strings.keepAliveLunarShort}")

            setViewVisibility(R.id.keep_alive_row_2, if (showRow2) View.VISIBLE else View.GONE)
            setViewVisibility(R.id.pill_count, if (settings.keepAliveShowCount) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_count, countFullText)

            setViewVisibility(R.id.pill_battery, if (settings.keepAliveShowBattery) View.VISIBLE else View.GONE)
            setTextViewText(R.id.txt_battery, batteryFullText)

            setViewVisibility(R.id.keep_alive_fallback_line, if (anyVisible) View.GONE else View.VISIBLE)
            setTextViewText(R.id.keep_alive_fallback_line, strings.keepAliveNotifText)
            setOnClickPendingIntent(R.id.btn_toggle_expand, toggleExpandPendingIntent)
        }

        val primaryViews = if (settings.keepAliveExpandedDefault) fullCompactViews else compactViews

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(strings.appName)
            .setContentText(fallbackSummary)
            .setCustomContentView(primaryViews)
            .setCustomBigContentView(expandedViews)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setColor(settings.keepAliveTheme.endColorHex.toInt())
            .setOngoing(true)
            .setAutoCancel(false)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(pendingIntent)
            .setDeleteIntent(deletePendingIntent)
            .build()

        notification.flags = notification.flags or
            Notification.FLAG_NO_CLEAR or
            Notification.FLAG_ONGOING_EVENT
        return notification
    }

    private fun ensureChannel(channelName: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                channelName,
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                setShowBadge(false)
                enableLights(false)
                enableVibration(false)
                setSound(null, null)
            }
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        AntiTheftRuntimeController.onForceStopMotionSensor = null
        stopMotionSensor()
        if (receiverRegistered) {
            runCatching { unregisterReceiver(systemStatusReceiver) }
            receiverRegistered = false
        }
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "notitrack_keep_alive_v3"
        const val NOTIFICATION_ID = 4091
        const val ACTION_START = "com.trieuz.notitrack.action.START_KEEP_ALIVE"
        const val ACTION_STOP = "com.trieuz.notitrack.action.STOP_KEEP_ALIVE"
        const val ACTION_REPOST = "com.trieuz.notitrack.action.REPOST_KEEP_ALIVE"
        const val ACTION_REPOST_KEEP_ALIVE_BROADCAST = "com.trieuz.notitrack.action.KEEP_ALIVE_DISMISSED"
        const val ACTION_TOGGLE_EXPAND_BROADCAST = "com.trieuz.notitrack.action.KEEP_ALIVE_TOGGLE_EXPAND"

        fun start(context: Context) {
            runCatching {
                val intent = Intent(context, KeepAliveService::class.java).apply {
                    action = ACTION_START
                }
                ContextCompat.startForegroundService(context, intent)
            }
        }

        fun repost(context: Context) {
            runCatching {
                val intent = Intent(context, KeepAliveService::class.java).apply {
                    action = ACTION_REPOST
                }
                ContextCompat.startForegroundService(context, intent)
            }
        }

        fun stop(context: Context) {
            runCatching {
                val intent = Intent(context, KeepAliveService::class.java).apply {
                    action = ACTION_STOP
                }
                context.startService(intent)
            }
        }
    }
}
