package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.NotiTrackApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Handles keep-alive status bar notification actions:
 * 1) Automatically restores the persistent notification if swiped away on Android 14+.
 * 2) Toggles between Compact and Full Info layout when the built-in chevron button is tapped
 *    (guarantees expand/collapse works on MIUI Classic, Android 8-11, and Android 12+ alike).
 */
class KeepAliveDismissReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != KeepAliveService.ACTION_REPOST_KEEP_ALIVE_BROADCAST &&
            action != KeepAliveService.ACTION_TOGGLE_EXPAND_BROADCAST
        ) {
            return
        }
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val app = context.applicationContext as? NotiTrackApplication ?: return@launch
                val settings = app.preferences.getSettingsSnapshot()
                when (action) {
                    KeepAliveService.ACTION_REPOST_KEEP_ALIVE_BROADCAST -> {
                        if (settings.keepAliveEnabled || settings.hasAnyUtilityMonitorEnabled) {
                            KeepAliveService.repost(context.applicationContext)
                        }
                    }
                    KeepAliveService.ACTION_TOGGLE_EXPAND_BROADCAST -> {
                        app.preferences.setKeepAliveExpandedDefault(!settings.keepAliveExpandedDefault)
                        if (settings.keepAliveEnabled || settings.hasAnyUtilityMonitorEnabled) {
                            KeepAliveService.repost(context.applicationContext)
                        }
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
