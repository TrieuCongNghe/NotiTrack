package com.example

import com.example.data.model.KeywordAction
import com.example.data.model.KeywordRuleEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.TtsFilterMode
import com.example.data.model.TtsNumberReadMode
import com.example.engine.ConversationGrouper
import com.example.engine.KeywordFilterEngine
import com.example.engine.SmartTtsFormatter
import com.example.engine.SmartTtsTemplateEngine
import com.example.engine.VietnameseLunarCalendar
import com.example.ui.i18n.AppLanguage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `keyword filter highlights OTP and mutes TTS`() {
        val rules = listOf(
            KeywordRuleEntity(
                id = 1L,
                keywords = "OTP, chuyển khoản",
                action = KeywordAction.HIGHLIGHT
            ),
            KeywordRuleEntity(
                id = 2L,
                keywords = "OTP, mật khẩu",
                action = KeywordAction.MUTE_TTS
            )
        )

        val result = KeywordFilterEngine.evaluate(
            packageName = "com.bank.app",
            title = "Thông báo giao dịch",
            content = "Mã OTP xác thực của bạn là 482916",
            subText = "",
            rules = rules
        )

        assertFalse(result.shouldBlock)
        assertTrue(result.shouldHighlight)
        assertTrue(result.shouldMuteTts)
        assertEquals(listOf(1L, 2L), result.matchedRuleIds)
    }

    @Test
    fun `keyword filter blocks spam and respects app scope`() {
        val rules = listOf(
            KeywordRuleEntity(
                id = 10L,
                keywords = "flash sale, voucher",
                action = KeywordAction.BLOCK,
                targetPackage = "com.shop.app"
            )
        )

        val blocked = KeywordFilterEngine.evaluate(
            packageName = "com.shop.app",
            title = "Flash Sale 50%",
            content = "Săn deal ngay",
            subText = "",
            rules = rules
        )
        assertTrue(blocked.shouldBlock)

        val otherApp = KeywordFilterEngine.evaluate(
            packageName = "com.chat.app",
            title = "Flash Sale 50%",
            content = "Bạn gửi link",
            subText = "",
            rules = rules
        )
        assertFalse(otherApp.shouldBlock)
    }

    @Test
    fun `otp extractor detects code only with otp context`() {
        assertEquals(
            "482916",
            KeywordFilterEngine.extractOtpCode(
                "Ngân hàng",
                "Mã xác thực OTP của bạn là 482916 để hoàn tất giao dịch"
            )
        )
        assertNull(
            KeywordFilterEngine.extractOtpCode(
                "Lịch họp",
                "Phòng họp 2045 lúc 14h chiều nay"
            )
        )
    }

    @Test
    fun `smart tts formats bank transaction concisely and hides balance when enabled`() {
        val spokenHidden = SmartTtsFormatter.formatForSpeech(
            appName = "MB Bank",
            title = "Biến động số dư",
            content = "TK 003456xxxx GD: +50,000 VND luc 14:25 19/11/2026. SD: 15,420,000 VND. ND: Chuyen tien cafe FT263239182736",
            includeAppName = true,
            smartFilterEnabled = true,
            hideBalance = true,
            language = AppLanguage.VIETNAMESE
        )

        assertTrue("Got: $spokenHidden", spokenHidden.contains("Đã nhận 50.000 đồng"))
        assertFalse("Got: $spokenHidden", spokenHidden.contains("FT263239182736"))
        assertFalse("Got: $spokenHidden", spokenHidden.contains("15.420.000"))
        assertFalse("Got: $spokenHidden", spokenHidden.contains("15,420,000"))

        val spokenWithBalance = SmartTtsFormatter.formatForSpeech(
            appName = "MB Bank",
            title = "Biến động số dư",
            content = "TK 003456xxxx GD: +50,000 VND luc 14:25 19/11/2026. SD: 15,420,000 VND. ND: Chuyen tien cafe FT263239182736",
            includeAppName = true,
            smartFilterEnabled = true,
            hideBalance = false,
            language = AppLanguage.VIETNAMESE
        )

        assertTrue("Got: $spokenWithBalance", spokenWithBalance.contains("Đã nhận 50.000 đồng"))
        assertTrue("Got: $spokenWithBalance", spokenWithBalance.contains("Số dư 15.420.000 đồng"))
        assertFalse("Got: $spokenWithBalance", spokenWithBalance.contains("FT263239182736"))
    }

    @Test
    fun `vietnamese lunar calendar converts known Tet dates accurately`() {
        val tet2025 = VietnameseLunarCalendar.solarToLunar(29, 1, 2025)
        assertEquals(1, tet2025.day)
        assertEquals(1, tet2025.month)
        assertEquals(2025, tet2025.year)

        val tet2026 = VietnameseLunarCalendar.solarToLunar(17, 2, 2026)
        assertEquals(1, tet2026.day)
        assertEquals(1, tet2026.month)
        assertEquals(2026, tet2026.year)
    }

    @Test
    fun `conversation grouper merges messages from same sender and strips count suffix`() {
        val m1 = NotificationEntity(
            id = 1L,
            packageName = "com.zing.zalo",
            appName = "Zalo",
            title = "Nhóm Gia Đình (2 tin nhắn)",
            content = "Tối nay ăn gì?",
            timestamp = 1000L
        )
        val m2 = NotificationEntity(
            id = 2L,
            packageName = "com.zing.zalo",
            appName = "Zalo",
            title = "Nhóm Gia Đình",
            content = "Ăn lẩu nhé!",
            timestamp = 2000L
        )

        val threads = ConversationGrouper.buildThreads(listOf(m1, m2))
        assertEquals(1, threads.size)
        assertEquals("Nhóm Gia Đình", threads.first().threadTitle)
        assertEquals(2, threads.first().totalCount)
        assertEquals("Ăn lẩu nhé!", threads.first().latestContent)
    }

    @Test
    fun `smart tts strictly strips account numbers and transfer memos`() {
        val spoken = SmartTtsFormatter.formatForSpeech(
            appName = "MB Bank",
            title = "Biến động số dư",
            content = "TK 003456 GD: +50,000 VND luc 14:25 19/11/2026. SD: 15,420,000 VND. ND: NGUYEN VAN A chuyen tien cafe",
            includeAppName = true,
            smartFilterEnabled = true,
            hideBalance = true,
            language = AppLanguage.VIETNAMESE
        )

        assertEquals("MB Bank: Đã nhận 50.000 đồng.", spoken)
        assertFalse("Should strip account number: $spoken", spoken.contains("003456"))
        assertFalse("Should strip memo: $spoken", spoken.contains("NGUYEN VAN A"))
        assertFalse("Should strip memo: $spoken", spoken.contains("cafe"))
    }

    @Test
    fun `number reading mode spells 9999 digit by digit in context auto and exact digits`() {
        val spoken = SmartTtsFormatter.formatForSpeech(
            appName = "Bank",
            title = "Thông báo",
            content = "Số đuôi 9999 đã xác nhận, thanh toán 50000 VND",
            includeAppName = false,
            smartFilterEnabled = false,
            hideBalance = false,
            language = AppLanguage.VIETNAMESE,
            numberReadMode = TtsNumberReadMode.CONTEXT_AUTO
        )

        assertTrue("Expected digit-by-digit for 9999, got: $spoken", spoken.contains("chín chín chín chín"))
        assertTrue("Expected currency amount preserved, got: $spoken", spoken.contains("50000 VND"))

        val exactMode = SmartTtsFormatter.applyNumberReadMode(
            text = "STK 003456 mã 9999",
            mode = TtsNumberReadMode.EXACT_DIGITS,
            language = AppLanguage.VIETNAMESE
        )
        assertTrue("Got: $exactMode", exactMode.contains("không không ba bốn năm sáu"))
        assertTrue("Got: $exactMode", exactMode.contains("chín chín chín chín"))
    }

    @Test
    fun `numeric only tts filter accepts balance alerts and rejects promo ads`() {
        assertTrue(
            SmartTtsFormatter.shouldSpeakForRule(
                title = "MB Bank",
                content = "TK 003456 GD: +250,000 VND. SD: 10,000,000 VND",
                filterMode = TtsFilterMode.NUMERIC_ONLY
            )
        )
        assertFalse(
            SmartTtsFormatter.shouldSpeakForRule(
                title = "Siêu ưu đãi hôm nay",
                content = "Flash sale giảm giá 50% voucher quà tặng cho bạn!",
                filterMode = TtsFilterMode.NUMERIC_ONLY
            )
        )
    }

    @Test
    fun `custom highlight template dynamically extracts highlighted region from new notifications`() {
        val sample = "TK 003456 GD: +50,000 VND luc 14:25 SD: 1,500,000 VND"
        // Tokens: 0=TK, 1=003456, 2=GD:, 3=+50,000, 4=VND, 5=luc, 6=14:25, 7=SD:, 8=1,500,000, 9=VND
        val template = SmartTtsTemplateEngine.buildSerializedTemplate(sample, setOf(3, 4))
        assertTrue(template.startsWith("v1||"))

        val incoming = "TK 998877 GD: +250,000 VND luc 18:10 SD: 9,000,000 VND"
        val extracted = SmartTtsTemplateEngine.applyTemplate(template, incoming)
        assertEquals("+250,000 VND", extracted)
    }

    @Test
    fun `app inbox grouper merges multiple threads of same app into one unique app entry`() {
        val notifications = listOf(
            NotificationEntity(
                id = 1L,
                packageName = "com.zing.zalo",
                appName = "Zalo",
                title = "Nhóm Gia Đình",
                content = "Ăn cơm chưa?",
                timestamp = 1000L
            ),
            NotificationEntity(
                id = 2L,
                packageName = "com.zing.zalo",
                appName = "Zalo",
                title = "Nguyễn Văn A",
                content = "Alo bạn ơi",
                timestamp = 3000L
            ),
            NotificationEntity(
                id = 3L,
                packageName = "com.mbmobile",
                appName = "MB Bank",
                title = "Biến động số dư",
                content = "+50,000 VND",
                timestamp = 2000L
            )
        )

        val appGroups = ConversationGrouper.buildAppGroups(notifications)
        assertEquals(2, appGroups.size)
        assertEquals("com.zing.zalo", appGroups[0].packageName)
        assertEquals(2, appGroups[0].threads.size)
        assertEquals(2, appGroups[0].totalCount)
        assertEquals("com.mbmobile", appGroups[1].packageName)
        assertEquals(1, appGroups[1].threads.size)
    }
}
