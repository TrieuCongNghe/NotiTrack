# Kế hoạch Nâng cấp 5 Tính năng Thông minh cho NotiTrack

Bản kế hoạch này mô tả chi tiết trải nghiệm người dùng, quyết định sản phẩm và kiến trúc kỹ thuật cho 5 nâng cấp mới trên **NotiTrack**: lọc chống đọc quảng cáo theo mật độ số, phản hồi tự học "Nên đọc to / Không đọc to", sao lưu & khôi phục dữ liệu JSON chọn lọc, mở đúng màn hình đích của thông báo khi nhấn biểu tượng ứng dụng, và tùy chọn chỉ đọc to khi màn hình tắt hoặc đang khóa.

---

## Điểm cần xác nhận & Các quyết định đã chốt

Các phương án dưới đây được thiết kế dựa trên các lựa chọn bạn đã xác nhận ở bước trước:

- **Ngưỡng lọc tin nhiều số chống quảng cáo:** Mặc định **> 40%** nội dung là chữ số/mã số, đi kèm thanh trượt cho phép bạn tự điều chỉnh linh hoạt trong khoảng **20% – 70%**.
- **Phạm vi sao lưu (Xuất dữ liệu):** Khi xuất tệp sao lưu JSON, ứng dụng mở hộp thoại cho phép bạn **tích chọn từng hạng mục** (Thông báo, Quy tắc từng ứng dụng, Bộ lọc từ khóa, Mẫu phản hồi đọc to đã học, Tùy chọn chung — mặc định chọn tất cả).
- **Xử lý trùng lặp khi khôi phục (Nhập dữ liệu):** Sau khi đọc tệp sao lưu và hiển thị trước số lượng dữ liệu, ứng dụng sẽ **luôn hỏi bạn chọn** giữa **Gộp thêm (bỏ qua trùng lặp)** hoặc **Thay thế hoàn toàn**.
- **Chế độ Chỉ đọc to khi màn hình tắt:** Khi bật, ứng dụng **vẫn đọc to khi màn hình sáng nhưng điện thoại đang ở màn hình khóa**; chỉ ngừng đọc khi bạn đã mở khóa và đang trực tiếp sử dụng máy.
- **Lưu ý minh bạch về mở đúng đích đến của thông báo:** Android chỉ lưu giữ hành động điều hướng gốc (`PendingIntent`) trong bộ nhớ hệ thống khi thông báo được nhận hoặc đang còn trên thanh trạng thái. Nếu thông báo đã quá cũ, điện thoại vừa khởi động lại, hoặc ứng dụng gốc không gắn liên kết điều hướng, NotiTrack sẽ tự động mở trang chính của ứng dụng đó và hiện thông báo nhỏ giải thích để trải nghiệm luôn mượt mà, không bị lỗi.

---

## 1. Tổng quan & Ý tưởng cốt lõi

NotiTrack tập trung biến hộp thư thông báo thành một trợ lý nghe – quản lý thông báo **chính xác, cá nhân hóa hoàn toàn ngoại tuyến và không bỏ sót giao dịch quan trọng**:

1. **Chặn quảng cáo chính xác khi đọc to:** Xử lý triệt để tình trạng thông báo khuyến mãi (chứa 1–2 con số như "Hoàn 500,000đ" hoặc "Ưu đãi 11/11") vẫn lọt qua bộ lọc cũ bằng thước đo mật độ số trên toàn bộ nội dung (tính cả số tiền, số tài khoản, số che `00xxx456`, mã giao dịch, ngày/giờ và OTP).
2. **Dạy ứng dụng hiểu ý bạn chỉ với 1 chạm:** Mỗi thông báo đều có thể được đánh dấu **"Nên đọc to"** hoặc **"Không đọc to"**. Hệ thống tự trích xuất khuôn mẫu văn bản (ẩn các phần biến động như số tiền, ngày giờ, mã giao dịch) để những lần sau nhận tin tương tự, ứng dụng sẽ tuyệt đối tuân theo lựa chọn của bạn.
3. **Di chuyển và bảo vệ dữ liệu an toàn:** Xuất/nhập toàn bộ hoặc từng phần dữ liệu sang tệp JSON chuẩn bằng trình quản lý tệp của Android mà không cần xin quyền truy cập bộ nhớ ngoài.
4. **Điều hướng một chạm đúng ngữ cảnh:** Nhấn vào biểu tượng ứng dụng ngay trên thẻ thông báo, dòng thời gian hội thoại hoặc bảng chi tiết để nhảy thẳng vào đúng đoạn tin nhắn hoặc màn hình chi tiết của thông báo đó.
5. **Tôn trọng ngữ cảnh sử dụng điện thoại:** Tự động im lặng khi bạn đang mở khóa cầm máy dùng, nhưng vẫn đọc kịp thời khi điện thoại đang tắt màn hình hoặc chỉ bật sáng ở màn hình khóa.

---

## 2. Trải nghiệm người dùng & Thiết kế giao diện

Toàn bộ giao diện bổ sung tuân theo ngôn ngữ **Material Design 3** hiện tại của NotiTrack (bảng màu Emerald/Teal chủ đạo, hỗ trợ giao diện Sáng/Tối, vùng chạm tối thiểu `48dp`, thanh trượt và chip trạng thái rõ ràng).

### Luồng 1: Lọc chống đọc quảng cáo theo mật độ số (Mặc định 40%)
- **Tự động kích hoạt đúng ý định:** Khi người dùng bật **"Lược bỏ thông báo"** (Smart Filter) cho ứng dụng, chế độ lọc tin nhiều số sẽ được kích hoạt đồng bộ mặc định để chặn quảng cáo ngay lập tức (trừ khi người dùng chủ động vào biểu tượng bánh răng ⚙️ và chọn *"Đọc tất cả (kể cả quảng cáo)"*).
- **Thanh trượt căn chỉnh trực quan (20% – 70%):**
  - Xuất hiện trong phần **Đọc to thông báo** ở tab **Cài đặt** (áp dụng ngưỡng chuẩn chung) và trong hộp thoại **Cấu hình lọc nâng cao (⚙️)** của từng ứng dụng.
  - Khi người dùng chọn một tin nhắn mẫu trong hộp thoại ⚙️, giao diện hiển thị ngay **tỷ lệ mật độ số thực tế** của tin đó (ví dụ: *"Mật độ số: 48% — Đạt ngưỡng > 40% (Sẽ đọc to)"* màu xanh ngọc, hoặc *"Mật độ số: 15% — Dưới ngưỡng 40% (Bỏ qua quảng cáo)"* màu hổ phách) để người dùng kiểm chứng ngay lập tức.

### Luồng 2: Phản hồi "Nên đọc to" / "Không đọc to" & Quản lý mẫu đã học
- **Tương tác ngay trên thông báo:**
  - Trong **bảng chi tiết thông báo** và **menu thao tác nhanh** ở dòng thời gian tin nhắn, bổ sung hàng nút phản hồi rõ ràng với biểu tượng trực quan:
    - Chip/nút **"Nên đọc to"** (biểu tượng loa có dấu tick, màu xanh chủ đạo khi đang kích hoạt).
    - Chip/nút **"Không đọc to"** (biểu tượng loa gạch chéo, màu cảnh báo nhẹ khi đang kích hoạt).
  - Sau khi bấm, xuất hiện thông báo nhanh (Snackbar) xác nhận *"Đã ghi nhớ: Các tin tương tự từ [Tên ứng dụng] sẽ được đọc to / sẽ không đọc to"* kèm nút **"Hoàn tác"**.
  - Nếu một thông báo khớp với mẫu đã học, hiển thị nhãn trạng thái nhỏ (*"Đã học: Nên đọc"* hoặc *"Đã học: Chặn đọc"*) để người dùng luôn biết lý do ứng dụng xử lý như vậy.
- **Quản lý mẫu đã học trong Cài đặt:**
  - Thêm mục **"Mẫu phản hồi đọc to đã học"** (hiển thị số lượng mẫu đang lưu) trong phần Đọc to ở tab Cài đặt.
  - Mở hộp thoại/trang danh sách liệt kê theo từng ứng dụng: nội dung mẫu đại diện, trạng thái (*Luôn đọc* / *Chặn đọc*), số lần đã áp dụng, nút đổi chiều nhanh và nút xóa từng mẫu hoặc xóa toàn bộ.

### Luồng 3: Nhập / Xuất dữ liệu sao lưu JSON chọn lọc
- **Vị trí:** Trong tab **Cài đặt** → nhóm **Bảo mật & Dữ liệu** (đặt cạnh tùy chọn xuất nhật ký văn bản hiện có), bổ sung hai nút rõ ràng: **"Sao lưu dữ liệu (Xuất JSON)"** và **"Khôi phục dữ liệu (Nhập JSON)"**.
- **Quy trình Xuất (Sao lưu):**
  1. Bấm **"Sao lưu dữ liệu"** → mở hộp thoại chọn hạng mục với 5 ô kiểm (mặc định tích sẵn tất cả) kèm số lượng bản ghi hiện có bên cạnh mỗi mục:
     - Thông báo đã lưu
     - Cài đặt từng ứng dụng (đọc to, lược bỏ, chế độ lọc...)
     - Bộ lọc từ khóa
     - Mẫu phản hồi đọc to đã học
     - Tùy chọn chung của ứng dụng
  2. Bấm **"Tiếp tục chọn nơi lưu"** → mở trình lưu tệp hệ thống Android với tên gợi ý `notitrack_backup_YYYYMMDD_HHmm.json`.
  3. Hoàn tất hiển thị Snackbar xác nhận thành công.
- **Quy trình Nhập (Khôi phục):**
  1. Bấm **"Khôi phục dữ liệu"** → mở trình chọn tệp hệ thống Android (lọc tệp JSON).
  2. Ứng dụng kiểm tra cấu trúc, phiên bản sao lưu và hiển thị hộp thoại **Xem trước bản sao lưu** (ngày tạo, số lượng thông báo, số quy tắc ứng dụng, từ khóa, mẫu học, và có kèm tùy chọn chung hay không).
  3. Người dùng chọn rõ 1 trong 2 phương án xử lý:
     - **Gộp thêm & bỏ qua trùng lặp** (Khuyên dùng — giữ dữ liệu hiện tại, chỉ thêm phần còn thiếu).
     - **Thay thế hoàn toàn** (Xóa dữ liệu cũ của các hạng mục có trong tệp và nạp dữ liệu sao lưu, kèm ghi chú cảnh báo trực quan).
  4. Sau khi khôi phục xong, hiển thị tổng kết ngắn gọn số mục đã thêm/cập nhật và làm mới giao diện ngay lập tức.

### Luồng 4: Mở đúng đích đến thông báo khi nhấn icon ứng dụng
- **Điểm chạm nhất quán khắp ứng dụng:** Biểu tượng ứng dụng (App Icon) trên:
  - Thẻ thông báo trong danh sách Hộp thư,
  - Tiêu đề nhóm ứng dụng / bong bóng tin nhắn trong Chế độ dòng thời gian hội thoại,
  - Thanh tiêu đề của bảng Chi tiết thông báo
  đều được thiết kế vùng chạm đạt chuẩn `48dp`, có hiệu ứng nhấn (ripple) và mô tả trợ năng rõ ràng (*"Mở thẳng nội dung thông báo trong [Tên ứng dụng]"*).
- **Hành vi điều hướng:**
  - Nhấn vào icon → mở ngay đúng cuộc trò chuyện, đúng bài viết hoặc đúng trang giao dịch gắn với thông báo đó.
  - Nếu thông báo không chứa dữ liệu điều hướng hoặc Android đã thu hồi liên kết cũ → tự động mở trang chính của ứng dụng gốc và hiện một dòng gợi ý nhẹ *"Liên kết gốc của thông báo đã hết hạn — đang mở trang chính ứng dụng"*.

### Luồng 5: Chỉ đọc to khi màn hình tắt (hỗ trợ màn hình khóa)
- **Vị trí:** Trong tab **Cài đặt** → phần **Đọc to thông báo** (hiển thị nổi bật ngay dưới các thiết lập điều kiện đọc to).
- **Hiển thị rõ ràng:** Công tắc **"Chỉ đọc to khi màn hình tắt"** kèm dòng mô tả phụ: *"Vẫn đọc to khi màn hình sáng nhưng điện thoại đang khóa; tạm ngừng đọc khi bạn đang mở khóa sử dụng máy."*

---

## 3. Quyết định sản phẩm & Các đánh đổi kỹ thuật

| Hạng mục | Giải pháp lựa chọn | Lý do & Đánh đổi |
| :--- | :--- | :--- |
| **Thuật toán tính tỷ lệ mật độ số (> 40%)** | Phân tích toàn bộ tiêu đề + nội dung, tách theo cụm từ/token. Những cụm mang bản chất số liệu (số tiền kèm dấu phẩy/chấm/đơn vị `VND`/`đ`, số tài khoản kể cả dạng che như `00xxx456`, mã giao dịch nhiều số như `FT263235...`, ngày `19/11/26`, giờ `18:28`, mã OTP) được tính vào tử số; mẫu số là tổng độ dài ký tự thực (không tính khoảng trắng thừa và dấu phân cách). | Kiểm chứng trên hai mẫu ngân hàng thực tế của bạn (MB Bank dạng dấu `\|` và Techcombank dạng nhiều dòng) đều đạt **~45% – 55%**, vượt xa ngưỡng 40%, trong khi thông báo quảng cáo điển hình (*"Ưu đãi hoàn 500,000 VND khi mở thẻ..."*) chỉ đạt **~13% – 20%** nên bị chặn sạch. Kèm thanh kéo 20%–70% để người dùng tinh chỉnh theo đặc thù từng ngân hàng. |
| **Nhận diện mẫu phản hồi tự học (Ngoại tuyến)** | Chuẩn hóa động nội dung thành "dấu vân tay mẫu" (thay số tiền thành `<AMT>`, ngày thành `<DATE>`, giờ thành `<TIME>`, số tài khoản/mã dài thành `<NUM>`/`<CODE>`). So khớp ưu tiên trùng dấu vân tay mẫu trong cùng ứng dụng; nếu cấu trúc hơi biến thiên (như quảng cáo thay đổi vài từ) thì đối chiếu độ tương đồng từ khóa tĩnh (ngưỡng ≥ 65%). | Không cần kết nối mạng hay AI đám mây, tốc độ kiểm tra tức thì (< 2ms), bảo mật tuyệt đối dữ liệu ngân hàng trên thiết bị. Nhờ chuẩn hóa động, chỉ cần đánh dấu 1 tin giao dịch hoặc 1 mẫu quảng cáo là áp dụng được cho tất cả tin tương tự về sau. |
| **Thứ tự ưu tiên quyết định Đọc to** | 1. Công tắc đọc to của ứng dụng → 2. Điều kiện màn hình tắt/khóa → 3. Quy tắc từ khóa tắt tiếng → 4. **Phản hồi người dùng đã học (`Nên đọc` / `Không đọc`)** → 5. Bộ lọc mật độ số (> 40%) khi bật Lược bỏ. | Đảm bảo ý muốn trực tiếp của người dùng luôn chiến thắng mọi thuật toán tự động: tin ít số vẫn được đọc nếu bạn đã dạy "Nên đọc to", và tin nhiều số vẫn bị chặn nếu bạn đã dạy "Không đọc to". |
| **Mở đúng đích đến từ Icon ứng dụng** | Kết hợp 2 lớp truy xuất `PendingIntent`: (1) Bộ nhớ đệm LRU lưu ngay tại thời điểm `NotificationListenerService` nhận thông báo (gắn theo cả ID bản ghi và khóa thông báo Android), và (2) Truy vấn trực tiếp `activeNotifications` của hệ thống nếu thông báo vẫn còn trên thanh trạng thái. Trên Android 14+, cấp cờ cho phép mở hoạt động từ `PendingIntent` hợp lệ khi người dùng chủ động chạm trên giao diện. | Đây là cách duy nhất trên Android để nhảy thẳng vào đúng cuộc trò chuyện hoặc màn hình chức năng của ứng dụng bên thứ ba mà không cần quyền đặc biệt hay tích hợp riêng từng app. Đánh đổi là giới hạn bảo mật cố hữu của Android: `PendingIntent` không thể ghi xuống đĩa cứng qua lần khởi động lại máy, nên có cơ chế dự phòng mở trang chính ứng dụng. |
| **Định dạng & Quyền Nhập/Xuất dữ liệu** | Sử dụng **Storage Access Framework** chuẩn của Android (`CreateDocument` / `OpenDocument`) với định dạng JSON có trường phiên bản schema (`schemaVersion = 1`). Khử trùng lặp khi Gộp thêm dựa trên tổ hợp đặc trưng `(packageName, timestamp, title, text)` cho thông báo và khóa tự nhiên cho quy tắc/từ khóa/mẫu học. | Tuân thủ tuyệt đối chính sách Google Play (không xin quyền đọc/ghi bộ nhớ ngoài), người dùng tự chọn lưu vào Bộ nhớ máy, Thẻ nhớ hoặc Google Drive. Chế độ Gộp thêm an toàn, không tạo bản ghi nhân đôi khi nhập lại nhiều lần. |
| **Nâng cấp cơ sở dữ liệu an toàn** | Bổ sung bảng lưu mẫu phản hồi mới và cột ngưỡng mật độ số thông qua quy trình nâng cấp lược đồ (Migration) không phá hủy dữ liệu từ phiên bản cơ sở dữ liệu hiện tại lên phiên bản kế tiếp. | Giữ nguyên 100% lịch sử thông báo, quy tắc ứng dụng và từ khóa người dùng đã thiết lập từ các bản trước mà không bị mất dữ liệu khi cập nhật ứng dụng. |

---

## 4. Kiến trúc kỹ thuật & Chiến lược dữ liệu

### Luồng xử lý thông báo & Tương tác tổng thể

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                    HỆ THỐNG THÔNG BÁO ANDROID                           │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │ onNotificationPosted(sbn)
                                ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    NotiTrack Listener Service                           │
│  ┌──────────────────────────────┐  ┌─────────────────────────────────┐  │
│  │ Lưu bản ghi thông báo (Room) │  │ Lưu PendingIntent gốc vào bộ    │  │
│  │ (Giữ nguyên lịch sử offline) │  │ nhớ đệm IntentRegistry (LRU)    │  │
│  └──────────────┬───────────────┘  └────────────────┬────────────────┘  │
└─────────────────┼───────────────────────────────────┼───────────────────┘
                  │                                   │
                  ▼                                   ▼
┌──────────────────────────────────────┐  ┌───────────────────────────────┐
│      BỘ LỌC QUYẾT ĐỊNH ĐỌC TO        │  │   ĐIỀU HƯỚNG TỪ ICON ỨNG DỤNG │
│  1. Quy tắc bật/tắt đọc theo App     │  │  (Hộp thư / Chat / Chi tiết)  │
│  2. Kiểm tra Màn hình tắt / Đang khóa│  │  1. Tìm PendingIntent trong   │
│     (!isInteractive || isLocked)     │  │     IntentRegistry (LRU)      │
│  3. Từ khóa tắt tiếng (Keyword)      │  │  2. Nếu không thấy, kiểm tra  │
│  4. Mẫu phản hồi người dùng (Room)   │  │     activeNotifications       │
│     ├─ Nên đọc to  ──► ĐỌC NGAY      │  │  3. Gửi intent (Android 14+   │
│     └─ Không đọc   ──► BỎ QUA        │  │     BackgroundStartAllowed)   │
│  5. Lọc mật độ số (Mặc định > 40%,   │  │  4. Dự phòng: Mở trang chính  │
│     tùy chỉnh 20%–70%)               │  │     ứng dụng + Snackbar       │
└─────────────────┬────────────────────┘  └───────────────────────────────┘
                  │ Đạt điều kiện
                  ▼
┌─────────────────────────────────────────────────────────────────────────┐
│          Smart TTS Formatter ──► Hàng đợi Đọc to tuần tự (TTS)          │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│             SAO LƯU & KHÔI PHỤC DỮ LIỆU CHỌN LỌC (SAF JSON)             │
│  [Hộp thoại chọn 5 mục] ──► Export JSON (CreateDocument)                │
│  Import JSON (OpenDocument) ──► [Xem trước số lượng]                    │
│                                  ├──► Gộp thêm (bỏ qua trùng lặp)       │
│                                  └──► Thay thế hoàn toàn                │
└─────────────────────────────────────────────────────────────────────────┘
```

### Mô hình dữ liệu & Lưu trữ

1. **Bảng Mẫu Phản Hồi Đọc To (Room — bảng mới, Migration không mất dữ liệu):**
   - Lưu mã định danh, tên gói ứng dụng, tên hiển thị ứng dụng, dấu vân tay mẫu đã chuẩn hóa, chữ ký tiêu đề, đoạn xem trước mẫu, quyết định (`shouldSpeak`: Nên đọc / Không đọc), số lần khớp thực tế và thời gian tạo.
   - Đánh chỉ mục theo tên gói ứng dụng để truy vấn tức thì khi có thông báo đến.
2. **Mở rộng Quy tắc theo Ứng dụng (Room — bổ sung cột tùy chọn):**
   - Bổ sung ngưỡng mật độ số riêng cho từng ứng dụng (cho phép dùng theo mức chuẩn chung hoặc tùy chỉnh riêng trong hộp thoại ⚙️).
   - Bảo đảm chế độ lọc tin nhiều số tự động có hiệu lực khi bật "Lược bỏ thông báo" trừ khi người dùng chủ động chọn đọc cả quảng cáo.
3. **Tùy chọn chung (DataStore Preferences):**
   - `ttsOnlyWhenScreenOff` (Boolean, mặc định `false`): Bật/tắt chỉ đọc to khi màn hình tắt hoặc đang khóa.
   - `ttsNumericRatioPercent` (Int, mặc định `40`, phạm vi `20..70`): Ngưỡng phần trăm mật độ số toàn cục.
4. **Bộ nhớ đệm Liên kết Điều hướng (Trong RAM):**
   - Hàng đợi giới hạn kích thước (tối đa ~500 thông báo gần nhất) ánh xạ theo cả ID thông báo trong cơ sở dữ liệu và khóa thông báo Android (`sbn.key`), tự dọn mục cũ nhất để không tốn RAM.

### Các nhóm tương tác & Trạng thái giao diện cần đồng bộ

- **Màn hình Hộp thư & Dòng thời gian Chat:** Biểu tượng ứng dụng nhận sự kiện nhấn mở đích đến thông báo; phản hồi nhanh nếu dùng đường dẫn dự phòng; đồng bộ trạng thái mẫu phản hồi ngay khi người dùng gắn nhãn.
- **Bảng Chi tiết Thông báo:** Thêm cụm nút phản hồi **"Nên đọc to"** / **"Không đọc to"** có trạng thái đang chọn rõ ràng, hiển thị tỷ lệ mật độ số của thông báo để người dùng dễ theo dõi, và biểu tượng ứng dụng nhấn mở đúng đích đến.
- **Hộp thoại Lọc nâng cao theo ứng dụng (⚙️):** Cập nhật thanh kéo mật độ số (20%–70%) kèm phần hiển thị kết quả đo % số trực tiếp trên tin mẫu được chọn.
- **Tab Cài đặt:**
  - Nhóm **Đọc to thông báo**: Thêm công tắc **"Chỉ đọc to khi màn hình tắt"**, thanh trượt **"Ngưỡng mật độ số chặn quảng cáo (40%)"**, và nút mở trình quản lý **"Mẫu phản hồi đã học"**.
  - Nhóm **Bảo mật & Dữ liệu**: Thêm nút **"Sao lưu dữ liệu (Xuất JSON)"** (mở hộp thoại chọn 5 mục) và **"Khôi phục dữ liệu (Nhập JSON)"** (mở hộp thoại xem trước & chọn Gộp thêm / Thay thế).
- **Xác minh chất lượng sau khi triển khai:** Viết bổ sung kiểm thử đơn vị (JVM) cho bộ tính mật độ số trên các tin ngân hàng thực tế & tin quảng cáo, cơ chế sinh dấu vân tay mẫu phản hồi, thuật toán khử trùng lặp JSON khi Gộp thêm, và biên dịch kiểm tra toàn bộ dự án.
