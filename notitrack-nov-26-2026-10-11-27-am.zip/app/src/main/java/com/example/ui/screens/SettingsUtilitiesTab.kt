package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.RingtoneManager
import android.net.Uri
import android.os.BatteryManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.BatterySaver
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeviceThermostat
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.PhonelinkRing
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.prefs.NotiTrackSettings
import com.example.engine.AntiTheftRuntimeState
import com.example.engine.DeviceGuardEngine
import com.example.engine.MotionSensitivity
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassSwitch
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.i18n.UtilitiesStrings
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.roundToInt

enum class UtilitySoundTarget {
    LOW_BATTERY,
    CHARGING,
    FULL_CHARGE,
    OVERHEAT
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsUtilitiesContent(
    settings: NotiTrackSettings,
    antiTheftState: AntiTheftRuntimeState,
    hasPostNotificationPermission: Boolean,
    hasOverlayPermission: Boolean,
    onRequestPostNotificationPermission: () -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onUpdateUtilities: ((NotiTrackSettings) -> NotiTrackSettings) -> Unit,
    onPickUtilitySound: (UtilitySoundTarget, String) -> Unit,
    onTestUtilityAlert: (UtilitySoundTarget) -> Unit,
    onRequestToggleChargeGuard: (Boolean) -> Unit,
    onRequestToggleMotionGuard: (Boolean) -> Unit,
    onRequestAuthorizeMotionSettings: (onAuthorized: () -> Unit) -> Unit
) {
    val context = LocalContext.current
    val u = LocalAppStrings.current.utilities
    var motionConfigUnlocked by remember { mutableStateOf(false) }

    // Live device telemetry (refreshes every 5s while viewing Utilities tab)
    var liveBatteryPct by remember { mutableIntStateOf(100) }
    var liveIsCharging by remember { mutableStateOf(false) }
    var liveTempC by remember { mutableFloatStateOf(32f) }

    LaunchedEffect(Unit) {
        while (true) {
            val batteryIntent = runCatching {
                context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            }.getOrNull()
            if (batteryIntent != null) {
                val level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                if (level >= 0) {
                    liveBatteryPct = ((level * 100f) / scale).roundToInt().coerceIn(0, 100)
                }
                val status = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val plugged = batteryIntent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
                liveIsCharging = plugged != 0 ||
                    status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
                val rawTemp = batteryIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 320)
                liveTempC = (rawTemp / 10f).coerceIn(0f, 99f)
            }
            delay(5_000L)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Live Device Telemetry & Notification Permission Status Banner
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (liveIsCharging) Icons.Filled.BatteryChargingFull else Icons.Filled.BatteryFull,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = u.telemetryBatteryStatus(liveBatteryPct, liveIsCharging),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DeviceThermostat,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "${String.format(Locale.getDefault(), "%.1f", liveTempC)}°C",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }

                if (!hasPostNotificationPermission) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.75f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.NotificationsOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = u.notifPermMissingBanner,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = onRequestPostNotificationPermission,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error,
                                    contentColor = MaterialTheme.colorScheme.onError
                                ),
                                modifier = Modifier.testTag("util_grant_notif_permission_button")
                            ) {
                                Text(u.grantPermissionAction)
                            }
                        }
                    }
                }
            }
        }

        // 1. Low Battery Alert
        UtilityCardHeader(
            title = u.lowBatTitle,
            subtitle = u.lowBatDesc,
            icon = Icons.Filled.BatteryAlert,
            accentColor = MaterialTheme.colorScheme.error,
            checked = settings.lowBatteryAlertEnabled,
            onCheckedChange = { on ->
                if (on && !hasPostNotificationPermission) onRequestPostNotificationPermission()
                onUpdateUtilities { it.copy(lowBatteryAlertEnabled = on) }
            },
            testTag = "util_low_battery_switch"
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = u.lowBatThresholdLabel(settings.lowBatteryThreshold),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                TextButton(
                    onClick = { onTestUtilityAlert(UtilitySoundTarget.LOW_BATTERY) },
                    modifier = Modifier.testTag("util_low_bat_test_button")
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(u.testAlertAction)
                }
            }
            Slider(
                value = settings.lowBatteryThreshold.toFloat(),
                onValueChange = { raw ->
                    val snapped = raw.roundToInt().coerceIn(5, 50)
                    onUpdateUtilities { it.copy(lowBatteryThreshold = snapped) }
                },
                valueRange = 5f..50f,
                modifier = Modifier.testTag("util_low_bat_slider")
            )
            UtilityAlertChannelsSection(
                context = context,
                u = u,
                ringtoneChecked = settings.lowBatteryRingtoneEnabled,
                onRingtoneChange = { on -> onUpdateUtilities { it.copy(lowBatteryRingtoneEnabled = on) } },
                musicChecked = settings.lowBatteryMusicEnabled,
                onMusicChange = { on -> onUpdateUtilities { it.copy(lowBatteryMusicEnabled = on) } },
                soundUri = settings.lowBatterySoundUri,
                onPickSound = { onPickUtilitySound(UtilitySoundTarget.LOW_BATTERY, settings.lowBatterySoundUri) },
                ttsChecked = settings.lowBatteryTtsEnabled,
                onTtsChange = { on -> onUpdateUtilities { it.copy(lowBatteryTtsEnabled = on) } },
                showBatterySaverOption = true,
                batterySaverChecked = settings.lowBatterySaverPromptEnabled,
                onBatterySaverChange = { on -> onUpdateUtilities { it.copy(lowBatterySaverPromptEnabled = on) } },
                prefixTag = "low_bat"
            )
        }

        // 2. Charging Reminder Alert (urgent plug-in threshold 5%-30%)
        UtilityCardHeader(
            title = u.chargingTitle,
            subtitle = u.chargingDesc,
            icon = Icons.Filled.BatteryChargingFull,
            accentColor = Color(0xFFFF8F00),
            checked = settings.chargingAlertEnabled,
            onCheckedChange = { on ->
                if (on && !hasPostNotificationPermission) onRequestPostNotificationPermission()
                onUpdateUtilities { it.copy(chargingAlertEnabled = on) }
            },
            testTag = "util_charging_switch"
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = u.chargingThresholdLabel(settings.chargingAlertThreshold),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                TextButton(
                    onClick = { onTestUtilityAlert(UtilitySoundTarget.CHARGING) },
                    modifier = Modifier.testTag("util_charging_test_button")
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(u.testAlertAction)
                }
            }
            Slider(
                value = settings.chargingAlertThreshold.coerceIn(5, 30).toFloat(),
                onValueChange = { raw ->
                    val snapped = raw.roundToInt().coerceIn(5, 30)
                    onUpdateUtilities { it.copy(chargingAlertThreshold = snapped) }
                },
                valueRange = 5f..30f,
                modifier = Modifier.testTag("util_charging_slider")
            )
            UtilityAlertChannelsSection(
                context = context,
                u = u,
                ringtoneChecked = settings.chargingRingtoneEnabled,
                onRingtoneChange = { on -> onUpdateUtilities { it.copy(chargingRingtoneEnabled = on) } },
                musicChecked = settings.chargingMusicEnabled,
                onMusicChange = { on -> onUpdateUtilities { it.copy(chargingMusicEnabled = on) } },
                soundUri = settings.chargingSoundUri,
                onPickSound = { onPickUtilitySound(UtilitySoundTarget.CHARGING, settings.chargingSoundUri) },
                ttsChecked = settings.chargingTtsEnabled,
                onTtsChange = { on -> onUpdateUtilities { it.copy(chargingTtsEnabled = on) } },
                showBatterySaverOption = true,
                batterySaverChecked = settings.chargingSaverPromptEnabled,
                onBatterySaverChange = { on -> onUpdateUtilities { it.copy(chargingSaverPromptEnabled = on) } },
                prefixTag = "charging"
            )
        }

        // 3. Full Charge Alert
        UtilityCardHeader(
            title = u.fullChargeTitle,
            subtitle = u.fullChargeDesc,
            icon = Icons.Filled.BatteryFull,
            accentColor = MaterialTheme.colorScheme.tertiary,
            checked = settings.fullChargeAlertEnabled,
            onCheckedChange = { on ->
                if (on && !hasPostNotificationPermission) onRequestPostNotificationPermission()
                onUpdateUtilities { it.copy(fullChargeAlertEnabled = on) }
            },
            testTag = "util_full_charge_switch"
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = u.fullChargeThresholdLabel(settings.fullChargeThreshold),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                TextButton(
                    onClick = { onTestUtilityAlert(UtilitySoundTarget.FULL_CHARGE) },
                    modifier = Modifier.testTag("util_full_charge_test_button")
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(u.testAlertAction)
                }
            }
            Slider(
                value = settings.fullChargeThreshold.toFloat(),
                onValueChange = { raw ->
                    val snapped = raw.roundToInt().coerceIn(80, 100)
                    onUpdateUtilities { it.copy(fullChargeThreshold = snapped) }
                },
                valueRange = 80f..100f,
                modifier = Modifier.testTag("util_full_charge_slider")
            )

            AnimatedVisibility(visible = settings.fullChargeThreshold == 100) {
                Column(modifier = Modifier.padding(top = 6.dp, bottom = 4.dp)) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = if (settings.fullChargeExtraMinutes == 0) {
                                    u.fullChargeExtraZeroLabel
                                } else {
                                    u.fullChargeExtraMinsLabel(settings.fullChargeExtraMinutes)
                                },
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Slider(
                                value = settings.fullChargeExtraMinutes.toFloat(),
                                onValueChange = { raw ->
                                    val snapped = ((raw / 5f).roundToInt() * 5).coerceIn(0, 60)
                                    onUpdateUtilities { it.copy(fullChargeExtraMinutes = snapped) }
                                },
                                valueRange = 0f..60f,
                                steps = 11,
                                modifier = Modifier.testTag("util_full_charge_extra_mins_slider")
                            )
                        }
                    }
                }
            }

            UtilityAlertChannelsSection(
                context = context,
                u = u,
                ringtoneChecked = settings.fullChargeRingtoneEnabled,
                onRingtoneChange = { on -> onUpdateUtilities { it.copy(fullChargeRingtoneEnabled = on) } },
                musicChecked = settings.fullChargeMusicEnabled,
                onMusicChange = { on -> onUpdateUtilities { it.copy(fullChargeMusicEnabled = on) } },
                soundUri = settings.fullChargeSoundUri,
                onPickSound = { onPickUtilitySound(UtilitySoundTarget.FULL_CHARGE, settings.fullChargeSoundUri) },
                ttsChecked = settings.fullChargeTtsEnabled,
                onTtsChange = { on -> onUpdateUtilities { it.copy(fullChargeTtsEnabled = on) } },
                showBatterySaverOption = false,
                batterySaverChecked = false,
                onBatterySaverChange = {},
                prefixTag = "full_chg"
            )
        }

        // 4. Overheat Temperature Alert
        UtilityCardHeader(
            title = u.overheatTitle,
            subtitle = u.overheatDesc,
            icon = Icons.Filled.DeviceThermostat,
            accentColor = Color(0xFFFF7A45),
            checked = settings.overheatAlertEnabled,
            onCheckedChange = { on ->
                if (on && !hasPostNotificationPermission) onRequestPostNotificationPermission()
                onUpdateUtilities { it.copy(overheatAlertEnabled = on) }
            },
            testTag = "util_overheat_switch"
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = u.overheatThresholdLabel(settings.overheatThresholdC),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                TextButton(
                    onClick = { onTestUtilityAlert(UtilitySoundTarget.OVERHEAT) },
                    modifier = Modifier.testTag("util_overheat_test_button")
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(u.testAlertAction)
                }
            }
            Slider(
                value = settings.overheatThresholdC.toFloat(),
                onValueChange = { raw ->
                    onUpdateUtilities { it.copy(overheatThresholdC = raw.roundToInt().coerceIn(36, 55)) }
                },
                valueRange = 36f..55f,
                steps = 18,
                modifier = Modifier.testTag("util_overheat_temp_slider")
            )

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = u.overheatStyleLabel,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = !settings.overheatUseAlarmSound,
                    onClick = { onUpdateUtilities { it.copy(overheatUseAlarmSound = false) } },
                    label = { Text(u.overheatStyleNotif) },
                    leadingIcon = {
                        Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier.testTag("util_overheat_mode_notif")
                )
                FilterChip(
                    selected = settings.overheatUseAlarmSound,
                    onClick = { onUpdateUtilities { it.copy(overheatUseAlarmSound = true) } },
                    label = { Text(u.overheatStyleAlarm) },
                    leadingIcon = {
                        Icon(Icons.Filled.Warning, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier.testTag("util_overheat_mode_alarm")
                )
            }

            if (settings.overheatUseAlarmSound) {
                Spacer(modifier = Modifier.height(6.dp))
                SoundPickerRow(
                    context = context,
                    u = u,
                    soundUri = settings.overheatSoundUri,
                    onPick = { onPickUtilitySound(UtilitySoundTarget.OVERHEAT, settings.overheatSoundUri) },
                    testTag = "util_overheat_pick_sound"
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = u.overheatCooldownLabel(settings.overheatCooldownSeconds),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Slider(
                value = settings.overheatCooldownSeconds.toFloat(),
                onValueChange = { raw ->
                    val snapped = ((raw / 15f).roundToInt() * 15).coerceIn(15, 600)
                    onUpdateUtilities { it.copy(overheatCooldownSeconds = snapped) }
                },
                valueRange = 15f..600f,
                steps = 38,
                modifier = Modifier.testTag("util_overheat_cooldown_slider")
            )
        }

        // Enhanced Alarm Lock Screen Overlay Protection Card
        OverlayProtectionStatusCard(
            u = u,
            hasOverlayPermission = hasOverlayPermission,
            onRequestOverlayPermission = onRequestOverlayPermission
        )

        // 5. Charging Anti-Theft Guard
        UtilityCardHeader(
            title = u.chargeGuardTitle,
            subtitle = u.chargeGuardDesc,
            icon = Icons.Filled.Power,
            accentColor = MaterialTheme.colorScheme.secondary,
            statusBadge = when {
                antiTheftState.isChargeGuardArmed -> u.chargeGuardArmedBadge
                settings.chargeGuardEnabled -> u.chargeGuardStandbyBadge
                else -> null
            },
            checked = settings.chargeGuardEnabled,
            onCheckedChange = onRequestToggleChargeGuard,
            testTag = "util_charge_guard_switch"
        ) {
            Text(
                text = if (settings.chargeGuardMinBatteryPercent == 0) {
                    u.chargeGuardMinBatAny
                } else {
                    u.chargeGuardMinBatAt(settings.chargeGuardMinBatteryPercent)
                },
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Slider(
                value = settings.chargeGuardMinBatteryPercent.toFloat(),
                onValueChange = { raw ->
                    val snapped = ((raw / 5f).roundToInt() * 5).coerceIn(0, 100)
                    onUpdateUtilities { it.copy(chargeGuardMinBatteryPercent = snapped) }
                },
                valueRange = 0f..100f,
                steps = 19,
                modifier = Modifier.testTag("util_charge_guard_min_bat_slider")
            )

            Text(
                text = u.chargeGuardDelayLabel(settings.chargeGuardDelaySeconds),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface
            )
            Slider(
                value = settings.chargeGuardDelaySeconds.toFloat(),
                onValueChange = { raw ->
                    onUpdateUtilities { it.copy(chargeGuardDelaySeconds = raw.roundToInt().coerceIn(0, 30)) }
                },
                valueRange = 0f..30f,
                steps = 29,
                modifier = Modifier.testTag("util_charge_guard_delay_slider")
            )

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            SettingSwitchRow(
                title = u.confirmDialogTitle,
                subtitle = u.confirmDialogDesc,
                checked = settings.chargeGuardConfirmDialogEnabled,
                onCheckedChange = { on -> onUpdateUtilities { it.copy(chargeGuardConfirmDialogEnabled = on) } },
                testTag = "util_charge_guard_confirm_switch"
            )

            AnimatedVisibility(visible = settings.chargeGuardConfirmDialogEnabled) {
                Column(modifier = Modifier.padding(bottom = 8.dp)) {
                    val confirmSec = DeviceGuardEngine.clampConfirmSeconds(settings.chargeGuardConfirmSeconds)
                    Text(
                        text = u.confirmWindowLabel(confirmSec),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Slider(
                        value = confirmSec.toFloat(),
                        onValueChange = { raw ->
                            val snapped = ((raw / 5f).roundToInt() * 5).coerceIn(5, 120)
                            onUpdateUtilities { it.copy(chargeGuardConfirmSeconds = snapped) }
                        },
                        valueRange = 5f..120f,
                        steps = 22,
                        modifier = Modifier.testTag("util_charge_guard_confirm_slider")
                    )
                }
            }

            SettingSwitchRow(
                title = u.flashStrobeTitle,
                subtitle = "",
                checked = settings.chargeGuardFlashEnabled,
                onCheckedChange = { on -> onUpdateUtilities { it.copy(chargeGuardFlashEnabled = on) } },
                testTag = "util_charge_guard_flash_switch",
                leadingIcon = Icons.Filled.FlashlightOn
            )
            SettingSwitchRow(
                title = u.strongVibrateTitle,
                subtitle = "",
                checked = settings.chargeGuardVibrateEnabled,
                onCheckedChange = { on -> onUpdateUtilities { it.copy(chargeGuardVibrateEnabled = on) } },
                testTag = "util_charge_guard_vibrate_switch",
                leadingIcon = Icons.Filled.Vibration
            )

            AntiTheftProtectionNotice(u = u)
        }

        // 6. Active Motion Anti-Theft Guard — always has PIN/Biometric-protected Customize Settings button
        SettingsCard(title = u.motionGuardTitle) {
            val motionAccent = MaterialTheme.colorScheme.error
            val motionBadge = when {
                antiTheftState.motionArmingCountdownSec > 0 ->
                    u.motionGuardArmingBadge(antiTheftState.motionArmingCountdownSec)
                antiTheftState.isMotionGuardArmed -> u.motionGuardArmedBadge
                else -> null
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = motionAccent.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.size(40.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = null,
                            tint = motionAccent,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    if (motionBadge != null) {
                        Surface(
                            color = motionAccent.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, motionAccent.copy(alpha = 0.55f))
                        ) {
                            Text(
                                text = motionBadge,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = motionAccent,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    Text(
                        text = u.motionGuardDesc,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                GlassSwitch(
                    checked = settings.motionGuardEnabled,
                    onCheckedChange = onRequestToggleMotionGuard,
                    modifier = Modifier.testTag("util_motion_guard_switch")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = {
                    if (motionConfigUnlocked) {
                        motionConfigUnlocked = false
                    } else {
                        onRequestAuthorizeMotionSettings {
                            motionConfigUnlocked = true
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("util_motion_guard_customize_button")
            ) {
                Icon(
                    imageVector = if (motionConfigUnlocked) Icons.Filled.LockOpen else Icons.Filled.Lock,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Filled.Tune,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (motionConfigUnlocked) u.motionCustomizeCloseAction else u.motionCustomizeOpenAction,
                    fontWeight = FontWeight.SemiBold
                )
            }

            AnimatedVisibility(visible = motionConfigUnlocked) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = u.motionSensitivityLabel,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MotionSensitivity.entries.forEach { sens ->
                            val label = when (sens) {
                                MotionSensitivity.LOW -> u.motionSensLow
                                MotionSensitivity.MEDIUM -> u.motionSensMedium
                                MotionSensitivity.HIGH -> u.motionSensHigh
                            }
                            FilterChip(
                                selected = settings.motionGuardSensitivity == sens.level,
                                onClick = { onUpdateUtilities { it.copy(motionGuardSensitivity = sens.level) } },
                                label = { Text(label, style = MaterialTheme.typography.labelMedium) },
                                modifier = Modifier.testTag("util_motion_sens_${sens.name.lowercase()}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = u.motionArmDelayLabel(settings.motionGuardArmDelaySeconds),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Slider(
                        value = settings.motionGuardArmDelaySeconds.toFloat(),
                        onValueChange = { raw ->
                            onUpdateUtilities { it.copy(motionGuardArmDelaySeconds = raw.roundToInt().coerceIn(0, 30)) }
                        },
                        valueRange = 0f..30f,
                        steps = 29,
                        modifier = Modifier.testTag("util_motion_arm_delay_slider")
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                    SettingSwitchRow(
                        title = u.confirmDialogTitle,
                        subtitle = u.confirmDialogDesc,
                        checked = settings.motionGuardConfirmDialogEnabled,
                        onCheckedChange = { on -> onUpdateUtilities { it.copy(motionGuardConfirmDialogEnabled = on) } },
                        testTag = "util_motion_guard_confirm_switch"
                    )

                    AnimatedVisibility(visible = settings.motionGuardConfirmDialogEnabled) {
                        Column(modifier = Modifier.padding(bottom = 8.dp)) {
                            val confirmSec = DeviceGuardEngine.clampConfirmSeconds(settings.motionGuardConfirmSeconds)
                            Text(
                                text = u.confirmWindowLabel(confirmSec),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Slider(
                                value = confirmSec.toFloat(),
                                onValueChange = { raw ->
                                    val snapped = ((raw / 5f).roundToInt() * 5).coerceIn(5, 120)
                                    onUpdateUtilities { it.copy(motionGuardConfirmSeconds = snapped) }
                                },
                                valueRange = 5f..120f,
                                steps = 22,
                                modifier = Modifier.testTag("util_motion_guard_confirm_slider")
                            )
                        }
                    }

                    SettingSwitchRow(
                        title = u.flashStrobeTitle,
                        subtitle = "",
                        checked = settings.motionGuardFlashEnabled,
                        onCheckedChange = { on -> onUpdateUtilities { it.copy(motionGuardFlashEnabled = on) } },
                        testTag = "util_motion_guard_flash_switch",
                        leadingIcon = Icons.Filled.FlashlightOn
                    )
                    SettingSwitchRow(
                        title = u.strongVibrateTitle,
                        subtitle = "",
                        checked = settings.motionGuardVibrateEnabled,
                        onCheckedChange = { on -> onUpdateUtilities { it.copy(motionGuardVibrateEnabled = on) } },
                        testTag = "util_motion_guard_vibrate_switch",
                        leadingIcon = Icons.Filled.Vibration
                    )

                    AntiTheftProtectionNotice(u = u)
                }
            }
        }
    }
}

@Composable
private fun OverlayProtectionStatusCard(
    u: UtilitiesStrings,
    hasOverlayPermission: Boolean,
    onRequestOverlayPermission: () -> Unit
) {
    val accent = if (hasOverlayPermission) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
    SettingsCard(title = u.overlaySectionTitle) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                color = accent.copy(alpha = 0.16f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.size(40.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (hasOverlayPermission) Icons.Filled.CheckCircle else Icons.Filled.Layers,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                if (hasOverlayPermission) {
                    Surface(
                        color = accent.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f))
                    ) {
                        Text(
                            text = u.overlayActiveBadge,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = accent,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }
                Text(
                    text = if (hasOverlayPermission) u.overlayGrantedDesc else u.overlayMissingDesc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (!hasOverlayPermission) {
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onRequestOverlayPermission,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("util_grant_overlay_permission_button")
            ) {
                Icon(Icons.Filled.Layers, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(u.overlayGrantAction)
            }
        }
    }
}

@Composable
private fun UtilityCardHeader(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String,
    statusBadge: String? = null,
    expandedContent: @Composable () -> Unit
) {
    SettingsCard(title = title) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = accentColor.copy(alpha = 0.16f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.size(40.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                if (statusBadge != null) {
                    Surface(
                        color = accentColor.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.55f))
                    ) {
                        Text(
                            text = statusBadge,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = accentColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            GlassSwitch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                modifier = Modifier.testTag(testTag)
            )
        }

        AnimatedVisibility(visible = checked) {
            Column(modifier = Modifier.padding(top = 12.dp)) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(10.dp))
                expandedContent()
            }
        }
    }
}

@Composable
private fun UtilityAlertChannelsSection(
    context: Context,
    u: UtilitiesStrings,
    ringtoneChecked: Boolean,
    onRingtoneChange: (Boolean) -> Unit,
    musicChecked: Boolean,
    onMusicChange: (Boolean) -> Unit,
    soundUri: String,
    onPickSound: () -> Unit,
    ttsChecked: Boolean,
    onTtsChange: (Boolean) -> Unit,
    showBatterySaverOption: Boolean,
    batterySaverChecked: Boolean,
    onBatterySaverChange: (Boolean) -> Unit,
    prefixTag: String
) {
    SettingSwitchRow(
        title = u.ringtoneToggleTitle,
        subtitle = "",
        checked = ringtoneChecked,
        onCheckedChange = onRingtoneChange,
        testTag = "util_${prefixTag}_ringtone",
        leadingIcon = Icons.Filled.PhonelinkRing
    )
    SettingSwitchRow(
        title = u.customSoundToggleTitle,
        subtitle = "",
        checked = musicChecked,
        onCheckedChange = onMusicChange,
        testTag = "util_${prefixTag}_music",
        leadingIcon = Icons.Filled.MusicNote
    )
    AnimatedVisibility(visible = musicChecked) {
        SoundPickerRow(
            context = context,
            u = u,
            soundUri = soundUri,
            onPick = onPickSound,
            testTag = "util_${prefixTag}_pick_sound"
        )
    }
    SettingSwitchRow(
        title = u.ttsToggleTitle,
        subtitle = "",
        checked = ttsChecked,
        onCheckedChange = onTtsChange,
        testTag = "util_${prefixTag}_tts",
        leadingIcon = Icons.Filled.RecordVoiceOver
    )
    if (showBatterySaverOption) {
        SettingSwitchRow(
            title = u.batterySaverToggleTitle,
            subtitle = u.batterySaverToggleDesc,
            checked = batterySaverChecked,
            onCheckedChange = onBatterySaverChange,
            testTag = "util_${prefixTag}_saver",
            leadingIcon = Icons.Filled.BatterySaver
        )
    }
}

@Composable
private fun SoundPickerRow(
    context: Context,
    u: UtilitiesStrings,
    soundUri: String,
    onPick: () -> Unit,
    testTag: String
) {
    val resolvedName = remember(soundUri, u) {
        if (soundUri.isBlank()) {
            u.defaultSoundLabel
        } else {
            runCatching {
                RingtoneManager.getRingtone(context, Uri.parse(soundUri))?.getTitle(context)
            }.getOrNull().orEmpty().ifBlank { u.selectedSoundLabel }
        }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = resolvedName,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        OutlinedButton(
            onClick = onPick,
            modifier = Modifier.testTag(testTag)
        ) {
            Icon(Icons.Filled.MusicNote, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(u.pickSoundAction)
        }
    }
}

@Composable
private fun AntiTheftProtectionNotice(u: UtilitiesStrings) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.35f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.GppGood,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = u.antiTheftProtectionNotice,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
        }
    }
}
