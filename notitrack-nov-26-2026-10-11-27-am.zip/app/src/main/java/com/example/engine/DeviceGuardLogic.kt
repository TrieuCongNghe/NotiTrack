package com.example.engine

import kotlin.math.sqrt

enum class AntiTheftTriggerReason {
    CHARGER_UNPLUGGED,
    DEVICE_MOVED
}

enum class MotionSensitivity(
    val level: Int,
    val labelVi: String,
    val labelEn: String,
    val linearThresholdMps2: Float
) {
    LOW(1, "Thấp", "Low", 4.0f),
    MEDIUM(2, "Vừa", "Medium", 2.4f),
    HIGH(3, "Cao", "High", 1.35f);

    companion object {
        fun fromLevel(level: Int): MotionSensitivity =
            entries.firstOrNull { it.level == level } ?: MEDIUM
    }
}

/**
 * Pure-Kotlin sustained motion filter that ignores sensor warm-up transients
 * and single noisy acceleration spikes. Requires [requiredConsecutive] readings
 * exceeding the sensitivity threshold within [maxGapMs] after [warmUpMs].
 */
class SustainedMotionFilter(
    private val warmUpMs: Long = 600L,
    private val requiredConsecutive: Int = 3,
    private val maxGapMs: Long = 500L
) {
    private var armedAtMs: Long = 0L
    private var consecutiveHits: Int = 0
    private var lastHitMs: Long = 0L

    fun reset(nowMs: Long) {
        armedAtMs = nowMs
        consecutiveHits = 0
        lastHitMs = 0L
    }

    fun onReading(
        ax: Float,
        ay: Float,
        az: Float,
        sensitivity: MotionSensitivity,
        nowMs: Long
    ): Boolean {
        if (armedAtMs <= 0L || (nowMs - armedAtMs) < warmUpMs) {
            consecutiveHits = 0
            return false
        }
        val exceeds = DeviceGuardEngine.exceedsMotionThreshold(ax, ay, az, sensitivity)
        if (!exceeds) {
            consecutiveHits = 0
            return false
        }
        if (lastHitMs > 0L && (nowMs - lastHitMs) > maxGapMs) {
            consecutiveHits = 1
        } else {
            consecutiveHits++
        }
        lastHitMs = nowMs
        if (consecutiveHits >= requiredConsecutive) {
            consecutiveHits = 0
            return true
        }
        return false
    }
}

data class GuardTelemetrySnapshot(
    val batteryPercent: Int,
    val isCharging: Boolean,
    val tempCelsius: Float,
    val nowMs: Long
)

data class DeviceGuardConfig(
    val lowBatteryEnabled: Boolean = false,
    val lowBatteryThreshold: Int = 20,
    val chargingAlertEnabled: Boolean = false,
    val chargingAlertThreshold: Int = 15,
    val fullChargeEnabled: Boolean = false,
    val fullChargeThreshold: Int = 100,
    val fullChargeExtraMinutes: Int = 15,
    val overheatEnabled: Boolean = false,
    val overheatThresholdC: Int = 42,
    val overheatCooldownSeconds: Int = 120,
    val chargeGuardEnabled: Boolean = false,
    val chargeGuardMinBatteryPercent: Int = 0,
    val chargeGuardDelaySeconds: Int = 3,
    val chargeGuardConfirmDialogEnabled: Boolean = true,
    val chargeGuardConfirmSeconds: Int = 15,
    val motionGuardEnabled: Boolean = false,
    val motionGuardSensitivity: Int = MotionSensitivity.MEDIUM.level,
    val motionGuardArmDelaySeconds: Int = 5,
    val motionGuardConfirmDialogEnabled: Boolean = true,
    val motionGuardConfirmSeconds: Int = 15
)

sealed interface DeviceGuardEvent {
    data class LowBatteryAlert(val batteryPercent: Int, val threshold: Int) : DeviceGuardEvent
    data class ChargingLevelAlert(val batteryPercent: Int, val threshold: Int) : DeviceGuardEvent
    data class FullChargeAlert(val batteryPercent: Int, val threshold: Int, val extraMinutesWaited: Int) : DeviceGuardEvent
    data class OverheatAlert(val tempCelsius: Float, val thresholdC: Int) : DeviceGuardEvent
    data class ChargerGuardUnplugged(
        val delaySeconds: Int,
        val confirmDialogEnabled: Boolean,
        val confirmSeconds: Int
    ) : DeviceGuardEvent
    data object ChargerReconnected : DeviceGuardEvent
}

/**
 * Pure-Kotlin state machine for tier-1 Low Battery alerts, tier-2 Plug-In Charging alerts (5-30%),
 * Full Charge + 100% extra-minute "soak" timer, Overheat cooldown throttling,
 * Charging Anti-Theft arming/unplugging, and Active Motion detection.
 */
class DeviceGuardEngine {

    private var lowBatteryAlerted = false
    private var lastLowBatteryThreshold = -1

    private var chargingLevelAlerted = false
    private var lastChargingAlertThreshold = -1

    private var fullChargeAlerted = false
    private var lastFullChargeThreshold = -1
    private var reached100ChargingAtMs: Long? = null

    private var lastOverheatAlertAtMs: Long = 0L
    private var lastOverheatThresholdC = -1

    private var wasCharging: Boolean? = null
    var isChargeGuardArmed: Boolean = false
        private set

    fun evaluateTelemetry(
        snapshot: GuardTelemetrySnapshot,
        config: DeviceGuardConfig
    ): List<DeviceGuardEvent> {
        val events = mutableListOf<DeviceGuardEvent>()
        val pct = snapshot.batteryPercent.coerceIn(0, 100)
        val charging = snapshot.isCharging
        val now = snapshot.nowMs

        // 1. Low battery alert (Tier 1: fires when NOT charging and battery <= threshold)
        val lowTarget = config.lowBatteryThreshold.coerceIn(5, 50)
        if (lastLowBatteryThreshold != lowTarget) {
            lastLowBatteryThreshold = lowTarget
            lowBatteryAlerted = false
        }
        if (config.lowBatteryEnabled) {
            if (!charging && pct <= lowTarget) {
                if (!lowBatteryAlerted) {
                    lowBatteryAlerted = true
                    events += DeviceGuardEvent.LowBatteryAlert(pct, lowTarget)
                }
            } else if (charging || pct >= (lowTarget + 3).coerceAtMost(100)) {
                lowBatteryAlerted = false
            }
        } else {
            lowBatteryAlerted = false
        }

        // 2. Charging reminder alert (Tier 2 low-battery warning 5%-30%: fires when NOT charging and battery <= threshold)
        val plugInTarget = config.chargingAlertThreshold.coerceIn(5, 30)
        if (lastChargingAlertThreshold != plugInTarget) {
            lastChargingAlertThreshold = plugInTarget
            chargingLevelAlerted = false
        }
        if (config.chargingAlertEnabled) {
            if (!charging && pct <= plugInTarget) {
                if (!chargingLevelAlerted) {
                    chargingLevelAlerted = true
                    events += DeviceGuardEvent.ChargingLevelAlert(pct, plugInTarget)
                }
            } else if (charging || pct >= (plugInTarget + 3).coerceAtMost(100)) {
                chargingLevelAlerted = false
            }
        } else {
            chargingLevelAlerted = false
        }

        // 3. Full charge alert (supports extra minutes soak timer when threshold == 100%)
        val fullTarget = config.fullChargeThreshold.coerceIn(80, 100)
        if (lastFullChargeThreshold != fullTarget) {
            lastFullChargeThreshold = fullTarget
            fullChargeAlerted = false
            reached100ChargingAtMs = null
        }
        if (config.fullChargeEnabled && charging) {
            if (pct >= fullTarget) {
                val extraMins = if (fullTarget == 100) config.fullChargeExtraMinutes.coerceIn(0, 60) else 0
                if (extraMins <= 0) {
                    if (!fullChargeAlerted) {
                        fullChargeAlerted = true
                        events += DeviceGuardEvent.FullChargeAlert(pct, fullTarget, 0)
                    }
                } else {
                    val startMs = reached100ChargingAtMs ?: now.also { reached100ChargingAtMs = it }
                    val elapsedMs = (now - startMs).coerceAtLeast(0L)
                    if (!fullChargeAlerted && elapsedMs >= extraMins * 60_000L) {
                        fullChargeAlerted = true
                        events += DeviceGuardEvent.FullChargeAlert(pct, fullTarget, extraMins)
                    }
                }
            } else {
                reached100ChargingAtMs = null
                if (pct <= (fullTarget - 3).coerceAtLeast(0)) {
                    fullChargeAlerted = false
                }
            }
        } else {
            reached100ChargingAtMs = null
            fullChargeAlerted = false
        }

        // 4. Overheat temperature alert with customizable repeat cooldown
        if (lastOverheatThresholdC != config.overheatThresholdC) {
            lastOverheatThresholdC = config.overheatThresholdC
            lastOverheatAlertAtMs = 0L
        }
        if (config.overheatEnabled && snapshot.tempCelsius >= config.overheatThresholdC.toFloat()) {
            val cooldownMs = config.overheatCooldownSeconds.coerceIn(15, 3600) * 1_000L
            if (lastOverheatAlertAtMs == 0L || (now - lastOverheatAlertAtMs) >= cooldownMs) {
                lastOverheatAlertAtMs = now
                events += DeviceGuardEvent.OverheatAlert(snapshot.tempCelsius, config.overheatThresholdC)
            }
        } else if (!config.overheatEnabled || snapshot.tempCelsius < (config.overheatThresholdC - 2f)) {
            if (!config.overheatEnabled) lastOverheatAlertAtMs = 0L
        }

        // 5. Charging Anti-Theft Guard arm/unplug state machine
        val prevCharging = wasCharging
        wasCharging = charging
        if (config.chargeGuardEnabled) {
            if (charging) {
                if (prevCharging == false) {
                    events += DeviceGuardEvent.ChargerReconnected
                }
                if (pct >= config.chargeGuardMinBatteryPercent.coerceIn(0, 100)) {
                    isChargeGuardArmed = true
                }
            } else {
                // Transitioned from armed+charging -> unplugged!
                if (isChargeGuardArmed && prevCharging == true) {
                    isChargeGuardArmed = false
                    events += DeviceGuardEvent.ChargerGuardUnplugged(
                        delaySeconds = config.chargeGuardDelaySeconds.coerceIn(0, 30),
                        confirmDialogEnabled = config.chargeGuardConfirmDialogEnabled,
                        confirmSeconds = clampConfirmSeconds(config.chargeGuardConfirmSeconds)
                    )
                } else if (!charging) {
                    isChargeGuardArmed = false
                }
            }
        } else {
            isChargeGuardArmed = false
        }

        return events
    }

    /**
     * Checks if the 100% extra-minutes soak timer has matured even if battery % hasn't changed.
     */
    fun checkFullChargeTimerTick(
        isCharging: Boolean,
        batteryPercent: Int,
        nowMs: Long,
        config: DeviceGuardConfig
    ): DeviceGuardEvent.FullChargeAlert? {
        if (!config.fullChargeEnabled || !isCharging || fullChargeAlerted) return null
        val target = config.fullChargeThreshold.coerceIn(80, 100)
        if (target != 100 || batteryPercent < 100) return null
        val extraMins = config.fullChargeExtraMinutes.coerceIn(0, 60)
        if (extraMins <= 0) return null
        val startMs = reached100ChargingAtMs ?: return null
        return if ((nowMs - startMs) >= extraMins * 60_000L) {
            fullChargeAlerted = true
            DeviceGuardEvent.FullChargeAlert(batteryPercent, target, extraMins)
        } else {
            null
        }
    }

    fun resetChargeGuardArm() {
        isChargeGuardArmed = false
    }

    companion object {
        const val MIN_CONFIRM_SECONDS = 5
        const val MAX_CONFIRM_SECONDS = 120

        fun clampConfirmSeconds(seconds: Int): Int =
            seconds.coerceIn(MIN_CONFIRM_SECONDS, MAX_CONFIRM_SECONDS)

        /**
         * Computes linear acceleration magnitude (m/s^2) and checks against sensitivity threshold.
         */
        fun exceedsMotionThreshold(
            ax: Float,
            ay: Float,
            az: Float,
            sensitivity: MotionSensitivity
        ): Boolean {
            val magnitude = sqrt((ax * ax + ay * ay + az * az).toDouble()).toFloat()
            return magnitude >= sensitivity.linearThresholdMps2
        }
    }
}
