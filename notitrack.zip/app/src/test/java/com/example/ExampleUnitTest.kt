package com.example

import com.example.data.model.KeywordAction
import com.example.data.model.KeywordRuleEntity
import com.example.engine.KeywordFilterEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `keyword filter highlights OTP and mutes TTS`() {
        val rules = listOf(
            KeywordRuleEntity(
                id = 1L,
                keywords = "OTP, chuyển khoản",
                action = KeywordAction.HIGHLIGHT
            ),
            KeywordRuleEntity(
                id = 2L,
                keywords = "OTP, mật khẩu",
                action = KeywordAction.MUTE_TTS
            )
        )

        val result = KeywordFilterEngine.evaluate(
            packageName = "com.bank.app",
            title = "Thông báo giao dịch",
            content = "Mã OTP xác thực của bạn là 482916",
            subText = "",
            rules = rules
        )

        assertFalse(result.shouldBlock)
        assertTrue(result.shouldHighlight)
        assertTrue(result.shouldMuteTts)
        assertEquals(listOf(1L, 2L), result.matchedRuleIds)
    }

    @Test
    fun `keyword filter blocks spam and respects app scope`() {
        val rules = listOf(
            KeywordRuleEntity(
                id = 10L,
                keywords = "flash sale, voucher",
                action = KeywordAction.BLOCK,
                targetPackage = "com.shop.app"
            )
        )

        val blocked = KeywordFilterEngine.evaluate(
            packageName = "com.shop.app",
            title = "Flash Sale 50%",
            content = "Săn deal ngay",
            subText = "",
            rules = rules
        )
        assertTrue(blocked.shouldBlock)

        val otherApp = KeywordFilterEngine.evaluate(
            packageName = "com.chat.app",
            title = "Flash Sale 50%",
            content = "Bạn gửi link",
            subText = "",
            rules = rules
        )
        assertFalse(otherApp.shouldBlock)
    }

    @Test
    fun `otp extractor detects code only with otp context`() {
        assertEquals(
            "482916",
            KeywordFilterEngine.extractOtpCode(
                "Ngân hàng",
                "Mã xác thực OTP của bạn là 482916 để hoàn tất giao dịch"
            )
        )
        assertNull(
            KeywordFilterEngine.extractOtpCode(
                "Lịch họp",
                "Phòng họp 2045 lúc 14h chiều nay"
            )
        )
    }
}
