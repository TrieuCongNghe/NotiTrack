package com.example.engine

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.R
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.stringsFor

enum class TestNotificationScenario {
    BANK_OTP,
    DELIVERY,
    PROMO_SPAM
}

object TestNotificationDispatcher {

    const val CHANNEL_ID = "notitrack_self_test"
    const val EXTRA_IS_NOTIVAULT_TEST = "extra_is_notivault_test"

    fun hasPostNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun dispatchTestNotification(
        context: Context,
        scenario: TestNotificationScenario,
        language: AppLanguage
    ): Boolean {
        if (!hasPostNotificationPermission(context)) return false
        val strings = stringsFor(language)
        val copy = strings.testScenarios[scenario] ?: return false
        ensureChannel(context, strings.testChannelName, strings.testChannelDesc)

        val extras = Bundle().apply {
            putBoolean(EXTRA_IS_NOTIVAULT_TEST, true)
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(copy.title)
            .setContentText(copy.content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(copy.content))
            .setSubText(copy.subText)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .addExtras(extras)
            .build()

        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        return runCatching {
            NotificationManagerCompat.from(context).notify(id, notification)
            true
        }.getOrDefault(false)
    }

    private fun ensureChannel(context: Context, name: String, desc: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                name,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = desc
            }
            manager.createNotificationChannel(channel)
        }
    }
}
