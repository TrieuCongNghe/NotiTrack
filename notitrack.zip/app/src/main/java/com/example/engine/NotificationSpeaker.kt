package com.example.engine

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.stringsFor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class NotificationSpeaker(context: Context) {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var isReady: Boolean = false
    private var pendingSpeech: PendingUtterance? = null

    private data class PendingUtterance(
        val text: String,
        val rate: Float,
        val notificationId: Long?,
        val language: AppLanguage
    )

    private val _speakingNotificationId = MutableStateFlow<Long?>(null)
    val speakingNotificationId: StateFlow<Long?> = _speakingNotificationId.asStateFlow()

    init {
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                applyLocale(AppLanguage.VIETNAMESE)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) {
                        _speakingNotificationId.value = null
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _speakingNotificationId.value = null
                    }
                    override fun onError(utteranceId: String?, errorCode: Int) {
                        _speakingNotificationId.value = null
                    }
                })
                isReady = true
                pendingSpeech?.let { pending ->
                    pendingSpeech = null
                    speakInternal(
                        text = pending.text,
                        rate = pending.rate,
                        notificationId = pending.notificationId,
                        language = pending.language,
                        flush = true
                    )
                }
            }
        }
    }

    private fun applyLocale(language: AppLanguage) {
        val targetLocale = language.toLocale()
        val availability = tts?.isLanguageAvailable(targetLocale) ?: TextToSpeech.LANG_NOT_SUPPORTED
        if (availability >= TextToSpeech.LANG_AVAILABLE) {
            tts?.language = targetLocale
        } else {
            tts?.language = Locale.getDefault()
        }
    }

    fun speakNotification(
        notificationId: Long?,
        appName: String,
        title: String,
        content: String,
        includeAppName: Boolean,
        speechRate: Float,
        language: AppLanguage = AppLanguage.VIETNAMESE,
        flush: Boolean = false
    ) {
        val strings = stringsFor(language)
        val parts = buildList {
            if (includeAppName && appName.isNotBlank()) add(strings.ttsSpokenPrefix(appName))
            if (title.isNotBlank()) add(title.trim().trimEnd('.') + ".")
            if (content.isNotBlank() && content.trim() != title.trim()) {
                add(content.trim().take(280))
            }
        }
        val text = parts.joinToString(" ").trim()
        if (text.isBlank()) return

        if (!isReady) {
            pendingSpeech = PendingUtterance(text, speechRate, notificationId, language)
            return
        }
        speakInternal(text, speechRate, notificationId, language, flush)
    }

    fun speakSample(speechRate: Float, language: AppLanguage = AppLanguage.VIETNAMESE) {
        val sample = stringsFor(language).ttsSampleSentence
        if (!isReady) {
            pendingSpeech = PendingUtterance(sample, speechRate, -1L, language)
            return
        }
        speakInternal(sample, speechRate, -1L, language, flush = true)
    }

    private fun speakInternal(
        text: String,
        rate: Float,
        notificationId: Long?,
        language: AppLanguage,
        flush: Boolean
    ) {
        applyLocale(language)
        tts?.setSpeechRate(rate.coerceIn(0.6f, 1.8f))
        val queueMode = if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        val utteranceId = "notitrack_${notificationId ?: UUID.randomUUID()}"
        _speakingNotificationId.value = notificationId
        tts?.speak(text, queueMode, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
        _speakingNotificationId.value = null
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isReady = false
        _speakingNotificationId.value = null
    }
}
