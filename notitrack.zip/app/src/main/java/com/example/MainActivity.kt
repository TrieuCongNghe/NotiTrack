package com.example

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.FilterAlt
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.BatteryOptimizationHelper
import com.example.engine.BiometricAuthHelper
import com.example.engine.TestNotificationDispatcher
import com.example.engine.TestNotificationScenario
import com.example.ui.i18n.AppStrings
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.i18n.stringsFor
import com.example.ui.screens.AppsScreen
import com.example.ui.screens.FiltersScreen
import com.example.ui.screens.InboxScreen
import com.example.ui.screens.SecuritySettingsScreen
import com.example.ui.screens.VaultLockScreen
import com.example.ui.theme.NotiVaultTheme
import com.example.ui.viewmodel.NotiVaultViewModel
import com.example.ui.viewmodel.VaultTab

class MainActivity : FragmentActivity() {

    private val viewModel: NotiVaultViewModel by viewModels {
        val app = application as NotiVaultApplication
        NotiVaultViewModel.Factory(applicationContext, app.repository, app.speaker)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            val appStrings = remember(settings.appLanguage) { stringsFor(settings.appLanguage) }

            LaunchedEffect(settings.flagSecureEnabled) {
                if (settings.flagSecureEnabled) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }

            CompositionLocalProvider(LocalAppStrings provides appStrings) {
                NotiVaultTheme(themeMode = settings.themeMode) {
                    NotiTrackRoot(
                        activity = this,
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        viewModel.onAppForegrounded()
    }

    override fun onStop() {
        viewModel.onAppBackgrounded()
        super.onStop()
    }
}

private data class NavDestination(
    val tab: VaultTab,
    val labelOf: (AppStrings) -> String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val NAV_DESTINATIONS = listOf(
    NavDestination(VaultTab.INBOX, { it.navInbox }, Icons.Filled.Inbox, Icons.Outlined.Inbox),
    NavDestination(VaultTab.APPS, { it.navApps }, Icons.Filled.Apps, Icons.Outlined.Apps),
    NavDestination(VaultTab.FILTERS, { it.navFilters }, Icons.Filled.FilterAlt, Icons.Outlined.FilterAlt),
    NavDestination(VaultTab.SECURITY, { it.navSecurity }, Icons.Filled.Shield, Icons.Outlined.Shield)
)

@Composable
private fun NotiTrackRoot(
    activity: FragmentActivity,
    viewModel: NotiVaultViewModel
) {
    val context = LocalContext.current
    val s = LocalAppStrings.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val allNotifications by viewModel.allNotifications.collectAsStateWithLifecycle()
    val filteredNotifications by viewModel.filteredNotifications.collectAsStateWithLifecycle()
    val groupedSummaries by viewModel.groupedSummaries.collectAsStateWithLifecycle()
    val appRules by viewModel.appRules.collectAsStateWithLifecycle()
    val filteredAppRules by viewModel.filteredAppRules.collectAsStateWithLifecycle()
    val keywordRules by viewModel.keywordRules.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val isListenerEnabled by viewModel.isListenerEnabled.collectAsStateWithLifecycle()
    val isIgnoringBatteryOptimizations by viewModel.isIgnoringBatteryOptimizations.collectAsStateWithLifecycle()
    val isLocked by viewModel.isLocked.collectAsStateWithLifecycle()
    val speakingId by viewModel.speakingNotificationId.collectAsStateWithLifecycle()
    val inboxQuery by viewModel.inboxQuery.collectAsStateWithLifecycle()
    val inboxFilter by viewModel.inboxFilter.collectAsStateWithLifecycle()
    val selectedAppPackage by viewModel.selectedAppPackage.collectAsStateWithLifecycle()
    val appsQuery by viewModel.appsQuery.collectAsStateWithLifecycle()
    val appsFilter by viewModel.appsFilter.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var authError by remember { mutableStateOf<String?>(null) }
    var pendingTestScenario by remember { mutableStateOf<TestNotificationScenario?>(null) }

    val biometricStatus = remember(isLocked, currentTab) {
        BiometricAuthHelper.checkHardwareStatus(context)
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        val scenario = pendingTestScenario
        pendingTestScenario = null
        if (granted && scenario != null) {
            TestNotificationDispatcher.dispatchTestNotification(context, scenario, settings.appLanguage)
            viewModel.showMessage(
                if (isListenerEnabled) s.msgTestSentCaptured else s.msgTestSentNeedAccess
            )
        } else if (!granted) {
            viewModel.showMessage(s.msgNeedPostPerm)
        }
    }

    fun triggerTestNotification(scenario: TestNotificationScenario) {
        if (TestNotificationDispatcher.hasPostNotificationPermission(context)) {
            TestNotificationDispatcher.dispatchTestNotification(context, scenario, settings.appLanguage)
            viewModel.showMessage(
                if (isListenerEnabled) s.msgTestSentCaptured else s.msgTestSentNeedAccess
            )
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pendingTestScenario = scenario
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun openListenerSettings() {
        runCatching {
            context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }.onFailure {
            viewModel.showMessage(s.msgCannotOpenSettings)
        }
    }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessage()
        }
    }

    if (isLocked) {
        VaultLockScreen(
            biometricEnabled = settings.biometricEnabled,
            biometricAvailable = biometricStatus.isUsable,
            hasPinConfigured = settings.hasPinConfigured,
            authErrorMessage = authError,
            onRequestBiometric = {
                authError = null
                BiometricAuthHelper.authenticate(
                    activity = activity,
                    title = s.lockPromptTitle,
                    subtitle = s.lockPromptSubtitle,
                    negativeButtonText = s.lockPromptNegative,
                    mismatchMessage = s.biometricMismatchMsg,
                    onSuccess = {
                        authError = null
                        viewModel.unlockVault()
                    },
                    onFailureOrCancel = { err -> authError = err }
                )
            },
            onVerifyPin = { pin, callback ->
                viewModel.verifyPinAndUnlock(pin, callback)
            }
        )
        return
    }

    val unreadCount = remember(allNotifications) {
        allNotifications.count { !it.isRead && !it.isHidden }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpanded = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!isExpanded) {
                    NavigationBar(
                        windowInsets = WindowInsets.navigationBars,
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
                    ) {
                        NAV_DESTINATIONS.forEach { dest ->
                            val selected = currentTab == dest.tab
                            val label = dest.labelOf(s)
                            NavigationBarItem(
                                selected = selected,
                                onClick = { viewModel.selectTab(dest.tab) },
                                icon = {
                                    NavTabIcon(
                                        dest = dest,
                                        label = label,
                                        selected = selected,
                                        unreadCount = if (dest.tab == VaultTab.INBOX) unreadCount else 0
                                    )
                                },
                                label = { Text(label) },
                                modifier = Modifier.testTag("nav_tab_${dest.tab.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isExpanded) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
                    ) {
                        NAV_DESTINATIONS.forEach { dest ->
                            val selected = currentTab == dest.tab
                            val label = dest.labelOf(s)
                            NavigationRailItem(
                                selected = selected,
                                onClick = { viewModel.selectTab(dest.tab) },
                                icon = {
                                    NavTabIcon(
                                        dest = dest,
                                        label = label,
                                        selected = selected,
                                        unreadCount = if (dest.tab == VaultTab.INBOX) unreadCount else 0
                                    )
                                },
                                label = { Text(label) },
                                modifier = Modifier.testTag("rail_tab_${dest.tab.route}")
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    val contentModifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 840.dp)

                    when (currentTab) {
                        VaultTab.INBOX -> InboxScreen(
                            notifications = filteredNotifications,
                            groupedSummaries = groupedSummaries,
                            isGroupedView = settings.defaultGroupedView,
                            selectedAppPackage = selectedAppPackage,
                            query = inboxQuery,
                            activeFilter = inboxFilter,
                            isListenerEnabled = isListenerEnabled,
                            isLockConfigured = settings.isVaultLockActive,
                            speakingNotificationId = speakingId,
                            onQueryChange = viewModel::updateInboxQuery,
                            onFilterChange = viewModel::selectInboxFilter,
                            onToggleGroupedView = viewModel::toggleGroupedView,
                            onOpenAppThread = viewModel::openAppThread,
                            onMarkAllRead = viewModel::markAllRead,
                            onMarkRead = viewModel::markNotificationRead,
                            onToggleStar = viewModel::toggleStar,
                            onToggleHidden = viewModel::toggleHidden,
                            onDeleteNotification = viewModel::deleteNotification,
                            onDeletePackageNotifications = viewModel::deletePackageNotifications,
                            onToggleSpeak = viewModel::toggleSpeakNotification,
                            onOpenListenerSettings = ::openListenerSettings,
                            onSendTestNotification = { triggerTestNotification(TestNotificationScenario.BANK_OTP) },
                            onLockNow = viewModel::lockVaultNow,
                            onShowMessage = viewModel::showMessage,
                            modifier = contentModifier
                        )

                        VaultTab.APPS -> AppsScreen(
                            allRulesCount = appRules.size,
                            capturingCount = appRules.count { it.captureEnabled },
                            ttsActiveCount = appRules.count { it.readAloudEnabled },
                            filteredRules = filteredAppRules,
                            query = appsQuery,
                            activeFilter = appsFilter,
                            ttsGlobalEnabled = settings.ttsGlobalEnabled,
                            onQueryChange = viewModel::updateAppsQuery,
                            onFilterChange = viewModel::selectAppsFilter,
                            onUpdateRule = viewModel::updateAppRule,
                            onSetCaptureAll = viewModel::setCaptureForAllApps,
                            modifier = contentModifier
                        )

                        VaultTab.FILTERS -> FiltersScreen(
                            rules = keywordRules,
                            appRules = appRules,
                            onSaveRule = viewModel::saveKeywordRule,
                            onAddPreset = viewModel::addPresetRule,
                            onToggleRule = viewModel::toggleKeywordRule,
                            onDeleteRule = viewModel::deleteKeywordRule,
                            modifier = contentModifier
                        )

                        VaultTab.SECURITY -> SecuritySettingsScreen(
                            settings = settings,
                            biometricStatus = biometricStatus,
                            isListenerEnabled = isListenerEnabled,
                            isIgnoringBatteryOptimizations = isIgnoringBatteryOptimizations,
                            totalSavedCount = allNotifications.size,
                            onSetAppLanguage = viewModel::setAppLanguage,
                            onToggleKeepAlive = viewModel::setKeepAliveEnabled,
                            onOpenBatterySettings = {
                                if (!BatteryOptimizationHelper.openBatteryOptimizationSettings(context)) {
                                    viewModel.showMessage(s.msgCannotOpenSettings)
                                }
                            },
                            onOpenAppDetailsSettings = {
                                if (!BatteryOptimizationHelper.openAppDetailsSettings(context)) {
                                    viewModel.showMessage(s.msgCannotOpenSettings)
                                }
                            },
                            onRebindListener = viewModel::rebindListenerService,
                            onToggleBiometric = { wantEnable ->
                                if (wantEnable && biometricStatus.isUsable) {
                                    BiometricAuthHelper.authenticate(
                                        activity = activity,
                                        title = s.lockBiometricEnableTitle,
                                        subtitle = s.lockBiometricEnableSub,
                                        negativeButtonText = s.cancel,
                                        mismatchMessage = s.biometricMismatchMsg,
                                        onSuccess = { viewModel.setBiometricEnabled(true) },
                                        onFailureOrCancel = { err -> viewModel.showMessage(err) }
                                    )
                                } else if (!wantEnable) {
                                    if (biometricStatus.isUsable) {
                                        BiometricAuthHelper.authenticate(
                                            activity = activity,
                                            title = s.lockBiometricDisableTitle,
                                            subtitle = s.lockBiometricDisableSub,
                                            negativeButtonText = s.cancel,
                                            mismatchMessage = s.biometricMismatchMsg,
                                            onSuccess = { viewModel.setBiometricEnabled(false) },
                                            onFailureOrCancel = { err -> viewModel.showMessage(err) }
                                        )
                                    } else {
                                        viewModel.setBiometricEnabled(false)
                                    }
                                } else {
                                    viewModel.showMessage(
                                        s.biometricStatusMessages[biometricStatus] ?: biometricStatus.messageVi
                                    )
                                }
                            },
                            onSavePin = viewModel::setPin,
                            onToggleFlagSecure = viewModel::setFlagSecure,
                            onSetAutoLockSeconds = viewModel::setAutoLockSeconds,
                            onLockNow = viewModel::lockVaultNow,
                            onToggleTtsGlobal = viewModel::setTtsGlobalEnabled,
                            onSetTtsSpeechRate = viewModel::setTtsSpeechRate,
                            onToggleTtsIncludeApp = viewModel::setTtsIncludeAppName,
                            onSpeakSample = viewModel::speakSampleVoice,
                            onToggleCaptureNewApps = viewModel::setCaptureNewAppsByDefault,
                            onSetRetentionDays = viewModel::setRetentionDays,
                            onSetThemeMode = viewModel::setThemeMode,
                            onOpenListenerSettings = ::openListenerSettings,
                            onExportNotifications = {
                                viewModel.generateExportText { exportText ->
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, "${s.appName} Log")
                                        putExtra(Intent.EXTRA_TEXT, exportText)
                                    }
                                    context.startActivity(
                                        Intent.createChooser(shareIntent, s.exportAction)
                                    )
                                }
                            },
                            onSendTestScenario = ::triggerTestNotification,
                            onClearAllNotifications = viewModel::clearAllNotifications,
                            modifier = contentModifier
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NavTabIcon(
    dest: NavDestination,
    label: String,
    selected: Boolean,
    unreadCount: Int
) {
    val icon = if (selected) dest.selectedIcon else dest.unselectedIcon
    if (unreadCount > 0) {
        BadgedBox(
            badge = {
                Badge {
                    Text(if (unreadCount > 99) "99+" else unreadCount.toString())
                }
            }
        ) {
            Icon(imageVector = icon, contentDescription = label)
        }
    } else {
        Icon(imageVector = icon, contentDescription = label)
    }
}
