package com.example.service

import android.app.Notification
import android.content.Intent
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.example.NotiVaultApplication
import com.example.engine.BatteryOptimizationHelper
import com.example.engine.TestNotificationDispatcher
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class NotiVaultListenerService : NotificationListenerService() {

    private val exceptionHandler = CoroutineExceptionHandler { _, _ -> }
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO + exceptionHandler)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        val app = application as? NotiVaultApplication ?: return
        serviceScope.launch {
            val settings = app.preferences.getSettingsSnapshot()
            if (settings.keepAliveEnabled) {
                KeepAliveService.start(applicationContext)
            }
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        // Automatically request Android to rebind the listener if OEM/OS detaches it
        BatteryOptimizationHelper.requestListenerRebind(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val statusBarNoti = sbn ?: return
        val notification = statusBarNoti.notification ?: return
        val extras = notification.extras ?: return

        val pkg = statusBarNoti.packageName ?: return
        val isSelfTest = extras.getBoolean(TestNotificationDispatcher.EXTRA_IS_NOTIVAULT_TEST, false)

        // Ignore own package notifications (including KeepAliveService) unless explicitly triggered as self-test
        if (pkg == applicationContext.packageName && !isSelfTest) return

        // Skip silent group summary containers and ongoing progress bars
        val isGroupSummary = (notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0
        if (isGroupSummary || statusBarNoti.isOngoing) return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim().orEmpty()
        val shortText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val content = bigText.ifBlank { shortText }
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.trim().orEmpty()
        val conversationTitle = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)
            ?.toString()?.trim().orEmpty()

        if (title.isBlank() && content.isBlank()) return

        val appLabel = resolveAppName(pkg)
        val postTime = if (statusBarNoti.postTime > 0L) statusBarNoti.postTime else System.currentTimeMillis()
        val key = statusBarNoti.key.orEmpty()
        val category = notification.category.orEmpty()

        val app = application as? NotiVaultApplication ?: return
        val repo = app.repository
        val speaker = app.speaker

        serviceScope.launch {
            val settings = repo.preferences.getSettingsSnapshot()
            val strings = com.example.ui.i18n.stringsFor(settings.appLanguage)
            val normalizedContent = if (
                content.equals("Sensitive notification content hidden", ignoreCase = true) ||
                title.equals("Sensitive notification content hidden", ignoreCase = true)
            ) {
                strings.androidRedactedNotice
            } else {
                content
            }

            val outcome = repo.processIncomingNotification(
                packageName = pkg,
                appName = appLabel,
                title = title.ifBlank { appLabel },
                content = normalizedContent,
                subText = subText,
                conversationTitle = conversationTitle,
                notificationKey = key,
                category = category,
                timestamp = postTime
            )

            if (outcome.shouldAutoDismiss && statusBarNoti.isClearable) {
                runCatching { cancelNotification(statusBarNoti.key) }
            }

            if (outcome.shouldSpeak && outcome.savedId != null) {
                speaker.speakNotification(
                    notificationId = outcome.savedId,
                    appName = appLabel,
                    title = title,
                    content = normalizedContent,
                    includeAppName = settings.ttsIncludeAppName,
                    speechRate = settings.ttsSpeechRate,
                    language = settings.appLanguage,
                    flush = false
                )
            }
        }
    }

    private fun resolveAppName(packageName: String): String {
        return runCatching {
            val pm = applicationContext.packageManager
            val appInfo = pm.getApplicationInfo(packageName, PackageManager.GET_META_DATA)
            pm.getApplicationLabel(appInfo).toString().ifBlank { packageName }
        }.getOrDefault(packageName)
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }
}
