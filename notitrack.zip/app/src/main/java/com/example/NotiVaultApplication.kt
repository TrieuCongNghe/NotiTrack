package com.example

import android.app.Application
import com.example.data.db.NotiVaultDatabase
import com.example.data.prefs.VaultPreferences
import com.example.data.repository.NotiVaultRepository
import com.example.engine.NotificationSpeaker

class NotiVaultApplication : Application() {

    lateinit var database: NotiVaultDatabase
        private set
    lateinit var preferences: VaultPreferences
        private set
    lateinit var repository: NotiVaultRepository
        private set
    lateinit var speaker: NotificationSpeaker
        private set

    override fun onCreate() {
        super.onCreate()
        database = NotiVaultDatabase.getInstance(this)
        preferences = VaultPreferences(this)
        repository = NotiVaultRepository(
            context = this,
            notificationDao = database.notificationDao(),
            appRuleDao = database.appRuleDao(),
            keywordRuleDao = database.keywordRuleDao(),
            preferences = preferences
        )
        speaker = NotificationSpeaker(this)
    }

    override fun onTerminate() {
        speaker.shutdown()
        super.onTerminate()
    }
}
