package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.example.data.model.AppRuleEntity
import com.example.data.model.KeywordAction
import com.example.data.model.KeywordRuleEntity
import com.example.data.model.NotificationEntity

class VaultTypeConverters {
    @TypeConverter
    fun fromKeywordAction(action: KeywordAction): String = action.name

    @TypeConverter
    fun toKeywordAction(value: String): KeywordAction =
        runCatching { KeywordAction.valueOf(value) }.getOrDefault(KeywordAction.HIGHLIGHT)
}

@Database(
    entities = [
        NotificationEntity::class,
        AppRuleEntity::class,
        KeywordRuleEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(VaultTypeConverters::class)
abstract class NotiVaultDatabase : RoomDatabase() {
    abstract fun notificationDao(): NotificationDao
    abstract fun appRuleDao(): AppRuleDao
    abstract fun keywordRuleDao(): KeywordRuleDao

    companion object {
        @Volatile
        private var INSTANCE: NotiVaultDatabase? = null

        fun getInstance(context: Context): NotiVaultDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NotiVaultDatabase::class.java,
                    "notivault_local.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
