package com.example.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.i18n.AppLanguage
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.MessageDigest

private val Context.vaultDataStore: DataStore<Preferences> by preferencesDataStore(name = "notivault_prefs")

data class VaultSettings(
    val biometricEnabled: Boolean = false,
    val pinHash: String = "",
    val autoLockSeconds: Int = 30,
    val flagSecureEnabled: Boolean = false,
    val ttsGlobalEnabled: Boolean = true,
    val ttsSpeechRate: Float = 1.0f,
    val ttsIncludeAppName: Boolean = true,
    val captureNewAppsByDefault: Boolean = true,
    val retentionDays: Int = 30,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val defaultGroupedView: Boolean = false,
    val appLanguage: AppLanguage = AppLanguage.VIETNAMESE,
    val keepAliveEnabled: Boolean = true
) {
    val hasPinConfigured: Boolean get() = pinHash.isNotEmpty()
    val isVaultLockActive: Boolean get() = biometricEnabled || hasPinConfigured
}

class VaultPreferences(private val context: Context) {

    private object Keys {
        val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val AUTO_LOCK_SECONDS = intPreferencesKey("auto_lock_seconds")
        val FLAG_SECURE_ENABLED = booleanPreferencesKey("flag_secure_enabled")
        val TTS_GLOBAL_ENABLED = booleanPreferencesKey("tts_global_enabled")
        val TTS_SPEECH_RATE = floatPreferencesKey("tts_speech_rate")
        val TTS_INCLUDE_APP_NAME = booleanPreferencesKey("tts_include_app_name")
        val CAPTURE_NEW_APPS = booleanPreferencesKey("capture_new_apps")
        val RETENTION_DAYS = intPreferencesKey("retention_days")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DEFAULT_GROUPED_VIEW = booleanPreferencesKey("default_grouped_view")
        val APP_LANGUAGE = stringPreferencesKey("app_language")
        val KEEP_ALIVE_ENABLED = booleanPreferencesKey("keep_alive_enabled")
    }

    val settingsFlow: Flow<VaultSettings> = context.vaultDataStore.data.map { prefs ->
        VaultSettings(
            biometricEnabled = prefs[Keys.BIOMETRIC_ENABLED] ?: false,
            pinHash = prefs[Keys.PIN_HASH] ?: "",
            autoLockSeconds = prefs[Keys.AUTO_LOCK_SECONDS] ?: 30,
            flagSecureEnabled = prefs[Keys.FLAG_SECURE_ENABLED] ?: false,
            ttsGlobalEnabled = prefs[Keys.TTS_GLOBAL_ENABLED] ?: true,
            ttsSpeechRate = prefs[Keys.TTS_SPEECH_RATE] ?: 1.0f,
            ttsIncludeAppName = prefs[Keys.TTS_INCLUDE_APP_NAME] ?: true,
            captureNewAppsByDefault = prefs[Keys.CAPTURE_NEW_APPS] ?: true,
            retentionDays = prefs[Keys.RETENTION_DAYS] ?: 30,
            themeMode = runCatching {
                ThemeMode.valueOf(prefs[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.name)
            }.getOrDefault(ThemeMode.SYSTEM),
            defaultGroupedView = prefs[Keys.DEFAULT_GROUPED_VIEW] ?: false,
            appLanguage = AppLanguage.fromCode(prefs[Keys.APP_LANGUAGE]),
            keepAliveEnabled = prefs[Keys.KEEP_ALIVE_ENABLED] ?: true
        )
    }

    suspend fun getSettingsSnapshot(): VaultSettings = settingsFlow.first()

    suspend fun setBiometricEnabled(enabled: Boolean) {
        context.vaultDataStore.edit { it[Keys.BIOMETRIC_ENABLED] = enabled }
    }

    suspend fun setPin(rawPin: String) {
        val hashed = if (rawPin.isBlank()) "" else hashPin(rawPin)
        context.vaultDataStore.edit { it[Keys.PIN_HASH] = hashed }
    }

    suspend fun verifyPin(rawPin: String): Boolean {
        val currentHash = getSettingsSnapshot().pinHash
        return currentHash.isNotEmpty() && currentHash == hashPin(rawPin)
    }

    suspend fun setAutoLockSeconds(seconds: Int) {
        context.vaultDataStore.edit { it[Keys.AUTO_LOCK_SECONDS] = seconds }
    }

    suspend fun setFlagSecureEnabled(enabled: Boolean) {
        context.vaultDataStore.edit { it[Keys.FLAG_SECURE_ENABLED] = enabled }
    }

    suspend fun setTtsGlobalEnabled(enabled: Boolean) {
        context.vaultDataStore.edit { it[Keys.TTS_GLOBAL_ENABLED] = enabled }
    }

    suspend fun setTtsSpeechRate(rate: Float) {
        context.vaultDataStore.edit { it[Keys.TTS_SPEECH_RATE] = rate.coerceIn(0.6f, 1.8f) }
    }

    suspend fun setTtsIncludeAppName(include: Boolean) {
        context.vaultDataStore.edit { it[Keys.TTS_INCLUDE_APP_NAME] = include }
    }

    suspend fun setCaptureNewAppsByDefault(enabled: Boolean) {
        context.vaultDataStore.edit { it[Keys.CAPTURE_NEW_APPS] = enabled }
    }

    suspend fun setRetentionDays(days: Int) {
        context.vaultDataStore.edit { it[Keys.RETENTION_DAYS] = days }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.vaultDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setDefaultGroupedView(grouped: Boolean) {
        context.vaultDataStore.edit { it[Keys.DEFAULT_GROUPED_VIEW] = grouped }
    }

    suspend fun setAppLanguage(language: AppLanguage) {
        context.vaultDataStore.edit { it[Keys.APP_LANGUAGE] = language.code }
    }

    suspend fun setKeepAliveEnabled(enabled: Boolean) {
        context.vaultDataStore.edit { it[Keys.KEEP_ALIVE_ENABLED] = enabled }
    }

    companion object {
        fun hashPin(pin: String): String {
            val digest = MessageDigest.getInstance("SHA-256")
            val bytes = digest.digest("notivault_salt_v1:$pin".toByteArray(Charsets.UTF_8))
            return bytes.joinToString("") { "%02x".format(it) }
        }
    }
}
