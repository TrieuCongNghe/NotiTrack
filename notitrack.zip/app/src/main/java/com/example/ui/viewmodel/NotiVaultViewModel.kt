package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppNotificationSummary
import com.example.data.model.AppRuleEntity
import com.example.data.model.KeywordAction
import com.example.data.model.KeywordRuleEntity
import com.example.data.model.NotificationEntity
import com.example.data.prefs.VaultSettings
import com.example.data.repository.NotiVaultRepository
import com.example.engine.BatteryOptimizationHelper
import com.example.engine.NotificationSpeaker
import com.example.service.KeepAliveService
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.stringsFor
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class VaultTab(val route: String) {
    INBOX("inbox"),
    APPS("apps"),
    FILTERS("filters"),
    SECURITY("security")
}

enum class InboxFilter(val labelVi: String) {
    ALL("Tất cả"),
    UNREAD("Chưa đọc"),
    STARRED("Đã ghim"),
    HIGHLIGHTED("Từ khóa ưu tiên"),
    HIDDEN("Nhạy cảm / Đã ẩn")
}

enum class AppsFilter(val labelVi: String) {
    ALL("Tất cả"),
    CAPTURING("Đang ghi nhận"),
    TTS_ACTIVE("Đang đọc to"),
    AUTO_DISMISS("Ẩn thanh trạng thái")
}

data class KeywordPreset(
    val titleVi: String,
    val keywords: String,
    val action: KeywordAction
)

class NotiVaultViewModel(
    private val appContext: Context,
    private val repository: NotiVaultRepository,
    private val speaker: NotificationSpeaker
) : ViewModel() {

    val settings: StateFlow<VaultSettings> = repository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), VaultSettings())

    val allNotifications: StateFlow<List<NotificationEntity>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val appRules: StateFlow<List<AppRuleEntity>> = repository.allAppRules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val keywordRules: StateFlow<List<KeywordRuleEntity>> = repository.allKeywordRules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val speakingNotificationId: StateFlow<Long?> = speaker.speakingNotificationId

    private val _currentTab = MutableStateFlow(VaultTab.INBOX)
    val currentTab: StateFlow<VaultTab> = _currentTab.asStateFlow()

    private val _isListenerEnabled = MutableStateFlow(repository.isNotificationListenerEnabled())
    val isListenerEnabled: StateFlow<Boolean> = _isListenerEnabled.asStateFlow()

    private val _isIgnoringBatteryOptimizations = MutableStateFlow(
        BatteryOptimizationHelper.isIgnoringBatteryOptimizations(appContext)
    )
    val isIgnoringBatteryOptimizations: StateFlow<Boolean> = _isIgnoringBatteryOptimizations.asStateFlow()

    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private var lockInitialized = false
    private var backgroundTimestampMs: Long? = null

    private val _inboxQuery = MutableStateFlow("")
    val inboxQuery: StateFlow<String> = _inboxQuery.asStateFlow()

    private val _inboxFilter = MutableStateFlow(InboxFilter.ALL)
    val inboxFilter: StateFlow<InboxFilter> = _inboxFilter.asStateFlow()

    private val _selectedAppPackage = MutableStateFlow<String?>(null)
    val selectedAppPackage: StateFlow<String?> = _selectedAppPackage.asStateFlow()

    private val _appsQuery = MutableStateFlow("")
    val appsQuery: StateFlow<String> = _appsQuery.asStateFlow()

    private val _appsFilter = MutableStateFlow(AppsFilter.ALL)
    val appsFilter: StateFlow<AppsFilter> = _appsFilter.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private fun currentStrings() = stringsFor(settings.value.appLanguage)

    val filteredNotifications: StateFlow<List<NotificationEntity>> = combine(
        allNotifications,
        _inboxQuery,
        _inboxFilter,
        _selectedAppPackage
    ) { items, query, filter, selectedPkg ->
        val trimmed = query.trim()
        items.filter { item ->
            val pkgMatch = selectedPkg == null || item.packageName == selectedPkg
            val filterMatch = when (filter) {
                InboxFilter.ALL -> !item.isHidden
                InboxFilter.UNREAD -> !item.isRead && !item.isHidden
                InboxFilter.STARRED -> item.isStarred
                InboxFilter.HIGHLIGHTED -> item.isHighlighted
                InboxFilter.HIDDEN -> item.isHidden
            }
            val queryMatch = trimmed.isEmpty() ||
                item.title.contains(trimmed, ignoreCase = true) ||
                item.content.contains(trimmed, ignoreCase = true) ||
                item.appName.contains(trimmed, ignoreCase = true) ||
                item.matchedKeywords.contains(trimmed, ignoreCase = true) ||
                (item.detectedOtp?.contains(trimmed) == true)
            pkgMatch && filterMatch && queryMatch
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val groupedSummaries: StateFlow<List<AppNotificationSummary>> = combine(
        allNotifications,
        _inboxQuery,
        _inboxFilter
    ) { items, query, filter ->
        val trimmed = query.trim()
        val matching = items.filter { item ->
            val filterMatch = when (filter) {
                InboxFilter.ALL -> !item.isHidden
                InboxFilter.UNREAD -> !item.isRead && !item.isHidden
                InboxFilter.STARRED -> item.isStarred
                InboxFilter.HIGHLIGHTED -> item.isHighlighted
                InboxFilter.HIDDEN -> item.isHidden
            }
            val queryMatch = trimmed.isEmpty() ||
                item.title.contains(trimmed, ignoreCase = true) ||
                item.content.contains(trimmed, ignoreCase = true) ||
                item.appName.contains(trimmed, ignoreCase = true)
            filterMatch && queryMatch
        }
        matching.groupBy { it.packageName }.map { (pkg, list) ->
            val latest = list.maxBy { it.timestamp }
            AppNotificationSummary(
                packageName = pkg,
                appName = latest.appName,
                totalCount = list.size,
                unreadCount = list.count { !it.isRead },
                latestTimestamp = latest.timestamp,
                latestTitle = latest.title,
                latestContent = latest.content,
                hasHighlighted = list.any { it.isHighlighted }
            )
        }.sortedByDescending { it.latestTimestamp }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val filteredAppRules: StateFlow<List<AppRuleEntity>> = combine(
        appRules,
        _appsQuery,
        _appsFilter
    ) { rules, query, filter ->
        val trimmed = query.trim()
        rules.filter { rule ->
            val filterMatch = when (filter) {
                AppsFilter.ALL -> true
                AppsFilter.CAPTURING -> rule.captureEnabled
                AppsFilter.TTS_ACTIVE -> rule.readAloudEnabled
                AppsFilter.AUTO_DISMISS -> rule.autoDismissEnabled
            }
            val queryMatch = trimmed.isEmpty() ||
                rule.appName.contains(trimmed, ignoreCase = true) ||
                rule.packageName.contains(trimmed, ignoreCase = true)
            filterMatch && queryMatch
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        viewModelScope.launch {
            val initialSettings = repository.preferences.getSettingsSnapshot()
            if (initialSettings.isVaultLockActive && !lockInitialized) {
                _isLocked.value = true
            }
            lockInitialized = true
            repository.syncInstalledAppRules()
            syncKeepAliveService(initialSettings.keepAliveEnabled)
        }
    }

    fun refreshSystemStatus() {
        val listenerOn = repository.isNotificationListenerEnabled()
        _isListenerEnabled.value = listenerOn
        _isIgnoringBatteryOptimizations.value = BatteryOptimizationHelper.isIgnoringBatteryOptimizations(appContext)
        viewModelScope.launch {
            repository.syncInstalledAppRules()
            val currentSettings = repository.preferences.getSettingsSnapshot()
            if (listenerOn) {
                BatteryOptimizationHelper.requestListenerRebind(appContext)
            }
            syncKeepAliveService(currentSettings.keepAliveEnabled)
        }
    }

    private fun syncKeepAliveService(enabled: Boolean) {
        if (enabled && repository.isNotificationListenerEnabled()) {
            KeepAliveService.start(appContext)
        } else if (!enabled) {
            KeepAliveService.stop(appContext)
        }
    }

    fun setKeepAliveEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setKeepAliveEnabled(enabled)
            if (enabled) {
                KeepAliveService.start(appContext)
                showMessage(currentStrings().msgKeepAliveOn)
            } else {
                KeepAliveService.stop(appContext)
                showMessage(currentStrings().msgKeepAliveOff)
            }
        }
    }

    fun rebindListenerService() {
        BatteryOptimizationHelper.requestListenerRebind(appContext)
        if (settings.value.keepAliveEnabled && repository.isNotificationListenerEnabled()) {
            KeepAliveService.start(appContext)
        }
        showMessage(currentStrings().msgServiceRebound)
    }

    fun setAppLanguage(language: AppLanguage) {
        viewModelScope.launch {
            repository.preferences.setAppLanguage(language)
            if (settings.value.keepAliveEnabled && repository.isNotificationListenerEnabled()) {
                KeepAliveService.start(appContext)
            }
        }
    }

    fun onAppBackgrounded() {
        backgroundTimestampMs = System.currentTimeMillis()
    }

    fun onAppForegrounded() {
        refreshSystemStatus()
        val bgTime = backgroundTimestampMs ?: return
        backgroundTimestampMs = null
        val currentSettings = settings.value
        if (!currentSettings.isVaultLockActive) return
        val elapsedSeconds = (System.currentTimeMillis() - bgTime) / 1000L
        if (elapsedSeconds >= currentSettings.autoLockSeconds) {
            _isLocked.value = true
        }
    }

    fun unlockVault() {
        _isLocked.value = false
    }

    fun lockVaultNow() {
        if (settings.value.isVaultLockActive) {
            _isLocked.value = true
        } else {
            showMessage(currentStrings().msgNeedLockFirst)
        }
    }

    fun verifyPinAndUnlock(rawPin: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = repository.preferences.verifyPin(rawPin)
            if (ok) {
                _isLocked.value = false
            }
            onResult(ok)
        }
    }

    fun selectTab(tab: VaultTab) {
        _currentTab.value = tab
    }

    fun updateInboxQuery(query: String) {
        _inboxQuery.value = query
    }

    fun selectInboxFilter(filter: InboxFilter) {
        _inboxFilter.value = filter
    }

    fun openAppThread(packageName: String?) {
        _selectedAppPackage.value = packageName
        if (packageName != null) {
            viewModelScope.launch { repository.markPackageRead(packageName) }
        }
    }

    fun toggleGroupedView() {
        val next = !settings.value.defaultGroupedView
        _selectedAppPackage.value = null
        viewModelScope.launch {
            repository.preferences.setDefaultGroupedView(next)
        }
    }

    fun markNotificationRead(id: Long) {
        viewModelScope.launch { repository.markRead(id) }
    }

    fun markAllRead() {
        viewModelScope.launch {
            repository.markAllRead()
            showMessage(currentStrings().msgMarkedAllRead)
        }
    }

    fun toggleStar(notification: NotificationEntity) {
        viewModelScope.launch {
            repository.toggleStar(notification.id, !notification.isStarred)
        }
    }

    fun toggleHidden(notification: NotificationEntity) {
        viewModelScope.launch {
            val nextHidden = !notification.isHidden
            repository.toggleHidden(notification.id, nextHidden)
            showMessage(
                if (nextHidden) currentStrings().msgMovedToHidden
                else currentStrings().msgRestoredToMain
            )
        }
    }

    fun deleteNotification(id: Long) {
        viewModelScope.launch {
            if (speakingNotificationId.value == id) speaker.stop()
            repository.deleteNotification(id)
            showMessage(currentStrings().msgDeletedOne)
        }
    }

    fun deletePackageNotifications(packageName: String, appName: String) {
        viewModelScope.launch {
            repository.deletePackageNotifications(packageName)
            if (_selectedAppPackage.value == packageName) _selectedAppPackage.value = null
            showMessage(currentStrings().msgDeletedApp(appName))
        }
    }

    fun toggleSpeakNotification(notification: NotificationEntity) {
        if (speakingNotificationId.value == notification.id) {
            speaker.stop()
            return
        }
        val currentSettings = settings.value
        speaker.speakNotification(
            notificationId = notification.id,
            appName = notification.appName,
            title = notification.title,
            content = notification.content,
            includeAppName = currentSettings.ttsIncludeAppName,
            speechRate = currentSettings.ttsSpeechRate,
            language = currentSettings.appLanguage,
            flush = true
        )
    }

    fun speakSampleVoice() {
        speaker.speakSample(settings.value.ttsSpeechRate, settings.value.appLanguage)
    }

    fun stopSpeaking() {
        speaker.stop()
    }

    fun updateAppsQuery(query: String) {
        _appsQuery.value = query
    }

    fun selectAppsFilter(filter: AppsFilter) {
        _appsFilter.value = filter
    }

    fun updateAppRule(rule: AppRuleEntity) {
        viewModelScope.launch {
            repository.upsertAppRule(rule)
        }
    }

    fun setCaptureForAllApps(enabled: Boolean) {
        viewModelScope.launch {
            repository.setCaptureForAllApps(enabled)
            showMessage(
                if (enabled) currentStrings().msgEnabledAllApps
                else currentStrings().msgDisabledAllApps
            )
        }
    }

    fun saveKeywordRule(
        existingId: Long?,
        keywords: String,
        action: KeywordAction,
        targetPackage: String?,
        targetAppName: String?,
        isCaseSensitive: Boolean,
        isRegex: Boolean
    ) {
        if (keywords.isBlank()) return
        viewModelScope.launch {
            if (existingId != null) {
                val existing = keywordRules.value.find { it.id == existingId }
                if (existing != null) {
                    repository.updateKeywordRule(
                        existing.copy(
                            keywords = keywords.trim(),
                            action = action,
                            targetPackage = targetPackage,
                            targetAppName = targetAppName,
                            isCaseSensitive = isCaseSensitive,
                            isRegex = isRegex
                        )
                    )
                    showMessage(currentStrings().msgRuleUpdated)
                    return@launch
                }
            }
            repository.addKeywordRule(
                keywords = keywords,
                action = action,
                targetPackage = targetPackage,
                targetAppName = targetAppName,
                isCaseSensitive = isCaseSensitive,
                isRegex = isRegex
            )
            showMessage(currentStrings().msgRuleAdded)
        }
    }

    fun addPresetRule(preset: KeywordPreset) {
        viewModelScope.launch {
            repository.addKeywordRule(
                keywords = preset.keywords,
                action = preset.action,
                targetPackage = null,
                targetAppName = null,
                isCaseSensitive = false,
                isRegex = false
            )
            showMessage(currentStrings().msgPresetAdded(preset.titleVi))
        }
    }

    fun toggleKeywordRule(rule: KeywordRuleEntity, enabled: Boolean) {
        viewModelScope.launch {
            repository.toggleKeywordRule(rule.id, enabled)
        }
    }

    fun deleteKeywordRule(id: Long) {
        viewModelScope.launch {
            repository.deleteKeywordRule(id)
            showMessage(currentStrings().msgRuleDeleted)
        }
    }

    fun setBiometricEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setBiometricEnabled(enabled)
            showMessage(
                if (enabled) currentStrings().msgBiometricOn
                else currentStrings().msgBiometricOff
            )
        }
    }

    fun setPin(rawPin: String) {
        viewModelScope.launch {
            repository.preferences.setPin(rawPin)
            showMessage(
                if (rawPin.isBlank()) currentStrings().msgPinCleared
                else currentStrings().msgPinSaved
            )
        }
    }

    fun setFlagSecure(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setFlagSecureEnabled(enabled)
        }
    }

    fun setAutoLockSeconds(seconds: Int) {
        viewModelScope.launch {
            repository.preferences.setAutoLockSeconds(seconds)
        }
    }

    fun setTtsGlobalEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsGlobalEnabled(enabled)
        }
    }

    fun setTtsSpeechRate(rate: Float) {
        viewModelScope.launch {
            repository.preferences.setTtsSpeechRate(rate)
        }
    }

    fun setTtsIncludeAppName(include: Boolean) {
        viewModelScope.launch {
            repository.preferences.setTtsIncludeAppName(include)
        }
    }

    fun setCaptureNewAppsByDefault(enabled: Boolean) {
        viewModelScope.launch {
            repository.preferences.setCaptureNewAppsByDefault(enabled)
        }
    }

    fun setRetentionDays(days: Int) {
        viewModelScope.launch {
            repository.preferences.setRetentionDays(days)
            repository.applyRetentionCleanup(days)
            showMessage(
                if (days == 0) currentStrings().msgRetentionNever
                else currentStrings().msgRetentionDays(days)
            )
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            repository.preferences.setThemeMode(mode)
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            speaker.stop()
            repository.clearAllNotifications()
            _selectedAppPackage.value = null
            showMessage(currentStrings().msgClearedAll)
        }
    }

    fun generateExportText(onReady: (String) -> Unit) {
        viewModelScope.launch {
            val content = repository.buildExportText()
            onReady(content)
        }
    }

    fun showMessage(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearMessage() {
        _snackbarMessage.value = null
    }

    class Factory(
        private val appContext: Context,
        private val repository: NotiVaultRepository,
        private val speaker: NotificationSpeaker
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return NotiVaultViewModel(appContext, repository, speaker) as T
        }
    }
}
