package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.prefs.VaultSettings
import com.example.engine.BiometricHardwareStatus
import com.example.engine.TestNotificationScenario
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.theme.ThemeMode
import com.example.ui.theme.VaultMintGlow
import com.example.ui.theme.VaultObsidianDeep
import com.example.ui.theme.VaultObsidianMid

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SecuritySettingsScreen(
    settings: VaultSettings,
    biometricStatus: BiometricHardwareStatus,
    isListenerEnabled: Boolean,
    isIgnoringBatteryOptimizations: Boolean,
    totalSavedCount: Int,
    onSetAppLanguage: (AppLanguage) -> Unit,
    onToggleKeepAlive: (Boolean) -> Unit,
    onOpenBatterySettings: () -> Unit,
    onOpenAppDetailsSettings: () -> Unit,
    onRebindListener: () -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onSavePin: (String) -> Unit,
    onToggleFlagSecure: (Boolean) -> Unit,
    onSetAutoLockSeconds: (Int) -> Unit,
    onLockNow: () -> Unit,
    onToggleTtsGlobal: (Boolean) -> Unit,
    onSetTtsSpeechRate: (Float) -> Unit,
    onToggleTtsIncludeApp: (Boolean) -> Unit,
    onSpeakSample: () -> Unit,
    onToggleCaptureNewApps: (Boolean) -> Unit,
    onSetRetentionDays: (Int) -> Unit,
    onSetThemeMode: (ThemeMode) -> Unit,
    onOpenListenerSettings: () -> Unit,
    onExportNotifications: () -> Unit,
    onSendTestScenario: (TestNotificationScenario) -> Unit,
    onClearAllNotifications: () -> Unit,
    modifier: Modifier = Modifier
) {
    val s = LocalAppStrings.current
    var showPinDialog by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var showTestPicker by remember { mutableStateOf(false) }
    val bioStatusText = s.biometricStatusMessages[biometricStatus] ?: biometricStatus.messageVi

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = s.securityTitle,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // Hero Vault Security Status Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.large)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(VaultObsidianDeep, VaultObsidianMid)
                        )
                    )
                    .padding(18.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_vault_shield_1795064151326),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (settings.isVaultLockActive) s.heroProtected else s.heroUnprotected,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = bioStatusText,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.78f)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(
                                color = VaultMintGlow.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = s.heroLocalCount(totalSavedCount),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = VaultMintGlow,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            if (settings.isVaultLockActive) {
                                Surface(
                                    color = Color.White.copy(alpha = 0.14f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable(onClick = onLockNow)
                                        .testTag("hero_lock_now_button")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Lock,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Text(
                                            text = s.heroLockNow,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 1: Background Persistence (Anti-Kill Optimization)
        item {
            SettingsCard(title = s.sectionPersistence) {
                SettingSwitchRow(
                    title = s.keepAliveTitle,
                    subtitle = s.keepAliveDesc,
                    checked = settings.keepAliveEnabled,
                    onCheckedChange = onToggleKeepAlive,
                    testTag = "keep_alive_switch",
                    leadingIcon = Icons.Filled.Bolt
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.BatteryChargingFull,
                        contentDescription = null,
                        tint = if (isIgnoringBatteryOptimizations) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = s.batteryTitle, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = if (isIgnoringBatteryOptimizations) s.batteryUnrestricted else s.batteryRestricted,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isIgnoringBatteryOptimizations) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onOpenBatterySettings,
                        modifier = Modifier.testTag("battery_optimization_button")
                    ) {
                        Text(s.batteryAction)
                    }
                    OutlinedButton(
                        onClick = onOpenAppDetailsSettings,
                        modifier = Modifier.testTag("app_info_settings_button")
                    ) {
                        Text(s.appInfoAction)
                    }
                    OutlinedButton(
                        onClick = onRebindListener,
                        modifier = Modifier.testTag("rebind_listener_button")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(s.rebindServiceAction)
                    }
                }
            }
        }

        // Section 2: Language & Theme
        item {
            SettingsCard(title = s.sectionLanguageAndTheme) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Language,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(text = s.languageTitle, style = MaterialTheme.typography.titleSmall)
                }
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AppLanguage.entries.forEach { lang ->
                        FilterChip(
                            selected = settings.appLanguage == lang,
                            onClick = { onSetAppLanguage(lang) },
                            label = { Text(lang.nativeLabel, style = MaterialTheme.typography.labelMedium) },
                            modifier = Modifier.testTag("lang_chip_${lang.code}")
                        )
                    }
                }

                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant,
                    modifier = Modifier.padding(vertical = 12.dp)
                )

                Text(text = s.themeTitle, style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ThemeMode.entries.forEach { mode ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { onSetThemeMode(mode) },
                            label = {
                                Text(
                                    text = s.themeLabels[mode] ?: mode.labelVi,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        )
                    }
                }
            }
        }

        // Section 3: Biometric & Privacy
        item {
            SettingsCard(title = s.sectionBiometricPrivacy) {
                SettingSwitchRow(
                    title = s.biometricTitle,
                    subtitle = if (biometricStatus.isUsable) s.biometricDesc else bioStatusText,
                    checked = settings.biometricEnabled,
                    enabled = biometricStatus.isUsable || settings.biometricEnabled,
                    onCheckedChange = onToggleBiometric,
                    testTag = "biometric_lock_switch",
                    leadingIcon = Icons.Filled.Fingerprint
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showPinDialog = true }
                        .padding(vertical = 12.dp)
                        .testTag("configure_pin_row"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Pin,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = s.pinTitle, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = if (settings.hasPinConfigured) s.pinConfiguredDesc else s.pinUnconfiguredDesc,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = if (settings.hasPinConfigured) s.pinChangeAction else s.pinSetupAction,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                SettingSwitchRow(
                    title = s.flagSecureTitle,
                    subtitle = s.flagSecureDesc,
                    checked = settings.flagSecureEnabled,
                    onCheckedChange = onToggleFlagSecure,
                    testTag = "flag_secure_switch",
                    leadingIcon = Icons.Filled.Security
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Text(text = s.autoLockTitle, style = MaterialTheme.typography.titleSmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    val lockOptions = listOf(
                        0 to s.autoLockImmediate,
                        30 to s.autoLock30s,
                        60 to s.autoLock1m,
                        300 to s.autoLock5m
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        lockOptions.forEach { (sec, label) ->
                            FilterChip(
                                selected = settings.autoLockSeconds == sec,
                                onClick = { onSetAutoLockSeconds(sec) },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
            }
        }

        // Section 4: Voice Read-Aloud (TTS)
        item {
            SettingsCard(title = s.sectionTts) {
                SettingSwitchRow(
                    title = s.ttsGlobalTitle,
                    subtitle = s.ttsGlobalDesc,
                    checked = settings.ttsGlobalEnabled,
                    onCheckedChange = onToggleTtsGlobal,
                    testTag = "tts_global_switch"
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                SettingSwitchRow(
                    title = s.ttsIncludeAppTitle,
                    subtitle = s.ttsIncludeAppDesc,
                    checked = settings.ttsIncludeAppName,
                    onCheckedChange = onToggleTtsIncludeApp,
                    testTag = "tts_include_app_switch"
                )

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = s.ttsSpeedTitle(settings.ttsSpeechRate),
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(
                            onClick = onSpeakSample,
                            modifier = Modifier.testTag("tts_test_sample_button")
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(s.ttsPreviewAction)
                        }
                    }
                    Slider(
                        value = settings.ttsSpeechRate,
                        onValueChange = onSetTtsSpeechRate,
                        valueRange = 0.7f..1.7f,
                        steps = 9,
                        modifier = Modifier.testTag("tts_rate_slider")
                    )
                }
            }
        }

        // Section 5: Capture Service & Testing
        item {
            SettingsCard(title = s.sectionListenerTest) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = s.listenerPermTitle, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = if (isListenerEnabled) s.listenerPermActiveDesc else s.listenerPermInactiveDesc,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isListenerEnabled) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.error
                        )
                    }
                    OutlinedButton(
                        onClick = onOpenListenerSettings,
                        modifier = Modifier.testTag("settings_open_listener_button")
                    ) {
                        Icon(Icons.Filled.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(s.openSettings)
                    }
                }

                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant,
                    modifier = Modifier.padding(vertical = 10.dp)
                )

                SettingSwitchRow(
                    title = s.captureNewAppsTitle,
                    subtitle = s.captureNewAppsDesc,
                    checked = settings.captureNewAppsByDefault,
                    onCheckedChange = onToggleCaptureNewApps,
                    testTag = "capture_new_apps_switch"
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = { showTestPicker = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_send_test_button")
                ) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(s.sendTest)
                }
            }
        }

        // Section 6: Data Retention & Export
        item {
            SettingsCard(title = s.sectionData) {
                Text(text = s.retentionTitle, style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(8.dp))
                val retentionOptions = listOf(
                    7 to s.retention7d,
                    30 to s.retention30d,
                    90 to s.retention90d,
                    0 to s.retentionNever
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    retentionOptions.forEach { (days, label) ->
                        FilterChip(
                            selected = settings.retentionDays == days,
                            onClick = { onSetRetentionDays(days) },
                            label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outlineVariant,
                    modifier = Modifier.padding(vertical = 12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onExportNotifications,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("export_notifications_button")
                    ) {
                        Icon(Icons.Filled.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(s.exportAction)
                    }
                    OutlinedButton(
                        onClick = { showClearConfirm = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("clear_all_notifications_button")
                    ) {
                        Icon(Icons.Filled.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(s.clearAllAction)
                    }
                }
            }
        }
    }

    if (showPinDialog) {
        ConfigurePinDialog(
            hasExistingPin = settings.hasPinConfigured,
            onDismiss = { showPinDialog = false },
            onSave = { newPin ->
                onSavePin(newPin)
                showPinDialog = false
            }
        )
    }

    if (showTestPicker) {
        AlertDialog(
            onDismissRequest = { showTestPicker = false },
            title = { Text(s.testDialogTitle) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = s.testDialogDesc,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TestNotificationScenario.entries.forEach { scenario ->
                        val copy = s.testScenarios[scenario] ?: return@forEach
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(MaterialTheme.shapes.small)
                                .clickable {
                                    onSendTestScenario(scenario)
                                    showTestPicker = false
                                }
                                .testTag("test_scenario_${scenario.name.lowercase()}"),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            shape = MaterialTheme.shapes.small
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(copy.label, style = MaterialTheme.typography.titleSmall)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = copy.content,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTestPicker = false }) {
                    Text(s.cancel)
                }
            }
        )
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text(s.clearAllDialogTitle) },
            text = { Text(s.clearAllDialogDesc(totalSavedCount)) },
            confirmButton = {
                Button(
                    onClick = {
                        onClearAllNotifications()
                        showClearConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(s.delete)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) {
                    Text(s.cancel)
                }
            }
        )
    }
}

@Composable
private fun SettingsCard(
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String,
    enabled: Boolean = true,
    leadingIcon: ImageVector? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leadingIcon != null) {
            Icon(
                imageVector = leadingIcon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
    }
}

@Composable
private fun ConfigurePinDialog(
    hasExistingPin: Boolean,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    val s = LocalAppStrings.current
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    val mismatch = confirmPin.isNotEmpty() && pin != confirmPin
    val valid = pin.length == 4 && pin.all { it.isDigit() } && pin == confirmPin

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (hasExistingPin) s.pinDialogChangeTitle else s.pinDialogSetTitle) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) pin = it },
                    label = { Text(s.pinInputLabel) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("pin_input_field")
                )
                OutlinedTextField(
                    value = confirmPin,
                    onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) confirmPin = it },
                    label = { Text(s.pinConfirmLabel) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    isError = mismatch,
                    supportingText = { if (mismatch) Text(s.pinMismatchError) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("pin_confirm_field")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(pin) },
                enabled = valid,
                modifier = Modifier.testTag("save_pin_button")
            ) {
                Text(s.save)
            }
        },
        dismissButton = {
            Row {
                if (hasExistingPin) {
                    TextButton(onClick = { onSave("") }) {
                        Text(s.pinRemoveAction, color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text(s.cancel)
                }
            }
        }
    )
}
