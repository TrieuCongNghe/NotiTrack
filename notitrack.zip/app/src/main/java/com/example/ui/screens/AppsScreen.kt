package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AppRuleEntity
import com.example.ui.components.AppIconAvatar
import com.example.ui.components.VaultSearchBar
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.viewmodel.AppsFilter

@Composable
fun AppsScreen(
    allRulesCount: Int,
    capturingCount: Int,
    ttsActiveCount: Int,
    filteredRules: List<AppRuleEntity>,
    query: String,
    activeFilter: AppsFilter,
    ttsGlobalEnabled: Boolean,
    onQueryChange: (String) -> Unit,
    onFilterChange: (AppsFilter) -> Unit,
    onUpdateRule: (AppRuleEntity) -> Unit,
    onSetCaptureAll: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val s = LocalAppStrings.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = s.appsTitle,
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = s.appsSubtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = s.appsCountSummary(capturingCount, allRulesCount),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = s.appsTtsSummary(ttsActiveCount),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
                TextButton(
                    onClick = { onSetCaptureAll(true) },
                    modifier = Modifier.testTag("apps_enable_all_button")
                ) {
                    Text(s.appsEnableAll)
                }
                TextButton(
                    onClick = { onSetCaptureAll(false) },
                    modifier = Modifier.testTag("apps_disable_all_button")
                ) {
                    Text(s.appsDisableAll)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        VaultSearchBar(
            query = query,
            placeholder = s.appsSearchHint,
            onQueryChange = onQueryChange,
            testTag = "apps_search_input"
        )

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(AppsFilter.entries) { filter ->
                FilterChip(
                    selected = activeFilter == filter,
                    onClick = { onFilterChange(filter) },
                    label = {
                        Text(
                            text = s.appsFilterLabels[filter] ?: filter.labelVi,
                            style = MaterialTheme.typography.labelLarge
                        )
                    },
                    modifier = Modifier.testTag("apps_filter_${filter.name.lowercase()}")
                )
            }
        }

        if (!ttsGlobalEnabled) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.small,
                color = MaterialTheme.colorScheme.tertiaryContainer
            ) {
                Text(
                    text = s.appsTtsGlobalOffNotice,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredRules, key = { it.packageName }) { rule ->
                AppRuleCard(
                    rule = rule,
                    onToggleCapture = { checked ->
                        onUpdateRule(rule.copy(captureEnabled = checked))
                    },
                    onToggleTts = { checked ->
                        onUpdateRule(
                            rule.copy(
                                captureEnabled = if (checked) true else rule.captureEnabled,
                                readAloudEnabled = checked
                            )
                        )
                    },
                    onToggleAutoDismiss = { checked ->
                        onUpdateRule(
                            rule.copy(
                                captureEnabled = if (checked) true else rule.captureEnabled,
                                autoDismissEnabled = checked
                            )
                        )
                    }
                )
            }
        }
    }
}

@Composable
private fun AppRuleCard(
    rule: AppRuleEntity,
    onToggleCapture: (Boolean) -> Unit,
    onToggleTts: (Boolean) -> Unit,
    onToggleAutoDismiss: (Boolean) -> Unit
) {
    val s = LocalAppStrings.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("app_rule_card_${rule.packageName}"),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(
            1.dp,
            if (rule.captureEnabled) MaterialTheme.colorScheme.outlineVariant
            else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AppIconAvatar(
                    packageName = rule.packageName,
                    appName = rule.appName,
                    size = 42.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = rule.appName,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = rule.packageName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Switch(
                    checked = rule.captureEnabled,
                    onCheckedChange = onToggleCapture,
                    modifier = Modifier.testTag("app_capture_switch_${rule.packageName}")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = rule.readAloudEnabled,
                    onClick = { onToggleTts(!rule.readAloudEnabled) },
                    enabled = rule.captureEnabled,
                    label = {
                        Text(
                            text = s.appsChipTts,
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.RecordVoiceOver,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.tertiaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onTertiaryContainer,
                        selectedLeadingIconColor = MaterialTheme.colorScheme.onTertiaryContainer
                    ),
                    modifier = Modifier.testTag("app_tts_chip_${rule.packageName}")
                )

                FilterChip(
                    selected = rule.autoDismissEnabled,
                    onClick = { onToggleAutoDismiss(!rule.autoDismissEnabled) },
                    enabled = rule.captureEnabled,
                    label = {
                        Text(
                            text = s.appsChipAutoDismiss,
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.CleaningServices,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        selectedLeadingIconColor = MaterialTheme.colorScheme.onSecondaryContainer
                    ),
                    modifier = Modifier.testTag("app_dismiss_chip_${rule.packageName}")
                )
            }
        }
    }
}
