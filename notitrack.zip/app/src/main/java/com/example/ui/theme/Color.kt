package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme — Alabaster & Deep Jade Vault
val JadePrimaryLight = Color(0xFF0E7C66)
val JadeOnPrimaryLight = Color(0xFFFFFFFF)
val JadePrimaryContainerLight = Color(0xFFCFF6EB)
val JadeOnPrimaryContainerLight = Color(0xFF05382D)

val AmberSecondaryLight = Color(0xFFB36D0D)
val AmberOnSecondaryLight = Color(0xFFFFFFFF)
val AmberSecondaryContainerLight = Color(0xFFFFE6C2)
val AmberOnSecondaryContainerLight = Color(0xFF3E2200)

val CobaltTertiaryLight = Color(0xFF245D8B)
val CobaltOnTertiaryLight = Color(0xFFFFFFFF)
val CobaltTertiaryContainerLight = Color(0xFFD4E9FF)
val CobaltOnTertiaryContainerLight = Color(0xFF002642)

val CrimsonErrorLight = Color(0xFFC43B3B)
val CrimsonOnErrorLight = Color(0xFFFFFFFF)
val CrimsonErrorContainerLight = Color(0xFFFFDAD6)
val CrimsonOnErrorContainerLight = Color(0xFF410002)

val SurfaceLight = Color(0xFFF6F8F6)
val SurfaceContainerLowestLight = Color(0xFFFFFFFF)
val SurfaceContainerLowLight = Color(0xFFF0F4F1)
val SurfaceContainerLight = Color(0xFFE9EFEA)
val SurfaceContainerHighLight = Color(0xFFE1E8E3)
val OnSurfaceLight = Color(0xFF131B18)
val OnSurfaceVariantLight = Color(0xFF475751)
val OutlineLight = Color(0xFF72827B)
val OutlineVariantLight = Color(0xFFD5DFDA)

// Dark Theme — Obsidian & Mint Jade Vault
val JadePrimaryDark = Color(0xFF4FD8B8)
val JadeOnPrimaryDark = Color(0xFF00382C)
val JadePrimaryContainerDark = Color(0xFF0C5243)
val JadeOnPrimaryContainerDark = Color(0xFFC3F7E9)

val AmberSecondaryDark = Color(0xFFF6B94D)
val AmberOnSecondaryDark = Color(0xFF442800)
val AmberSecondaryContainerDark = Color(0xFF603C00)
val AmberOnSecondaryContainerDark = Color(0xFFFFDEA8)

val CobaltTertiaryDark = Color(0xFF8CC5F8)
val CobaltOnTertiaryDark = Color(0xFF003356)
val CobaltTertiaryContainerDark = Color(0xFF154B74)
val CobaltOnTertiaryContainerDark = Color(0xFFD4E9FF)

val CrimsonErrorDark = Color(0xFFFFB4AB)
val CrimsonOnErrorDark = Color(0xFF690005)
val CrimsonErrorContainerDark = Color(0xFF8C1D18)
val CrimsonOnErrorContainerDark = Color(0xFFFFDAD6)

val SurfaceDark = Color(0xFF0C1210)
val SurfaceContainerLowestDark = Color(0xFF080D0B)
val SurfaceContainerLowDark = Color(0xFF121A17)
val SurfaceContainerDark = Color(0xFF17211E)
val SurfaceContainerHighDark = Color(0xFF1F2B27)
val OnSurfaceDark = Color(0xFFE6EEEA)
val OnSurfaceVariantDark = Color(0xFF9FB0A8)
val OutlineDark = Color(0xFF697B74)
val OutlineVariantDark = Color(0xFF283732)

// Vault Atmospheric Accents (for Lock Screen & Security Hero)
val VaultObsidianDeep = Color(0xFF081915)
val VaultObsidianMid = Color(0xFF0E2E27)
val VaultMintGlow = Color(0xFF4FD8B8)
val VaultGoldGlow = Color(0xFFF6B94D)
