package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AppNotificationSummary
import com.example.data.model.NotificationEntity
import com.example.ui.components.AppIconAvatar
import com.example.ui.components.ListenerAccessBanner
import com.example.ui.components.OtpCopyPill
import com.example.ui.components.VaultSearchBar
import com.example.ui.components.formatFullTimestamp
import com.example.ui.components.formatRelativeTimestamp
import com.example.ui.i18n.LocalAppStrings
import com.example.ui.viewmodel.InboxFilter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InboxScreen(
    notifications: List<NotificationEntity>,
    groupedSummaries: List<AppNotificationSummary>,
    isGroupedView: Boolean,
    selectedAppPackage: String?,
    query: String,
    activeFilter: InboxFilter,
    isListenerEnabled: Boolean,
    isLockConfigured: Boolean,
    speakingNotificationId: Long?,
    onQueryChange: (String) -> Unit,
    onFilterChange: (InboxFilter) -> Unit,
    onToggleGroupedView: () -> Unit,
    onOpenAppThread: (String?) -> Unit,
    onMarkAllRead: () -> Unit,
    onMarkRead: (Long) -> Unit,
    onToggleStar: (NotificationEntity) -> Unit,
    onToggleHidden: (NotificationEntity) -> Unit,
    onDeleteNotification: (Long) -> Unit,
    onDeletePackageNotifications: (String, String) -> Unit,
    onToggleSpeak: (NotificationEntity) -> Unit,
    onOpenListenerSettings: () -> Unit,
    onSendTestNotification: () -> Unit,
    onLockNow: () -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val s = LocalAppStrings.current
    var inspectedNotification by remember { mutableStateOf<NotificationEntity?>(null) }

    if (selectedAppPackage != null) {
        BackHandler { onOpenAppThread(null) }
    }

    val selectedAppTitle = remember(selectedAppPackage, notifications) {
        selectedAppPackage?.let { pkg ->
            notifications.firstOrNull { it.packageName == pkg }?.appName ?: pkg
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selectedAppPackage != null) {
                IconButton(
                    onClick = { onOpenAppThread(null) },
                    modifier = Modifier.testTag("back_from_app_thread")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = s.back
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = selectedAppTitle.orEmpty(),
                        style = MaterialTheme.typography.headlineSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = s.inboxSavedCount(notifications.size),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(
                    onClick = {
                        onDeletePackageNotifications(selectedAppPackage, selectedAppTitle.orEmpty())
                    },
                    modifier = Modifier.testTag("delete_app_thread_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = s.delete,
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            } else {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = s.appName,
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isListenerEnabled) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.error
                                )
                        )
                        Text(
                            text = if (isListenerEnabled) s.listenerActive else s.listenerInactive,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = onToggleGroupedView,
                    modifier = Modifier.testTag("toggle_grouped_view_button")
                ) {
                    Icon(
                        imageVector = if (isGroupedView) Icons.AutoMirrored.Filled.ViewList else Icons.Filled.GridView,
                        contentDescription = if (isGroupedView) s.inboxTimeline else s.inboxGrouped,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                IconButton(
                    onClick = onMarkAllRead,
                    modifier = Modifier.testTag("mark_all_read_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.DoneAll,
                        contentDescription = s.inboxMarkAllRead,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (isLockConfigured) {
                    IconButton(
                        onClick = onLockNow,
                        modifier = Modifier.testTag("quick_lock_vault_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Lock,
                            contentDescription = s.inboxLockNow,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        VaultSearchBar(
            query = query,
            placeholder = s.inboxSearchHint,
            onQueryChange = onQueryChange,
            testTag = "inbox_search_input"
        )

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(InboxFilter.entries) { filter ->
                FilterChip(
                    selected = activeFilter == filter,
                    onClick = { onFilterChange(filter) },
                    label = {
                        Text(
                            text = s.inboxFilterLabels[filter] ?: filter.labelVi,
                            style = MaterialTheme.typography.labelLarge
                        )
                    },
                    modifier = Modifier.testTag("inbox_filter_${filter.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        val showingGrouped = isGroupedView && selectedAppPackage == null

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (!isListenerEnabled) {
                item(key = "listener_banner") {
                    ListenerAccessBanner(onGrantAccess = onOpenListenerSettings)
                }
            }

            if (showingGrouped) {
                if (groupedSummaries.isEmpty()) {
                    item(key = "empty_grouped") {
                        EmptyInboxCard(
                            isListenerEnabled = isListenerEnabled,
                            onGrantAccess = onOpenListenerSettings,
                            onSendTestNotification = onSendTestNotification
                        )
                    }
                } else {
                    items(groupedSummaries, key = { it.packageName }) { summary ->
                        AppGroupCard(
                            summary = summary,
                            onClick = { onOpenAppThread(summary.packageName) }
                        )
                    }
                }
            } else {
                if (notifications.isEmpty()) {
                    item(key = "empty_timeline") {
                        EmptyInboxCard(
                            isListenerEnabled = isListenerEnabled,
                            onGrantAccess = onOpenListenerSettings,
                            onSendTestNotification = onSendTestNotification
                        )
                    }
                } else {
                    items(notifications, key = { it.id }) { item ->
                        NotificationCard(
                            item = item,
                            isSpeaking = speakingNotificationId == item.id,
                            onClick = {
                                if (!item.isRead) onMarkRead(item.id)
                                inspectedNotification = item
                            },
                            onCopyOtp = { code ->
                                copyToClipboard(context, "OTP", code)
                                onShowMessage(s.inboxCopiedOtp(code))
                            },
                            onToggleSpeak = { onToggleSpeak(item) },
                            onToggleStar = { onToggleStar(item) }
                        )
                    }
                }
            }
        }
    }

    inspectedNotification?.let { selected ->
        val latestState = notifications.find { it.id == selected.id } ?: selected
        NotificationDetailBottomSheet(
            notification = latestState,
            isSpeaking = speakingNotificationId == latestState.id,
            onDismiss = { inspectedNotification = null },
            onCopyAll = {
                copyToClipboard(context, latestState.title, "${latestState.title}\n${latestState.content}")
                onShowMessage(s.inboxCopied)
            },
            onCopyOtp = { otp ->
                copyToClipboard(context, "OTP", otp)
                onShowMessage(s.inboxCopiedOtp(otp))
            },
            onShare = {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, latestState.title)
                    putExtra(
                        Intent.EXTRA_TEXT,
                        "[${latestState.appName}] ${latestState.title}\n${latestState.content}"
                    )
                }
                context.startActivity(Intent.createChooser(shareIntent, s.inboxShareTitle))
            },
            onToggleSpeak = { onToggleSpeak(latestState) },
            onToggleStar = { onToggleStar(latestState) },
            onToggleHidden = { onToggleHidden(latestState) },
            onDelete = {
                onDeleteNotification(latestState.id)
                inspectedNotification = null
            }
        )
    }
}

@Composable
private fun AppGroupCard(
    summary: AppNotificationSummary,
    onClick: () -> Unit
) {
    val s = LocalAppStrings.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("app_group_card_${summary.packageName}"),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(
            width = 1.dp,
            color = if (summary.hasHighlighted) MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f)
            else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppIconAvatar(
                packageName = summary.packageName,
                appName = summary.appName,
                size = 46.dp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = summary.appName,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = formatRelativeTimestamp(summary.latestTimestamp, s),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = summary.latestTitle.ifBlank { summary.latestContent },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (summary.unreadCount > 0) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (summary.latestContent.isNotBlank() && summary.latestContent != summary.latestTitle) {
                    Text(
                        text = summary.latestContent,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Surface(
                shape = CircleShape,
                color = if (summary.unreadCount > 0) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.surfaceContainerHigh
            ) {
                Text(
                    text = if (summary.unreadCount > 0) "${summary.unreadCount}" else "${summary.totalCount}",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (summary.unreadCount > 0) MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                )
            }
        }
    }
}

@Composable
private fun NotificationCard(
    item: NotificationEntity,
    isSpeaking: Boolean,
    onClick: () -> Unit,
    onCopyOtp: (String) -> Unit,
    onToggleSpeak: () -> Unit,
    onToggleStar: () -> Unit
) {
    val s = LocalAppStrings.current
    val borderColor = when {
        item.isHighlighted -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.55f)
        !item.isRead -> MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
        else -> MaterialTheme.colorScheme.outlineVariant
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("notification_card_${item.id}"),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                AppIconAvatar(
                    packageName = item.packageName,
                    appName = item.appName,
                    size = 40.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!item.isRead) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text(
                            text = item.appName,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = formatRelativeTimestamp(item.timestamp, s),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (!item.isRead) FontWeight.Bold else FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (item.content.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = item.content,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (item.matchedKeywords.isNotBlank() || !item.detectedOtp.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    item.detectedOtp?.let { otp ->
                        OtpCopyPill(otpCode = otp, onCopy = { onCopyOtp(otp) })
                    }
                    if (item.matchedKeywords.isNotBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "#${item.matchedKeywords}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onToggleSpeak,
                    modifier = Modifier.testTag("speak_notification_${item.id}")
                ) {
                    Icon(
                        imageVector = if (isSpeaking) Icons.Filled.StopCircle else Icons.Filled.VolumeUp,
                        contentDescription = if (isSpeaking) s.stopSpeak else s.speak,
                        tint = if (isSpeaking) MaterialTheme.colorScheme.tertiary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(
                    onClick = onToggleStar,
                    modifier = Modifier.testTag("star_notification_${item.id}")
                ) {
                    Icon(
                        imageVector = if (item.isStarred) Icons.Filled.Star else Icons.Outlined.StarOutline,
                        contentDescription = s.inboxPinStar,
                        tint = if (item.isStarred) MaterialTheme.colorScheme.secondary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyInboxCard(
    isListenerEnabled: Boolean,
    onGrantAccess: () -> Unit,
    onSendTestNotification: () -> Unit
) {
    val s = LocalAppStrings.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_inbox_1795064150853),
                contentDescription = s.inboxEmptyTitle,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(176.dp)
                    .clip(MaterialTheme.shapes.medium)
            )
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = s.inboxEmptyTitle,
                style = MaterialTheme.typography.titleLarge,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = s.inboxEmptyDesc,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            if (!isListenerEnabled) {
                Button(
                    onClick = onGrantAccess,
                    modifier = Modifier.testTag("empty_grant_listener_button")
                ) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(s.grantAccess)
                }
            } else {
                OutlinedButton(
                    onClick = onSendTestNotification,
                    modifier = Modifier.testTag("empty_send_test_notification_button")
                ) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(s.sendTest)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NotificationDetailBottomSheet(
    notification: NotificationEntity,
    isSpeaking: Boolean,
    onDismiss: () -> Unit,
    onCopyAll: () -> Unit,
    onCopyOtp: (String) -> Unit,
    onShare: () -> Unit,
    onToggleSpeak: () -> Unit,
    onToggleStar: () -> Unit,
    onToggleHidden: () -> Unit,
    onDelete: () -> Unit
) {
    val s = LocalAppStrings.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIconAvatar(
                    packageName = notification.packageName,
                    appName = notification.appName,
                    size = 46.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = notification.appName,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = formatFullTimestamp(notification.timestamp),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onToggleStar) {
                    Icon(
                        imageVector = if (notification.isStarred) Icons.Filled.Star else Icons.Outlined.StarOutline,
                        contentDescription = s.inboxPinStar,
                        tint = if (notification.isStarred) MaterialTheme.colorScheme.secondary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = notification.title,
                style = MaterialTheme.typography.titleLarge
            )
            if (notification.subText.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = notification.subText,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            if (notification.content.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = notification.content,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            if (!notification.detectedOtp.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(14.dp))
                OtpCopyPill(
                    otpCode = notification.detectedOtp,
                    onCopy = { onCopyOtp(notification.detectedOtp) }
                )
            }

            if (notification.matchedKeywords.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = s.inboxMatchedKeywords(notification.matchedKeywords),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onToggleSpeak,
                    modifier = Modifier.weight(1f).testTag("detail_speak_button")
                ) {
                    Icon(
                        imageVector = if (isSpeaking) Icons.Filled.StopCircle else Icons.Filled.VolumeUp,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isSpeaking) s.stopSpeak else s.speak)
                }
                OutlinedButton(
                    onClick = onCopyAll,
                    modifier = Modifier.weight(1f).testTag("detail_copy_button")
                ) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(s.copy)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onToggleHidden,
                    modifier = Modifier.weight(1f).testTag("detail_hide_button")
                ) {
                    Icon(
                        imageVector = if (notification.isHidden) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (notification.isHidden) s.inboxShowAgain else s.inboxHidePrivate)
                }
                OutlinedButton(
                    onClick = onShare,
                    modifier = Modifier.testTag("detail_share_button")
                ) {
                    Icon(Icons.Filled.Share, contentDescription = s.share)
                }
                OutlinedButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("detail_delete_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = s.delete,
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, text))
}
