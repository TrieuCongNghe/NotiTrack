package com.example.ui.i18n

import androidx.compose.runtime.staticCompositionLocalOf
import com.example.data.model.KeywordAction
import com.example.data.prefs.KeepAliveNotifTheme
import com.example.engine.BiometricHardwareStatus
import com.example.engine.TestNotificationScenario
import com.example.ui.theme.ThemeMode
import com.example.ui.viewmodel.AppsFilter
import com.example.ui.viewmodel.InboxFilter
import com.example.ui.viewmodel.KeywordPreset

data class TestScenarioCopy(
    val label: String,
    val title: String,
    val content: String,
    val subText: String
)

data class AppStrings(
    // Nav
    val navInbox: String,
    val navApps: String,
    val navFilters: String,
    val navSettings: String,
    // Common
    val save: String,
    val cancel: String,
    val delete: String,
    val copy: String,
    val share: String,
    val speak: String,
    val stopSpeak: String,
    val openSettings: String,
    val grantAccess: String,
    val sendTest: String,
    val clearSearch: String,
    val back: String,
    val edit: String,
    val close: String,
    val today: String,
    val yesterday: String,
    // Listener Banner
    val listenerBannerTitle: String,
    val listenerBannerDesc: String,
    val listenerActive: String,
    val listenerInactive: String,
    // Inbox & Chat Timeline & Multi-select Delete
    val inboxSearchHint: String,
    val inboxTimeline: String,
    val inboxGrouped: String,
    val inboxMarkAllRead: String,
    val inboxLockNow: String,
    val inboxSavedCount: (Int) -> String,
    val inboxEmptyTitle: String,
    val inboxEmptyDesc: String,
    val inboxCopied: String,
    val inboxCopiedOtp: (String) -> String,
    val inboxMatchedKeywords: (String) -> String,
    val inboxShowAgain: String,
    val inboxHidePrivate: String,
    val inboxShareTitle: String,
    val inboxPinStar: String,
    val inboxFilterLabels: Map<InboxFilter, String>,
    val timeJustNow: String,
    val timeMinutesAgo: (Long) -> String,
    val inboxSelectMode: String,
    val inboxSelectedCount: (Int) -> String,
    val inboxSelectAll: String,
    val inboxDeselectAll: String,
    val inboxDeleteSelected: String,
    val inboxDeleteAll: String,
    val inboxUnreadWarnTitle: String,
    val inboxUnreadWarnBody: (total: Int, unread: Int) -> String,
    val inboxDeleteConfirmTitle: String,
    val inboxDeleteConfirmBody: (total: Int) -> String,
    val inboxDeleteOnlyRead: (readCount: Int) -> String,
    val inboxDeleteForceAll: String,
    val inboxChatGroupingHint: String,
    // Apps
    val appsTitle: String,
    val appsSubtitle: String,
    val appsSearchHint: String,
    val appsEnableAll: String,
    val appsDisableAll: String,
    val appsCountSummary: (Int, Int) -> String,
    val appsTtsSummary: (Int) -> String,
    val appsTtsGlobalOffNotice: String,
    val appsChipTts: String,
    val appsChipAutoDismiss: String,
    val appsChipSmartTts: String,
    val appsChipHideBalance: String,
    val appsFilterLabels: Map<AppsFilter, String>,
    // Filters
    val filtersTitle: String,
    val filtersSubtitle: String,
    val filtersPresetsTitle: String,
    val filtersAddRule: String,
    val filtersEmptyTitle: String,
    val filtersEmptyDesc: String,
    val filtersDialogCreate: String,
    val filtersDialogEdit: String,
    val filtersKeywordLabel: String,
    val filtersKeywordPlaceholder: String,
    val filtersRegexInvalid: String,
    val filtersActionPrompt: String,
    val filtersScopePrefix: String,
    val filtersScopeAll: String,
    val filtersCaseSensitive: String,
    val filtersUseRegex: String,
    val filtersMatchCount: (Int) -> String,
    val keywordActionLabel: Map<KeywordAction, String>,
    val keywordActionShort: Map<KeywordAction, String>,
    val keywordActionDesc: Map<KeywordAction, String>,
    val keywordPresets: List<KeywordPreset>,
    // Settings
    val settingsTitle: String,
    val heroProtected: String,
    val heroUnprotected: String,
    val heroLocalCount: (Int) -> String,
    val heroLockNow: String,
    // Support / Donate
    val supportCardTitle: String,
    val supportCardSubtitle: String,
    val supportButtonLabel: String,
    val supportDialogTitle: String,
    val supportAppIntro: String,
    val supportAuthorLabel: String,
    val supportFacebookLabel: String,
    val supportBuyCoffeeAction: String,
    val supportDonateBankAction: String,
    val donateQrDialogTitle: String,
    val donateQrDialogSubtitle: String,
    val donateBankLabel: String,
    val donateAccountNoLabel: String,
    val donateAccountHolderLabel: String,
    val donateSaveQrAction: String,
    val donateCopyStkAction: String,
    val msgQrSaved: String,
    val msgQrSaveFailed: String,
    val msgStkCopied: String,
    // Display & Chat Grouping
    val sectionDisplayGrouping: String,
    val chatGroupingTitle: String,
    val chatGroupingDesc: String,
    val sectionLanguageAndTheme: String,
    val languageTitle: String,
    val themeTitle: String,
    val themeLabels: Map<ThemeMode, String>,
    // Keep-Alive Notification Customization
    val sectionPersistence: String,
    val keepAliveTitle: String,
    val keepAliveDesc: String,
    val keepAliveCustomizeTitle: String,
    val keepAliveShowTempTitle: String,
    val keepAliveShowLunarTitle: String,
    val keepAliveShowCountTitle: String,
    val keepAliveShowBatteryTitle: String,
    val keepAliveThemeTitle: String,
    val keepAliveThemeLabels: Map<KeepAliveNotifTheme, String>,
    val keepAliveActiveBadge: String,
    val keepAliveLunarShort: String,
    val keepAliveCountShort: String,
    val keepAliveBatteryShort: String,
    val batteryTitle: String,
    val batteryUnrestricted: String,
    val batteryRestricted: String,
    val batteryAction: String,
    val appInfoAction: String,
    val rebindServiceAction: String,
    val sectionBiometricPrivacy: String,
    val biometricTitle: String,
    val biometricDesc: String,
    val pinTitle: String,
    val pinConfiguredDesc: String,
    val pinUnconfiguredDesc: String,
    val pinChangeAction: String,
    val pinSetupAction: String,
    val flagSecureTitle: String,
    val flagSecureDesc: String,
    val autoLockTitle: String,
    val autoLockImmediate: String,
    val autoLock30s: String,
    val autoLock1m: String,
    val autoLock5m: String,
    // TTS & Smart Reader
    val sectionTts: String,
    val ttsGlobalTitle: String,
    val ttsGlobalDesc: String,
    val ttsIncludeAppTitle: String,
    val ttsIncludeAppDesc: String,
    val ttsSmartFilterTitle: String,
    val ttsSmartFilterDesc: String,
    val ttsHideBalanceTitle: String,
    val ttsHideBalanceDesc: String,
    val ttsSpeedTitle: (Float) -> String,
    val ttsPreviewAction: String,
    val ttsSpokenPrefix: (String) -> String,
    val ttsSampleSentence: String,
    val sectionListenerTest: String,
    val listenerPermTitle: String,
    val listenerPermActiveDesc: String,
    val listenerPermInactiveDesc: String,
    val captureNewAppsTitle: String,
    val captureNewAppsDesc: String,
    val sectionData: String,
    val retentionTitle: String,
    val retention7d: String,
    val retention30d: String,
    val retention90d: String,
    val retentionNever: String,
    val exportAction: String,
    val clearAllAction: String,
    val clearAllDialogTitle: String,
    val clearAllDialogDesc: (Int) -> String,
    // Test Picker Dialog
    val testDialogTitle: String,
    val testDialogDesc: String,
    val testChannelName: String,
    val testChannelDesc: String,
    val testScenarios: Map<TestNotificationScenario, TestScenarioCopy>,
    val androidRedactedNotice: String,
    // PIN Dialog
    val pinDialogChangeTitle: String,
    val pinDialogSetTitle: String,
    val pinInputLabel: String,
    val pinConfirmLabel: String,
    val pinMismatchError: String,
    val pinRemoveAction: String,
    // Lock Screen
    val lockScreenTitle: String,
    val lockScreenSubtitle: String,
    val lockBiometricButton: String,
    val lockPinButton: String,
    val lockHidePinButton: String,
    val lockPromptTitle: String,
    val lockPromptSubtitle: String,
    val lockPromptNegative: String,
    val lockPinIncorrect: String,
    val lockBiometricEnableTitle: String,
    val lockBiometricEnableSub: String,
    val lockBiometricDisableTitle: String,
    val lockBiometricDisableSub: String,
    val biometricStatusMessages: Map<BiometricHardwareStatus, String>,
    val biometricMismatchMsg: String,
    // Keep-Alive Notification
    val keepAliveChannelName: String,
    val keepAliveNotifTitle: String,
    val keepAliveNotifText: String,
    val feedback: FeedbackStrings,
    val extra: ExtraAppStrings = ExtraAppStrings()
) {
    val appName: String = "NotiTrack"

    val msgNeedLockFirst: String get() = feedback.msgNeedLockFirst
    val msgMarkedAllRead: String get() = feedback.msgMarkedAllRead
    val msgMovedToHidden: String get() = feedback.msgMovedToHidden
    val msgRestoredToMain: String get() = feedback.msgRestoredToMain
    val msgDeletedOne: String get() = feedback.msgDeletedOne
    val msgDeletedMany: (Int) -> String get() = feedback.msgDeletedMany
    val msgDeletedApp: (String) -> String get() = feedback.msgDeletedApp
    val msgEnabledAllApps: String get() = feedback.msgEnabledAllApps
    val msgDisabledAllApps: String get() = feedback.msgDisabledAllApps
    val msgRuleUpdated: String get() = feedback.msgRuleUpdated
    val msgRuleAdded: String get() = feedback.msgRuleAdded
    val msgPresetAdded: (String) -> String get() = feedback.msgPresetAdded
    val msgRuleDeleted: String get() = feedback.msgRuleDeleted
    val msgBiometricOn: String get() = feedback.msgBiometricOn
    val msgBiometricOff: String get() = feedback.msgBiometricOff
    val msgPinCleared: String get() = feedback.msgPinCleared
    val msgPinSaved: String get() = feedback.msgPinSaved
    val msgRetentionNever: String get() = feedback.msgRetentionNever
    val msgRetentionDays: (Int) -> String get() = feedback.msgRetentionDays
    val msgClearedAll: String get() = feedback.msgClearedAll
    val msgTestSentCaptured: String get() = feedback.msgTestSentCaptured
    val msgTestSentNeedAccess: String get() = feedback.msgTestSentNeedAccess
    val msgNeedPostPerm: String get() = feedback.msgNeedPostPerm
    val msgCannotOpenSettings: String get() = feedback.msgCannotOpenSettings
    val msgServiceRebound: String get() = feedback.msgServiceRebound
    val msgKeepAliveOn: String get() = feedback.msgKeepAliveOn
    val msgKeepAliveOff: String get() = feedback.msgKeepAliveOff
    val exportEmpty: String get() = feedback.exportEmpty
    val exportHeader: (Int) -> String get() = feedback.exportHeader
    val exportTimeLabel: String get() = feedback.exportTimeLabel

    val settingsTabGeneral: String get() = extra.settingsTabGeneral
    val settingsTabTts: String get() = extra.settingsTabTts
    val settingsTabNotif: String get() = extra.settingsTabNotif
    val settingsTabSecurity: String get() = extra.settingsTabSecurity
    val ttsVolumeSectionTitle: String get() = extra.ttsVolumeSectionTitle
    val ttsOverrideVolumeTitle: String get() = extra.ttsOverrideVolumeTitle
    val ttsOverrideVolumeDesc: String get() = extra.ttsOverrideVolumeDesc
    val ttsBypassSilentTitle: String get() = extra.ttsBypassSilentTitle
    val ttsBypassSilentDesc: String get() = extra.ttsBypassSilentDesc
    val ttsVolumeLevelTitle: (Int) -> String get() = extra.ttsVolumeLevelTitle
    val msgTtsAllOn: String get() = extra.msgTtsAllOn
    val msgTtsAllOff: String get() = extra.msgTtsAllOff
    val msgSmartTtsAllOn: String get() = extra.msgSmartTtsAllOn
    val msgSmartTtsAllOff: String get() = extra.msgSmartTtsAllOff
    val msgHideBalanceAllOn: String get() = extra.msgHideBalanceAllOn
    val msgHideBalanceAllOff: String get() = extra.msgHideBalanceAllOff
    val advTtsTitle: String get() = extra.advTtsTitle
    val advTtsFilterModeLabel: String get() = extra.advTtsFilterModeLabel
    val advTtsFilterNumeric: String get() = extra.advTtsFilterNumeric
    val advTtsFilterNumericDesc: String get() = extra.advTtsFilterNumericDesc
    val advTtsFilterAll: String get() = extra.advTtsFilterAll
    val advTtsFilterAllDesc: String get() = extra.advTtsFilterAllDesc
    val advTtsSampleSection: String get() = extra.advTtsSampleSection
    val advTtsSampleEmptyNotice: String get() = extra.advTtsSampleEmptyNotice
    val advTtsSamplePickHint: String get() = extra.advTtsSamplePickHint
    val advTtsSampleTapHint: String get() = extra.advTtsSampleTapHint
    val advTtsSampleClearTemplate: String get() = extra.advTtsSampleClearTemplate
    val advTtsSamplePreviewLabel: String get() = extra.advTtsSamplePreviewLabel
    val advTtsNumberModeLabel: String get() = extra.advTtsNumberModeLabel
    val advTtsNumberAuto: String get() = extra.advTtsNumberAuto
    val advTtsNumberExact: String get() = extra.advTtsNumberExact
    val advTtsNumberNatural: String get() = extra.advTtsNumberNatural
    val advTtsAutoBoostTitle: String get() = extra.advTtsAutoBoostTitle
    val advTtsAutoBoostDesc: String get() = extra.advTtsAutoBoostDesc
    val advTtsCustomBadge: String get() = extra.advTtsCustomBadge
    val advTtsGearDesc: String get() = extra.advTtsGearDesc
    val msgAdvTtsSaved: String get() = extra.msgAdvTtsSaved
    val filtersAppPickerTitle: String get() = extra.filtersAppPickerTitle
    val filtersAppPickerSearchHint: String get() = extra.filtersAppPickerSearchHint
    val inboxThreadsSummary: (Int, Int) -> String get() = extra.inboxThreadsSummary
    val inboxConversationsTitle: String get() = extra.inboxConversationsTitle
    val ttsDelayTitle: (Int) -> String get() = extra.ttsDelayTitle
    val ttsDelayDesc: String get() = extra.ttsDelayDesc
    val inboxFabMarkAllRead: String get() = extra.inboxFabMarkAllRead
    val msgAllAlreadyRead: String get() = extra.msgAllAlreadyRead
}

data class FeedbackStrings(
    val msgNeedLockFirst: String,
    val msgMarkedAllRead: String,
    val msgMovedToHidden: String,
    val msgRestoredToMain: String,
    val msgDeletedOne: String,
    val msgDeletedMany: (Int) -> String,
    val msgDeletedApp: (String) -> String,
    val msgEnabledAllApps: String,
    val msgDisabledAllApps: String,
    val msgRuleUpdated: String,
    val msgRuleAdded: String,
    val msgPresetAdded: (String) -> String,
    val msgRuleDeleted: String,
    val msgBiometricOn: String,
    val msgBiometricOff: String,
    val msgPinCleared: String,
    val msgPinSaved: String,
    val msgRetentionNever: String,
    val msgRetentionDays: (Int) -> String,
    val msgClearedAll: String,
    val msgTestSentCaptured: String,
    val msgTestSentNeedAccess: String,
    val msgNeedPostPerm: String,
    val msgCannotOpenSettings: String,
    val msgServiceRebound: String,
    val msgKeepAliveOn: String,
    val msgKeepAliveOff: String,
    val exportEmpty: String,
    val exportHeader: (Int) -> String,
    val exportTimeLabel: String
)

data class ExtraAppStrings(
    val settingsTabGeneral: String = "General",
    val settingsTabTts: String = "Read Aloud",
    val settingsTabNotif: String = "Notification",
    val settingsTabSecurity: String = "Security & Data",
    val ttsVolumeSectionTitle: String = "Read-Aloud Volume",
    val ttsOverrideVolumeTitle: String = "Independent read-aloud volume",
    val ttsOverrideVolumeDesc: String = "Speak at your chosen level regardless of current media volume, then restore automatically",
    val ttsBypassSilentTitle: String = "Bypass Silent / Vibrate mode",
    val ttsBypassSilentDesc: String = "Route speech through Alarm audio channel so important alerts are heard even when muted",
    val ttsVolumeLevelTitle: (Int) -> String = { "Read-aloud volume: $it%" },
    val msgTtsAllOn: String = "Enabled read-aloud for all apps",
    val msgTtsAllOff: String = "Disabled read-aloud for all apps (you can still enable individual apps)",
    val msgSmartTtsAllOn: String = "Enabled smart concise readout for all apps",
    val msgSmartTtsAllOff: String = "Disabled smart concise readout for all apps",
    val msgHideBalanceAllOn: String = "Enabled hide balance for all apps",
    val msgHideBalanceAllOff: String = "Disabled hide balance for all apps",
    val advTtsTitle: String = "Advanced Read-Aloud Filter",
    val advTtsFilterModeLabel: String = "Which notifications to read aloud:",
    val advTtsFilterNumeric: String = "Numeric / Balance alerts only",
    val advTtsFilterNumericDesc: String = "Only speak notifications rich in numbers (transfers, balances, OTP) and skip ads",
    val advTtsFilterAll: String = "Read all notifications",
    val advTtsFilterAllDesc: String = "Speak every notification from this app, including promos and general updates",
    val advTtsSampleSection: String = "Highlight parts to read from a saved sample",
    val advTtsSampleEmptyNotice: String = "This app has no saved notifications yet. Receive at least one real notification first so you can highlight which parts to read aloud.",
    val advTtsSamplePickHint: String = "Choose a saved notification sample:",
    val advTtsSampleTapHint: String = "Tap words below to highlight what NotiTrack should read aloud:",
    val advTtsSampleClearTemplate: String = "Clear highlight",
    val advTtsSamplePreviewLabel: String = "Spoken preview:",
    val advTtsNumberModeLabel: String = "Number reading style:",
    val advTtsNumberAuto: String = "Smart by context",
    val advTtsNumberExact: String = "Exact digits (9999 -> 9 9 9 9)",
    val advTtsNumberNatural: String = "Natural words",
    val advTtsAutoBoostTitle: String = "Auto-boost volume for this app",
    val advTtsAutoBoostDesc: String = "Automatically raise speech volume when this app posts an alert",
    val advTtsCustomBadge: String = "Custom",
    val advTtsGearDesc: String = "Advanced read-aloud filter",
    val msgAdvTtsSaved: String = "Saved advanced read-aloud settings",
    val filtersAppPickerTitle: String = "Select Application Scope",
    val filtersAppPickerSearchHint: String = "Search all installed apps…",
    val inboxThreadsSummary: (threads: Int, total: Int) -> String = { threads, total -> "$threads groups • $total alerts" },
    val inboxConversationsTitle: String = "Grouped Conversations",
    val ttsDelayTitle: (Int) -> String = { ms -> "Pause between announcements: ${String.format("%.1f", ms / 1000f)}s" },
    val ttsDelayDesc: String = "Keeps volume ready and adds a clean pause between back-to-back notifications so nothing is missed",
    val inboxFabMarkAllRead: String = "Mark all read",
    val msgAllAlreadyRead: String = "All notifications are already read"
)

val LocalAppStrings = staticCompositionLocalOf<AppStrings> { vietnameseStrings() }

fun stringsFor(language: AppLanguage): AppStrings = when (language.resolved()) {
    AppLanguage.VIETNAMESE -> vietnameseStrings()
    AppLanguage.ENGLISH -> englishStrings()
    AppLanguage.CHINESE -> chineseStrings()
    AppLanguage.JAPANESE -> japaneseStrings()
    AppLanguage.KOREAN -> koreanStrings()
    AppLanguage.SPANISH -> spanishStrings()
    AppLanguage.FRENCH -> frenchStrings()
    AppLanguage.GERMAN -> germanStrings()
    AppLanguage.SYSTEM -> englishStrings()
}
