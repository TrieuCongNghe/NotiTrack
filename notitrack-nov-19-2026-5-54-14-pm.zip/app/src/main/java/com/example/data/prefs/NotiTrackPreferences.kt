package com.example.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.i18n.AppLanguage
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.MessageDigest

private val Context.notiTrackDataStore: DataStore<Preferences> by preferencesDataStore(name = "notitrack_prefs")

enum class KeepAliveNotifTheme(
    val labelVi: String,
    val startColorHex: Long,
    val endColorHex: Long
) {
    JADE("Ngọc lục bảo", 0xFF0A2E26, 0xFF125948),
    OCEAN("Xanh đại dương", 0xFF0D253F, 0xFF194B78),
    OBSIDIAN("Đen tuyền", 0xFF13171B, 0xFF252E36),
    AMBER("Hổ phách", 0xFF3B2408, 0xFF6D4412),
    CRIMSON("Đỏ rượu vang", 0xFF3E111B, 0xFF6E1E31)
}

data class NotiTrackSettings(
    val biometricEnabled: Boolean = false,
    val pinHash: String = "",
    val autoLockSeconds: Int = 30,
    val flagSecureEnabled: Boolean = false,
    val ttsGlobalEnabled: Boolean = true,
    val ttsSpeechRate: Float = 1.0f,
    val ttsIncludeAppName: Boolean = true,
    val ttsSmartFilterGlobal: Boolean = true,
    val ttsHideBalanceGlobal: Boolean = true,
    val captureNewAppsByDefault: Boolean = true,
    val retentionDays: Int = 30,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val defaultGroupedView: Boolean = true,
    val chatTimelineGroupingEnabled: Boolean = true,
    val appLanguage: AppLanguage = AppLanguage.VIETNAMESE,
    val keepAliveEnabled: Boolean = true,
    val keepAliveShowTemp: Boolean = true,
    val keepAliveShowLunar: Boolean = true,
    val keepAliveShowCount: Boolean = true,
    val keepAliveShowBattery: Boolean = true,
    val keepAliveTheme: KeepAliveNotifTheme = KeepAliveNotifTheme.JADE
) {
    val hasPinConfigured: Boolean get() = pinHash.isNotEmpty()
    val isAppLockActive: Boolean get() = biometricEnabled || hasPinConfigured
}

class NotiTrackPreferences(private val context: Context) {

    private object Keys {
        val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val AUTO_LOCK_SECONDS = intPreferencesKey("auto_lock_seconds")
        val FLAG_SECURE_ENABLED = booleanPreferencesKey("flag_secure_enabled")
        val TTS_GLOBAL_ENABLED = booleanPreferencesKey("tts_global_enabled")
        val TTS_SPEECH_RATE = floatPreferencesKey("tts_speech_rate")
        val TTS_INCLUDE_APP_NAME = booleanPreferencesKey("tts_include_app_name")
        val TTS_SMART_FILTER_GLOBAL = booleanPreferencesKey("tts_smart_filter_global")
        val TTS_HIDE_BALANCE_GLOBAL = booleanPreferencesKey("tts_hide_balance_global")
        val CAPTURE_NEW_APPS = booleanPreferencesKey("capture_new_apps")
        val RETENTION_DAYS = intPreferencesKey("retention_days")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DEFAULT_GROUPED_VIEW = booleanPreferencesKey("default_grouped_view")
        val CHAT_TIMELINE_GROUPING = booleanPreferencesKey("chat_timeline_grouping")
        val APP_LANGUAGE = stringPreferencesKey("app_language")
        val KEEP_ALIVE_ENABLED = booleanPreferencesKey("keep_alive_enabled")
        val KEEP_ALIVE_SHOW_TEMP = booleanPreferencesKey("keep_alive_show_temp")
        val KEEP_ALIVE_SHOW_LUNAR = booleanPreferencesKey("keep_alive_show_lunar")
        val KEEP_ALIVE_SHOW_COUNT = booleanPreferencesKey("keep_alive_show_count")
        val KEEP_ALIVE_SHOW_BATTERY = booleanPreferencesKey("keep_alive_show_battery")
        val KEEP_ALIVE_THEME = stringPreferencesKey("keep_alive_theme")
    }

    val settingsFlow: Flow<NotiTrackSettings> = context.notiTrackDataStore.data.map { prefs ->
        NotiTrackSettings(
            biometricEnabled = prefs[Keys.BIOMETRIC_ENABLED] ?: false,
            pinHash = prefs[Keys.PIN_HASH] ?: "",
            autoLockSeconds = prefs[Keys.AUTO_LOCK_SECONDS] ?: 30,
            flagSecureEnabled = prefs[Keys.FLAG_SECURE_ENABLED] ?: false,
            ttsGlobalEnabled = prefs[Keys.TTS_GLOBAL_ENABLED] ?: true,
            ttsSpeechRate = prefs[Keys.TTS_SPEECH_RATE] ?: 1.0f,
            ttsIncludeAppName = prefs[Keys.TTS_INCLUDE_APP_NAME] ?: true,
            ttsSmartFilterGlobal = prefs[Keys.TTS_SMART_FILTER_GLOBAL] ?: true,
            ttsHideBalanceGlobal = prefs[Keys.TTS_HIDE_BALANCE_GLOBAL] ?: true,
            captureNewAppsByDefault = prefs[Keys.CAPTURE_NEW_APPS] ?: true,
            retentionDays = prefs[Keys.RETENTION_DAYS] ?: 30,
            themeMode = runCatching {
                ThemeMode.valueOf(prefs[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.name)
            }.getOrDefault(ThemeMode.SYSTEM),
            defaultGroupedView = prefs[Keys.DEFAULT_GROUPED_VIEW] ?: true,
            chatTimelineGroupingEnabled = prefs[Keys.CHAT_TIMELINE_GROUPING] ?: true,
            appLanguage = AppLanguage.fromCode(prefs[Keys.APP_LANGUAGE]),
            keepAliveEnabled = prefs[Keys.KEEP_ALIVE_ENABLED] ?: true,
            keepAliveShowTemp = prefs[Keys.KEEP_ALIVE_SHOW_TEMP] ?: true,
            keepAliveShowLunar = prefs[Keys.KEEP_ALIVE_SHOW_LUNAR] ?: true,
            keepAliveShowCount = prefs[Keys.KEEP_ALIVE_SHOW_COUNT] ?: true,
            keepAliveShowBattery = prefs[Keys.KEEP_ALIVE_SHOW_BATTERY] ?: true,
            keepAliveTheme = runCatching {
                KeepAliveNotifTheme.valueOf(prefs[Keys.KEEP_ALIVE_THEME] ?: KeepAliveNotifTheme.JADE.name)
            }.getOrDefault(KeepAliveNotifTheme.JADE)
        )
    }

    suspend fun getSettingsSnapshot(): NotiTrackSettings = settingsFlow.first()

    suspend fun setBiometricEnabled(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.BIOMETRIC_ENABLED] = enabled }
    }

    suspend fun setPin(rawPin: String) {
        val hashed = if (rawPin.isBlank()) "" else hashPin(rawPin)
        context.notiTrackDataStore.edit { it[Keys.PIN_HASH] = hashed }
    }

    suspend fun verifyPin(rawPin: String): Boolean {
        val currentHash = getSettingsSnapshot().pinHash
        return currentHash.isNotEmpty() && currentHash == hashPin(rawPin)
    }

    suspend fun setAutoLockSeconds(seconds: Int) {
        context.notiTrackDataStore.edit { it[Keys.AUTO_LOCK_SECONDS] = seconds }
    }

    suspend fun setFlagSecureEnabled(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.FLAG_SECURE_ENABLED] = enabled }
    }

    suspend fun setTtsGlobalEnabled(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.TTS_GLOBAL_ENABLED] = enabled }
    }

    suspend fun setTtsSpeechRate(rate: Float) {
        context.notiTrackDataStore.edit { it[Keys.TTS_SPEECH_RATE] = rate.coerceIn(0.6f, 1.8f) }
    }

    suspend fun setTtsIncludeAppName(include: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.TTS_INCLUDE_APP_NAME] = include }
    }

    suspend fun setTtsSmartFilterGlobal(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.TTS_SMART_FILTER_GLOBAL] = enabled }
    }

    suspend fun setTtsHideBalanceGlobal(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.TTS_HIDE_BALANCE_GLOBAL] = enabled }
    }

    suspend fun setCaptureNewAppsByDefault(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.CAPTURE_NEW_APPS] = enabled }
    }

    suspend fun setRetentionDays(days: Int) {
        context.notiTrackDataStore.edit { it[Keys.RETENTION_DAYS] = days }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.notiTrackDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setDefaultGroupedView(grouped: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.DEFAULT_GROUPED_VIEW] = grouped }
    }

    suspend fun setChatTimelineGroupingEnabled(enabled: Boolean) {
        context.notiTrackDataStore.edit {
            it[Keys.CHAT_TIMELINE_GROUPING] = enabled
            it[Keys.DEFAULT_GROUPED_VIEW] = enabled
        }
    }

    suspend fun setAppLanguage(language: AppLanguage) {
        context.notiTrackDataStore.edit { it[Keys.APP_LANGUAGE] = language.code }
    }

    suspend fun setKeepAliveEnabled(enabled: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.KEEP_ALIVE_ENABLED] = enabled }
    }

    suspend fun setKeepAliveShowTemp(show: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.KEEP_ALIVE_SHOW_TEMP] = show }
    }

    suspend fun setKeepAliveShowLunar(show: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.KEEP_ALIVE_SHOW_LUNAR] = show }
    }

    suspend fun setKeepAliveShowCount(show: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.KEEP_ALIVE_SHOW_COUNT] = show }
    }

    suspend fun setKeepAliveShowBattery(show: Boolean) {
        context.notiTrackDataStore.edit { it[Keys.KEEP_ALIVE_SHOW_BATTERY] = show }
    }

    suspend fun setKeepAliveTheme(theme: KeepAliveNotifTheme) {
        context.notiTrackDataStore.edit { it[Keys.KEEP_ALIVE_THEME] = theme.name }
    }

    companion object {
        fun hashPin(pin: String): String {
            val digest = MessageDigest.getInstance("SHA-256")
            val bytes = digest.digest("notitrack_salt_v1:$pin".toByteArray(Charsets.UTF_8))
            return bytes.joinToString("") { "%02x".format(it) }
        }
    }
}
