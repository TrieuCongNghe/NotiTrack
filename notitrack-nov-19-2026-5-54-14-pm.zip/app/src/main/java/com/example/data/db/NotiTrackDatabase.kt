package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.AppRuleEntity
import com.example.data.model.KeywordAction
import com.example.data.model.KeywordRuleEntity
import com.example.data.model.NotificationEntity

class NotiTrackTypeConverters {
    @TypeConverter
    fun fromKeywordAction(action: KeywordAction): String = action.name

    @TypeConverter
    fun toKeywordAction(value: String): KeywordAction =
        runCatching { KeywordAction.valueOf(value) }.getOrDefault(KeywordAction.HIGHLIGHT)
}

@Database(
    entities = [
        NotificationEntity::class,
        AppRuleEntity::class,
        KeywordRuleEntity::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(NotiTrackTypeConverters::class)
abstract class NotiTrackDatabase : RoomDatabase() {
    abstract fun notificationDao(): NotificationDao
    abstract fun appRuleDao(): AppRuleDao
    abstract fun keywordRuleDao(): KeywordRuleDao

    companion object {
        @Volatile
        private var INSTANCE: NotiTrackDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE app_rules ADD COLUMN smartTtsEnabled INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE app_rules ADD COLUMN ttsHideBalance INTEGER NOT NULL DEFAULT 1")
            }
        }

        fun getInstance(context: Context): NotiTrackDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NotiTrackDatabase::class.java,
                    "notitrack_local.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration(dropAllTables = false)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
