package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_rules")
data class AppRuleEntity(
    @PrimaryKey val packageName: String,
    val appName: String,
    val captureEnabled: Boolean = true,
    val readAloudEnabled: Boolean = false,
    val autoDismissEnabled: Boolean = false,
    val smartTtsEnabled: Boolean = true,
    val ttsHideBalance: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis()
)
