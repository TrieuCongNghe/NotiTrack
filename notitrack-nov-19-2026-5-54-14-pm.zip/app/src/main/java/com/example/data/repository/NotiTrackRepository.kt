package com.example.data.repository

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import com.example.data.db.AppRuleDao
import com.example.data.db.KeywordRuleDao
import com.example.data.db.NotificationDao
import com.example.data.model.AppRuleEntity
import com.example.data.model.KeywordAction
import com.example.data.model.KeywordRuleEntity
import com.example.data.model.NotificationEntity
import com.example.data.prefs.NotiTrackPreferences
import com.example.data.prefs.NotiTrackSettings
import com.example.engine.KeywordFilterEngine
import com.example.service.NotiTrackListenerService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class InstalledAppInfo(
    val packageName: String,
    val appName: String
)

data class CaptureOutcome(
    val savedId: Long? = null,
    val blocked: Boolean = false,
    val shouldSpeak: Boolean = false,
    val useSmartTts: Boolean = true,
    val hideBalanceInTts: Boolean = true,
    val shouldAutoDismiss: Boolean = false
)

class NotiTrackRepository(
    private val context: Context,
    private val notificationDao: NotificationDao,
    private val appRuleDao: AppRuleDao,
    private val keywordRuleDao: KeywordRuleDao,
    val preferences: NotiTrackPreferences
) {

    val allNotifications: Flow<List<NotificationEntity>> = notificationDao.observeAllNotifications()
    val totalNotificationCount: Flow<Int> = notificationDao.observeTotalCount()
    val allAppRules: Flow<List<AppRuleEntity>> = appRuleDao.observeAllRules()
    val allKeywordRules: Flow<List<KeywordRuleEntity>> = keywordRuleDao.observeAllRules()
    val settingsFlow: Flow<NotiTrackSettings> = preferences.settingsFlow

    fun isNotificationListenerEnabled(): Boolean {
        val enabledListeners = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        val expected = ComponentName(context, NotiTrackListenerService::class.java).flattenToString()
        val shortExpected = ComponentName(context, NotiTrackListenerService::class.java).flattenToShortString()
        return enabledListeners.split(":").any {
            it.equals(expected, ignoreCase = true) || it.equals(shortExpected, ignoreCase = true)
        }
    }

    suspend fun getInstalledLauncherApps(): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val activities = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        activities
            .mapNotNull { resolveInfo ->
                val pkg = resolveInfo.activityInfo?.packageName ?: return@mapNotNull null
                val label = resolveInfo.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() } ?: pkg
                InstalledAppInfo(packageName = pkg, appName = label)
            }
            .distinctBy { it.packageName }
            .sortedBy { it.appName.lowercase(Locale.getDefault()) }
    }

    suspend fun syncInstalledAppRules() = withContext(Dispatchers.IO) {
        val settings = preferences.getSettingsSnapshot()
        val installed = getInstalledLauncherApps()
        val existingMap = appRuleDao.getAllSnapshot().associateBy { it.packageName }
        val newRules = installed.mapNotNull { app ->
            if (existingMap.containsKey(app.packageName)) null
            else AppRuleEntity(
                packageName = app.packageName,
                appName = app.appName,
                captureEnabled = settings.captureNewAppsByDefault,
                readAloudEnabled = false,
                autoDismissEnabled = false,
                smartTtsEnabled = settings.ttsSmartFilterGlobal,
                ttsHideBalance = settings.ttsHideBalanceGlobal
            )
        }
        if (newRules.isNotEmpty()) {
            appRuleDao.upsertAll(newRules)
        }
    }

    suspend fun getAppRule(packageName: String): AppRuleEntity? = appRuleDao.getRuleForPackage(packageName)

    suspend fun processIncomingNotification(
        packageName: String,
        appName: String,
        title: String,
        content: String,
        subText: String,
        conversationTitle: String,
        notificationKey: String,
        category: String,
        timestamp: Long
    ): CaptureOutcome = withContext(Dispatchers.IO) {
        val settings = preferences.getSettingsSnapshot()
        var appRule = appRuleDao.getRuleForPackage(packageName)
        if (appRule == null) {
            appRule = AppRuleEntity(
                packageName = packageName,
                appName = appName,
                captureEnabled = settings.captureNewAppsByDefault,
                readAloudEnabled = false,
                autoDismissEnabled = false,
                smartTtsEnabled = settings.ttsSmartFilterGlobal,
                ttsHideBalance = settings.ttsHideBalanceGlobal
            )
            appRuleDao.upsert(appRule)
        }

        if (!appRule.captureEnabled) {
            return@withContext CaptureOutcome(savedId = null, blocked = false)
        }

        val dupCount = notificationDao.countRecentDuplicates(
            packageName = packageName,
            title = title,
            content = content,
            sinceTimestamp = timestamp - 8_000L
        )
        if (dupCount > 0) {
            return@withContext CaptureOutcome(savedId = null, blocked = false)
        }

        val activeRules = keywordRuleDao.getEnabledRulesSnapshot()
        val eval = KeywordFilterEngine.evaluate(
            packageName = packageName,
            title = title,
            content = content,
            subText = subText,
            rules = activeRules
        )

        if (eval.matchedRuleIds.isNotEmpty()) {
            keywordRuleDao.incrementMatchCounts(eval.matchedRuleIds)
        }

        if (eval.shouldBlock) {
            return@withContext CaptureOutcome(
                savedId = null,
                blocked = true,
                shouldAutoDismiss = appRule.autoDismissEnabled
            )
        }

        val detectedOtp = KeywordFilterEngine.extractOtpCode(title, content)
        val shouldSpeak = settings.ttsGlobalEnabled && appRule.readAloudEnabled && !eval.shouldMuteTts

        val entity = NotificationEntity(
            packageName = packageName,
            appName = appName,
            title = title,
            content = content,
            subText = subText,
            conversationTitle = conversationTitle,
            timestamp = timestamp,
            notificationKey = notificationKey,
            category = category,
            isRead = false,
            isStarred = eval.shouldHighlight,
            isHighlighted = eval.shouldHighlight,
            isHidden = eval.shouldHide,
            matchedKeywords = eval.matchedKeywords.joinToString(", "),
            wasSpoken = shouldSpeak,
            detectedOtp = detectedOtp
        )

        val insertedId = notificationDao.insert(entity)

        if (settings.retentionDays > 0) {
            val cutoff = System.currentTimeMillis() - settings.retentionDays * 24L * 60L * 60L * 1000L
            notificationDao.deleteOlderThan(cutoff)
        }

        CaptureOutcome(
            savedId = insertedId,
            blocked = false,
            shouldSpeak = shouldSpeak,
            useSmartTts = settings.ttsSmartFilterGlobal && appRule.smartTtsEnabled,
            hideBalanceInTts = settings.ttsHideBalanceGlobal || appRule.ttsHideBalance,
            shouldAutoDismiss = appRule.autoDismissEnabled
        )
    }

    suspend fun upsertAppRule(rule: AppRuleEntity) = appRuleDao.upsert(rule.copy(updatedAt = System.currentTimeMillis()))

    suspend fun setCaptureForAllApps(enabled: Boolean) = appRuleDao.setCaptureForAll(enabled)

    suspend fun addKeywordRule(
        keywords: String,
        action: KeywordAction,
        targetPackage: String?,
        targetAppName: String?,
        isCaseSensitive: Boolean,
        isRegex: Boolean
    ) {
        keywordRuleDao.insert(
            KeywordRuleEntity(
                keywords = keywords.trim(),
                action = action,
                targetPackage = targetPackage,
                targetAppName = targetAppName,
                isCaseSensitive = isCaseSensitive,
                isRegex = isRegex,
                isEnabled = true
            )
        )
    }

    suspend fun updateKeywordRule(rule: KeywordRuleEntity) = keywordRuleDao.update(rule)

    suspend fun toggleKeywordRule(id: Long, enabled: Boolean) = keywordRuleDao.setEnabled(id, enabled)

    suspend fun deleteKeywordRule(id: Long) = keywordRuleDao.deleteById(id)

    suspend fun markRead(id: Long) = notificationDao.markRead(id)

    suspend fun markIdsRead(ids: List<Long>) {
        if (ids.isNotEmpty()) notificationDao.markIdsRead(ids)
    }

    suspend fun markPackageRead(packageName: String) = notificationDao.markPackageRead(packageName)

    suspend fun markAllRead() = notificationDao.markAllRead()

    suspend fun toggleStar(id: Long, starred: Boolean) = notificationDao.setStarred(id, starred)

    suspend fun toggleHidden(id: Long, hidden: Boolean) = notificationDao.setHidden(id, hidden)

    suspend fun deleteNotification(id: Long) = notificationDao.deleteById(id)

    suspend fun deleteNotificationsByIds(ids: List<Long>) {
        if (ids.isNotEmpty()) notificationDao.deleteByIds(ids)
    }

    suspend fun deleteReadNotifications() = notificationDao.deleteReadNotifications()

    suspend fun deletePackageNotifications(packageName: String) = notificationDao.deleteByPackage(packageName)

    suspend fun clearAllNotifications() = notificationDao.deleteAll()

    suspend fun applyRetentionCleanup(retentionDays: Int) {
        if (retentionDays <= 0) return
        val cutoff = System.currentTimeMillis() - retentionDays * 24L * 60L * 60L * 1000L
        notificationDao.deleteOlderThan(cutoff)
    }

    suspend fun buildExportText(): String = withContext(Dispatchers.IO) {
        val list = notificationDao.getAllSnapshot()
        val lang = preferences.getSettingsSnapshot().appLanguage
        val strings = com.example.ui.i18n.stringsFor(lang)
        if (list.isEmpty()) return@withContext strings.exportEmpty
        val df = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", lang.toLocale())
        buildString {
            appendLine(strings.exportHeader(list.size))
            appendLine("${strings.exportTimeLabel}: ${df.format(Date())}")
            appendLine()
            for (item in list) {
                appendLine("[${df.format(Date(item.timestamp))}] ${item.appName} (${item.packageName})")
                if (item.title.isNotBlank()) appendLine(item.title)
                if (item.content.isNotBlank()) appendLine(item.content)
                if (item.matchedKeywords.isNotBlank()) appendLine(strings.inboxMatchedKeywords(item.matchedKeywords))
                if (!item.detectedOtp.isNullOrBlank()) appendLine("OTP: ${item.detectedOtp}")
                appendLine("----------------------------------------")
            }
        }
    }
}
