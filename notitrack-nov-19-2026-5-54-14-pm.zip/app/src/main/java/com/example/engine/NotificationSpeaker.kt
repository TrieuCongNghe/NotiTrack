package com.example.engine

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.stringsFor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class NotificationSpeaker(context: Context) {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var isReady: Boolean = false
    private var pendingSpeech: PendingUtterance? = null

    private data class PendingUtterance(
        val text: String,
        val rate: Float,
        val notificationId: Long?,
        val language: AppLanguage
    )

    private val _speakingNotificationId = MutableStateFlow<Long?>(null)
    val speakingNotificationId: StateFlow<Long?> = _speakingNotificationId.asStateFlow()

    init {
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                applyLocale(AppLanguage.VIETNAMESE)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) {
                        _speakingNotificationId.value = null
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _speakingNotificationId.value = null
                    }
                    override fun onError(utteranceId: String?, errorCode: Int) {
                        _speakingNotificationId.value = null
                    }
                })
                isReady = true
                pendingSpeech?.let { pending ->
                    pendingSpeech = null
                    speakInternal(
                        text = pending.text,
                        rate = pending.rate,
                        notificationId = pending.notificationId,
                        language = pending.language,
                        flush = true
                    )
                }
            }
        }
    }

    private fun applyLocale(language: AppLanguage) {
        val targetLocale = language.toLocale()
        val availability = tts?.isLanguageAvailable(targetLocale) ?: TextToSpeech.LANG_NOT_SUPPORTED
        if (availability >= TextToSpeech.LANG_AVAILABLE) {
            tts?.language = targetLocale
        } else {
            tts?.language = Locale.getDefault()
        }
    }

    fun speakNotification(
        notificationId: Long?,
        appName: String,
        title: String,
        content: String,
        includeAppName: Boolean,
        speechRate: Float,
        language: AppLanguage = AppLanguage.VIETNAMESE,
        smartFilterEnabled: Boolean = true,
        hideBalance: Boolean = true,
        flush: Boolean = false
    ) {
        val text = SmartTtsFormatter.formatForSpeech(
            appName = appName,
            title = title,
            content = content,
            includeAppName = includeAppName,
            smartFilterEnabled = smartFilterEnabled,
            hideBalance = hideBalance,
            language = language
        )
        if (text.isBlank()) return

        if (!isReady) {
            pendingSpeech = PendingUtterance(text, speechRate, notificationId, language)
            return
        }
        speakInternal(text, speechRate, notificationId, language, flush)
    }

    fun speakSample(
        speechRate: Float,
        language: AppLanguage = AppLanguage.VIETNAMESE,
        smartFilterEnabled: Boolean = true,
        hideBalance: Boolean = true,
        includeAppName: Boolean = true
    ) {
        val sampleRawTitle = if (language.resolved() == AppLanguage.VIETNAMESE) {
            "Biến động số dư"
        } else {
            "Balance Alert"
        }
        val sampleRawContent = if (language.resolved() == AppLanguage.VIETNAMESE) {
            "TK 003456xxxx GD: +50,000 VND luc 14:25 19/11/2026. SD: 15,420,000 VND. ND: Chuyen tien cafe FT263239182736"
        } else {
            "Acct **3456 Credited +$50.00 at 14:25. Balance: $1,540.00. Ref: FT263239182736 Coffee transfer"
        }
        val text = if (smartFilterEnabled || hideBalance) {
            SmartTtsFormatter.formatForSpeech(
                appName = "MB Bank",
                title = sampleRawTitle,
                content = sampleRawContent,
                includeAppName = includeAppName,
                smartFilterEnabled = smartFilterEnabled,
                hideBalance = hideBalance,
                language = language
            )
        } else {
            stringsFor(language).ttsSampleSentence
        }
        if (!isReady) {
            pendingSpeech = PendingUtterance(text, speechRate, -1L, language)
            return
        }
        speakInternal(text, speechRate, -1L, language, flush = true)
    }

    private fun speakInternal(
        text: String,
        rate: Float,
        notificationId: Long?,
        language: AppLanguage,
        flush: Boolean
    ) {
        applyLocale(language)
        tts?.setSpeechRate(rate.coerceIn(0.6f, 1.8f))
        val queueMode = if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        val utteranceId = "notitrack_${notificationId ?: UUID.randomUUID()}"
        _speakingNotificationId.value = notificationId
        tts?.speak(text, queueMode, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
        _speakingNotificationId.value = null
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isReady = false
        _speakingNotificationId.value = null
    }
}
