package com.example.engine

import com.example.ui.i18n.AppLanguage
import com.example.ui.i18n.stringsFor

/**
 * Formats notification text into clean, natural spoken speech:
 * - Summarizes bank / payment alerts (e.g., "Đã nhận 50.000 đồng")
 * - Strips unreadable transaction IDs, tracking codes, account numbers, URLs & timestamps
 * - Optionally hides account balance clauses ("SD: ...", "Số dư: ...", "Balance: ...")
 */
object SmartTtsFormatter {

    // Match signed or contextual currency amounts: +50,000 VND, -120.000đ, +$250.00, 50.000 vnđ
    private val SIGNED_AMOUNT_REGEX = Regex(
        """(?i)([+\-])\s*(\d{1,3}(?:[.,]\d{3})+|\d+(?:[.,]\d{1,2})?)\s*(vnđ|vnd|đ|d|usd|\$|€|eur|¥|jpy|원|krw)?\b"""
    )
    private val CONTEXT_AMOUNT_REGEX = Regex(
        """(?i)(nhận(?:\s+được)?|được\s+cộng|chuyển\s+đến|biến\s+động|cộng|trừ|thanh\s+toán|rút|chuyển\s+(?:đi|khoản)|received|credited|deposited|spent|paid|debited|withdrew)\s*[:\-]?\s*([+\-])?\s*(\d{1,3}(?:[.,]\d{3})+|\d+(?:[.,]\d{1,2})?)\s*(vnđ|vnd|đ|usd|\$|€|eur|¥|jpy)?"""
    )

    // Balance clauses to strip when hideBalance = true
    private val BALANCE_CLAUSE_REGEX = Regex(
        """(?i)\b(?:số\s*dư(?:\s*hiện\s*tại|\s*khả\s*dụng|\s*cuối)?|so\s*du(?:\s*hien\s*tai|\s*kha\s*dung)?|sd|s\.d|balance|avail(?:able)?\s*bal(?:ance)?|bal)\s*[:=\-]?\s*[+\-]?\s*(?:\$|€|¥)?\d[\d.,]*\s*(?:vnđ|vnd|đ|d|usd|\$|€|eur|¥|krw)?(?=\s|[.,;)\n]|$)"""
    )

    // Account number patterns (TK 003456xxxx, STK 1903..., Acct **4321)
    private val ACCOUNT_NO_REGEX = Regex(
        """(?i)\b(?:stk|tk|số\s*tk|so\s*tk|tài\s*khoản|tai\s*khoan|acct|account)\s*[:#\-]?\s*[a-z0-9*xX\-]{4,}\b"""
    )

    // Transaction / reference / tracking IDs (FT26323..., MBVCB..., Ma GD: ..., Ref: ..., SPXVN...)
    private val LABELED_CODE_REGEX = Regex(
        """(?i)\b(?:mã\s*gd|ma\s*gd|mã\s*giao\s*dịch|ma\s*giao\s*dich|mã\s*đơn|ma\s*don|ref(?:\s*no)?|trace|ft|ibft|trans(?:action)?\s*(?:id|code|no)?|order\s*(?:id|no|#)?|code|id)\s*[:#=\-]?\s*[a-z0-9\-_]{5,}\b"""
    )

    // Long alphanumeric mixed codes (e.g. FT26323849102, MBVCB8839201, SPXVN0482918273, #261119ABC992)
    private val MIXED_ALPHANUM_CODE_REGEX = Regex(
        """(?i)(?:#|\b)(?=[a-z0-9\-_]{6,}\b)(?=[a-z\-_]*\d)(?=\d*[a-z])[a-z0-9\-_]{6,}\b"""
    )

    // Long pure digit sequences (7+ consecutive digits like 003456789123, phone/ref/trace numbers)
    private val LONG_DIGIT_ID_REGEX = Regex("""\b\d{7,}\b""")

    // Date & time fragments ("luc 14:25:03 19/11/2026", "14:25 19-11-26")
    private val DATETIME_NOISE_REGEX = Regex(
        """(?i)\b(?:lúc|luc|vào\s*lúc|vao\s*luc|ngày|ngay|at|on)?\s*\d{1,2}:\d{2}(?::\d{2})?(?:\s+\d{1,2}[/\-]\d{1,2}(?:[/\-]\d{2,4})?)?\b|\b\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}\b"""
    )

    // URLs
    private val URL_REGEX = Regex("""https?://\S+|www\.\S+""", RegexOption.IGNORE_CASE)

    // Memo extraction ("ND: ...", "Nội dung: ...", "Memo: ...")
    private val MEMO_REGEX = Regex(
        """(?i)\b(?:nd|nội\s*dung|noi\s*dung|memo|diễn\s*giải|dien\s*giai|lời\s*nhắn|loi\s*nhan)\s*[:\-]\s*([^.;\n]{2,100})"""
    )

    fun formatForSpeech(
        appName: String,
        title: String,
        content: String,
        includeAppName: Boolean,
        smartFilterEnabled: Boolean,
        hideBalance: Boolean,
        language: AppLanguage = AppLanguage.VIETNAMESE
    ): String {
        val resolvedLang = language.resolved()
        val strings = stringsFor(resolvedLang)

        val workingTitle = if (hideBalance) stripBalance(title) else title
        val workingContent = if (hideBalance) stripBalance(content) else content

        if (!smartFilterEnabled) {
            return buildStandardSpeech(
                appName = appName,
                title = workingTitle,
                content = workingContent,
                includeAppName = includeAppName,
                prefixProvider = strings.ttsSpokenPrefix
            )
        }

        // 1. Try smart banking / money transaction summary first
        val combined = "$workingTitle. $workingContent"
        val bankSummary = tryFormatTransactionSummary(
            appName = appName,
            combinedText = combined,
            includeAppName = includeAppName,
            hideBalance = hideBalance,
            language = resolvedLang
        )
        if (bankSummary != null) {
            return bankSummary
        }

        // 2. General concise cleaning: strip URLs, transaction/order codes, account IDs, timestamps
        val cleanTitle = cleanNoisyTokens(workingTitle)
        val cleanContent = cleanNoisyTokens(workingContent)

        return buildStandardSpeech(
            appName = appName,
            title = cleanTitle,
            content = cleanContent,
            includeAppName = includeAppName,
            prefixProvider = strings.ttsSpokenPrefix
        )
    }

    private fun buildStandardSpeech(
        appName: String,
        title: String,
        content: String,
        includeAppName: Boolean,
        prefixProvider: (String) -> String
    ): String {
        val parts = buildList {
            if (includeAppName && appName.isNotBlank()) add(prefixProvider(appName))
            if (title.isNotBlank()) add(title.trim().trimEnd('.') + ".")
            if (content.isNotBlank() && !content.trim().equals(title.trim(), ignoreCase = true)) {
                add(content.trim().take(240))
            }
        }
        return parts.joinToString(" ").replace(Regex("\\s+"), " ").trim()
    }

    private fun stripBalance(text: String): String {
        return BALANCE_CLAUSE_REGEX.replace(text, " ")
            .replace(Regex("""\s{2,}"""), " ")
            .trim()
    }

    private fun extractBalanceAmount(text: String): Pair<String, String>? {
        val match = Regex(
            """(?i)\b(?:số\s*dư(?:\s*hiện\s*tại|\s*khả\s*dụng|\s*cuối)?|so\s*du(?:\s*hien\s*tai|\s*kha\s*dung)?|sd|s\.d|balance|avail(?:able)?\s*bal(?:ance)?|bal)\s*[:=\-]?\s*([+\-]?\d{1,3}(?:[.,]\d{3})+|\d+(?:[.,]\d{1,2})?)\s*(vnđ|vnd|đ|d|usd|\$|€|eur|¥|krw)?"""
        ).find(text) ?: return null
        val amount = match.groupValues[1].trimStart('+')
        val currency = match.groupValues[2]
        return amount to currency
    }

    private fun tryFormatTransactionSummary(
        appName: String,
        combinedText: String,
        includeAppName: Boolean,
        hideBalance: Boolean,
        language: AppLanguage
    ): String? {
        // Remove balance first so we never mistake balance for transaction amount
        val balancePair = if (!hideBalance) extractBalanceAmount(combinedText) else null
        val withoutBalance = stripBalance(combinedText)

        var isIncoming: Boolean? = null
        var rawAmount: String? = null
        var rawCurrency: String? = null

        val signedMatch = SIGNED_AMOUNT_REGEX.find(withoutBalance)
        if (signedMatch != null) {
            val sign = signedMatch.groupValues[1]
            val amt = signedMatch.groupValues[2]
            val cur = signedMatch.groupValues[3]
            val hasCurrencyOrBankCue = cur.isNotBlank() || looksLikeMoneyContext(withoutBalance)
            if (hasCurrencyOrBankCue && amt.replace(Regex("[.,]"), "").length <= 12) {
                isIncoming = (sign == "+")
                rawAmount = amt
                rawCurrency = cur
            }
        }

        if (rawAmount == null) {
            val ctxMatch = CONTEXT_AMOUNT_REGEX.find(withoutBalance)
            if (ctxMatch != null) {
                val verb = ctxMatch.groupValues[1].lowercase()
                val sign = ctxMatch.groupValues[2]
                val amt = ctxMatch.groupValues[3]
                val cur = ctxMatch.groupValues[4]
                if (cur.isNotBlank() || looksLikeMoneyContext(withoutBalance)) {
                    isIncoming = when {
                        sign == "+" -> true
                        sign == "-" -> false
                        verb.contains("nhận") || verb.contains("cộng") || verb.contains("đến") ||
                            verb.contains("received") || verb.contains("credited") || verb.contains("deposited") -> true
                        else -> false
                    }
                    rawAmount = amt
                    rawCurrency = cur
                }
            }
        }

        if (rawAmount == null || isIncoming == null) return null

        val spokenAmount = formatSpokenAmount(rawAmount, rawCurrency, language)
        val actionPhrase = if (language == AppLanguage.VIETNAMESE) {
            if (isIncoming) "Đã nhận $spokenAmount" else "Đã trừ $spokenAmount"
        } else {
            if (isIncoming) "Received $spokenAmount" else "Spent $spokenAmount"
        }

        val memo = extractCleanMemo(withoutBalance)
        val parts = buildList {
            if (includeAppName && appName.isNotBlank()) {
                add("$appName:")
            }
            add("$actionPhrase.")
            if (balancePair != null) {
                val spokenBal = formatSpokenAmount(balancePair.first, balancePair.second, language)
                val balPhrase = if (language == AppLanguage.VIETNAMESE) {
                    "Số dư $spokenBal."
                } else {
                    "Balance $spokenBal."
                }
                add(balPhrase)
            }
            if (!memo.isNullOrBlank()) {
                val memoPrefix = if (language == AppLanguage.VIETNAMESE) "Nội dung:" else "Note:"
                add("$memoPrefix $memo.")
            }
        }
        return parts.joinToString(" ").replace(Regex("\\s+"), " ").trim()
    }

    private fun looksLikeMoneyContext(text: String): Boolean {
        val lower = text.lowercase()
        val cues = listOf(
            "vnd", "vnđ", "đồng", "chuyển khoản", "số dư", "biến động", "tài khoản",
            "gd:", "thanh toán", "nhận tiền", "giao dịch", "bank", "momo", "zalopay",
            "vnpay", "transfer", "balance", "payment", "credited", "debited", "usd", "$"
        )
        return cues.any { lower.contains(it) }
    }

    private fun formatSpokenAmount(amount: String, currency: String?, language: AppLanguage): String {
        val cur = currency?.trim()?.lowercase().orEmpty()
        val normalizedVnd = amount.replace(",", ".")
        return when {
            cur in listOf("vnd", "vnđ", "đ", "d", "") && language == AppLanguage.VIETNAMESE -> "$normalizedVnd đồng"
            cur in listOf("usd", "$") -> if (language == AppLanguage.VIETNAMESE) "$amount đô la" else "$amount dollars"
            cur in listOf("eur", "€") -> "$amount euro"
            cur in listOf("jpy", "¥") -> if (language == AppLanguage.VIETNAMESE) "$amount yên" else "$amount yen"
            cur in listOf("krw", "원") -> if (language == AppLanguage.VIETNAMESE) "$amount won" else "$amount won"
            cur.isNotBlank() -> "$amount $cur"
            else -> "$amount VND"
        }
    }

    private fun extractCleanMemo(text: String): String? {
        val rawMemo = MEMO_REGEX.find(text)?.groupValues?.getOrNull(1) ?: return null
        val cleaned = cleanNoisyTokens(rawMemo)
            .trim(' ', '.', ',', '-', ':', ';')
        if (cleaned.length < 3) return null
        return cleaned.take(65)
    }

    fun cleanNoisyTokens(raw: String): String {
        if (raw.isBlank()) return ""
        return raw
            .replace(URL_REGEX, " ")
            .replace(ACCOUNT_NO_REGEX, " ")
            .replace(LABELED_CODE_REGEX, " ")
            .replace(MIXED_ALPHANUM_CODE_REGEX, " ")
            .replace(DATETIME_NOISE_REGEX, " ")
            .replace(LONG_DIGIT_ID_REGEX, " ")
            .replace(Regex("""[|•·_*#~`]+"""), " ")
            .replace(Regex("""\s*[,;:\-]+\s*([.,;:\-]+\s*)+"""), ", ")
            .replace(Regex("""\s{2,}"""), " ")
            .trim(' ', ',', ';', '-', ':', '.')
    }
}
